// Last Update:2015-11-20 13:48:39
/**
 * @file ice_server_text.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-17
 */

#include "ice_server_text.h"

__thread string* ice_server_text::port = NULL;
__thread int ice_server_text::plugin_id = 10003;


