// Last Update:2016-04-11 16:39:15
/**
 * @file ice_server.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-19
 */

#ifndef ICE_SERVER_H
#define ICE_SERVER_H

#include <Ice/Ice.h>
#include "ice_comm.h"
#include <CASqueue.h>
#include <CEnteranceBase.h>

using namespace std;

class recv_interface : public Comm::Recv
{
    public:
        recv_interface(thread_pool *pQueue, void *p)
        {
            pSortQueue = pQueue;
            p_this = p;
            pNode = NULL;
        };
        ~recv_interface(){};
        virtual Ice::Long RecvMsg(const std::string&, const Ice::Current&);
    private:
        NodeData *pNode;
        thread_pool *pSortQueue;
        void *p_this;
};


class ice_server
{
    public:
        ice_server();
        ~ice_server();
        void run(string adapter_name, string port, string interface_identity, thread_pool *pQueue, void *p);
    private:
        Ice::ObjectPtr recv;
};


#endif  /*ICE_SERVER_H*/
