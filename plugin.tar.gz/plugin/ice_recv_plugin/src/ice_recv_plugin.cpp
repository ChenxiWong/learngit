// Last Update:2016-04-11 16:38:31
/**
 * @file ice_recv_plugin.cpp
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2015-11-17
 */

#include "ice_recv_plugin.h"
#include <ZMPNMsg.pb.h>
extern "C"
{
    int GetPluginId()
    {
        return ice_server_text::plugin_id;
    }
    CEnteranceBase  * FortoryEnterace()
    {
        return new  ice_recv_plugin();
    }
    FormatHandleBase * FortoryDataFormat()
    {
        return new ice_data_format();
    }
}


ice_recv_plugin::ice_recv_plugin()
{
    counter = 0;
}


ice_recv_plugin::~ice_recv_plugin()
{

}

void ice_recv_plugin::reload() 
{
    counter = 0;
    config();
}

void ice_recv_plugin::config()
{
    string npr_root  = getenv("NPR_ROOT");
    pthread_mutex_lock(&stat_xml_mutex);
    ice_config_parse config_parse;
    config_parse.parse(npr_root + config_file_path);
    pthread_mutex_unlock(&stat_xml_mutex);
}


void ice_recv_plugin::_Recv(string confile , thread_pool * pSortQueue)
{
    config_file_path = confile;
    reload();
    p_ice_server = new ice_server();
    string adapter_name = "HelloAdapter";
    string port = "10001";
    string interface_identity = "Hello";
    p_ice_server->run(adapter_name, *ice_server_text::port, interface_identity,pSortQueue,(void *)(this));
}


int ice_recv_plugin::ParseAndStiring(NodeData* pData)
{
    if(counter == 99999)
    {
        return 1;
    }
    else
    {
        return counter++;
    }
}


void out_put_data::handle(void * data , int b_out_type, TCFDATALIST * plist)
{
//   plist->push_back((CANmsg*)data);
}



ice_data_format::ice_data_format()
{

}


ice_data_format::~ice_data_format()
{

}


void ice_data_format::Reload()
{

}


void  ice_data_format::FromatData(NodeData *  pData , TCFDATALIST * plist)
{
    CANmsg *pMsg = new CANmsg() ;
    pMsg -> ParseFromArray(pData->data, pData->datalen);
    CFDataMsg *p_msg = new CFDataMsg;
    p_msg -> SendType =  0x01;
    p_msg -> MsgCrc = 0;
    p_msg -> bMsgEnd  =  true;
    p_msg -> pMsg = pMsg;
    plist->push_back(p_msg);
//    m_out_put.handle(pMsg, NETSEND, plist);
}

void ice_data_format::TimeOut( TCFDATALIST * plist )
{

}
