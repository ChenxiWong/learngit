// Last Update:2016-04-11 16:38:13
/**
 * @file ice_recv_plugin.h
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2015-11-17
 */

#ifndef ICE_recv_PLUGIN_H
#define ICE_recv_PLUGIN_H

#include <CEnteranceBase.h>
#include <DataFormatBase.h>
//#include <data_interface_base.h>
#include <CASqueue.h>
#include  "ice_config_parse.h"
#include <string>
#include <list>
#include "ice_server.h"

using namespace std;

extern "C"
{
        int GetPluginId();
        CEnteranceBase * FortoryEnterace();
        FormatHandleBase * FortoryDataFormat();
};


class ice_recv_plugin : public CEnteranceBase
{
    public:
        ice_recv_plugin();
        ~ice_recv_plugin();
        virtual void  _Recv(string config ,  thread_pool * pSortQueue) ; // 读取数据
        virtual void  reload();
        virtual int ParseAndStiring(NodeData* pData) ;//数据分捡
    private:
        void config();
        uint32_t  counter;
//        ice_config_parse  config_parse;
        string config_file_path;
        ice_server *p_ice_server;
};


class out_put_data
{
    public:
        virtual void handle(void * data , int b_out_type ,TCFDATALIST * plist ) ;
};


class ice_data_format : public FormatHandleBase
{
    public:
        ice_data_format();
        ~ice_data_format();
        virtual void FromatData(NodeData *  pdata , TCFDATALIST * plist);
        virtual void Reload();
        virtual void TimeOut (TCFDATALIST * plist);
    private:
        out_put_data m_out_put;
//        ice_config_parse  parse;
};

#endif  /*ICE_recv_PLUGIN_H*/
