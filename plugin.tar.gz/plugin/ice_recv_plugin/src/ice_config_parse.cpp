// Last Update:2015-11-25 19:18:37
/**
 * @file ice_config_parse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-17
 */

#include "ice_config_parse.h"
#include <sstream>

using namespace std;
void ice_config_parse::itoa(int n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}

void ice_config_parse::assemble_path(string & path, int t)
{
    path += "[";
    string seq;
    itoa(t, seq);
    path += seq;
    path += "]";
}

ice_config_parse::ice_config_parse()
{

}

ice_config_parse::~ice_config_parse()
{

}
void ice_config_parse::parse(string xmlstr)
{
    xml_parse  xml;
    string tmp = "" ;
    xml.set_file_path(xmlstr.c_str());
    if(ice_server_text::port==NULL)
    {
        ice_server_text::port = new string("");
    }
    // ice  端口
    char * p_value = (char *)xml.get_value("/config/ice/port");
    if(p_value !=NULL)
    {
         *ice_server_text::port = p_value;
    }
}
