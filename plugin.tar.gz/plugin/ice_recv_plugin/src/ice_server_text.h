// Last Update:2015-11-20 13:45:45
/**
 * @file ice_text.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-17
 */

#ifndef ICE_SERVER_TEXT_H
#define ICE_SERVER_TEXT_H

#include <pthread.h>
#include <string>

using namespace std;

class ice_server_text
{
    public:
        static __thread string *port;
        static __thread int plugin_id;
};

#endif  /*ICE_SERVER_TEXT_H*/
