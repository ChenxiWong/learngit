// Last Update:2016-04-11 16:40:03
/**
 * @file ice_server.cpp
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2015-11-19
 */


#include "ice_server.h"
#include <string>
#include "ice_server_text.h"

using namespace std;

Ice::Long recv_interface::RecvMsg(const std::string& data, const Ice::Current&)
{
    static int i = 0 ;
    uint64_t buf_len = data.length();
    char * p_buf = new char[buf_len];
    data.copy(p_buf,buf_len,0);
//    printf("%s\n",data.c_str());
    pNode = NULL;
    pNode = new NodeData(p_buf,buf_len,ice_server_text::plugin_id);
    //pNode -> p_CEnteranceBase = phandle;
    //pNode -> ts = ph.ts;
    pNode -> p_CEnteranceBase = p_this;
    pSortQueue -> push((work_data*)pNode, i++);
    return data.length();
}


ice_server::ice_server()
{

}


ice_server::~ice_server()
{

}


void ice_server::run(string adapter_name, string port, string interface_identity, thread_pool  *pQueue, void *p)
{
//    string adapter_name = "HelloAdapter";
//    string config = "default -p 10001";
//    string interface_identity = "Hello";
    Ice::CommunicatorPtr ic = Ice::initialize();
    Ice::ObjectAdapterPtr adapter = ic->createObjectAdapterWithEndpoints(adapter_name, "default -p " + port);
    recv  = new recv_interface(pQueue, p);
    adapter->add(recv, ic->stringToIdentity(interface_identity));
    adapter->activate();
    printf("Ice server has been launched!\n");
    ic->waitForShutdown();
    return;
}
