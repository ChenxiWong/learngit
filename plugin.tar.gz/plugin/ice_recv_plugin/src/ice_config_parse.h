// Last Update:2015-11-17 13:37:15
/**
 * @file ice_config_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-17
 */

#ifndef ICE_CONFIG_PARSE_H
#define ICE_CONFIG_PARSE_H

#include <xml_parse.h>
#include <string>
#include "ice_server_text.h"
#include <stdlib.h>
using namespace std;

class ice_config_parse
{
    public:
        ice_config_parse();
        ~ice_config_parse();
        void parse(string xmlstr);
    private :
        void assemble_path(string & path, int t);
        void itoa(int n, string& str);
};

#endif  /*ICE_CONFIG_PARSE_H*/
