// Last Update:2016-01-04 17:01:09
/**
 * @file file_config_parse.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-19
 */

#include "file_config_parse.h"

void itoa(int n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}

void assemble_path(string & path, int t)
{
    path += "[";
    string seq;
    itoa(t, seq);
    path += seq;
    path += "]";
}

file_config_parse::file_config_parse()
{

}

file_config_parse::~file_config_parse()
{

}

void file_config_parse::parse(string xmlstr)
{
    xml_parse  xml;

    xml.set_file_path(xmlstr.c_str());

    char * p_value = (char *)xml.get_value("/config/file_dir");
    if (p_value != NULL)
    {
        *file_text::file_dir = p_value;
    }

    p_value = (char *)xml.get_value("/config/file_save");
    if (p_value != NULL)
    {
        *file_text::file_save = p_value;
    }
    p_value = (char *)xml.get_value("/config/next_file_save");
    if (p_value != NULL)
    {
        *file_text::next_file_save = p_value;
    }

    p_value = (char *)xml.get_value("/config/time");
    if (p_value != NULL)
    {
        file_text::time = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/removefile");
    if (p_value != NULL)
    {
        string tmp = p_value;
        if(tmp == "true")
        {
            file_text::b_file_remove = true;
        }
        else
        {
            file_text::b_file_remove = false;
        }
    }

    string xpath_type = "/config/file_postfix";
    uint32_t type_count = xml.get_value_count(xpath_type.c_str());
    for (uint32_t i=0; i < type_count; i++)
    {
        string xpath_type_tmp = xpath_type;
        assemble_path(xpath_type_tmp, i+1);
        p_value = (char *)xml.get_value(xpath_type_tmp.c_str());
        if (p_value != NULL)
        {
            string type = p_value;
            file_text::file_postfix->push_back(type);
        }
    }
}


