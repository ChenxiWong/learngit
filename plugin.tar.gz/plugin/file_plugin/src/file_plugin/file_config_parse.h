// Last Update:2015-11-20 09:08:11
/**
 * @file file_config_parse.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-19
 */

#ifndef FILE_CONFIG_PARSE_H
#define FILE_CONFIG_PARSE_H
#include <xml_parse.h>
#include <string>
#include "file_text.h"
#include <stdlib.h>
#include <sstream>
using namespace std;

class file_config_parse
{
    public:
        file_config_parse();
        ~file_config_parse();
        void parse(string xmlstr);

};

void assemble_path(string & path,int t);


#endif  /*FILE_CONFIG_PARSE_H*/
