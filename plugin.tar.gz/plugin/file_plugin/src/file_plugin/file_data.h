// Last Update:2016-01-04 17:24:46
/**
 * @file file_data.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-22
 */

#ifndef FILE_DATA_H
#define FILE_DATA_H
#include <dirent.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>
#include <string>
#include <list>
#include <CASqueue.h>
#include <CEnteranceBase.h>

using namespace std;
class FileData  : public WorkDataBase
{
    public:
        string file_name ;
        string save_name ; 
        

};
class file_data
{
    public:
        file_data( thread_pool * SortQueue ,void * pthis);
        ~file_data();
        void file_parse();
};


#endif  /*FILE_DATA_H*/
