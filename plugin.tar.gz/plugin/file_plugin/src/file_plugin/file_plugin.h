// Last Update:2015-11-23 15:12:22
/**
 * @file file_plugin.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-20
 */

#ifndef FILE_PLUGIN_H
#define FILE_PLUGIN_H
#include <CEnteranceBase.h>
#include <DataFormatBase.h>
#include <CASqueue.h>
#include "file_config_parse.h"
#include "file_data.h"
#include <string>
#include <list>
#include "ZMPNMsg.pb.h"
#include <commit_tools.h>
#include <fstream>
using namespace std;
extern "C" {
    int GetPluginId();
    CEnteranceBase * FortoryEnterace();
    FormatHandleBase * FortoryDataFormat();
};

class file_plugin : public CEnteranceBase
{
    public:
        file_plugin();
        ~file_plugin();
        virtual void  _Recv(string config ,  thread_pool * pSortQueue) ;
        virtual void  reload()  ;
        virtual int ParseAndStiring(NodeData* pData) ;
    private:
        void config();
//        file_config_parse Parse;
        file_data *p_file_data;
        string sConfile;
};

class file_data_format : public FormatHandleBase
{
    public:
        file_data_format();
        ~file_data_format();
        virtual void FromatData(NodeData *  pdata , TCFDATALIST * plist) ;
        virtual void Reload();
        virtual void TimeOut (TCFDATALIST * plist) ;
    private:
        file_config_parse Parse;
};



#endif  /*FILE_PLUGIN_H*/
