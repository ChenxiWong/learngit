// Last Update:2015-11-23 14:35:16
/**
 * @file file_text.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-19
 */

#include "file_text.h"

__thread int file_text::file_thread_num = 0;
__thread int file_text::plugin_id = 10002;
__thread string *file_text::file_dir = NULL;
__thread string *file_text::file_save = NULL;
__thread string *file_text::next_file_save = NULL;
__thread int file_text::time = 60;
__thread string *file_text::sNPRRoot = NULL;
__thread list<string> *file_text::file_postfix = NULL;
__thread bool file_text::b_file_remove = true;
