// Last Update:2016-04-11 16:45:17
/**
 * @file file_plugin.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-20
 */

#include "file_plugin.h"
extern "C" {
    int GetPluginId()
    {
        return file_text::plugin_id;
    }
    CEnteranceBase  * FortoryEnterace()
    {
        return new file_plugin();
    }
    FormatHandleBase * FortoryDataFormat()
    {
        return new file_data_format();
    }
}

file_plugin::file_plugin()
{

}

file_plugin::~file_plugin()
{

}

void file_plugin::reload()
{
    config();
}

void file_plugin::config()
{
    pthread_mutex_lock(&stat_xml_mutex);
    file_config_parse Parse;
    *file_text::sNPRRoot  = getenv("NPR_ROOT");
    Parse.parse(*file_text::sNPRRoot + sConfile);
    pthread_mutex_unlock(&stat_xml_mutex);
}

void  file_plugin::_Recv(string confile , thread_pool * pSortQueue)
{
    if (file_text::file_dir == NULL)
    {
        file_text::file_dir = new string("");
    }
    if (file_text::file_save == NULL)
    {
        file_text::file_save = new string("");
    }
    if (file_text::next_file_save == NULL)
    {
        file_text::next_file_save = new string("");
    }
    if (file_text::sNPRRoot == NULL)
    {
        file_text::sNPRRoot =  new string("");
    }
    if (file_text::file_postfix == NULL)
    {
        file_text::file_postfix = new list<string>;
    }

    sConfile = confile;
    config();
    p_file_data = new file_data(pSortQueue,(void *)(this ));
    if (p_file_data == NULL)
    {
        printf("file error\n");
        abort();
    }
    p_file_data->file_parse();
    if (file_text::sNPRRoot != NULL)
    {
        delete file_text::sNPRRoot;
    }
    if (file_text::file_dir != NULL)
    {
        delete file_text::file_dir;
    }
    if (file_text::file_save != NULL)
    {
        delete file_text::file_save;
    }
    if (file_text::next_file_save != NULL)
    {
        delete file_text::next_file_save;
    }
    if (file_text::file_postfix != NULL)
    {
        delete file_text::file_postfix;
    }

    file_text::file_dir = NULL;
    file_text::file_save = NULL;
    file_text::next_file_save = NULL;
    file_text::sNPRRoot = NULL;
    file_text::file_postfix = NULL;
}

int file_plugin::ParseAndStiring(NodeData* pData)
{
    file_text::file_thread_num++;
    return file_text::file_thread_num;
}

file_data_format::file_data_format()
{
    /*if (file_text::file_dir == NULL)
    {
        file_text::file_dir = new string("");
    }
    if (file_text::file_save == NULL)
    {
        file_text::file_save = new string("");
    }
    if (file_text::sNPRRoot == NULL)
    {
        file_text::sNPRRoot =  new string("");
    }
    if (file_text::file_postfix == NULL)
    {
        file_text::file_postfix = new list<string>;
    }
    *file_text::sNPRRoot  = getenv("NPR_ROOT");
    string conf_path = "conf/file_plugin.xml";
    Parse.parse(*file_text::sNPRRoot + conf_path);*/
}

file_data_format::~file_data_format()
{
    /*if (file_text::sNPRRoot != NULL)
    {
        delete file_text::sNPRRoot;
    }
    if (file_text::file_dir != NULL)
    {
        delete file_text::file_dir;
    }
    if (file_text::file_save != NULL)
    {
        delete file_text::file_save;
    }
    if (file_text::file_postfix != NULL)
    {
        delete file_text::file_postfix;
    }

    file_text::file_dir = NULL;
    file_text::file_save = NULL;
    file_text::sNPRRoot = NULL;
    file_text::file_postfix = NULL;*/
}

void file_data_format::FromatData(NodeData *  pdata , TCFDATALIST * plist)
{

    FileData * p_file_data  =(FileData *) pdata->pWorkData;
    string file_name = p_file_data -> file_name ;
    uint64_t file_id = crc32((unsigned char *)file_name.c_str(),file_name.length());
    unsigned  int MaxBufLen = 4*1024*1024;
    fstream in(file_name.c_str(), ios::in);
    istreambuf_iterator<char> beg(in), end;
    string strdata(beg, end);
    in.close();
    int pos = file_name.find_last_of('/');
    file_name = file_name.substr(pos+1);

    while(strdata.length() > MaxBufLen)
    {
        CANmsg* p_file_msg = new CANmsg;
        p_file_msg->Clear();
        p_file_msg->set_type(6);
        file_msg* p_file = p_file_msg->mutable_file();
        p_file->set_file_name( p_file_data -> save_name + file_name);
        p_file->set_file_crc_id(0);
        p_file->set_file_id(file_id);
        p_file->set_b_end(false);
        p_file->set_data(strdata.substr(0,MaxBufLen));
        strdata = strdata.substr(MaxBufLen);

        CFDataMsg * p_msg = new CFDataMsg;
        p_msg -> SendType =  0x01;
        p_msg -> bMsgEnd = false;
        p_msg -> MsgCrc = file_id;
        p_msg -> pMsg = p_file_msg;
        plist->push_back(p_msg);
    }


    CANmsg* p_file_msg = new CANmsg;
    p_file_msg->Clear();
    p_file_msg->set_type(6);
    file_msg* p_file = p_file_msg->mutable_file();
    p_file->set_file_name( p_file_data -> save_name + file_name);
    p_file->set_file_crc_id(0);
    p_file->set_file_id(file_id);
    p_file->set_b_end(true);
    p_file->set_data(strdata);

    CFDataMsg * p_msg = new CFDataMsg;
    p_msg -> SendType =  0x01;
    p_msg -> bMsgEnd = true;
    p_msg -> MsgCrc = file_id;
    p_msg -> pMsg = p_file_msg;
    plist->push_back(p_msg);
}

void file_data_format::Reload()
{

}


void file_data_format::TimeOut(TCFDATALIST * plist)
{

}
