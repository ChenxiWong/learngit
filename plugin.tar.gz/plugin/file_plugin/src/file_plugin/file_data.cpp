// Last Update:2016-04-11 16:47:56
/**
 * @file file_data.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-23
 */

#include "file_data.h"
#include <commit_tools.h>
#include "file_text.h"
#include <pthread.h>

static __thread    thread_pool  * pSortQueue  =NULL;
static __thread    void * p_this = NULL;

file_data::file_data(thread_pool * SortQueue ,void * pthis)
{
    pSortQueue  = SortQueue;
    p_this = pthis;
}

file_data::~file_data()
{

}

void file_data::file_parse()
{
    for(;;)
    {
        printf ("file_parse()  \n");
        struct dirent *ptr;
        DIR *dir;
        dir=opendir(file_text::file_dir->c_str());
        while((ptr=readdir(dir))!=NULL)
        {
            if(ptr->d_name[0] == '.')
            {
                continue;
            }

            int isign = 0;
            list<string>::iterator iter = file_text::file_postfix->begin();
            for( ; iter != file_text::file_postfix->end(); iter++)
            {
                isign = cmp_wiat_end(ptr->d_name,iter->c_str());
                if (isign == 1)
                {
                    break;
                }
            }

            if(isign == 1)
            {
                /*string prefix = file_text::file_dir->substr(0,file_text::file_dir->size()-1);
                int num_pos = file_text::file_dir->find_last_of('/');
                prefix = prefix.substr(num_pos+1);*/

                string file_name = *file_text::file_dir + string(ptr->d_name);
                if(file_text::b_file_remove)
                {
                    string target = *file_text::file_save;
                    string tmp = file_name;
                    target+="/";

                    target += string(tmp,file_text::file_dir->size(),tmp.size());
                    create_path(target);
                    rename(tmp.c_str(), target.c_str());
                }
                file_name = *file_text::file_save + string(ptr->d_name);
                //char *p = new char[file_name.length()+1];

                //memcpy(p,file_name.c_str(),file_name.length()+1);
                struct timeval tv ;
                gettimeofday(&tv,NULL);
               NodeData *pNode = new NodeData();
               pNode -> packettype = file_text::plugin_id ;
               FileData * p_data  = new FileData();
               p_data -> file_name = file_name ;
               p_data -> save_name  = *file_text::next_file_save ;
               pNode ->pWorkData = p_data ;

                pNode -> p_CEnteranceBase = p_this;
                pNode -> ts = tv;
                static int i = 0;
                pSortQueue -> push((work_data *)pNode, i++);
            }
           // sleep(1);
        }
        closedir(dir);
        sleep(file_text::time);
    }
}


