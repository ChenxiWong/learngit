// Last Update:2016-01-04 16:59:07
/**
 * @file file_text.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2015-11-19
 */

#ifndef FILE_TEXT_H
#define FILE_TEXT_H

#include <stdint.h>
#include <string>
#include <list>
#include <pthread.h>
#include <sys/syscall.h>
using namespace std;
class file_text
{
    public:
        static __thread int file_thread_num;
        static __thread int plugin_id;
        static __thread string *file_dir;
        static __thread string *file_save;
        static __thread string *next_file_save;
        static __thread int time;
        static __thread string *sNPRRoot;
        static __thread list<string> *file_postfix;
        static __thread bool b_file_remove;
};

#endif  /*FILE_TEXT_H*/
