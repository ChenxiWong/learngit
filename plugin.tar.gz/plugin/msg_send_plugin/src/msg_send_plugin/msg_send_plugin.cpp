// Last Update:2016-11-04 10:00:51
/**
 * @file msg_send_plugin.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2016-05-11
 */

#include "msg_send_plugin.h"

extern "C" {
    int GetPluginId()
    {
        return msg_send_text::plugin_id;
    }
    CFDataSendBase *FortoryEnterace()
    {
        return new msg_send_plugin();
    }
}

void itoa(long n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}

msg_send_plugin::msg_send_plugin()
{
    if (msg_send_text::result_dir == NULL)
    {
        msg_send_text::result_dir = new string("");
    }
    if (msg_send_text::source == NULL)
    {
        msg_send_text::source = new string("");
    }
    if (msg_send_text::sign == NULL)
    {
        msg_send_text::sign = new string("");
    }
    if (msg_send_text::devide_sign == NULL)
    {
        msg_send_text::devide_sign = new string("");
    }
    if (msg_send_text::txt_time == NULL)
    {
        msg_send_text::txt_time = new int(0);
    }
    if (msg_send_text::txt_num == NULL)
    {
        msg_send_text::txt_num = new int(0);
    }
    if (msg_send_text::zip_time == NULL)
    {
        msg_send_text::zip_time = new int(0);
    }

    msg_send_config_parse parse;
    string config_path = getenv("NPR_ROOT");
    config_path += "conf/msg_send_plugin.xml";
    parse.parse(config_path);
    result_dir = *msg_send_text::result_dir;
    data_source = *msg_send_text::source;
    data_source_sign = *msg_send_text::sign;
    devide_sign = *msg_send_text::devide_sign;
    zip_count = 0;
    txt_time = *(msg_send_text::txt_time);
    txt_num = *(msg_send_text::txt_num);
    zip_time = *(msg_send_text::zip_time);
    zip_last_check_time = 0;//用于解决valgrind测试出使用未初始化变量
    init_map_action();
}

msg_send_plugin::~msg_send_plugin()
{
    if (msg_send_text::result_dir != NULL)
    {
        delete msg_send_text::result_dir;
    }
    if (msg_send_text::source != NULL)
    {
        delete msg_send_text::source;
    }
    if (msg_send_text::sign != NULL)
    {
        delete msg_send_text::sign;
    }
    if (msg_send_text::devide_sign != NULL)
    {
        delete msg_send_text::devide_sign;
    }
    if (msg_send_text::txt_time != NULL)
    {
        delete msg_send_text::txt_time;
    }
    if (msg_send_text::txt_num != NULL)
    {
        delete msg_send_text::txt_num;
    }
    if (msg_send_text::zip_time != NULL)
    {
        delete msg_send_text::zip_time;
    }
    msg_send_text::result_dir = NULL;
    msg_send_text::source = NULL;
    msg_send_text::sign = NULL;
    msg_send_text::devide_sign = NULL;
}

void msg_send_plugin::init_map_action()
{
    map_action[1] = "eml";
    map_action[2] = "telnet";
    map_action[3] = "ftp";
    map_action[4] = "dns";
    map_action[5] = "webmail";
    map_action[6] = "file";
    map_action[7] = "qq_file";
    map_action[8] = "fileattach";
    map_action[9] = "http";
    map_action[10] = "urltext";
    map_action[11] = "report";
    map_action[12] = "regist";
    map_action[13] = "login";
    map_action[14] = "http_lbs";
    map_action[15] = "http_cloud";
    map_action[17] = "search";
    map_action[18] = "scan";
    map_action[19] = "shop";
    map_action[20] = "bbs";//"bbs";
    map_action[21] = "job";
    map_action[22] = "tickets";
    map_action[23] = "social";
    map_action[24] = "logout";
    map_action[25] = "pptp";
    map_action[26] = "l2tp";
    map_action[27] = "isakmp";
    map_action[28] = "ssh";
    map_action[29] = "ssl";
    map_action[30] = "all_stream";
}

void msg_send_plugin::SendData(int len ,char * &buff, CFDataMsg * pMsg)
{
    /*if (map_ing_path.find(pMsg->pMsg->type()) == map_ing_path.end())
      {
      struct timeval tv;
      gettimeofday(&tv,NULL);
      uint64_t m_timeval = tv.tv_sec * 1000000 + tv.tv_usec;
      zip_last_check_time = m_timeval;
      string s_count;
      itoa(zip_count++, s_count);
      long pid = getpid();
      string s_pid;
      itoa(pid, s_pid);
      string type;
      if (map_action.find(pMsg->pMsg->type()) != map_action.end())
      {
      type = map_action.find(pMsg->pMsg->type())->second;
      }
      else
      {
      itoa(pMsg->pMsg->type(), type);
      }
      string year_month = get_year_month();
      string day_hour = get_day_hour();
      string min_sec = get_min_sec();
      string data_time = year_month.substr(0,year_month.size()-1) + day_hour.substr(0,day_hour.size()-1) + min_sec.substr(0,min_sec.size()-1);
      string ing_path = result_dir + data_source + '_' + data_source_sign + '_' + type + '_' + s_pid + '_' + data_time + '_' + s_count + ".ing" + '/';
      string zip_path = result_dir + data_source + '_' + data_source_sign + '_' + type + '_' + s_pid + '_' + data_time + '_' + s_count + ".zip";
      create_path(ing_path);
      map_ing_path.insert(make_pair(pMsg->pMsg->type(), ing_path));
      map_zip_path.insert(make_pair(pMsg->pMsg->type(), zip_path));
      }*/

    write_txt(pMsg);

    //写文件完毕释放内存。
    delete pMsg->pMsg;
    pMsg->pMsg = NULL;

}

void msg_send_plugin::add_path(CFDataMsg * pMsg)
{
    if (map_ing_path.find(pMsg->pMsg->type()) == map_ing_path.end())
    {
        struct timeval tv;
        gettimeofday(&tv,NULL);
        uint64_t m_timeval = tv.tv_sec * 1000000 + tv.tv_usec;
        zip_last_check_time = m_timeval;
        string s_count;
        itoa(zip_count++, s_count);
        long pid = getpid();
        string s_pid;
        itoa(pid, s_pid);
        string type;
        if (map_action.find(pMsg->pMsg->type()) != map_action.end())
        {
            type = map_action.find(pMsg->pMsg->type())->second;
        }
        else
        {
            itoa(pMsg->pMsg->type(), type);
        }
        string year_month = get_year_month();
        string day_hour = get_day_hour();
        string min_sec = get_min_sec();
        string usec = "";
        itoa(tv.tv_usec,usec);
        string data_time = year_month.substr(0,year_month.size()-1) + day_hour.substr(0,day_hour.size()-1) + min_sec.substr(0,min_sec.size()-1);
        string ing_path = result_dir + data_source + '_' + data_source_sign + '_' + type + '_' + s_pid + '_' + data_time + '_' + usec + '_' + s_count + ".ing" + '/';
        string zip_path = result_dir + data_source + '_' + data_source_sign + '_' + type + '_' + s_pid + '_' + data_time + '_' + usec + '_' + s_count + ".zip";
        create_path(ing_path);
        map_ing_path.insert(make_pair(pMsg->pMsg->type(), ing_path));
        map_zip_path.insert(make_pair(pMsg->pMsg->type(), zip_path));
    }
}

void msg_send_plugin::write_txt(CFDataMsg * pMsg)
{
    /* if (pMsg->pMsg->type() == 2)
       {
       add_path(pMsg);
       write_telnet(pMsg);
       }*/
    if(pMsg->pMsg->type() == 5)
    {
        add_path(pMsg);
        write_webmail(pMsg);
    }
    else if (pMsg->pMsg->type() == 17)
    {
        add_path(pMsg);
        write_search(pMsg);
    }
    else if (pMsg->pMsg->type() == 27)
    {
        add_path(pMsg);
        write_isakmp(pMsg);
    }
    else if(pMsg->pMsg->type() == 18)
    {
        add_path(pMsg);
        write_news(pMsg);
    }
    else if(pMsg->pMsg->type() == 19)
    {
        add_path(pMsg);
        write_shop(pMsg);
    }
    else if(pMsg->pMsg->type() == 20)
    {
        add_path(pMsg);
        write_bbs(pMsg);
    }
    else if(pMsg->pMsg->type() == 13)
    {
        add_path(pMsg);
        write_login(pMsg);
    }
    else if(pMsg->pMsg->type() == 24)
    {
        add_path(pMsg);
        write_logout(pMsg);
    }
    else if(pMsg->pMsg->type() == 12)
    {
        add_path(pMsg);
        write_register(pMsg);
    }
    else if(pMsg->pMsg->type() == 21)
    {
        add_path(pMsg);
        write_job(pMsg);
    }
    else if(pMsg->pMsg->type() == 22)
    {
        add_path(pMsg);
        write_ticket(pMsg);
    }
    else if(pMsg->pMsg->type() == 25)
    {
        add_path(pMsg);
        write_pptp(pMsg);
    }
    else if(pMsg->pMsg->type() == 26)
    {
        add_path(pMsg);
        write_l2tp(pMsg);
    }
    else if(pMsg->pMsg->type() == 28)
    {
        add_path(pMsg);
        write_ssh(pMsg);
    }
    else if(pMsg->pMsg->type() == 29)
    {
        add_path(pMsg);
        write_ssl(pMsg);
    }
    else if(pMsg->pMsg->type() == 30)
    {
        add_path(pMsg);
        write_all_stream(pMsg);
    }
}

void msg_send_plugin::creat_txt_file(CFDataMsg * pMsg)
{
    if (map_txt_path.find(pMsg->pMsg->type()) == map_txt_path.end())
    {
        struct timeval tv;
        gettimeofday(&tv,NULL);
        map_last_check_time[pMsg->pMsg->type()] = tv.tv_sec * 1000000 + tv.tv_usec;

        string s_count;
        int count = 0;
        if (map_txt_count.find(pMsg->pMsg->type()) == map_txt_count.end())
        {
            count = 0;
            map_txt_count[pMsg->pMsg->type()] = 0;
        }
        else
        {
            count = map_txt_count.find(pMsg->pMsg->type())->second + 1;
            map_txt_count[pMsg->pMsg->type()] = count;
        }
        itoa(count, s_count);
        long pid = getpid();
        string s_pid;
        itoa(pid, s_pid);
        string type;
        if (map_action.find(pMsg->pMsg->type()) != map_action.end())
        {
            type = map_action.find(pMsg->pMsg->type())->second;
        }
        else
        {
            itoa(pMsg->pMsg->type(), type);
        }
        string year_month = get_year_month();
        string day_hour = get_day_hour();
        string min_sec = get_min_sec();
        string data_time = year_month.substr(0,year_month.size()-1) + day_hour.substr(0,day_hour.size()-1) + min_sec.substr(0,min_sec.size()-1);
        string ing_path = map_ing_path.find(pMsg->pMsg->type())->second;
        string txt_path = ing_path + data_source + '_' + data_source_sign + '_' + type + '_' + s_pid + '_' + data_time + '_' + s_count + ".txt";
        map_txt_path.insert(make_pair(pMsg->pMsg->type(), txt_path));
    }
}

void msg_send_plugin::write_Comm_msg(const Comm_msg common, FILE *p_index_file)
{
    if(p_index_file == NULL)
        return;
    fprintf(p_index_file, "%s", common.src_ip().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.src_country().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.src_area().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.src_port());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.dst_ip().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.dst_country().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.dst_area().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.dst_port());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lu", common.time());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    //fprintf(p_index_file, "%s", common.vpn_src_ip().c_str());
    //fprintf(p_index_file, "\t%s", devide_sign.c_str());
    //fprintf(p_index_file, "%s", common.vpn_dst_ip().c_str());
    //fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.dev_num().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", common.line_num().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.link_layer_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.is_ipv4());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.is_mpls());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.n_label());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.inner_label());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.other_label());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.proto());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%f", common.duration());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%f", common.longitude());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%f", common.latitude());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.total_pay_load_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.tatal_pay_load_packets());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", common.is_ipv6());

}

void msg_send_plugin::write_c2s_http_head_msg(const c2s_http_head_msg c2s, FILE *p_index_file)
{
    if(p_index_file == NULL)
        return;
    fprintf(p_index_file, "%s", c2s.method().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.url().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.referer().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.accept().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.accept_language().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.user_agent().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.accept_encoding().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.host().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.cookie().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.accept_charset().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.via().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.content_length().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.content_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", c2s.x_forwarded_for().c_str());
}

void msg_send_plugin::write_s2c_http_head_msg(const s2c_http_head_msg s2c, FILE *p_index_file)
{
    if(p_index_file == NULL)
        return;
    fprintf(p_index_file, "%s", s2c.http_version().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.status_code().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.cache_control().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.pragma().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.content_type().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.expires().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.last_modified().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.server().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.date().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.content_length().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.is_download_file().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.via().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", s2c.x_forwarded_for().c_str());
}

void msg_send_plugin::write_telnet(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->telnet().comm_msg(), p_index_file);
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->telnet().username().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->telnet().password().c_str());
    fprintf(p_index_file, "%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->telnet().is_valid());
    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

void msg_send_plugin::write_webmail(CFDataMsg *pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->webmail().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->webmail().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().from().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().to().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().username().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().title().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().mainfile().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().other_file().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->webmail().mail_send_time());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().folder().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->webmail().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().sessonid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().from_part().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().to_part().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().cc_part().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->webmail().bcc_part().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

void msg_send_plugin::write_search(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->search().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->search().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().keyword().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().board().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->search().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->search().uid().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_pptp(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->pptp().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().protocol_family());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lf",pMsg->pMsg->pptp().communication_rate());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().direction());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().message_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().protocol_version());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().framing_capabilities());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().bearer_capabilities());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().server_firmware_revision());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().client_firmware_revision());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->pptp().has_server_hostname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->pptp().server_hostname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->pptp().has_client_hostname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->pptp().client_hostname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().server_call_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().client_call_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().call_serial_number());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().server_send_accm());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().server_receive_accm());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().client_send_accm());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->pptp().client_receive_accm());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->pptp().has_vendor_name())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->pptp().vendor_name().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_l2tp(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->l2tp().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().protocol_family());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lf",pMsg->pMsg->l2tp().communication_rate());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().direction());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().protocol_version());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().framing_capabilities());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().bearer_capabilities());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_server_hostname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().server_hostname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_client_hostname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().client_hostname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_server_vendorname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().server_vendorname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_client_vendorname())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().client_vendorname().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_calling_number())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().calling_number().c_str());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->l2tp().proxy_authen_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->l2tp().has_proxy_authen_name())
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->l2tp().proxy_authen_name().c_str());
    }
    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_isakmp(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->isakmp().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().protocol_family());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lf",pMsg->pMsg->isakmp().communication_rate());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().direction());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->isakmp().initiator_cookie().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().initiator_cookie().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->isakmp().responder_cookie().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().responder_cookie().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().protocol_version());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().exchange_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().b_sa_payload());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
   /* fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().b_cookie_zero());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());*/
    int i = 0;
    if(pMsg->pMsg->isakmp().encryption_algorithm_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().encryption_algorithm_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().encryption_algorithm(i));
            if(i != pMsg->pMsg->isakmp().encryption_algorithm_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    if(pMsg->pMsg->isakmp().hash_algorithm_size() > 0)
    {
        for(int i = 0; i < pMsg->pMsg->isakmp().hash_algorithm_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().hash_algorithm(i));
            if(i != pMsg->pMsg->isakmp().hash_algorithm_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    if(pMsg->pMsg->isakmp().group_destription_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().group_destription_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().group_destription(i));
            if(i != pMsg->pMsg->isakmp().group_destription_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    
    if(pMsg->pMsg->isakmp().authentication_method_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().authentication_method_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().authentication_method(i));
            if(i != pMsg->pMsg->isakmp().authentication_method_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->isakmp().life_type_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().life_type_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().life_type(i));
            if(i != pMsg->pMsg->isakmp().life_type_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());


    if(pMsg->pMsg->isakmp().life_duration_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().life_duration_size(); i++)
        {
            fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().life_duration(i));
            if(i != pMsg->pMsg->isakmp().life_duration_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    for(int i = 0; i< pMsg->pMsg->isakmp().transform_data().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().transform_data().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    
    if(pMsg->pMsg->isakmp().vendor_id_size() > 0)
    {
        for(i = 0; i < pMsg->pMsg->isakmp().vendor_id_size(); i++)
        {
            //fwrite(pMsg->pMsg->isakmp().vendor_id(i).c_str(), 1,pMsg->pMsg->isakmp().vendor_id(i).length() , p_index_file);
            for(int j = 0; j < pMsg->pMsg->isakmp().vendor_id(i).length(); j++)
            {
                fprintf(p_index_file, "%02X",(unsigned char)(pMsg->pMsg->isakmp().vendor_id(i).c_str())[j]);
            }
            if(i != pMsg->pMsg->isakmp().vendor_id_size() -1)
            {
                fprintf(p_index_file, "%s", ";");
            }
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->isakmp().key_exchange_data().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().key_exchange_data().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->isakmp().nonce_data().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().nonce_data().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->isakmp().exchange_type()!=2)
    {
    fprintf(p_index_file, "%s", pMsg->pMsg->isakmp().identification_data().c_str());
    }
    else
    {
    for(int i = 0; i< pMsg->pMsg->isakmp().identification_data().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->isakmp().identification_data().c_str()[i]);
    }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->isakmp().b_nat());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

void msg_send_plugin::write_ssh(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path=map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->ssh().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->ssh().protocol_family());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lf",pMsg->pMsg->ssh().communication_rate());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->ssh().direction());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().protocol_c()!="")
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->ssh().protocol_c().c_str());
    }

    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().protocol_s()!="")
    {
        fprintf(p_index_file, "%s", pMsg->pMsg->ssh().protocol_s().c_str());
    }

    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().cookie()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().cookie().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().cookie().c_str()[i]);
        }
    }

    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().kex_algorithms_c()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().kex_algorithms_c().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().kex_algorithms_c().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
   /* if(pMsg->pMsg->ssh().kex_algorithms_s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().kex_algorithms_s().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().kex_algorithms_s().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    */
    if(pMsg->pMsg->ssh().s_host_key_algorithms()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().s_host_key_algorithms().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().s_host_key_algorithms().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().encryption_algorithms_c2s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().encryption_algorithms_c2s().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().encryption_algorithms_c2s().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().encryption_algorithms_s2c()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().encryption_algorithms_s2c().length(); i++)
        {fprintf(p_index_file, "%c", pMsg->pMsg->ssh().encryption_algorithms_s2c().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().mac_algorithms_c2s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().mac_algorithms_c2s().length(); i++)
        {fprintf(p_index_file, "%c", pMsg->pMsg->ssh().mac_algorithms_c2s().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().mac_algorithms_s2c()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().mac_algorithms_s2c().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().mac_algorithms_s2c().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().compression_algorithms_c2s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().compression_algorithms_c2s().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().compression_algorithms_c2s().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().compression_algorithms_s2c()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().compression_algorithms_s2c().length(); i++)
        {
            fprintf(p_index_file, "%c", pMsg->pMsg->ssh().compression_algorithms_s2c().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().p_len()==0)
    {
    fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssh().p_len());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().p()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().p().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().p().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().g()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().g().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().g().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().e()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().e().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().e().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().k_s()!=""&&pMsg->pMsg->ssh().f()!=""&&pMsg->pMsg->ssh().h_s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().k_s().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().k_s().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().k_s()!=""&&pMsg->pMsg->ssh().f()!=""&&pMsg->pMsg->ssh().h_s()!="")
    //if(pMsg->pMsg->ssh().f()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().f().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().f().c_str()[i]);
        }
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssh().k_s()!=""&&pMsg->pMsg->ssh().f()!=""&&pMsg->pMsg->ssh().h_s()!="")
    //if(pMsg->pMsg->ssh().h_s()!="")
    {
        for(int i = 0; i< pMsg->pMsg->ssh().h_s().length(); i++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssh().h_s().c_str()[i]);
        }
    }
    //    fprintf(p_index_file, "%s", devide_sign.c_str());
    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_ssl(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;
    write_Comm_msg(pMsg->pMsg->ssl().comm_msg(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().protocol_family());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%lf",pMsg->pMsg->ssl().communication_rate());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().direction());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if((pMsg->pMsg->ssl().client_version_major()==0)&&(pMsg->pMsg->ssl().client_version_minor()==0))
    {
        fprintf(p_index_file, "%s"," ");
    }
    else
    {
        fprintf(p_index_file, "%d", pMsg->pMsg->ssl().client_version_major());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if((pMsg->pMsg->ssl().client_version_major()==0)&&(pMsg->pMsg->ssl().client_version_minor()==0))
    {
        fprintf(p_index_file, "%s"," ");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().client_version_minor());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().c_session_id().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().c_session_id().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if(pMsg->pMsg->ssl().cipher_suites_length()==0)
    {
    fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().cipher_suites_length());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    /*for(int i = 0; i< pMsg->pMsg->ssl().c_cipher_suites_size(); i++)
    {
        fprintf(p_index_file, "%04x", pMsg->pMsg->ssl().c_cipher_suites(i));
    }*/
    for(int i = 0; i< pMsg->pMsg->ssl().c_cipher_suites().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().c_cipher_suites().c_str()[i]);
    }
    //fprintf(p_index_file,"%s",pMsg->pMsg->ssl().c_cipher_suites().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ssl().c_gmt_unix_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().c_random_bytes().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().c_random_bytes().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ssl().c_server_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().challenge().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().challenge().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if((pMsg->pMsg->ssl().server_version_major()==0)&&(pMsg->pMsg->ssl().server_version_minor()==0))
    {
        fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().server_version_major());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    
    if((pMsg->pMsg->ssl().server_version_major()==0)&&(pMsg->pMsg->ssl().server_version_minor()==0))
    {
        fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().server_version_minor());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ssl().s_gmt_unix_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().s_random_bytes().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().s_random_bytes().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().s_session_id().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().s_session_id().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    
    if(pMsg->pMsg->ssl().s_cipher_suites()==0)
    {
    fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%04x", pMsg->pMsg->ssl().s_cipher_suites());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    ssl_certificate* p_certificate = NULL;


    int size = pMsg->pMsg->ssl().certificate_size();
    for(int i = 0; i< size; i++)
    {
        for(int j = 0; j< pMsg->pMsg->ssl().certificate(i).certificate_algorithm().length(); j++)
        {
            fprintf(p_index_file, "%02x",(unsigned char)pMsg->pMsg->ssl().certificate(i).certificate_algorithm().c_str()[j]);
        }
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%lu", pMsg->pMsg->ssl().certificate(i).certificate_pubkeylength());
        fprintf(p_index_file, "%s", "/");
        for(int j = 0; j< pMsg->pMsg->ssl().certificate(i).certificate_pubkey().length(); j++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().certificate(i).certificate_pubkey().c_str()[j]);
        }
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_countryname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_provincename().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_localityname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_organizationname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_organizationalunitname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_commonname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).issuer_emailaddress().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_countryname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_provincename().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_localityname().c_str());
        fprintf(p_index_file, "%s", "/");

        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_organizationname().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_organizationalunitname().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_commonname().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).subject_emailaddress().c_str());
        fprintf(p_index_file, "%s", "/");
        for(int j = 0; j< pMsg->pMsg->ssl().certificate(i).certificate_serialnumber().length(); j++)
        {
            fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().certificate(i).certificate_serialnumber().c_str()[j]);
        }
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).notbefore().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).notafter().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).kusage().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).exkusage().c_str());
        fprintf(p_index_file, "%s", "/");
        fprintf(p_index_file, "%s", pMsg->pMsg->ssl().certificate(i).dns_name().c_str());
        if(i + 1  <  size)
        {
            fprintf(p_index_file, "%s", ";");
        }
    }

    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().dh_s_pubkey().length(); i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().dh_s_pubkey().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if((pMsg->pMsg->ssl().dh_s_algorithm_hash()==0)&&(pMsg->pMsg->ssl().dh_s_algorithm_signature()==0))
    {
    fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().dh_s_algorithm_hash());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if((pMsg->pMsg->ssl().dh_s_algorithm_hash()==0)&&(pMsg->pMsg->ssl().dh_s_algorithm_signature()==0))
    {
    fprintf(p_index_file, "%s","");
    }
    else
    {
    fprintf(p_index_file, "%d", pMsg->pMsg->ssl().dh_s_algorithm_signature());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    //if(pMsg->pMsg->ssl().has_dh_s_signature()==true)
    for(int i=0;i < pMsg->pMsg->ssl().dh_s_signature().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().dh_s_signature().c_str()[i]);
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    for(int i = 0; i< pMsg->pMsg->ssl().dh_c_pubkey().length();i++)
    {
        fprintf(p_index_file, "%02x", (unsigned char)pMsg->pMsg->ssl().dh_c_pubkey().c_str()[i]);
    }

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_news(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->scan().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->scan().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%d", pMsg->pMsg->scan().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().search_key().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().board().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().user_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().user_passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().email().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().mobil().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().content().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().verify_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().content_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().keyword().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().charset().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->scan().title().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


void msg_send_plugin::write_shop(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->shop().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->shop().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->shop().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().buy_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().buy_nickname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().sell_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().sell_nichname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().order_num().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().materials_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().goods_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().buyphone().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().buycount().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->shop().money());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().buytime().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().addresstime().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().address().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().contact_account_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().contact_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().leaveword().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().username().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().phone().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().pickup_certificate_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().pickup_certificate().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().reg_account_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().reg_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().pay_account_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().pay_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().reciever_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().associate().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().email().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().color().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->shop().board().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }

}


void msg_send_plugin::write_bbs(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->bbs().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->bbs().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().username().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().password().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().nickname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().bbs_topic().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().board_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().copy_from().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().link_url().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().author().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().issue_status().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().app_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().sessonid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().touid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().to_nickname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().message_text().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().tid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().software().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().content_meta().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().filename().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->bbs().newemail().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);

    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

//job write file
void msg_send_plugin::write_job(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->job().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->job().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->job().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().reg_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().password().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().resume_sex() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().resume_sex());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_certificate_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_certificate_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_mobile().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_address().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().resume_city() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().resume_city());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().file_path().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().email_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_date().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().usename().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().nickname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().birthday() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().birthday());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().wrokyear() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().wrokyear());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().location() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%.6u", pMsg->pMsg->job().location());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().resume_school().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().is_full_time() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().is_full_time());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().edu_from_time() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().edu_from_time());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().edu_to_time() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().edu_to_time());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().edu_degree_input() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().edu_degree_input());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().edu_major().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().edu_detail().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().edu_isoverseas().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().industry_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().issue_date() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().issue_date());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().provide_salary().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().search_key().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().key_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().job_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().company_size().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().company_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().email().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().job_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().title().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    if (pMsg->pMsg->job().emply() == 0)
    {
        fprintf(p_index_file, "%s", " ");
    }
    else
    {
        fprintf(p_index_file, "%u", pMsg->pMsg->job().emply());
    }
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().address().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->job().company_name().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

void msg_send_plugin::write_ticket(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);
    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->ticket().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->ticket().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().flight_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().origin_city().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().dest_city().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().origin_station().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().dest_station().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().begin_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().end_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().air_com().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().flight_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().businesstime().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().pickup_certificate_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().pickup_certificatecode().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_mobilephone().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_email().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().telintersectional().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_telnum().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_ext().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().relationship_address().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().website().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().english_lastname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().english_firstname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().nationlity());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().password().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().company().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().username().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().person_qlty());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().mobilephone().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().nickname().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().using_language().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().study_experience().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().position().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().recentwork().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().connect_account_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().connect_account().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().connect_passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().transfer_city().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().transfer_station().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().adults_qlty());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().child_qlty());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().seat_class().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().ticket_price());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().language().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().pnr().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().search_key_words().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().flight_class().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().flightid_bno().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().order_qty_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%u", pMsg->pMsg->ticket().return_tickets());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().throught_lines().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().wait_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().to_car_no().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().back_car_no().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().to_car_date().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().bak_car_date().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().verify_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().inorout().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().inquiry_time().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().line_no().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().from_station_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().to_station_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().transfer_station_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->ticket().back_time().c_str());
    //fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

// 登陆行为动作写文件
void msg_send_plugin::write_login(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->login().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->login().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->login().user_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().nice_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().mail().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    // fprintf(p_index_file, "%s", pMsg->pMsg->login().confirm_code().c_str());
    fprintf(p_index_file, "%s", "");
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().confirm_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%u", pMsg->pMsg->login().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->login().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", "");
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    // 注册是否成功和验证方式
    fprintf(p_index_file, "%s", pMsg->pMsg->login().status().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->login().authorization().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

// 登出行为动作写文件
void msg_send_plugin::write_logout(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->logout().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->logout().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->logout().user_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    //新增加昵称和邮箱，为了和登出输出文件一致
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().nicke_name().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().mail().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    //fprintf(p_index_file, "%u", pMsg->pMsg->logout().login_time().c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().passwd().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%u", pMsg->pMsg->logout().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->logout().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().uid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", "");
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    // 注册是否成功和验证方式
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().status().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->logout().authorization().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}

// 注册行为动作写文件
void msg_send_plugin::write_register(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    write_Comm_msg(pMsg->pMsg->regist().st_http().common(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    write_c2s_http_head_msg(pMsg->pMsg->regist().st_http().c2s(), p_index_file);
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().engine_type().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().service_provider().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->regist().username().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    //新增加昵称和邮箱，为了和登出输出文件一致
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().nickename().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().email().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().secret().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().resecret().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    // 验证码
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().confirm_code().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%u", pMsg->pMsg->regist().app_id());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%s", pMsg->pMsg->regist().action().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().session_id().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().uuid().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().cell_phone().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file, "%u", pMsg->pMsg->regist().successed());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().authorization().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file, "%s", pMsg->pMsg->regist().old_password().c_str());

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }
}


//quan liu liang
void msg_send_plugin::write_all_stream(CFDataMsg * pMsg)
{
    creat_txt_file(pMsg);

    string txt_path = map_txt_path.find(pMsg->pMsg->type())->second;
    FILE *p_index_file = fopen(txt_path.c_str(), "a");
    if(p_index_file == NULL)
        return;

    fprintf(p_index_file,"%s",pMsg->pMsg->flow_info().dev_num().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%s",pMsg->pMsg->flow_info().line_num().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%lu",pMsg->pMsg->flow_info().capdate_begin());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%d",pMsg->pMsg->flow_info().is_tcp_shakehand_begin());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().come_tcp_max_sclice());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().come_tcp_win_size());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().come_tcp_win_size_multiple());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().cv_tcp_max_sclice());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().cv_tcp_win_size());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().cv_tcp_win_size_multiple());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%lu",pMsg->pMsg->flow_info().capdate_end());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%d",pMsg->pMsg->flow_info().is_tcp_shakehand_discon());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%lu",pMsg->pMsg->flow_info().capdate_duration());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file,"%s",pMsg->pMsg->flow_info().come_ip().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%s",pMsg->pMsg->flow_info().conver_ip().c_str());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().come_port());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().conver_port());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().proto_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().ds_stream_type());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%d",pMsg->pMsg->flow_info().proto());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_send_packages());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_send_sum_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_lost_buyes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_send_unknow_ptks());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_send_unknow_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_win_size_zero_times());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_repeat_package());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_repeat_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_app_payload_packages());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_square_payload_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().src_sum_app_payload_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_send_packages());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_send_sum_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_lost_buyes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_send_unknow_ptks());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_send_unknow_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_win_size_zero_times());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_repeat_package());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_repeat_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_app_payload_packages());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_square_payload_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());
    fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().dst_sum_app_payload_bytes());
    fprintf(p_index_file, "\t%s", devide_sign.c_str());

    for(int j=0;j<pMsg->pMsg->flow_info().package_property_size();j++)
    {
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).package_offset_num_size()*/;n++)
        {
            fprintf(p_index_file,"%d",pMsg->pMsg->flow_info().package_property(j).package_offset_num(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());

            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).package_charst_len(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());

            fprintf(p_index_file,"%s",pMsg->pMsg->flow_info().package_property(j).package_charst(n).c_str());
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).sd_package_noapp_stream_order_size()*/;n++)
        {
            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).sd_package_noapp_stream_order(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).s_package_noapp_stream_order_size()*/;n++)
        {
            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).s_package_noapp_stream_order(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).sd_package_app_payloadlen_size()*/;n++)
        {
            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).sd_package_app_payloadlen(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).sd_package_app_stream_order_size()*/;n++)
        {
            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).sd_package_app_stream_order(n));
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
        for(int n=0;n<10/*pMsg->pMsg->flow_info().package_property(j).s_package_app_stream_order_size()*/;n++)
        {
            fprintf(p_index_file,"%u",pMsg->pMsg->flow_info().package_property(j).s_package_app_stream_order(n));
            if((n == 9)&&(j == (pMsg->pMsg->flow_info().package_property_size() - 1)))
            {
            	break;
            }
            fprintf(p_index_file, "\t%s", devide_sign.c_str());
        }
    }

    fwrite("\n", 1, 1, p_index_file);
    fclose(p_index_file);
    if (map_count.find(pMsg->pMsg->type()) == map_count.end())
    {
        map_count[pMsg->pMsg->type()] = 0;
    }
    else
    {
        int count = map_count.find(pMsg->pMsg->type())->second + 1;
        map_count[pMsg->pMsg->type()] = count;
    }

}



void msg_send_plugin::write_all_xml()
{
    map<int,string>::iterator iter = map_ing_path.begin();
    for ( ; iter != map_ing_path.end(); iter++)
    {
        string ing_path = iter->second;
        int type = iter->first;
        string zip_path = map_zip_path.find(type)->second;
        write_xml(ing_path, zip_path);
        delete_dir(ing_path.c_str());
    }
    map_ing_path.clear();
    map_zip_path.clear();
    map_txt_path.clear();
    zip_count = 0;
}

void msg_send_plugin::write_xml(string ing_path, string zip_path)
{
    string txt_file;
    struct dirent *ptr;
    DIR *dir;
    dir = opendir(ing_path.c_str());
    if(dir == NULL)
    {
        return;
    }
    while((ptr = readdir(dir)) != NULL)
    {
        if (ptr->d_name[0] == '.')
        {
            continue;
        }
        string file_name = ptr->d_name;
        if (file_name.find(".txt", 0) != string::npos)
        {
            txt_file += ptr->d_name;
            txt_file += " ";
        }
    }
    txt_file = txt_file.substr(0, txt_file.size() - 1);
    closedir(dir);

    xmlDocPtr doc = xmlNewDoc(BAD_CAST"1.0");
    xmlNodePtr root_node = xmlNewNode(NULL, BAD_CAST"MESSAGE");
    xmlDocSetRootElement(doc, root_node);
    xmlNodePtr node1 = xmlNewNode(NULL, BAD_CAST"FILE_ATTR_TYPE_1");
    xmlAddChild(root_node, node1);
    xmlNodePtr node2 = xmlNewNode(NULL, BAD_CAST"ITEM");
    xmlNewProp(node2,BAD_CAST"key", BAD_CAST "ENCODE_FORMAT");
    xmlNewProp(node2,BAD_CAST"val", BAD_CAST "utf-8");
    xmlNewProp(node2,BAD_CAST"rmk", BAD_CAST "文件编码格式");
    xmlAddChild(node1, node2);
    xmlNodePtr node3 = xmlNewNode(NULL, BAD_CAST"ITEM");
    xmlNewProp(node3,BAD_CAST"key", BAD_CAST "LINE_SPLIT");
    xmlNewProp(node3,BAD_CAST"val", BAD_CAST "\\n");
    xmlNewProp(node3,BAD_CAST"rmk", BAD_CAST "记录分隔符");
    xmlAddChild(node1, node3);
    xmlNodePtr node4 = xmlNewNode(NULL, BAD_CAST"ITEM");
    xmlNewProp(node4,BAD_CAST"key", BAD_CAST "FIELD_SPLIT");
    xmlNewProp(node4,BAD_CAST"val", BAD_CAST devide_sign.c_str());
    xmlNewProp(node4,BAD_CAST"rmk", BAD_CAST "记录中字段分隔符");
    xmlAddChild(node1, node4);
    xmlNodePtr node5 = xmlNewNode(NULL, BAD_CAST"ITEM");
    xmlNewProp(node5,BAD_CAST"key", BAD_CAST "PARSE_METHOND");
    xmlNewProp(node5,BAD_CAST"val", BAD_CAST "1");
    xmlNewProp(node5,BAD_CAST"rmk", BAD_CAST "无值默认为非k-v格式,1为k-v格式");
    xmlAddChild(node1, node5);
    xmlNodePtr node6 = xmlNewNode(NULL, BAD_CAST"ITEM");
    xmlNewProp(node6,BAD_CAST"key", BAD_CAST "FILE_NAME");
    xmlNewProp(node6,BAD_CAST"val", BAD_CAST txt_file.c_str());
    xmlNewProp(node6,BAD_CAST"rmk", BAD_CAST "文件名");
    xmlAddChild(node1, node6);
    string xml_path = ing_path + "STD_ZIP_INDEX.xml";
    xmlSaveFormatFileEnc(xml_path.c_str(), doc, "UTF-8", 1);
    xmlFreeDoc(doc);

    zip_compress file_compress;
    dir = opendir(ing_path.c_str());
    if(dir == NULL)
    {
        return;
    }
    while((ptr = readdir(dir)) != NULL)
    {
        if (ptr->d_name[0] == '.')
        {
            continue;
        }
        string file_name = ing_path + ptr->d_name;
        file_compress.file_to_zip(zip_path.c_str(), zip_path.size(), file_name.c_str(), file_name.size());
    }
    closedir(dir);
}

void msg_send_plugin::timeout()
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    uint64_t m_timeval = tv.tv_sec * 1000000 + tv.tv_usec;
    //根据valgrind测试出map_last_check_time处有循环删除元素时有无效读问题。
    //在此添加了一个list_type链表用于存放map_last_check_time中关键子key也就是文件类型，然后遍历list将满足条件的语句进行删除
    list<int> list_type;
    map<int,uint64_t>::iterator iter = map_last_check_time.begin();
    for (; iter!=map_last_check_time.end(); ++iter)
    {
        list_type.push_back(iter->first);
    }
    list<int>::iterator iter_list = list_type.begin();

    for ( ; iter_list != list_type.end(); iter_list++)
    {
        if ((m_timeval - iter->second > txt_time * 1000000) || map_count.find(*iter_list)->second > txt_num)
        {
            if(map_txt_path.find(*iter_list) != map_txt_path.end())
            {
                map_txt_path.erase(map_txt_path.find(*iter_list));
            }
            if(map_count.find(*iter_list) != map_count.end())
            {
                map_count.erase(map_count.find(*iter_list));
            }
            if(map_last_check_time.find(*iter_list) != map_last_check_time.end())
            {
                map_last_check_time.erase(map_last_check_time.find(*iter_list));
            }
        }
    }
    list_type.clear();
    if (m_timeval - zip_last_check_time > zip_time * 1000000)
    {
        write_all_xml();
        zip_last_check_time = m_timeval;
        iter = map_last_check_time.begin();
        map_count.clear();
        map_txt_count.clear();
        map_last_check_time.clear();
    }
}


int is_dir(char * filename)
{
    struct stat buf;
    int ret = stat(filename,&buf);
    if(0 == ret)
    {
        if(buf.st_mode & S_IFDIR)
        {
            //printf("%s is folder\n",filename);
            return 0;
        }
        else
        {
            //printf("%s is file\n",filename);
            return 1;
        }
    }
    return -1;
}

int delete_dir(const char *dirname)
{
    char chBuf[256];
    DIR * dir = NULL;
    struct dirent *ptr;
    int ret = 0;
    dir = opendir(dirname);
    if(NULL == dir)
    {
        return -1;
    }
    while((ptr = readdir(dir)) != NULL)
    {
        ret = strcmp(ptr->d_name, ".");
        if(0 == ret)
        {
            continue;
        }
        ret = strcmp(ptr->d_name, "..");
        if(0 == ret)
        {
            continue;
        }
        snprintf(chBuf, 256, "%s/%s", dirname, ptr->d_name);
        ret = is_dir(chBuf);
        if(0 == ret)
        {
            //printf("%s is dir\n", chBuf);
            ret = delete_dir(chBuf);
            if(0 != ret)
            {
                return -1;
            }
        }
        else if(1 == ret)
        {
            //printf("%s is file\n", chBuf);
            ret = remove(chBuf);
            if(0 != ret)
            {
                return -1;
            }
        }
    }
    (void)closedir(dir);

    ret = remove(dirname);
    if(0 != ret)
    {
        return -1;
    }
    return 0;
}
