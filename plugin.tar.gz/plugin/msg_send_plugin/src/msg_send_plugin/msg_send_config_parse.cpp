// Last Update:2016-05-13 11:19:27
/**
 * @file msg_send_config_parse.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2016-05-11
 */

#include "msg_send_config_parse.h"

msg_send_config_parse::msg_send_config_parse()
{

}

msg_send_config_parse::~msg_send_config_parse()
{

}

void msg_send_config_parse::parse(string xmlstr)
{
    xml_parse xml;
    xml.set_file_path(xmlstr.c_str());

    char * p_value = (char *)xml.get_value("/config/txt_time");
    if (p_value != NULL)
    {
        *(msg_send_text::txt_time) = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/txt_num");
    if (p_value != NULL)
    {
        *(msg_send_text::txt_num) = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/zip_time");
    if (p_value != NULL)
    {
        *(msg_send_text::zip_time) = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/result_dir");
    if (p_value != NULL)
    {
        *msg_send_text::result_dir = p_value;
    }

    p_value = (char *)xml.get_value("/config/source");
    if (p_value != NULL)
    {
        *msg_send_text::source = p_value;
    }

    p_value = (char *)xml.get_value("/config/sign");
    if (p_value != NULL)
    {
        *msg_send_text::sign = p_value;
    }

    p_value = (char *)xml.get_value("/config/devide_sign");
    if (p_value != NULL)
    {
        *msg_send_text::devide_sign = p_value;
    }
}
