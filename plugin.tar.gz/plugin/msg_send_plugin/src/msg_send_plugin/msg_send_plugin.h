// Last Update:2016-05-27 15:37:28
/**
 * @file msg_send_plugin.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2016-05-11
 */

#ifndef MSG_SEND_PLUGIN_H
#define MSG_SEND_PLUGIN_H

#include "msg_send_config_parse.h"
#include "CFDataSendBase.h"
#include <commit_tools.h>
#include <sys/types.h>
#include <unistd.h>
#include <sstream>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <dirent.h>
#include "minizip.h"
#include <map>
#include <list>
#include <sys/time.h>
#include <sys/stat.h>
#include <stdio.h>
using namespace std;

extern "C" {
    int GetPluginId();
    CFDataSendBase * FortoryEnterace();
};

class msg_send_plugin : public CFDataSendBase
{
    public:
        msg_send_plugin();
        virtual ~msg_send_plugin();
        virtual void SendData(int len ,char * &buff, CFDataMsg * pMsg);
        virtual bool DistingishSendType(int type)
        {
            return true;
        }
        virtual void timeout();
    private:
        void init_map_action();
        void add_path(CFDataMsg * pMsg);
        void write_txt(CFDataMsg * pMsg);
        void write_telnet(CFDataMsg * pMsg);
        void write_search(CFDataMsg * pMsg);
        void write_news(CFDataMsg * pMsg);
        void write_shop(CFDataMsg * pMsg);
        void write_bbs(CFDataMsg * pMsg);
        void write_webmail(CFDataMsg * pMsg);
        void write_login(CFDataMsg * pMsg);
        void write_logout(CFDataMsg * pMsg);
        void write_register(CFDataMsg * pMsg);
        void write_job(CFDataMsg * pMsg);
        void write_ticket(CFDataMsg * pMsg);
        void write_pptp(CFDataMsg * pMsg);
        void write_l2tp(CFDataMsg * pMsg);
        void write_isakmp(CFDataMsg * pMsg);
        void write_ssh(CFDataMsg * pMsg);
        void write_ssl(CFDataMsg * pMsg);
        void write_all_stream(CFDataMsg * pMsg);
        void creat_txt_file(CFDataMsg * pMsg);
        void write_all_xml();
        void write_xml(string ing_path, string zip_path);
        map<int,string> map_ing_path;
        map<int,string> map_zip_path;
        map<int,string> map_txt_path;
        string result_dir;
        string data_source;
        string data_source_sign;
        string devide_sign;
        int zip_count;

        int txt_time;
        int txt_num;
        int zip_time;

        map<int,int> map_txt_count;
        map<int,int> map_count;
        map<int,uint64_t> map_last_check_time;


        uint64_t zip_last_check_time;

        map<int,string> map_action;

        void write_Comm_msg(const Comm_msg common, FILE *p_index_file);
        void write_c2s_http_head_msg(const c2s_http_head_msg c2s, FILE *p_index_file);
        void write_s2c_http_head_msg(const s2c_http_head_msg s2c, FILE *p_index_file);
};

void itoa(long n, string& str);
int delete_dir(const char *dirname);
#endif  /*MSG_SEND_PLUGIN_H*/
