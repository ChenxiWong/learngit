// Last Update:2016-05-11 10:48:24
/**
 * @file msg_send_config_parse.h
 * @brief 
 * @author zh
 * @version 0.1.00
 * @date 2016-05-11
 */

#ifndef MSG_SEND_CONFIG_PARSE_H
#define MSG_SEND_CONFIG_PARSE_H
#include <stdlib.h>
#include <xml_parse.h>
#include "msg_send_text.h"
using namespace std;

class msg_send_config_parse
{
    public:
        msg_send_config_parse();
        ~msg_send_config_parse();
        void parse(string xmlstr);
};


#endif  /*MSG_SEND_CONFIG_PARSE_H*/
