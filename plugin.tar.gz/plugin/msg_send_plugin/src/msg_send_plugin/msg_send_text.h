// Last Update:2016-05-13 11:16:53
/**
 * @file msg_send_text.h
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2016-05-11
 */

#ifndef MSG_SEND_TEXT_H
#define MSG_SEND_TEXT_H
#include <stdint.h>
#include <string>
#include <pthread.h>
#include <sys/syscall.h>
using namespace std;

class msg_send_text
{
    public:
        static __thread int plugin_id;
        static __thread int* txt_time;
        static __thread int* txt_num;
        static __thread int* zip_time;
        static __thread string *result_dir;
        static __thread string *source;
        static __thread string *sign;
        static __thread string *devide_sign;
};


#endif  /*MSG_SEND_TEXT_H*/
