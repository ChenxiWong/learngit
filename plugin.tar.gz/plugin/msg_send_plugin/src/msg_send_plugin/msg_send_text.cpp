// Last Update:2016-05-12 10:25:39
/**
 * @file msg_send_text.cpp
 * @brief 
 * @author tianfeng
 * @version 0.1.00
 * @date 2016-05-11
 */

#include "msg_send_text.h"
static int temp_txt_time = 120;
static int temp_txt_num = 100000;
static int temp_zip_time = 600;



__thread int msg_send_text::plugin_id = 100001;
__thread int* msg_send_text::txt_time = &temp_txt_time;
__thread int* msg_send_text::txt_num = &temp_txt_num;
__thread int* msg_send_text::zip_time = &temp_zip_time;
__thread string *msg_send_text::result_dir = NULL;
__thread string *msg_send_text::source = NULL;
__thread string *msg_send_text::sign = NULL;
__thread string *msg_send_text::devide_sign = NULL;
