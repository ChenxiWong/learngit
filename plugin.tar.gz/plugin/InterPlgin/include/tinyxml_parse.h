// Last Update:2015-05-08 16:39:09
/**
 * @file tinyxml_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-08
 */

#ifndef TINYXML_PARSE_H
#define TINYXML_PARSE_H
#include <tinyxml.h>
#include <string>
#include <iostream>
using namespace std;
void createXml(const char * ccXmlName) ; 
void readXml(const char * ccXmlName)  ;

string dumpNode(TiXmlNode * pNode,int flag) ;
void dumpTextNode(TiXmlNode * pNode,int flag,string & msg) ;

TiXmlNode * SelectSingleNodeByRootEle(TiXmlElement* RootElement,string nodeName,string nodeAttrName,string nodeAttrValue)  ;
TiXmlNode * SelectSingleNode(const char * cXmlName,string nodeName,string nodeAttrName,string nodeAttrValue)  ;
TiXmlNode * selectChildNode(TiXmlNode * pNode,string nodeName,string nodeAttrName,string nodeAttrValue)  ;



TiXmlNode * get_path_node(TiXmlElement* RootElement , char * src_path);

// char * 路径解析  解析 
#endif  /*TINYXML_PARSE_H*/
