// Last Update:2016-03-24 10:01:19
/**
 * @file pcap_data_offline.h
 * @brief :
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-03-30
 */

#ifndef PCAP_DATA_OFFLINE_H
#define PCAP_DATA_OFFLINE_H

#include <pcap/pcap.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/types.h>

#include <errno.h>
#include <string>
#include <list>
#include <CASqueue.h>
#include <CEnteranceBase.h>

using namespace std;
class pcap_data_offline {
    // -- 
    public:
        pcap_data_offline( thread_pool * SortQueue ,void * pthis);
        ~pcap_data_offline();
         void pcap_parse();
        static void call_back(u_char *user, const struct pcap_pkthdr *hdr, const u_char *pkt);
        
    private:
        void check_dir();
        static void  send_speed_control( );
        list<string> filelist;
        int file_pcap_parse(string filename );

        static  uint64_t  sum_byte_num ; 

        static uint64_t send_begin_time;

        //static int nPut2TimeOut;
        static bool bNeedInitTime;
        
};


#endif  /*PCAP_DATA_OFFLINE_H*/
