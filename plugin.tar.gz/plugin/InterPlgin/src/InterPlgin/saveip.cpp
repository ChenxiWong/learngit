////////////////////////////////////////////////////////////////////////
/// \filename      :  CSaveSpecialIp.cpp
/// \date          :  2016-07-9   14:16:53
/// \author        :  phl
/// \brief comment :  
/// \modify
/// \time          : 
/// \author        :
/// \comment       :
/// \file purpose  :    
////////////////////////////////////////////////////////////////////////

#define F_INPUT_MODE   "r"
#define F_OUTPUT_MODE  "wb"

#include <stdio.h>
#include <readline/readline.h>
#include <readline/history.h>

#include "saveip.h"
CSaveSpecialIp::CSaveSpecialIp()
{
    memset(m_Table,0x0,sizeof(m_Table));
    m_nSum=0;
}


CSaveSpecialIp::~CSaveSpecialIp()
{
    Close();
}


void CSaveSpecialIp::Close()
{
    for (int i=0 ;i< HASHLEN;i++)
    {
        Node * pNode=m_Table[i];
        if (pNode) 
        {           
            while (pNode) 
            {               
                Node * tmp =pNode;
                pNode=pNode->pNext;
                delete tmp;
            }
        }
        m_Table[i]= NULL;
    }
}

int CSaveSpecialIp::Init(string pathFile)
{
    string  ipStr;

    u_int32_t   nIp;

    FILE* infile;
    
    infile = fopen(pathFile.c_str(), F_INPUT_MODE);
    if (infile == NULL)
    {
        printf("error! CSaveSpecialIp::Init(string pathFile) Failed to open %s\r\n",pathFile.c_str());
        return 0;
    }

    char *line = NULL;
    size_t len = 0;
    int read;
    
    while ((read = getline(&line, &len, infile)) != -1) 
    {
        printf("Retrieved line of length %u :\n", read);
        printf("%s", line);         
        string str = line;
        string::size_type cur;
        string host = "";
        cur = str.find("\t");
        if (cur != string::npos)
        {
            host = str.substr(0, cur);
            str = str.substr(cur+strlen("\t"));
        }
        else
        {
            continue;
        }
        if (len>6) 
        {
            //nIp=InetAddr(line);
            nIp=InetAddr(str.c_str());
            if(nIp > 0)
            {
                AddIp(nIp, host);
            }
        }
        else
        {
            break;
        }           
    }
    
    free(line);
    fclose(infile);
    return 0;
}

int CSaveSpecialIp::AddIp(u_int32_t nIP, string& str_host)
{
    if (nIP == 0) 
    {
        //����
        return -1;
    }
    printf("CSaveSpecialIp::AddIp() nIP=%u.\n", nIP);

    
    Node * pTmpNode;
    u_int16_t nHash=Hash(nIP);
    Node * pNode=m_Table[nHash];
    if (pNode == NULL) 
    {
        pTmpNode=new Node;
        //20160714 �����������
        pTmpNode->m_index = m_nSum;
        m_ipName[m_nSum]=ntohl(nIP);
        m_hostName[m_nSum] = str_host;
        pTmpNode->nIp=nIP;
        pTmpNode->pNext = NULL;         
        m_Table[nHash]=pTmpNode;
        m_nSum++;
    }
    else
    {
        while (pNode) 
        {
            
            if (pNode->nIp == nIP ) 
            {
                //�Ѿ������ip
                return 3;
            }   
            pNode=pNode->pNext;
            
        }
        pNode=m_Table[nHash];
        pTmpNode=new Node;
        //20160714 �����������
        pTmpNode->m_index = m_nSum;
        m_ipName[m_nSum]=ntohl(nIP);
        m_hostName[m_nSum] = str_host;
        pTmpNode->nIp=nIP;
        pTmpNode->pNext = m_Table[nHash];
        m_Table[nHash]=pTmpNode;
        m_nSum++;
    }
    //��ȷ����

    printf("CSaveSpecialIp::AddIp() nIP=%u nHash=%u[%d].\n", nIP,nHash,m_nSum);
    return 0;
}


int CSaveSpecialIp::IsSave(u_int32_t nIp)
{
    //20160714 �����������
    //�Ľ�����ֵ�����ڵ���0ʱ����ʾ������

    u_int16_t nHash=Hash(nIp);
    Node * pNode=m_Table[nHash];
    int ret =-1;
    while (pNode) 
    {
        if (pNode->nIp==nIp)
        {
            ret= pNode->m_index;
            break;
        }
        pNode=pNode->pNext;
    }
    
    //printf("CSaveSpecialIp::IsSave() nIp=%u nHash=%u IsSave=%d.\n", nIp,nHash,ret);
    
    return ret;
}


u_int32_t CSaveSpecialIp::InetAddr(const char* pIp)
{
    if (pIp == NULL)
        return 0;
    
    int nLgh = strlen(pIp);
    char szAddr[4][4];
    memset(szAddr,0,sizeof(szAddr));
    int j = 0;
    int x = 0;
    for (int i=0; i<nLgh; i++)
    {
        
        if (*(pIp+i) == '.')
        {
            szAddr[j][x] = '\0';
            j++;
            x =0;
        }
        else
        {
            //20160719 �޸��س�����ʶ��©�� by phl 
            if ( *(pIp+i) == '\n' || *(pIp+i) == '\r' )
            {
                break;
            }
            if (x >= 3 )
            {
                return 0;
            }            
            //20160719 �޸��س�����ʶ��©�� by phl 
            if ( (szAddr[j][x++] = *(pIp+i)) == '0' )
                if (szAddr[j][0] == '0')
                    x--;            
        }
    }
    
    u_int32_t a0,a1,a2,a3;
    a0 = atoi(szAddr[0]);
    a1 = atoi(szAddr[1]);
    a2 = atoi(szAddr[2]);
    a3 = atoi(szAddr[3]);
    u_int32_t nn0 = a0<<24;
    u_int32_t nn1 = a1<<16;
    u_int32_t nn2 = a2<<8;  
    u_int32_t IP = nn0+nn1+nn2+a3;
    return IP;
};

