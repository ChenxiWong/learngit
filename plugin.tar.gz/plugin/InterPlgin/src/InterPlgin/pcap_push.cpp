/*
 * pcap_push.cpp
 *
 *  Created on: 2016年4月12日
 *      Author: cuixiaobo
 */

#include <stdio.h>
#include "pcap_push.h"

thread_write_file::thread_write_file()
{
    p_file_all_pcap = NULL;
    p_file_ip_pcap = NULL;
    p_file = NULL;
    p_file_pcap= NULL;
    reload();

}

thread_write_file::~thread_write_file()
{
    if(InterText::save_pcap_flag != 0)
    {
        if(InterText::save_pcap_flag == 1)
        {
            free(p_file_all_pcap);
        }
        else if(InterText::save_pcap_flag == 2)
        {
            free(p_file);
        }
        else if(InterText::save_pcap_flag == 3)
        {
            free(p_file_pcap);
        }
        else if(InterText::save_pcap_flag == 4)
        {
            free(p_file_all_pcap);
            free(p_file);
            free(p_file_pcap);
        }
        if(InterText::save_pcap_flag == 5)
        {   
            //释放ip列表存包对象
            /*
            for(int index =0 ; index < InterText::save_pcap_ip->m_nSum ; index++)
            {
                 p_file_ip_pcap[index].p_strfile_name = NULL;
            }
            */
            free(p_file_ip_pcap);
        }
    }

}

void thread_write_file::reload()
{
    if(InterText::save_pcap_flag != 0)
    {
        //thread_write_file_fun::get_instrance();//->set_pthread_pool_fun();
        if(InterText::save_pcap_flag == 1)
        {
            p_file_all_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file_all_pcap->fp = NULL; //用于初始化空间下边类似解决valgrind中进行无效读取
            p_file_all_pcap->buffer = NULL;
            p_file_all_pcap->p_strfile_name = NULL;
            buf_file_init(p_file_all_pcap,1,InterText::save_all_pcap_name);
        }
        else if(InterText::save_pcap_flag == 2)
        {
            p_file =  (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file->fp = NULL;
            p_file->buffer = NULL;
            p_file->p_strfile_name = NULL;
            buf_file_init(p_file,1,InterText::save_pfring_lost_name);
        }
        else if(InterText::save_pcap_flag == 3)
        {
            p_file_pcap =  (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file_pcap->fp = NULL;
            p_file_pcap->buffer = NULL;
            p_file_pcap->p_strfile_name = NULL;
            buf_file_init(p_file_pcap,1,InterText::save_pcap_lost_name);
        }
        else if(InterText::save_pcap_flag == 4)
        {
            p_file_all_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
            p_file_all_pcap->fp = NULL;
            p_file_all_pcap->buffer = NULL;
            p_file_all_pcap->p_strfile_name = NULL;
            p_file->fp = NULL;
            p_file->buffer = NULL;
            p_file->p_strfile_name = NULL;
            p_file_pcap->fp = NULL;
            p_file_pcap->buffer = NULL;
            p_file_pcap->p_strfile_name = NULL;
            buf_file_init(p_file_all_pcap,1,InterText::save_all_pcap_name);
            buf_file_init(p_file,1,InterText::save_pfring_lost_name);
            //memset((char *)p_file_pcap,0x0,sizeof(struct write_buf_file));p_file_all_pcap
            buf_file_init(p_file_pcap,1,InterText::save_pcap_lost_name);
        }
        else if(InterText::save_pcap_flag == 5)
        {        
            //2016-07-18 phl 添加if-NULL判断
            if(NULL==p_file_ip_pcap)
            {
                //创建ip列表存包对象
                p_file_ip_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file) *  InterText::save_pcap_ip->m_nSum );
                //20160714 每个ip一个存包对象
                for(int index =0 ; index < InterText::save_pcap_ip->m_nSum ; index++)
                {
                    //下边代码主要用于将IP以及HOST以及save_ip_pcap_name配置的名字拼接在ipName中
                    char ipName[256];
                    memset(ipName,0x0,256);
                    int nlen = strlen(InterText::save_ip_pcap_name);
                    memcpy(ipName,InterText::save_ip_pcap_name,nlen);
                    sprintf(ipName+strlen(ipName), "%s", "_");
                    inet_ntop(AF_INET, (void *)&(InterText::save_pcap_ip->m_ipName[index]), ipName+strlen(ipName), 16);   
                    sprintf(ipName+strlen(ipName), "_%s", InterText::save_pcap_ip->m_hostName[index].c_str());
                    p_file_ip_pcap[index].p_strfile_name = NULL;
                        
                    buf_file_init(&p_file_ip_pcap[index],1,ipName);
                    /*
                    c_ip ip = c_ip( InterText::save_pcap_ip->m_ipName[index]);
                    string name = InterText::save_ip_pcap_name;
                    name = name + ip.ip_str();      
                    buf_file_init(&p_file_ip_pcap[index],1,name.c_str());
                    */
                }
            }
            //20160718
        }
    }
}

void thread_write_file::timeout()
{
    if(InterText::save_pcap_flag != 0)
    {
        if(InterText::save_pcap_flag == 1)
        {
            if(p_file_all_pcap->sumlen != 24)
            {
                buf_file_destroy(p_file_all_pcap);
                buf_file_init(p_file_all_pcap,1,InterText::save_all_pcap_name);
            }
        }
        else if(InterText::save_pcap_flag == 2)
        {
            if(p_file->sumlen != 24)
            {
                buf_file_destroy(p_file);
                buf_file_init(p_file,1,InterText::save_pfring_lost_name);
            }
        }
        else if(InterText::save_pcap_flag == 3)
        {
            if(p_file_pcap->sumlen != 24)
            {
                buf_file_destroy(p_file_pcap);
                buf_file_init(p_file_pcap,1,InterText::save_pcap_lost_name);
            }
        }
        else if(InterText::save_pcap_flag == 4)
        {
            if(p_file_all_pcap->sumlen != 24)
            {
                buf_file_destroy(p_file_all_pcap);
                buf_file_init(p_file_all_pcap,1,InterText::save_all_pcap_name);
            }
            if(p_file->sumlen != 24)
            {
                buf_file_destroy(p_file);
                buf_file_init(p_file,1,InterText::save_pfring_lost_name);
            }
            if(p_file_pcap->sumlen != 24)
            {
                buf_file_destroy(p_file_pcap);
                buf_file_init(p_file_pcap,1,InterText::save_pcap_lost_name);
            }
        }
        else  if(InterText::save_pcap_flag == 5)
        {
           
            //超时处理ip列表存包对象
            for(int index =0 ; index < InterText::save_pcap_ip->m_nSum ; index++)
            {
                 if(p_file_ip_pcap[index].sumlen != 24)
                 {                  
                    buf_file_destroy(&p_file_ip_pcap[index]);
                    
                    char ipName[256];
                    memset(ipName,0x0,256);
                    int nlen = strlen(InterText::save_ip_pcap_name);
                    memcpy(ipName,InterText::save_ip_pcap_name,nlen);
                    sprintf(ipName+strlen(ipName), "%s", "_");
                    inet_ntop(AF_INET, (void *)&(InterText::save_pcap_ip->m_ipName[index]), ipName+strlen(ipName), 16);               
                    sprintf(ipName+strlen(ipName), "_%s", InterText::save_pcap_ip->m_hostName[index].c_str());//在文件名中IP后边添加host
                    buf_file_init(&p_file_ip_pcap[index],1,ipName);

                    /*
                    c_ip ip = c_ip( InterText::save_pcap_ip->m_ipName[index]);
                    string name = InterText::save_ip_pcap_name;
                    name = name + ip.ip_str();      
                    buf_file_init(&p_file_ip_pcap[index],1,name.c_str());
                    */
                }
            }
    
            //超时处理ip列表存包对象
            //buf_file_destroy(p_file_ip_pcap);
            //buf_file_init(p_file_ip_pcap,1,InterText::save_ip_pcap_name);
            
        }
    }
}

void thread_write_file::_Work(work_data * &pworkdata)
{
    thread_write_file_data *p_data_msg = (thread_write_file_data *)pworkdata;
    //p_data_msg->flag  = InterText::save_pcap_flag;
    // c_packet *p_data = (c_packet *) p_data_msg->data;
    //printf("p_data************** = %s\n",p_data->p_app_data);
    if (p_data_msg->type == TIMEOUT) //该处用于处理valgrind测出来的p_data_msg->flag无效读取数据
    {
        return ;
    }
   
   
    if(p_data_msg->flag == 1)
    {
        write_packet_file_p(p_file,p_data_msg);
    }
    else if(p_data_msg->flag == 2)
    {
        write_packet_file_p(p_file_pcap,p_data_msg);
    }
    else if(p_data_msg->flag == 3)
    {
        write_packet_file_p(p_file_all_pcap,p_data_msg);
    }
    else if(p_data_msg->flag == 4)
    {
        //保存ip列表存包
        write_packet_file_p(&p_file_ip_pcap[p_data_msg->pFileIndex],p_data_msg);
    }
    //free(p_file);
    //将超时处理注释掉，使生成文件大的大小为126MB
  /*  if(pworkdata->type == TIMEOUT)
    {
        timeout();
    }*/
}

void thread_write_file::write_packet_file_p(write_buf_file *p_file_real,thread_write_file_data *pdata)
{
    if(pdata == NULL)
    {
        return;
    }
    if(pdata->buf != NULL && pdata->len >0)
    {
        p_file_real -> write_packet_file(p_file_real,(char *)pdata->buf,pdata->len,pdata->ts);
    }
}

thread_write_file_fun::thread_write_file_fun()
{
    pp_work = new thread_write_file*[InterText::thread_pcap_lost_num];
    int i = 0;
    for(i = 0;i< InterText::thread_pcap_lost_num;i++)
    {
        pp_work[i] = new thread_write_file();
    }
    thpool.set_thread_pool(InterText::thread_pcap_lost_num,(work_base**)pp_work,false,InterText::queue_len);
    int_num_thread = InterText::thread_pcap_lost_num;
}

void thread_write_file_fun::set_pthread_pool_fun()
{
    /*pp_work = new thread_write_file*[1];
      int i = 0;
      for(i = 0;i< 1;i++)
      {
      pp_work[i] = new thread_write_file();
      }
      thpool.set_thread_pool(1,(work_base**)pp_work,false,1000);
      int_num_thread = 1;*/
}


thread_write_file_fun::~thread_write_file_fun()
{
    int i = 0;
    for(;i < int_num_thread ; i++)
    {
        delete pp_work[i];
    }
    delete [] pp_work;
}

void thread_write_file_fun::send_data(thread_write_file_data *p_file_data)
{
    thpool.push(p_file_data,p_file_data->hash);
}

void thread_write_file_fun::Timeout()
{
    int i = 0 ;
    for(;i < int_num_thread ; i++ )
    {
        Pcap_cont * p = new Pcap_cont();
        p->type = TIMEOUT;
        thpool.push_back(p,i);
    }
}

