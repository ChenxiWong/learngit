// Last Update:2016-04-11 17:09:02
/**
 * @file InterPlugin.h
 * @brief : 数据接入插件，暂时使用PF-RING
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-25
 */

#ifndef _INTER_PLUGIN_H
#define _INTER_PLUGIN_H

#include <CEnteranceBase.h>
#include <DataFormatBase.h>
#include <CASqueue.h>
#include  "InterConfigParse.h"
//#if (PFRING)
#include "c_pfring.h"
//#endif
#include "c_dpdk.h"
#include <string>
#include <packet.h>
#include <list>
#include <session_hash.h>
#include "out_put_data.h"
#include "protocol_plugin_marge.h"
#include "pcap_data_offline.h"
#include "pcap_push.h"
#include "linkDecodeInterface.h"
using namespace std;
extern "C" {
        int GetPluginId();
        CEnteranceBase * FortoryEnterace();
        FormatHandleBase * FortoryDataFormat();
};
class InterPlugin : public CEnteranceBase
{
    public:
        InterPlugin();
        ~InterPlugin();
        virtual void  _Recv(string config ,  thread_pool  * pSortQueue) ; // 读取数据- 
        virtual void  reload()  ;
        virtual int ParseAndStiring(NodeData* pData) ;//数据分捡
        static bool m_bReady;
    private:
       void config();
       CIneterConfigParse  Parse; 
//#if (PFRING)
       c_pfring * p_pfring;
//#endif
       c_dpdk * p_dpdk;
       pcap_data_offline  * p_savefile;
       string sConfile;
       thread_pool thpool;
       thread_write_file **ppwork;

};
class InterDataFormat : public FormatHandleBase
{
    public:
        InterDataFormat();
        ~InterDataFormat();
        virtual void FromatData(NodeData *  pdata , TCFDATALIST * plist) ;
//        virtual void  JugeRepeatReady(CFDataMsg  *  pdata,string & JugeData,string & JugeFile) ;
        virtual void Reload()  ; 
        virtual void TimeOut (TCFDATALIST * plist) ; 
        list<data_interface>  p_data_interface_list;
        out_put_data m_out_put;
        TCFDATALIST * out_plist;
//phl 2016-11-13 add
		uint32_t workid;
		void* Receive(uint32_t  id );
//phl 2016-11-13

    private:
        bool protocol_identify(session * p_sess , c_packet * p_packet);
      //  int allflow_data_handle(void *pObj,out2protobuf *pdata);
        int initLinkPpt();
        session_hash * m_phash;
       // list<data_interface>  p_data_interface_list;
        t_procotol_handle_map plugin_handle_map;
       // out_put_data m_out_put;
       // TCFDATALIST * out_plist;
        string m_rootPath;
	    c_dpdk * m_pDpdk ;
//        CIneterConfigParse  Parse; 
};

int allflow_handle_dataout(list<data_interface> * p_list,const out2protobuf  & outData);

#endif  /*_INTEL_PLUGIN_H*/
