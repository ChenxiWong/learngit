// Last Update:2016-03-03 14:05:25
/**
 * @file protocol_parse_base_handle.cpp
 * @brief :
 * @author lidandan
 * @version 0.1.00
 * @date 2016-02-26
 */
#include <protocol_parse_base_handle.h>
extern protocal  protocal_instance ;
void protocal::PotocolStatistics(int PotocolType , int record_num , int filesize , int effective_num) 
{
    if(MAXPLUGINNUM > PotocolType )
    {
        PluginStatistics *p_Plugin = &(StatisArray[PotocolType]);
        __sync_fetch_and_add(&(p_Plugin -> record_num) , record_num  );
        __sync_fetch_and_add(&(p_Plugin -> filesize) , filesize  );
        __sync_fetch_and_add(&(p_Plugin -> effective_num)  , effective_num );
    }
}
void protocal::PotocolHandlePacketStatistics(int PotocolType )
{
    if(MAXPLUGINNUM > PotocolType )
    {
        PluginStatistics *p_Plugin = &(StatisArray[PotocolType]);
        __sync_fetch_and_add(&(p_Plugin -> handle_num ) , 1  );
    }
}
PluginStatistics  protocal::GetPocolValue(int PotocolType) 
{
    return  StatisArray[PotocolType];
}
void protocal ::StatisticsSortHandlenum()
{
        __sync_fetch_and_add(&(sort_handle_packet ) , 1  );
}
uint64_t protocal::getSortHandlenum() 
{
    return  sort_handle_packet ;
}

void sync_uint64_add(uint64_t & data ,int  num ) 
{
    __sync_fetch_and_add(&(data ) , num );
}
void sync_uint32_add(uint32_t & data ,int  num ) 
{
    __sync_fetch_and_add(&(data ) , num );
}
void sync_int_add(int & data ,int  num ) 
{
    __sync_fetch_and_add(&(data ) , num );
}
