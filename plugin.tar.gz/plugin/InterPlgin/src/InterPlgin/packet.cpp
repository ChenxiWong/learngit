// 
// Last Update:2016-06-17 16:50:22
/**
 * @file packet.cpp
 * @brief-
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-03-30
 */
#include "packet.h"
#include <sstream>
#include <iomanip> 
#include <stdlib.h>
#ifdef DPDK_SUPPLY
#include "DpdkInterface.h"
funFree c_packet::pfunFree = PortReleaseData;
#else
funFree c_packet::pfunFree = NULL;
#endif

c_packet::c_packet()
{
    b_vpn = false;
    buff = NULL;
    p_ethhdr   = NULL;
    p_iphdr    = NULL;
    p_ipv6hdr   = NULL;
    p_udphdr   = NULL;
    p_tcphdr   = NULL;
    p_app_data     = NULL;
    dpdkfree = NULL;
    app_data_len   = 0;
    buff =  NULL;
    m_is_mpls = 0;
    m_label = 0;
    m_inner_label = 0;
    m_other_lable = 0;
    b_is_tcp = true; //解决valgrind测试出来使用未初始化空间
    rule_reulst = NULL;
    dpdkidx =-1;
}
void c_packet::prepare_rule_for_identify()
{
    rule_reulst = new rule();
}
c_packet::~c_packet()
{
    if(dpdkfree != NULL)
    {
#ifdef  DPDK_SUPPLY
        //PortReleaseData(dpdkidx , dpdkfree) ;
        pfunFree(dpdkidx , dpdkfree,-1) ;
#endif
    }
    else
    {
        if(buff != NULL)
        {
            delete [] buff;
        }
        buff = NULL;
    }
    if(rule_reulst != NULL)
    {
        delete rule_reulst;
        rule_reulst = NULL;
    }
}
void c_packet::init_packet(const c_packet * res)
{
    
    // 
    this -> buff_len = res -> buff_len ;
    memcpy(this -> buff , res -> buff , res->buff_len); 
    this -> b_vpn = res ->b_vpn ;
    this -> vpn_dst_ip = res -> vpn_dst_ip ;
    this -> vpn_src_ip = res -> vpn_src_ip ;
    //  -----------  tcp 
    if(res -> p_tcphdr != NULL) 
    {
        this -> p_tcphdr = (tcphdr *)(this -> buff + ((uint8_t *) res -> p_tcphdr - res -> buff ));
    }
    else 
    {
        this -> p_tcphdr == NULL; 
    }
    // udp 
    if(res -> p_udphdr != NULL) 
    {
        this -> p_udphdr = (udphdr *)(this -> buff + ((uint8_t *) res -> p_udphdr - res -> buff ));
    }
    else 
    {
        this -> p_tcphdr == NULL; 
    }
    // app data 
    if(res -> p_app_data != NULL) 
    {
        this -> p_app_data = ( u_int8_t*)(this -> buff + ((uint8_t *) res -> p_app_data - res -> buff ));
    }
    else 
    {
        this -> p_app_data == NULL; 
    }
    //m_timeval 
    this ->m_timeval = res -> m_timeval ;
    this ->app_data_len = res->app_data_len ;
    this ->b_is_tcp = res -> b_is_tcp ;
    pfunFree = NULL; 
    this -> dpdkfree = res -> dpdkfree ;
    // app data 
    if(res -> p_ethhdr != NULL) 
    {
        this -> p_ethhdr = ( ethhdr *)(this -> buff + ((uint8_t *) res -> p_ethhdr - res -> buff ));
    }
    else 
    {
        this -> p_ethhdr == NULL; 
    }
    // 
    if(res -> p_iphdr != NULL) 
    {
        this -> p_iphdr = ( iphdr *)(this -> buff + ((uint8_t *) res -> p_iphdr - res -> buff ));
    }
    else 
    {
        this -> p_iphdr == NULL; 
    }
    //
    if(res -> p_ipv6hdr != NULL) 
    {
        this -> p_ipv6hdr = ( ip6_hdr *)(this -> buff + ((uint8_t *) res -> p_ipv6hdr - res -> buff ));
    }
    else 
    {
        this -> p_ipv6hdr == NULL; 
    }

}
bool c_packet::parse(uint8_t *p_cap_data,uint32_t len)
{
    if(p_cap_data == NULL || len == 0)
    {
        return false;
    }
    //buff = (uint8_t *)new char [len];//p_cap_data;
    buff = p_cap_data;
    buff_len = len ;

    if(t_parse(buff, len))
    {
        m_timeval       =  0 ;
        return true;
    }

    return false;
}
bool c_packet::parse(uint8_t *p_cap_data,uint32_t len,timeval ts)
{
    if(p_cap_data == NULL || len == 0)
    {
        return false;
    }
    buff = p_cap_data;
    buff_len = len ; 
    //memcpy(buff,p_cap_data,len);
    //不论是否解析，保证时间戳正确
    //使得存包功能时间正确
    m_timeval       = ts.tv_sec * 1000000 + ts.tv_usec;
    m_ts  = ts;
    if(t_parse(buff, len))
    {
        return true;
    }
    return false;
}
bool c_packet::parse(int idx,void * pfree,uint8_t *p_cap_data,uint32_t len,timeval ts,bool bCopy)
{
    // ------ 
    struct timeval tv ;
    gettimeofday(&tv,NULL);
    //buff = p_cap_data ;
    //buff_len = len ;
    if(!bCopy)
    {
        dpdkfree = pfree;
        dpdkidx =idx;
        return parse(p_cap_data,len,tv);
    }
    else
    {
        dpdkfree =NULL;
        dpdkidx = -1;
        buff = (uint8_t *)malloc( ((len>>8)+1)<<8 );
        memcpy(buff,p_cap_data,len);
        p_cap_data =NULL;
        return parse(buff,len,tv);
    }
    
}




bool c_packet::t_parse(uint8_t *p_capdata, uint32_t len)
{

    uint8_t * p_mac_begin  = NULL;
    bool b_ipv6 = false;
    uint8_t ip_type = 0;

    p_mac_begin = p_capdata;
    uint16_t mac_type = ntohs(*((unsigned short*) (p_mac_begin + 12)));
    uint32_t offise = 14;
    uint8_t * p_rawpacket = p_capdata;
    bool b_is_ip = false;
    p_ethhdr = (struct ethhdr *) p_mac_begin;
    bool b_ip_true = false ;
    // 判断是否是 空MAC
    if(*p_mac_begin == 0x0F  && *(p_mac_begin +1 ) == 0x00)
    {
        offise = 4;
        mac_type = ntohs(*((unsigned short*) (p_mac_begin + 2)));
    }
    //值解析IP的协议  // 暂时不考虑 VLAN
    while(!b_ip_true )
    {
        if(offise >= len ) return false;
        switch(mac_type) 
        {
            case 0x0800:// IPV4 
                {
                    b_is_ip = true;
                    b_ip_true = true;
                    break;
                }
                break;
            case 0x86dd: //IPV6
                {
                    b_is_ip = true;
                    b_ipv6 = true;
                    b_ip_true = true;
                    break;
                }
                break;
            case 0x8100: //VLAN
                offise +=2 ;
                mac_type = ntohs(*((unsigned short*) (p_mac_begin + offise)));
                offise += 2 ;
                break;
            case 0X8848: //MPLS v6
                b_ipv6 = true;
            case 0X8847: // MPLS 1
                {
                    //修复mpls的bug，
                    //原有解析不符合mpls的协议解析
                    //统计
                    m_is_mpls = 1;
                    ++m_label;

                    u_int32_t nMPLS = 0;
                    u_int32_t nBos = 0;
                    nMPLS = ntohl( *(u_int32_t *)(p_mac_begin + offise) );
                    nBos = (u_int32_t)( nMPLS & 0x00000100 );

                    if(m_inner_label == 0)
                    {
                        m_inner_label = (u_int32_t)(( nMPLS & 0xfffff000 )>>12);
                    }
                    b_is_ip = true;
                    if(nBos)
                    {
                        b_ip_true = true;
                        m_other_lable = (u_int32_t)(( nMPLS & 0xfffff000 )>>12);
                    }

                    offise += 4;

                    //以下臆造的规律不存在
                    /*
                       b_is_ip = true;
                       if(*(p_mac_begin  + offise) == 0x0)
                       {
                       offise += 4;
                       break;
                       }
                       else if(*(p_mac_begin  + offise) == 0x1)
                       {
                       b_ip_true = true;
                       offise += 4;
                       break;
                       }
                       */
                }
                break;
            default:
                return false;
        }
        /*if(mac_type == 0x0800 ) 
          {
          b_is_ip = true;
          break;
          }
          else if( mac_type == 0x86dd)
          {
          b_is_ip = true;
          b_ipv6 = true;
          break;
          }
          else if(mac_type == 0x8100)
          {
          offise +=2 ;
          mac_type = ntohs(*((unsigned short*) (p_mac_begin + offise)));
          offise += 2 ;
          }
          else {
          return false;
          }*/

    }
    uint16_t iplen = 0;
    if(b_ipv6 )
    {
        p_ipv6hdr = (struct ip6_hdr *) ( p_rawpacket + offise);
        //ip_type = p_ipv6hdr->ip6_un1->ip6_un1_nxt;
        offise += 40; 
        while(true) // ipv6扩张头 
        {
            if(ip_type == IPPROTO_TCP || ip_type == IPPROTO_UDP)
            {
                break;
            }
            else {
                return false;
            }
        }
    }
    else 
    {
        p_iphdr = (struct iphdr*) ( p_rawpacket + offise);
        iplen = ntohs(p_iphdr->tot_len);
        if(iplen == 0)
        {
            p_iphdr->tot_len = htons(len - offise);
            iplen = ntohs(p_iphdr->tot_len);
        }
        else if((len < iplen + offise) && (ip_type == IPPROTO_GRE))
        {
            return false;
        }
        ip_type = p_iphdr->protocol;

        offise +=   p_iphdr->ihl * 4;
    }

    //GRE协议解析
    if(ip_type == IPPROTO_GRE)
    {
        b_vpn = true;
        vpn_dst_ip = get_dst_ip();
        vpn_src_ip = get_src_ip();
        uint16_t gre_flag = ntohs(*((uint16_t*)(p_rawpacket + offise)));
        uint16_t gre_protocol_type = ntohs(*((uint16_t*)(p_rawpacket + offise + 2)));
        //printf("gre protocol type:%x \t",gre_protocol_type);
        offise += 4;
        if((gre_flag & 0x4000) != 0)            //路由标志位
        {
            offise+=8;
        }
        else if((gre_flag & 0x8000) != 0)       //校验和标志位
        {
            offise+=4;
        }
        if((gre_flag & 0x2000) != 0)            //密钥标志位
        {
            offise+=4;
        }
        if((gre_flag & 0x1000) != 0)            //序列号同步标志位
        {
            offise+=4;
        }
        if((gre_flag & 0x0080) !=0)             //序列号确认标志位
        {
            offise+=4;
        }
        switch(gre_protocol_type)             //目前仅考虑PPP协议封装IPv4协议的情况
        {
            case GRE_PROTO_PPP:
                {
                    uint16_t ppp_protocol = ntohs(*((uint16_t*)(p_rawpacket + offise)));
                    offise += 2;
                    //printf("ppp protocol type:%x \t",ppp_protocol);
                    if(ppp_protocol == 0x0021)      //ipv4协议
                        break;
                    else
                        return false;
                    break;
                }
            default:
                return false;
                break;
        }
        //ipv4协议解析
        b_ipv6 = false;
        p_iphdr = (struct iphdr*) ( p_rawpacket + offise);
        iplen = ntohs(p_iphdr->tot_len);
        if(iplen == 0)
        {
            p_iphdr->tot_len = htons(len - offise);
            iplen = ntohs(p_iphdr->tot_len);
        }
        else if(len < iplen + offise)
        {
            return false;
        }
        ip_type = p_iphdr->protocol;             //ip_type复用
        offise += p_iphdr ->ihl * 4;
        //printf("ip type:%x\n",ip_type);
        //offise += sizeof(struct iphdr);
        //vpn_count++;
        //printf("%ld\n",vpn_count);
    }


    if (ip_type == IPPROTO_TCP)
    {
        b_is_tcp = true;
        p_udphdr = NULL;

        p_tcphdr = (struct tcphdr *) ( p_rawpacket + offise);
        offise += p_tcphdr->doff * 4;


        //根据握手包进行方向判断。
        ack_seq = p_tcphdr->ack_seq;
        syn = p_tcphdr->syn;


        p_app_data   = (uint8_t *) (p_rawpacket + offise );
        app_data_len = iplen - p_iphdr->ihl * 4 - p_tcphdr->doff * 4;
        //#define IP_MF       0x2000      /* Flag: "More Fragments"   */
        //#define IP_OFFSET   0x1FFF      /* "Fragment Offset" part   */

        if (p_iphdr->frag_off & htons(0x2000|0x1FFF))
        {
        }
        //ip分片可能小于
        else if(app_data_len + offise > len)
        {
            return false;
        }

        return true; //(p_rawpacket != NULL);
    }
    else if(ip_type== IPPROTO_UDP)
    {
        b_is_tcp = false;
        p_tcphdr = NULL; 
        p_udphdr = (struct udphdr *)(p_rawpacket + offise) ; 
        offise += sizeof(struct udphdr);
        p_app_data = (uint8_t *) (p_rawpacket + offise);
        app_data_len= ntohs(p_udphdr  -> len)  - sizeof(struct udphdr);

        //#define IP_MF       0x2000      /* Flag: "More Fragments"   */
        //#define IP_OFFSET   0x1FFF      /* "Fragment Offset" part   */
        if (p_iphdr->frag_off & htons(0x2000|0x1FFF))
        {

        }
        //ip分片可能小于
        else if(app_data_len > len - offise) 
        {
            return false;
        }
        return true;
    }
    return false;
}

uint64_t c_packet::get_dst_mac()
{
    return BCD2UInt64(p_ethhdr->h_dest, 6);
}
uint64_t c_packet::get_src_mac()
{
    return BCD2UInt64(p_ethhdr->h_source, 6);
}
string c_packet::get_mac_line_num()
{
    uint32_t src_num1 = p_ethhdr->h_source[4];
    uint32_t src_num2 = p_ethhdr->h_source[5];
    src_num1 += 1;
    src_num2 += 1;
    uint32_t dst_num = p_ethhdr->h_dest [3];
    stringstream ss;
    ss << setfill('0')<< setw(3)<< src_num1 << setw(3) << src_num2 << setw(3) << dst_num;
    uint64_t line_num = 0;
    //ss >> line_num;
    return ss.str();

}

c_ip c_packet::get_dst_ip()
{
    if(p_iphdr != NULL)
    {
        return c_ip(p_iphdr->daddr);
    }
    else if(p_ipv6hdr != NULL){
        //       return c_ip(&(p_ipv6hdr->ip6_dst));
    }

}
c_ip c_packet::get_src_ip()
{
    if(p_iphdr != NULL)
    {
        return c_ip(p_iphdr->saddr);
    }
    else if (p_ipv6hdr != NULL){
        //        return c_ip(&(p_ipv6hdr->ip6_src));

    }

}


//2016-7-11 获取目的ip的host序uint32

u_int32_t c_packet::get_dst_uint32Ip()
{
    if(p_iphdr !=NULL)
    {
        return ntohl(p_iphdr->daddr);
    }
    else
    {
        return 0;
    }
}

//2016-7-11 获取源头ip的host序uint32

u_int32_t c_packet::get_src_uint32Ip()
{
    if(p_iphdr !=NULL)
    {
        return ntohl(p_iphdr->saddr);
    }
    else
    {
        return 0;
    }
}

uint16_t c_packet::get_src_port()
{
    //if(p_ipv6hdr) retrun p_ipv6hdr->source;
    if (p_tcphdr) return p_tcphdr->source;
    if (p_udphdr) return p_udphdr->source;
    return 0;

}
uint16_t c_packet::get_dst_port()
{
    //if(p_ipv6hdr) retrun p_ipv6hdr->source;
    if (p_tcphdr) return p_tcphdr->dest;
    if (p_udphdr) return p_udphdr->dest;
    return 0;
}

uint32_t c_packet::get_seqnumber()
{

    if (p_tcphdr) 
    {
        return ntohl(p_tcphdr->seq);
    }
    else 
    {
        return 0;
    }
}

uint64_t c_packet::BCD2UInt64(uint8_t *buff, int32_t len)
{
    uint16_t i = 0;
    int32_t slen = len;
    uint64_t re_int64 = 0;
    if (slen <= 0) return 0;
    if (slen > 8) slen = 8;

    for (i = 0; i< slen; i++)
    {
        re_int64 <<= 8;
        re_int64 += buff[i];
    }
    return re_int64;
}
uint32_t c_packet::hash()
{
    if (p_iphdr == NULL)//用于解决无效读取问题
    {
        return 1;
    }
    c_ip src_ip(p_iphdr->saddr);
    c_ip dst_ip(p_iphdr->daddr);
    return src_ip.get_hash()^dst_ip.get_hash()^get_src_port()^get_dst_port();
    //return (get_src_ip().get_hash())^(get_dst_ip().get_hash())^get_src_port()^get_dst_port();
}

