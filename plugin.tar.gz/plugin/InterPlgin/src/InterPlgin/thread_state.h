// Last Update:2016-03-24 15:31:02
/**
 * @file thread_state.h
 * @brief  
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-22
 */

#ifndef THREAD_STATE_H
#define THREAD_STATE_H

#include <stdio.h>
#include "InterText.h"
#include <protocol_parse_base_handle.h>
#include <syslog.h>
#include <clog.h>
#include <pthread.h>
#include <unistd.h>
#include "commit_tools.h"
#include "c_dpdk.h"
using namespace std;

// 创建一个线程 
int  stat(  ) 
{
    timeval cur_time  ;
    gettimeofday(&cur_time,NULL);
	
	static  __thread  timeval cur_time_last=cur_time;
	if(cur_time.tv_sec - cur_time_last.tv_sec < 10)
	{
		return 0;
	}
	cur_time_last=cur_time;

	static  timeval g_cur_time_last=cur_time;
	if(cur_time.tv_sec - g_cur_time_last.tv_sec < 10)
	{
		return 0;
	}
	g_cur_time_last=cur_time;
	
    uint64_t u64_time = cur_time.tv_sec * 100000 + cur_time.tv_usec;
	
    if(InterText::ethDriverType == DPDK_DRIVER ||InterText::ethDriverType == DPDK_2_DRIVER)
    {       
	    c_dpdk* pDriver =((c_dpdk*)(InterText::driverObj));
		if(pDriver)
		{
		pDriver->stat(pDriver->idx);
        //timeval cur_time  ;
        //gettimeofday(&cur_time,NULL);
        //uint64_t u64_time = cur_time.tv_sec * 100000 + cur_time.tv_usec;
        //uint64_t  recved  =    InterText::d_recved ;   //接收到的数据包
        //uint64_t  dropped =   InterText::d_dropped_all ;  //丢弃的数据包      
        //uint64_t  imiss =   InterText::d_imiss ;
        
        attach_info *p_attch = (attach_info *)InterText::p_attch ;
		char logmem[65536];
		int printflen =0; 
		printflen=sprintf(logmem,"dpdk 抓到的包数 ： %llu,dpdk 丢弃的包数  %llu.\r\n", InterText::d_recved,InterText::d_dropped_all );
		printflen=sprintf(logmem+printflen,"dpdk miss的包数 %llu,dpdk 收到字节数 %llu.\r\n",InterText::d_imiss, InterText::d_ibytes);
        printflen=sprintf(logmem+printflen,"程序处理的包数 ： %llu,分检包数: %u.\r\n",InterText::i_push_packet_num ,InterText::i_sort_packet_num);
        printflen=sprintf(logmem+printflen,"空包数:  分检成功的包数 :%llu, 分检成功的包数 :%llu.\r\n", InterText::i_sort_null_num , InterText::i_sort_suess_num);
        printflen=sprintf(logmem+printflen,"分检失败的包数:%llu 插件收到的总包数 :%llu.\r\n" ,InterText::i_sort_fail_num,p_attch -> p_protocal -> getSortHandlenum() );
        printflen=sprintf(logmem+printflen,"session 不够丢弃的包数  :%llu,sesion handle 出错丢弃的包数  %llu.\r\n", InterText::i_session_lost_pocket_num,InterText:: i_handle_lost_pocket_num);
        printflen=sprintf(logmem+printflen,"参加 协议识别的包数 :%llu.\r\n" , InterText::i_protocol_pocket_num );
        
		LOG (INFO) << logmem ;
/*
		LOG (INFO) << "dpdk 抓到的包数 ： "<< InterText::d_recved << " dpdk 丢弃的包数 "<< InterText::d_dropped_all ;
        LOG (INFO) << "dpdk miss的包数 "<< InterText::d_imiss << " dpdk 收到字节数 "<< InterText::d_ibytes ;;
        LOG (INFO) << "程序处理的包数 ： "<<InterText::i_push_packet_num << " 分检包数: "<< InterText:: i_sort_packet_num;
        LOG (INFO) << "空包数: " << InterText::i_sort_null_num <<" 分检成功的包数 :"<< InterText::i_sort_suess_num;
        LOG (INFO) << "分检失败的包数: " <<InterText::i_sort_fail_num << " 插件收到的总包数 : " << p_attch -> p_protocal -> getSortHandlenum() ;  
        LOG (INFO) << "session 不够丢弃的包数  : "<< InterText::i_session_lost_pocket_num << "sesion handle 出错丢弃的包数 "<< InterText:: i_handle_lost_pocket_num;
        LOG (INFO) << "参加 协议识别的包数 :" << InterText::i_protocol_pocket_num ; 
        LOG (INFO)<<u64_time<< " eml处理的包数 ： "<<p_attch -> p_protocal -> GetPocolValue(1).handle_num  ;
        
        LOG(INFO)<<"file:" << p_attch -> p_protocal -> GetPocolValue (6).record_num<<"  mail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num + p_attch -> p_protocal -> GetPocolValue (5).record_num <<"  clientmail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num<<"  webmail:" << p_attch -> p_protocal -> GetPocolValue (5).record_num;
        LOG(INFO)<<"qq:" << p_attch -> p_protocal -> GetPocolValue (7).record_num<<"    dns:" << p_attch -> p_protocal -> GetPocolValue (4).record_num<<"  telnet:" << p_attch -> p_protocal -> GetPocolValue (2).record_num<<"  ftp:" << p_attch -> p_protocal -> GetPocolValue (3).record_num<<"  regist:" << p_attch -> p_protocal -> GetPocolValue (12).record_num<<"  login:" << p_attch -> p_protocal -> GetPocolValue (13).record_num<<"  location:" << p_attch -> p_protocal -> GetPocolValue (14).record_num<<"  cloud:" << p_attch -> p_protocal -> GetPocolValue (15).record_num;
*/
		}
    }   
    else  if(InterText::ethDriverType == PFRING_DRIVER)
    {
        //timeval cur_time  ;
        //gettimeofday(&cur_time,NULL);
        //uint64_t u64_time = cur_time.tv_sec * 100000 + cur_time.tv_usec;
        uint64_t  recved  =    InterText::recved ;   //接收到的数据包
        uint64_t  dropped =   InterText::dropped ;  //丢弃的数据包
        
        attach_info *p_attch = (attach_info *)InterText::p_attch ;
        LOG (INFO) << "pfring 抓到的包数 ： "<< InterText::recved_sum << " PFRING 丢弃的包数 "<< InterText::dropped  <<" 程序处理的包数 ： "<<InterText::i_push_packet_num << " 分检包数: "<< InterText:: i_sort_packet_num << " 空包数: " << InterText::i_sort_null_num <<" 分检成功的包数 :"<< InterText::i_sort_suess_num  <<" 分检失败的包数: " <<InterText::i_sort_fail_num << " 插件收到的总包数 : " << p_attch -> p_protocal -> getSortHandlenum() ;  
        LOG(INFO) << "session 不够丢弃的包数  : "<< InterText::i_session_lost_pocket_num << "sesion handle 出错丢弃的包数 "<< InterText:: i_handle_lost_pocket_num << "参加 协议识别的包数 :" << InterText::i_protocol_pocket_num ; 
        LOG(INFO)<<u64_time<< "eml处理的包数 ： "<<p_attch -> p_protocal -> GetPocolValue(1).handle_num  ;
        
        string loctime = hour_time();
        LOG(INFO)<<loctime <<"  file:" << p_attch -> p_protocal -> GetPocolValue (6).record_num<<"  mail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num + p_attch -> p_protocal -> GetPocolValue (5).record_num <<"  clientmail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num<<"  webmail:" << p_attch -> p_protocal -> GetPocolValue (5).record_num<<"  qq:" << p_attch -> p_protocal -> GetPocolValue (7).record_num<<"  dns:" << p_attch -> p_protocal -> GetPocolValue (4).record_num<<"  telnet:" << p_attch -> p_protocal -> GetPocolValue (2).record_num<<"  ftp:" << p_attch -> p_protocal -> GetPocolValue (3).record_num<<"  regist:" << p_attch -> p_protocal -> GetPocolValue (12).record_num<<"  login:" << p_attch -> p_protocal -> GetPocolValue (13).record_num<<"  location:" << p_attch -> p_protocal -> GetPocolValue (14).record_num<<"  cloud:" << p_attch -> p_protocal -> GetPocolValue (15).record_num;
    }
    else  
    {       
        //timeval cur_time  ;
        //gettimeofday(&cur_time,NULL);
        //uint64_t u64_time = cur_time.tv_sec * 100000 + cur_time.tv_usec;
        uint64_t  recved  =    InterText::recved ;   //接收到的数据包
        uint64_t  dropped =   InterText::dropped ;  //丢弃的数据包
        
        attach_info *p_attch = (attach_info *)InterText::p_attch ;
        LOG (INFO) << "pfring 抓到的包数 ： "<< InterText::recved_sum << " PFRING 丢弃的包数 "<< InterText::dropped  <<" 程序处理的包数 ： "<<InterText::i_push_packet_num << " 分检包数: "<< InterText:: i_sort_packet_num << " 空包数: " << InterText::i_sort_null_num <<" 分检成功的包数 :"<< InterText::i_sort_suess_num  <<" 分检失败的包数: " <<InterText::i_sort_fail_num << " 插件收到的总包数 : " << p_attch -> p_protocal -> getSortHandlenum() ;  
        LOG(INFO) << "session 不够丢弃的包数  : "<< InterText::i_session_lost_pocket_num << "sesion handle 出错丢弃的包数 "<< InterText:: i_handle_lost_pocket_num << "参加 协议识别的包数 :" << InterText::i_protocol_pocket_num ; 
        LOG(INFO)<<u64_time<< "eml处理的包数 ： "<<p_attch -> p_protocal -> GetPocolValue(1).handle_num  ;
        
        string loctime = hour_time();
        LOG(INFO)<<loctime <<"  file:" << p_attch -> p_protocal -> GetPocolValue (6).record_num<<"  mail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num + p_attch -> p_protocal -> GetPocolValue (5).record_num <<"  clientmail:" << p_attch -> p_protocal -> GetPocolValue (1).record_num<<"  webmail:" << p_attch -> p_protocal -> GetPocolValue (5).record_num<<"  qq:" << p_attch -> p_protocal -> GetPocolValue (7).record_num<<"  dns:" << p_attch -> p_protocal -> GetPocolValue (4).record_num<<"  telnet:" << p_attch -> p_protocal -> GetPocolValue (2).record_num<<"  ftp:" << p_attch -> p_protocal -> GetPocolValue (3).record_num<<"  regist:" << p_attch -> p_protocal -> GetPocolValue (12).record_num<<"  login:" << p_attch -> p_protocal -> GetPocolValue (13).record_num<<"  location:" << p_attch -> p_protocal -> GetPocolValue (14).record_num<<"  cloud:" << p_attch -> p_protocal -> GetPocolValue (15).record_num;
    }

    return 1;
}

#endif  /*THREAD_STATE_H*/
