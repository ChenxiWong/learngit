// Last Update:2016-09-22 09:14:15
/**
 * @file InterPlugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-25
 */

#include <pthread.h>

#include "InterPlugin.h"
#include "thread_state.h"

/*
   struct write_buf_file *p_file = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
   struct write_buf_file *p_file_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
   struct write_buf_file *p_file_all_pcap = (struct write_buf_file *)malloc(sizeof(struct write_buf_file));
   */

#include "ipPkt.h"
#include "nprdef.h"
#include "linkDecodeInterface.h"

extern "C" {
    int GetPluginId()
    {
        return InterText::PluginID;
    }
    CEnteranceBase  * FortoryEnterace()
    {
        return new  InterPlugin();
    }
    FormatHandleBase * FortoryDataFormat()
    {
        return new InterDataFormat();
    }
}


int out(void* pObj,out2protobuf * pOut)
{
    //for test
    // delete pOut;
    //return 0;
    //for test end

    InterDataFormat *p_DataFormat = (InterDataFormat *)pObj;

    p_DataFormat->p_data_interface_list.clear();
    int ret = allflow_handle_dataout(&(p_DataFormat->p_data_interface_list), *pOut);
    if(ret == 1)
    {
        delete pOut;
        return 1;
    }
    list<data_interface> ::iterator iter = p_DataFormat->p_data_interface_list.begin();
    for(;iter != p_DataFormat->p_data_interface_list.end();iter ++)
    {
        p_DataFormat->m_out_put.handle(iter->data,iter->b_out_type,p_DataFormat->out_plist );

    }

    delete pOut;
    return 0;
}

bool InterPlugin::m_bReady=false;

InterPlugin::InterPlugin()
{
    if( InterText::p_attch == NULL)//(void *)  protocal::get_instance() ; 
    {
        InterText::p_attch = (void *)new attach_info; 
    }


}

InterPlugin::~InterPlugin()
{
    if(InterText::p_attch != NULL) 
    {
        attach_info * p =   (attach_info * )InterText::p_attch ;
        InterText::p_attch = NULL;
        delete  p ;
    }
    /*    if(InterText::save_pcap_flag != 0)
          {
          if(InterText::save_pcap_flag == 1)
          {
          free(p_file_all_pcap);
          }
          else if(InterText::save_pcap_flag == 2)     
          {
          free(p_file);
          }
          else if(InterText::save_pcap_flag == 3)
          {
          free(p_file_pcap);
          }     
          else if(InterText::save_pcap_flag == 4) 
          {
          free(p_file_all_pcap);
          free(p_file);
          free(p_file_pcap);
          }
          }*/

}
void InterPlugin::reload() 
{
    config();
}

void InterPlugin::config()
{
    pthread_mutex_lock(&stat_xml_mutex);
    *InterText::sNPRRoot  = getenv("NPR_ROOT");
    CIneterConfigParse  Parse;
    Parse.parse(*InterText::sNPRRoot+sConfile);
    pthread_mutex_unlock(&stat_xml_mutex);

}


void  InterPlugin::_Recv(string confile , thread_pool * pSortQueue)
{
    if(InterText::network_card == NULL) 
    {
        InterText::network_card =  new string("");
    }
    if(InterText::sz_plugin_path == NULL) 
    {
        InterText::sz_plugin_path =  new string("");
    }
    if(InterText::sNPRRoot == NULL)
    {
        InterText::sNPRRoot =  new string("");
    }
    if(InterText::offline_pcap_dir == NULL)
    {
        InterText::offline_pcap_dir =  new string("");
    }
    if(InterText::offline_pcap_save  == NULL) 
    {
        InterText::offline_pcap_save  =  new string("");
    }


    sConfile = confile;
    config();
    if(InterText::ethDriverType== PFRING_DRIVER)
    {
        // PF ring 
        //#if (PFRING)
        p_pfring  = new c_pfring(pSortQueue,(void *)(this ));
        if(p_pfring == NULL) 
        {
            printf("pfring error \n") ;
            abort();
        }
        p_pfring->recv_packet();
        //:#endif
    }
    else if(InterText::ethDriverType==  DPDK_DRIVER)
    {
        p_dpdk  = new c_dpdk(pSortQueue,(void *)(this ));
        if(p_dpdk == NULL)
        {
            printf("dpdk error.\n") ;
            abort();
        }
        InterText::driverObj = p_dpdk;
        p_dpdk->recv_packet();
        printf("recv_packet return,dpdk error.\n") ;
    }
    else if(InterText::ethDriverType==  DPDK_2_DRIVER)
    {
        //pSortQueue->m_num_pthread;        
        //pSortQueue->m_queue_len;
        p_dpdk  = new c_dpdk((void *)(this ),pSortQueue->m_num_pthread,pSortQueue->m_queue_len);
        if(p_dpdk == NULL)
        {
            printf("dpdk error.\n") ;
            abort();
        }
        InterText::driverObj = p_dpdk;
        m_bReady=true;
        p_dpdk->recvNullPacket();
        printf("recv_packet return,dpdk error.\n") ;
    }
    else {
        // 读包
        p_savefile  = new pcap_data_offline(pSortQueue,(void *)(this ));
        if(p_savefile == NULL) 
        {
            printf("pfring error \n") ;
            abort();
        }
        p_savefile -> pcap_parse();
        //p_pfring->recv_packet();
    }
    /*
    if(InterText::sNPRRoot != NULL)
    {
        delete InterText ::sNPRRoot ;
        InterText ::sNPRRoot =NULL;
    }
    */
    if(InterText::sz_plugin_path != NULL)
    {
        delete InterText::sz_plugin_path ;
        InterText ::sz_plugin_path =NULL;
    }
    if(InterText::sNPRRoot != NULL)
    {
        delete InterText::sNPRRoot;
        InterText ::sNPRRoot =NULL;
    }
    
    if(InterText::offline_pcap_dir == NULL) 
    {
        delete InterText::offline_pcap_dir;
        InterText ::offline_pcap_dir =NULL;
    }
    if(InterText::offline_pcap_save == NULL) 
    {
        delete InterText::offline_pcap_save;
        InterText ::offline_pcap_save =NULL;
    }

    //InterText::sNPRRoot = NULL;
    InterText::sz_plugin_path = NULL;
    InterText::sNPRRoot = NULL;
    InterText::offline_pcap_dir = NULL;
    InterText::offline_pcap_save = NULL;
}

int InterPlugin::ParseAndStiring(NodeData* pData)
{
    InterText::i_sort_packet_num ++;
    if(pData == NULL) 
    {
        InterText::i_sort_null_num ++;
        return  0;
    }

    // 申请一个c_packet ，用来存储数据 
    c_packet * p_packet  = new c_packet();
    bool retParse=false;
    if(pData->dpdk_free !=NULL)
    {
        retParse = p_packet->parse(pData->dpdk_idx,pData->dpdk_free,(uint8_t *)pData ->data,pData->datalen,pData->ts,0);
        pData->dpdk_free =NULL;
        pData->dpdk_idx = -1;
    }
    else 
    {
        retParse = p_packet->parse((uint8_t *)pData ->data,pData->datalen,pData->ts);
    }



    if(InterText::save_pcap_flag == 4 )
    {
        thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
        p_pcap_lost_data->flag = 3;
        thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
    }
    /*
    //delete begin 2016-7-18 phl 
    //save in function of formatData()
    //2016-7-11 保存原始数据包，依照ip或散列抽样
    if( InterText::save_pcap_flag == 5)
    {
    if(InterText::save_pcap_ip)
    {
    //依照ip命名存包文件，依照名字索引查找写文件对象
    //20160714
    int index = InterText::save_pcap_ip->IsSave(p_packet->get_dst_uint32Ip());          
    if(index >=0)
    {
    thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
    p_pcap_lost_data->flag = 4;
    p_pcap_lost_data->pFileIndex = index;
    thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
    }
    else 
    {
    index = InterText::save_pcap_ip->IsSave(p_packet->get_src_uint32Ip());
    if(index >=0)
    {
    thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
    p_pcap_lost_data->flag = 4;
    p_pcap_lost_data->pFileIndex = index;
    thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
    }
    }
    //20160714              
    }
    }
    //delete end 2016-7-18 phl 
    */
    if( InterText::save_pcap_flag == 1)
    {
        if(0 == p_packet->hash()%InterText::saveall_pcap_mod )
        {
            thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
            p_pcap_lost_data->flag = 3;
            thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
        }               
    }
    //2016-7-11
    if(!retParse)
    {
        if(InterText::save_pcap_flag == 4 || InterText::save_pcap_flag == 2)
        {
            thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
            p_pcap_lost_data->flag = 1;
            thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
        }
        // 解析识别   记录日志 
        InterText::i_sort_fail_num ++;
        delete p_packet;
        pData ->data = NULL;
        return 0;
    }
    InterText::i_sort_suess_num ++;
    // 成功解析一条数据 
    pData->pWorkData = (WorkDataBase*)p_packet;
    pData ->data  = NULL;
    uint32_t num = p_packet->hash() ;
    if (num == 1)
    {
        num = 0;
        //主要添加是因为如果hash值为1为其内部数据没有获取完整
    }
    return num;
}

InterDataFormat::InterDataFormat()
{
    if(InterText::network_card == NULL) 
    {
        InterText::network_card =  new string("");
    }
    if(InterText::sz_plugin_path == NULL) 
    {
        InterText::sz_plugin_path =  new string("plugin/InterPlugin/");
    }
    if(InterText::sNPRRoot == NULL) 
    {
        InterText::sNPRRoot =  new string(getenv("NPR_ROOT"));
    }
    if(InterText::offline_pcap_dir == NULL) 
    {
        InterText::offline_pcap_dir =  new string("");
    }
    if(InterText::offline_pcap_save  == NULL) 
    {
        InterText::offline_pcap_save  =  new string("");
    }
    m_pDpdk = NULL;
    m_phash = new session_hash;
    Reload();
}

InterDataFormat::~InterDataFormat()
{
    if(m_phash != NULL)  
        delete m_phash;

    t_procotol_handle_map::iterator iter = plugin_handle_map.begin();
    for(;iter!= plugin_handle_map.end();iter++)
    {
        if(iter->second!=NULL)
            delete iter->second;
    }
    plugin_handle_map.clear();

    if(InterText::sNPRRoot != NULL)
        delete InterText ::sNPRRoot ;
    if(InterText::sz_plugin_path != NULL)
        delete InterText::sz_plugin_path ;
    if(InterText::sNPRRoot != NULL)
        delete InterText::sNPRRoot;
    if(InterText::offline_pcap_dir == NULL) 
        delete InterText::offline_pcap_dir;
    if(InterText::offline_pcap_save == NULL) 
        delete InterText::offline_pcap_save;

    InterText ::sNPRRoot = NULL;
    InterText::sz_plugin_path = NULL;
    InterText::sNPRRoot = NULL;
    InterText::offline_pcap_dir = NULL;
    InterText::offline_pcap_save = NULL;
    //  p_data_interface_list =  new  list<data_interface>;

}

void InterDataFormat::Reload()
{
    protocol_plugin_marge::get_instance()->reload();
    t_procotol_handle_map::iterator iter = plugin_handle_map.begin();
    for(;iter!= plugin_handle_map.end();iter++)
    {
        if(iter->second!=NULL)
            delete iter->second;
    }
    plugin_handle_map.clear();
    protocol_plugin_marge::get_instance()->procotol_handle_factory(&plugin_handle_map);

}

int allflow_handle_dataout(list<data_interface> * p_list,const out2protobuf & outData)
{
    /*
       if(pdata == NULL)
       {
       return 1;
       }
       */
    data_interface m_data;
    net_str * p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();
    p_net->msg->set_type(30);
    all_package_property* p_allflow = p_net->msg->mutable_flow_info();

    p_allflow->set_dev_num(InterText::device_num);
    p_allflow->set_line_num(outData.m_lineNumber);

    uint64_t capdate_begin_time = outData.m_firstTb.tv_sec*1000000 + outData.m_firstTb.tv_usec;
    uint64_t capdate_end_time = outData.m_lastTb.tv_sec*1000000 + outData.m_lastTb.tv_usec;
    p_allflow->set_capdate_begin(capdate_begin_time);
    p_allflow->set_capdate_end(capdate_end_time);
    p_allflow->set_is_tcp_shakehand_begin(outData.m_nHandshake);
    p_allflow->set_is_tcp_shakehand_discon(outData.m_nByeHandshake);
    uint64_t duration_dtime = capdate_end_time - capdate_begin_time;
    p_allflow->set_capdate_duration(duration_dtime);
    in_addr a;
    a.s_addr = htonl(outData.m_cmIp);
    char *comeip = inet_ntoa(a);
    p_allflow->set_come_ip(comeip);
    a.s_addr = htonl(outData.m_cvIp);
    char *covip = inet_ntoa(a);
    p_allflow->set_conver_ip(covip);
    p_allflow->set_come_port(outData.m_cmPort);
    p_allflow->set_conver_port(outData.m_cvPort);
    p_allflow->set_proto_type(outData.m_ipPayloadType);
    p_allflow->set_ds_stream_type(outData.m_duplexType);
    p_allflow->set_proto(outData.m_appType);

    p_allflow->set_src_send_packages(outData.m_cmPkts);
    p_allflow->set_src_send_sum_bytes(outData.m_cmBytes);
    //	p_allflow->set_src_app_payload_packages(outData.m_cmLoadPkts);
    //	p_allflow->set_src_sum_app_payload_bytes(outData.m_cmLoadMaclen);
    p_allflow->set_src_repeat_package(outData.m_cmRsPkts);
    p_allflow->set_src_repeat_bytes(outData.m_cmRsBytes);
    p_allflow->set_src_send_unknow_ptks(outData.m_cmUnPkts);
    p_allflow->set_src_send_unknow_bytes(outData.m_cmUnBytes);
    p_allflow->set_src_lost_buyes(outData.m_cmJumpLostBys);
    p_allflow->set_src_app_payload_packages(outData.m_cmAppPkts);
    p_allflow->set_src_square_payload_bytes(outData.m_cmAppLenSq);
    p_allflow->set_src_sum_app_payload_bytes(outData.m_cmAppBys);
    p_allflow->set_come_tcp_max_sclice(outData.m_cmSegmentMax);
    p_allflow->set_come_tcp_win_size(outData.m_cmWindowSize);
    p_allflow->set_come_tcp_win_size_multiple(outData.m_cmWindowScale);
    p_allflow->set_src_win_size_zero_times(outData.m_cmWinZeroSize);

    p_allflow->set_dst_send_packages(outData.m_cvPkts);
    p_allflow->set_dst_send_sum_bytes(outData.m_cvBytes);
    //p_allflow->set_dst_app_payload_packages(outData.m_cmLoadPkts);
    //p_allflow->set_dst_sum_app_payload_bytes(outData.m_cmLoadMaclen);
    p_allflow->set_dst_repeat_package(outData.m_cvRsPkts);
    p_allflow->set_dst_repeat_bytes(outData.m_cvRsBytes);
    p_allflow->set_dst_send_unknow_ptks(outData.m_cvUnPkts);
    p_allflow->set_dst_send_unknow_bytes(outData.m_cvUnBytes);
    p_allflow->set_dst_lost_buyes(outData.m_cvJumpLostBys);
    p_allflow->set_dst_app_payload_packages(outData.m_cvAppPkts);
    p_allflow->set_dst_square_payload_bytes(outData.m_cvAppLenSq);
    p_allflow->set_dst_sum_app_payload_bytes(outData.m_cvAppBys);
    p_allflow->set_cv_tcp_max_sclice(outData.m_cvSegmentMax);
    p_allflow->set_cv_tcp_win_size(outData.m_cvWindowSize);
    p_allflow->set_cv_tcp_win_size_multiple(outData.m_cvWindowScale);
    p_allflow->set_dst_win_size_zero_times(outData.m_cvWinZeroSize);
    //outData.out_buff_data->

    //all_package_property All_pkgproperty;
    stream_property *Str_property;
    for(int j=0;j<2 ;j++)
    {
        Str_property  = p_allflow->add_package_property();
        if(outData.m_porpertyDone[j] == 0)
        {
            for(int i=0;i<10;i++)
            {
                Str_property->add_package_offset_num(0);
                Str_property->add_package_charst_len(0);
                Str_property->add_package_charst("");
            }
        }
        for(int i=0; i<10;i++)
        {
            if(outData.m_porpertyDone[j] == 0)
                break;
            //	p_allflow->package_property(j).sd_package_noapp_stream_order(outData.m_porpertyPktNum[j][i]);
            if(i < outData.m_porpertyOffsize[j].size())
            {
                Str_property->add_package_offset_num(outData.m_porpertyOffsize[j][i]);
            }
            else
            {
                Str_property->add_package_offset_num(0);
            }
            if(i < outData.m_porpertyLen[j].size())
            {
                Str_property->add_package_charst_len(outData.m_porpertyLen[j][i]);
            }
            else
            {
                Str_property->add_package_charst_len(0);
            }

            if(i >= outData.m_porperty[j].size())
            {
                string svalue_nil = "";
                Str_property->add_package_charst(svalue_nil);
            }
            else
            {
            	 char buffer[1024];
            	 string svalue="";
            	 memcpy(buffer,outData.m_porperty[j][i],outData.m_porpertyLen[j][i]);
            	 buffer[outData.m_porpertyLen[j][i]]='\0';
            	 for(int len_c = 0;len_c < outData.m_porpertyLen[j][i];len_c++)
            	 {
            		 char temp[2] = {0x0};
            		 sprintf(temp,"0x%02x ",buffer[len_c]&0x000000ff);//outData.m_porperty[j][i][len_n]);
            		 svalue += temp;
            	 }
                Str_property->add_package_charst(svalue);
            }
        }
        if(outData.m_headZeroLenPktDone[j] == 0)
        {
            for(int n=0;n<10 ;n++)
            {
                Str_property->add_sd_package_noapp_stream_order(0);
                Str_property->add_s_package_noapp_stream_order(0);
            }
        }
        for(int n=0;n<10;n++)
        {
            if(outData.m_headZeroLenPktDone[j] == 0)
                break;
            if(n < outData.m_zeroLenPktStreamId[j].size())
            {
                Str_property->add_sd_package_noapp_stream_order(outData.m_zeroLenPktStreamId[j][n]);
            }
            else
            {
                Str_property->add_sd_package_noapp_stream_order(0);
            }
            if(n < outData.m_zeroLenPktLinkId[j].size())
            {
                Str_property->add_s_package_noapp_stream_order(outData.m_zeroLenPktLinkId[j][n]);
            }
            else
            {
                Str_property->add_s_package_noapp_stream_order(0);
            }
        }
        if(outData.m_payLoadPktDone[j] == 0)
        {
            for(int m=0;m<10;m++)
            {
                Str_property->add_sd_package_app_payloadlen(0);
                Str_property->add_sd_package_app_stream_order(0);
                Str_property->add_s_package_app_stream_order(0);
            }
        }
        for(int m=0;m<10;m++)
        {
            if(outData.m_payLoadPktDone[j] == 0)
                break;
            if(m < outData.m_payLoadPktLen[j].size())
            {
                Str_property->add_sd_package_app_payloadlen(outData.m_payLoadPktLen[j][m]);
            }
            else
            {
                Str_property->add_sd_package_app_payloadlen(0);
            }
            if(m < outData.m_payLoadPktStreamId[j].size())
            {
                Str_property->add_sd_package_app_stream_order(outData.m_payLoadPktStreamId[j][m]);
            }
            else
            {
                Str_property->add_sd_package_app_stream_order(0);
            }
            if(m < outData.m_payLoadPktLinkId[j].size())
            {
                Str_property->add_s_package_app_stream_order(outData.m_payLoadPktLinkId[j][m]);
            }
            else
            {
                Str_property->add_s_package_app_stream_order(0);
            }
        }
    }
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    //delete pdata;
    p_list->push_back(m_data);
    return 0;
}

void linkProperty(c_packet * p_packet)
{

    ipPkt * newOne =new ipPkt;
    newOne->init();

    newOne->initIp((char*)p_packet->buff,p_packet->p_iphdr ,p_packet->buff_len);
    nprDecodeLink(newOne);
}

/*
   void linkPropertyBack(c_packet * p_packet)
   {

//2016-06-22 phl test   
if(p_packet->p_ethhdr ==NULL || p_packet->p_iphdr ==NULL)
{
return ;
}
if(p_packet->p_tcphdr !=NULL )
{
linkTcpProperty( p_packet) ;
}      
if( p_packet->p_udphdr !=NULL)
{
linkUdpProperty( p_packet) ;
}
}
*/
//全流量分析
static __thread bool bInit =false;
int __thread nLinkProperty=0;

int InterDataFormat::initLinkPpt()
{
    string rootPath =  string(getenv("NPR_ROOT"));
    string strFile =rootPath;
    strFile = rootPath + "/conf/link-property.xml";

    xml_parse  xml; 
    xml.set_file_path(strFile.c_str());
    // 收数据插件的

    char *p_value = (char *)xml.get_value("/config/linkstream/open");
    if(p_value !=NULL)
    {
        nLinkProperty = atoi(p_value);
    }

    if(0 == nLinkProperty )
    {
        printf("Link-property is closed.\r\n");
        return 0;
    }

    linkPptInit pInit;
    p_value = (char *)xml.get_value("/config/linkstream/tcp/cachePktsMax");
    if(p_value !=NULL)
    {
        pInit.cacheSumMaxSetting = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/jumpBytesMax");
    if(p_value !=NULL)
    {
        pInit.seqJumpMaxSetting = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/jumpMaxTimes");
    if(p_value !=NULL)
    {
        pInit.seqJumpSumMax = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/bTcpSeqSameCache/open");
    if(p_value !=NULL)
    {
        pInit.bTcpSeqSameCache = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/bTcpSeqSameCache/nCacheTimeout");
    if(p_value !=NULL)
    {
        pInit.nCacheTimeout = atoi(p_value);
    } 

    p_value = (char *)xml.get_value("/config/linkstream/nOutputMaxTime");
    if(p_value !=NULL)
    {
        pInit.nOutputMaxTime = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/RstFinTimeout");
    if(p_value !=NULL)
    {
        pInit.RstFinTimeout = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/udp/UdpTimeout");
    if(p_value !=NULL)
    {
        pInit.UdpTimeout= atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/linkstream/tcp/NoByeDefaultTimeout");
    if(p_value !=NULL)
    {
        pInit.nNoByeDefaultTimeout = atoi(p_value);
    }
    int retInit = nprInitLinkDecode(&pInit,out,(void*)this);
    if(retInit < 0 )
    {
        //初始化失败，恢复为不打开模式
        nLinkProperty = 0;
        printf("pthread[%u] link-property init failed.\r\n",pthread_self());
    }
    else
    {
        nLinkProperty = 1;
        printf("pthread[%u] link-property init success.\r\n",pthread_self());
    }
    return retInit;
}


//phl 2016-11-13 add
void* InterDataFormat::Receive(uint32_t  id)
{
    if(!InterPlugin::m_bReady)
    {
        for(;!InterPlugin::m_bReady;)
        {
            sleep(1);
        }
        sleep(id*4+4);
        printf("worker[%u] begin running.",id);
    }
    if (m_pDpdk)
    {
        void *ret  =m_pDpdk->recvWorkPacket(id);
        return ret;
    }
    else
    {
        m_pDpdk = (c_dpdk*)InterText::driverObj ; 
        return NULL;
    }
}
//phl 2016-11-13


void  InterDataFormat::FromatData(NodeData *  pData , TCFDATALIST * plist)
{
//phl 2016-11-12 add
//去掉分捡机制后，需要处理原始包
//特别时dpdk需要拷贝数据
    // 申请一个c_packet ，用来存储数据	 
    if(pData == NULL) 
    {
        return ;
    }
    c_packet * pPacket  = new c_packet();
    bool retParse=false;
    if(InterText::ethDriverType == DPDK_DRIVER )
    {
        retParse = pPacket->parse(pData->dpdk_idx,pData->dpdk_free,(uint8_t *)pData ->data,pData->datalen,pData->ts,false);
        pData->dpdk_free =NULL;
        pData->dpdk_idx = -1;
    } 
    else if(InterText::ethDriverType == DPDK_2_DRIVER)
    {
        retParse = pPacket->parse(pData->dpdk_idx,pData->dpdk_free,(uint8_t *)pData ->data,pData->datalen,pData->ts,true);
        pData->dpdk_free =NULL;
        pData->dpdk_idx = -1;
        pData ->data=NULL;
    }
    else 
    {
        retParse = pPacket->parse((uint8_t *)pData ->data,pData->datalen,pData->ts);
    } 

    //test dpdk
    
    static uint64_t w=0;
    uint64_t tmp64 = ++w;
    if((tmp64 & 0xffffff )==0 )
    {
    printf("packet %llu \r\n",tmp64);
    }
    /*
    delete pPacket;  
    return ;
    */
    
    //test 
    
    if(!retParse)
    {
        delete pPacket;
        pData ->data = NULL;
        return ;
    }
    pData->pWorkData = (WorkDataBase*)pPacket;
    pData ->data  = NULL;
//phl 2016-11-12

    out_plist = plist;
    if(!bInit)
    {
        //依照包确定是否初始化
        if(pData->linkPpt)
        {
            initLinkPpt();
            bInit =true;
        }
    }


    // if(plugin_handle_map.size() == 0)
    // 协议处理主函数 
    if(InterText::thread_session == 0) 
    {

    }
    if(pData ->type == TIMEOUT)
    {
        TimeOut(plist);
    }
    c_packet * p_packet  = (c_packet *)pData->pWorkData;
    if(p_packet == NULL)
    {
        return  ;
    }

    if(pData->linkPpt && nLinkProperty)
    {
        linkProperty(p_packet);
    }

    //2016-7-18 保存原始数据包，依照ip或散列抽样
    if( InterText::save_pcap_flag == 5)
    {
        if(InterText::save_pcap_ip)
        {
            //依照ip命名存包文件，依照名字索引查找写文件对象
            //20160714
            int index = InterText::save_pcap_ip->IsSave(p_packet->get_dst_uint32Ip());
            if(index >=0)
            {
                thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
                p_pcap_lost_data->flag = 4;
                p_pcap_lost_data->pFileIndex = index;
                thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
            }
            else 
            {
                index = InterText::save_pcap_ip->IsSave(p_packet->get_src_uint32Ip());
                if(index >=0)
                {
                    thread_write_file_data *p_pcap_lost_data = new thread_write_file_data(p_packet);
                    p_pcap_lost_data->flag = 4;
                    p_pcap_lost_data->pFileIndex = index;
                    thread_write_file_fun::get_instrance()->send_data(p_pcap_lost_data);
                }
            }
            //20160714
        }
    }
    //2016-7-18 保存原始数据包，依照ip或散列抽样


    attach_info *p_attch = (attach_info *)InterText::p_attch ;
    p_attch ->p_protocal ->StatisticsSortHandlenum() ;
    // session 查找和判断-
    session * p_session = m_phash->get_session(p_packet);
    if(p_session == NULL)
    {
        sync_uint64_add(InterText::i_session_lost_pocket_num , 1) ;
        return ;
    }

    p_session->last_packet_time = p_packet->m_timeval;
    p_session ->packet_time = p_packet->m_timeval;
    
    p_session->packet_len += p_packet->buff_len;
    ++p_session->packet_num;

    if (p_session->packet_begin_time == 0)
    {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
    }

    if (p_packet->m_timeval > p_session->packet_end_time )
    {
        p_session->packet_end_time = p_packet->m_timeval;
    }


    // printf("p_packet = %s\n",p_packet->p_app_data);
    // 判断是否需要做协议识别-
    // 关于协议识别的前提是
    // 1、只识别首包；
    // 2、首包应用层数据长度不应该太长
    // 3、如果太长直接去除；
    if(p_packet->app_data_len > 0 && p_session -> handle == NULL && !p_session->b_first_identify)
    {
        p_session->b_first_identify = true;

        // 多模匹配
        if(p_packet->app_data_len  < 1500)
        {
            p_packet->prepare_rule_for_identify();
            int int_identify_len = 0;
            //因为当前仅仅用到从头部开始查找，根据加载的规则，确定最大查找长度，之在最大查找长度内进行查找，而不是在整个应用层数据内进行查找，从而提高效率。
            if(p_packet->app_data_len > p_attch->g_p_ac_tree.head_max_length)
            {
                int_identify_len = p_attch->g_p_ac_tree.head_max_length;
            }else
            {
                int_identify_len = p_packet->app_data_len;
            }
            p_attch  -> g_p_ac_tree .ac_rule_find((char *)p_packet->p_app_data , int_identify_len, p_packet -> rule_reulst );
        }

        // 协议识别-
        if(p_packet->app_data_len > 1499 || protocol_identify(p_session, p_packet) == false )
        {
            if(InterText::save_pcap_flag == 4 || InterText::save_pcap_flag == 3)
            {
                thread_write_file_data *p_lost_data = new thread_write_file_data(p_packet);
                p_lost_data->flag = 2;
                //printf("p_lost_data=%s\n",*p_lost_data->data);
                thread_write_file_fun::get_instrance()->send_data(p_lost_data);
            }
            // 未识别协议- delete  by   wangchenxi   广东项目超时机制更改
            //m_phash->find_del_session(p_session);
            return  ;
        }
    }

    //检测原始数据包处理
    if(p_session -> handle == NULL)
    {
        // 未识别协议

        sync_uint64_add(InterText::i_handle_lost_pocket_num , 1) ;
        // delete  by   wcx  广东项目超时机制更改
        //m_phash->find_del_session(p_session);
        return ;
    }
    // 更新时间--
    protocol_parse_base_handle * p_handle = (protocol_parse_base_handle *)p_session -> handle ;
    // 清空 状态--
    ZERO_S_SIGN(p_session);
    p_handle->potocol_sign_judge(p_session , p_packet);
    // 状态判断     是否需要导出文件解析--
    if(IS_EXPORT(p_session))
    {
        //开始解析--
        p_session ->send_len  = 0;
        p_session ->p_send_buf = NULL;
        p_handle->pococol_parse_handle(p_session);
        if(p_session ->p_send_buf != NULL && p_session -> send_len > 0 )
        {
            // 统计数据-
            p_data_interface_list.clear();
            p_handle->potocol_data_handle(p_session, &p_data_interface_list) ;
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            list<data_interface> ::iterator iter = p_data_interface_list.begin();
            for(;iter != p_data_interface_list .end(); iter ++)
            {
                m_out_put.handle(iter->data , iter ->b_out_type , plist );

            }
        }
    }
    // ZERO_S_SIGN(p_session);
    // 回收资源-
    if(IS_SESSION_OVER(p_session))
    {
    // 删除session_hash 中的 session 数据-
        p_handle->resources_recovery(p_session);
        m_phash->find_del_session(p_session);
    }
    else //用于解决valgrind测试出来的无效写
    {
        ZERO_S_SIGN(p_session);
    }
}
bool InterDataFormat::protocol_identify(session * p_sess , c_packet * p_packet)
{
    sync_uint64_add(InterText::i_protocol_pocket_num , 1) ;
    t_procotol_handle_map::iterator iter = plugin_handle_map.begin();
    for(;iter != plugin_handle_map.end();iter++)
    {
        protocol_parse_base_handle * p_handle = iter->second;
        if((p_handle->potocol_identify)(p_sess,p_packet))
        {
            p_sess ->handle = iter->second;
            return true;
        }
    }
    return false;
}

void InterDataFormat::TimeOut( TCFDATALIST * plist )
{
    uint32_t i = 0;
    struct timeval tv ;
    gettimeofday(&tv,NULL);

//test add 
    //this->m_pDpdk->getWorkInfo(workid);
//test end

    uint64_t u64_time = tv.tv_sec * 1000000 + tv.tv_usec ;

    thread_write_file_fun::get_instrance()->Timeout();

    list<session*>::iterator iter ;

    // 广东项目超时机制添加变量    王晨曦添加
    list<session*>::iterator tmp_iter ;
    for (;i < MAXHASH; i++)
    {
        for(iter = m_phash->sess_tcp[i].begin();iter != m_phash->sess_tcp[i].end();)
        {
            session * p_session = *iter;

            if(p_session ->handle  != NULL)
            {
                ZERO_S_SIGN(p_session);
                protocol_parse_base_handle * p_handle = (protocol_parse_base_handle * )p_session->handle;
                if(u64_time > p_session ->last_packet_time)
                {
                    p_handle ->time_out(p_session,u64_time);
                }
                if(IS_EXPORT(p_session))
                {
                    //开始解析--
                    p_session -> send_len  = 0;
                    p_session -> p_send_buf = NULL;
                    p_handle->pococol_parse_handle(p_session);
                    // 统计数据-
                    p_data_interface_list.clear();
                    p_handle->potocol_data_handle(p_session,&p_data_interface_list) ;
                    p_session->send_len = 0;
                    p_session->p_send_buf = NULL;
                    list<data_interface> ::iterator iter = p_data_interface_list.begin();
                    for(;iter != p_data_interface_list . end(); iter ++)
                    {
                        m_out_put.handle(iter->data , iter -> b_out_type , plist );

                    }
                }
                if(IS_SESSION_OVER(p_session))
                {
                    p_handle->resources_recovery(p_session);
                    m_phash ->session_number--;
                    delete p_session ;
                    p_session = NULL;
                    iter = m_phash -> sess_tcp[i].erase(iter);
                }
            }
            else
            {
                // 超时机制处理代码tcp协议超时处理
                if((u64_time - (*(InterText::iTcpTimeOut) * 1000000)) > p_session ->last_packet_time)
                {
                    ++iter;
                    tmp_iter = iter;
                    --iter;
                    m_phash->find_del_session(p_session);
                    if(tmp_iter == m_phash->sess_tcp[i].end())
                    {
                        break;
                    }else
                    {
                        iter = tmp_iter;
                        continue;
                    }
                }
            }
            ++iter;
        }
        for(iter = m_phash->sess_udp[i].begin();iter != m_phash->sess_udp[i].end();)
        {
            session * p_session = *iter;
            if(p_session ->handle  != NULL)
            {
                protocol_parse_base_handle * p_handle = (protocol_parse_base_handle * )p_session->handle;
                p_handle ->time_out(p_session,u64_time);
                if(IS_EXPORT(p_session))
                {
                    //开始解析--
                    p_handle->pococol_parse_handle(p_session);
                    // 统计数据-
                    p_data_interface_list.clear();
                    p_handle->potocol_data_handle(p_session, &p_data_interface_list) ;
                    p_session->send_len = 0;
                    p_session->p_send_buf = NULL;
                    list<data_interface> ::iterator iter = p_data_interface_list.begin();
                    for(;iter != p_data_interface_list . end(); iter ++)
                    {
                        m_out_put.handle(iter->data , iter -> b_out_type , plist );
                    }
                }
                if(IS_SESSION_OVER(p_session))
                {
                    p_handle->resources_recovery(p_session);

                    delete p_session ;
                    p_session = NULL;
                    m_phash ->session_number--;
                    iter = m_phash -> sess_udp[i].erase(iter);
                }
            }else
            {
                // 超时机制处理代码udp协议超时处理
                if((u64_time - (*(InterText::iUdpTimeOut) * 1000000)) > p_session ->last_packet_time)
                {
                    ++iter;
                    tmp_iter = iter ;
                    --iter;
                    m_phash->find_del_session(p_session);
                    if(tmp_iter == m_phash->sess_tcp[i].end())
                    {
                        break;
                    }else
                    {
                        iter = tmp_iter;
                        continue;
                    }
                }

            }
            ++iter;
        }

    }
	//驱动层的信息输出
    //stat() ;
    return ;
}


