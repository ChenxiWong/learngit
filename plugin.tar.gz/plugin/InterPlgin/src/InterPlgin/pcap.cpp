// Last Update:2016-04-20 18:20:08
/**
 * @file pcap.cpp
 * @author wangxiang
 * @version 0.1.00
 * @date 2016-04-04
 */
#include "pcap.h"
#include <time.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

//20160714 �޸�Ĭ�ϻ���ռ��С
#define MAXBUF_FILE 32*1024
//20160714
#define MAXFILE 128*1024*1024


struct pcap_file_header_p
{
    uint32_t magic;
    uint16_t version_major;
    uint16_t version_minor;
    uint32_t thiszone;     /* gmt to local correction */
    uint32_t sigfigs;    /* accuracy of timestamps */
    uint32_t snaplen;    /* max length saved portion of each pkt */
    uint32_t linktype;   /* data link type (LINKTYPE_*) */
};
char pcap_magic[]={0xd4,0xc3 ,0xb2 ,0xa1};
#define PCAP_VERSION_MAJOR 2
#define PCAP_VERSION_MINOR 4
#define PCAP_SNAPLEN 65535
#define PCAP_LINKTYPE 1

int num  = 0 ;

struct pcap_pkthdr_p
{
    // struct timeval ts;      /* time stamp */
    //uint64_t t_stamp ;
    //�޸�ʱ�������ȷ��¼�����ʱ��
    //2016-8-29 by penghuiliang
    uint32_t sec;
    uint32_t usec;
    uint32_t caplen;     /* length of portion present */
    uint32_t len;        /* length this packet (off wire) */
};

char p_pcapfile_hdr[24] = {0xD4,0xC3,0xb2,0xa1,0x20,0x00,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x00,0x01,0x00,0x00,0x00};
void write_file(struct write_buf_file * p_file);
void buf_file_destroy(struct write_buf_file * p_file);
int write_packet_buf_file(struct write_buf_file * pp_file ,char * data, int len,struct timeval ts );
void write_file(struct write_buf_file * p_file);

void buf_file_init( struct write_buf_file * p_write_struct , int b_no_buf, char * p_file_name )
{
    if(b_no_buf == 1 )
    {
        p_write_struct -> init = buf_file_init ;
        p_write_struct -> destroy = buf_file_destroy ;
        p_write_struct -> write_packet_file = write_packet_buf_file;


        //20160714 ���ı���Ϊstring*����
        //p_write_struct ->p_file_name = string(p_file_name) ;
        if(NULL != p_write_struct ->p_strfile_name)
        {
            delete p_write_struct ->p_strfile_name;
            p_write_struct ->p_strfile_name =NULL;
        }
        p_write_struct ->p_strfile_name= new string(p_file_name) ;
        //20160714

        p_write_struct -> buffer = (char *) malloc(MAXBUF_FILE) ;
        num ++;
    }
    else
    {
        if(p_write_struct ->fp != NULL)
        {
            if(p_write_struct->bufflen != 0 )
            {
                fwrite(p_write_struct -> buffer ,p_write_struct -> bufflen ,1, p_write_struct->fp);
            }
            fclose(p_write_struct -> fp ) ;
            p_write_struct -> fp  = NULL;
            num ++ ;
            // fflush(p_file ->fp) ;
        }
    }
    /*
       struct pcap_file_header m_pkfilehdr ;
       memcpy((char *)(&m_pkfilehdr.magic) , &pcap_magic ,4);
       m_pkfilehdr.version_major = htons(PCAP_VERSION_MAJOR) ;
       m_pkfilehdr.version_minor = htons(PCAP_VERSION_MINOR) ;
       m_pkfilehdr.thiszone = 0;
       m_pkfilehdr.sigfigs = 0;
       m_pkfilehdr.snaplen = ntohl(PCAP_SNAPLEN );
       m_pkfilehdr.linktype = ntohl(PCAP_LINKTYPE );
       */

    struct pcap_file_header_p st_fpcap_hdr;
    st_fpcap_hdr.magic = 0xa1b2c3d4;
    st_fpcap_hdr.version_major = 2;
    st_fpcap_hdr.version_minor = 4;
    st_fpcap_hdr.thiszone = 0;
    st_fpcap_hdr.sigfigs = 0;
    st_fpcap_hdr.snaplen = 65535;
    //st_fpcap_hdr.snaplen = 0x40000;
    st_fpcap_hdr.linktype = 1;

    //memcpy(p_write_struct -> buffer  , (const char  *)&st_fpcap_hdr ,sizeof(struct pcap_file_header ));
    memcpy(p_write_struct -> buffer  , (const char  *)&st_fpcap_hdr ,24);

    p_write_struct -> sumlen = 24 ;//sizeof(struct pcap_file_header) ;
    p_write_struct -> bufflen = 24 ;//sizeof(struct pcap_file_header);

    char file_name[1024] ;
    //20160714 ���ı���Ϊstring*����
    if (InterText::save_pcap_flag == 5)
    {
        //��ȡ����ʱ��
        memset(file_name, 0, 1024);
        struct tm* t = NULL;
        time_t tt;
        time(&tt);
        t = localtime(&tt);
        if (t == NULL)
        {
            return ;
        }
        //sprintf(file_name,"%s/%s.pcap%c",InterText::save_pcap_lost_path,p_write_struct->p_strfile_name->c_str() , 0x0);
        //��ȡ�ļ����·��
        sprintf(file_name, "%s/", InterText::save_pcap_lost_path);
        const char* p_str = p_write_struct->p_strfile_name->c_str();
        if (p_str == NULL)
        {
            return ;
        }
        const char* p_begin = strstr(p_str, "_");
        if ((p_begin != NULL) && ((p_begin-p_str)> 1) && ((p_begin-p_str)<p_write_struct->p_strfile_name->size()))
        {
            //�ļ��������������е�save_ip_pcap_name�����õ�����
            memcpy(file_name+strlen(file_name), p_str, p_begin-p_str);
            //������ǰ���ļ����������ʱ����_��ʼ
            sprintf(file_name+strlen(file_name), "_%d-%02d-%02d_%02d-%02d-%02d", t->tm_year+1900, t->tm_mon+1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);
            //�Ӵ�����ļ����н���ip��host���ӵ���ǰ�ļ������
            memcpy(file_name+strlen(file_name), p_begin, (p_write_struct->p_strfile_name)->size()-(p_begin-p_str));
            sprintf(file_name+strlen(file_name), ".pcap%c", 0x0);
        }
        else
        {
            return ;
        }
    }
    else
    {
        //���save_pcaps��־λ��Ϊ5���±ߵ�
        sprintf(file_name,"%s/%s-%d.pcap%c",InterText::save_pcap_lost_path,p_write_struct->p_strfile_name->c_str(), num, 0x0);
    }

    p_write_struct -> fp = fopen(file_name, "wb+");
    if(p_write_struct -> fp == NULL || p_write_struct -> buffer  == NULL)
    {
        exit(1);
    }

}
void buf_file_destroy(struct write_buf_file * p_file)
{
    if(p_file ->fp != NULL)
    {
        if(p_file->bufflen != 0 )
        {
            fwrite(p_file -> buffer  ,p_file -> bufflen ,1, p_file->fp);
        }
        fclose(p_file -> fp ) ;
        p_file -> fp  = NULL;
        // fflush(p_file ->fp) ;
    }
    if(p_file -> buffer != NULL)
    {
        free(p_file -> buffer );
        p_file -> buffer = NULL;
    }

}
int write_packet_buf_file(struct write_buf_file *p_file ,char * data, int len,struct timeval  ts )
{
    struct pcap_pkthdr_p m_pkehdr;
    /* m_pkehdr.ts .tv_sec  = htonl(ts.tv_sec);
       m_pkehdr.ts .tv_usec  = htonl(ts.tv_usec);*/
    //m_pkehdr.t_stamp  = ts;//ts.tv_sec * 1000000 + ts.tv_usec ;
    //�޸�ʱ�������ȷ��¼�����ʱ��
    //2016-8-29 by penghuiliang
    m_pkehdr.sec  = ts.tv_sec;//ts.tv_sec * 1000000 + ts.tv_usec ;
    m_pkehdr.usec  = ts.tv_usec;//ts.tv_sec * 1000000 + ts.tv_usec ;
    //  memcpy((char*)(&(m_pkehdr.ts)), (const char *)(&ts), 8);
    //m_pkehdr.caplen = ntohl(len );
    //m_pkehdr.len = ntohl(len);
    m_pkehdr.caplen = len;
    m_pkehdr.len = len;

    if(data == NULL)
        return 0;
    char *p_data = data;
    //20160714 ���Ļ�������С MAXBUF_FILE
    if(p_file->bufflen + len + sizeof(struct pcap_pkthdr_p) > MAXBUF_FILE)
    {
        write_file(p_file) ;
        if(p_file ->sumlen + 2 * 1024 * 1024  >= MAXFILE)
        {
            p_file ->init(p_file,0,NULL);
            //   p_file = (struct write_buf_file *)malloc(sizeof(struct write_buf_file)) ;
            // char * p_file_name = "111";
            // buf_file_init(p_file,1, p_file_name);
            // *pp_file = p_file ;
        }
        //20160714 ���Ļ�������С MAXBUF_FILE
        if(len + sizeof(struct pcap_pkthdr_p)  > MAXBUF_FILE)
        {
            if(p_file ->fp != NULL && p_data != NULL )
            {
                fwrite(&(m_pkehdr),16, 1 , p_file ->fp ) ;
                fwrite(p_data ,len ,1, p_file->fp);
                p_file ->sumlen += len  + 16;
                if(p_file ->sumlen + 2 * 1024 * 1024  >= MAXFILE)
                {
                    p_file ->init(p_file,0,NULL);
                }
            }
            p_file ->bufflen = 0;
        }
    }
    //memcpy(p_file -> buffer  + p_file -> bufflen ,(const char  *)&(m_pkehdr),sizeof(struct pcap_pkthdr)) ;
    if(data != NULL && len >= 0)
    {
        memcpy(p_file ->buffer  + p_file ->bufflen ,(const char  *)&(m_pkehdr),16) ;
        p_file ->bufflen += 16 ;
        memcpy(p_file ->buffer + p_file ->bufflen ,data , len ) ;
        p_file ->bufflen += len ;
    }
}
void write_file(struct write_buf_file * p_file)
{
    if( p_file ->bufflen > 0 && p_file->buffer != NULL &&  p_file ->fp != NULL)
        fwrite(p_file->buffer , p_file ->bufflen , 1 , p_file ->fp ) ;
    p_file ->sumlen += p_file ->bufflen ;
    p_file ->bufflen = 0 ;
}



