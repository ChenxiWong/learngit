// Last Update:2015-09-10 15:11:06
/**
 * @file out_put_data.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-09
 */

#ifndef OUT_PUT_DATA_H
#define OUT_PUT_DATA_H

#include <data_interface_base.h>
#include <DataFormatBase.h>
#include <string>
#include <map>
using namespace  std;
class out_put_data
{
    public :
        virtual void handle(void * data , int b_out_type ,TCFDATALIST * plist ) ;
};





#endif  /*OUT_PUT_DATA_H*/
