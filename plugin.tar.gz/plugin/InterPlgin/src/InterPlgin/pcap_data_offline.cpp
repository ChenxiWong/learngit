// Last Update:2016-07-18 08:09:10
/**
 * @file pcap_data_offline.cpp
 * @brief :
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-03-30
 */
#include "pcap_data_offline.h"
#include <commit_tools.h>
#include "InterText.h"
#include <pthread.h>
#include <clog.h>

static __thread    thread_pool * pSortQueue  =NULL;
static __thread    void * p_this = NULL;
uint64_t pcap_data_offline::send_begin_time = 0; 
uint64_t pcap_data_offline::sum_byte_num  = 0 ;

//int pcap_data_offline::nPut2TimeOut=0;

bool pcap_data_offline::bNeedInitTime=false;

pcap_data_offline::pcap_data_offline( thread_pool  * SortQueue ,void * pthis)
{
    pSortQueue  = SortQueue;
    p_this = pthis;
    //uint64_t pcap_data_offline::sum_byte_num  = 0 ; 
    //uint64_t pcap_data_offline::send_begin_time = 0 ;
}

pcap_data_offline::~pcap_data_offline()
{
}


void pcap_data_offline::check_dir()
{
    // printf(" pcap_data_offline::check_dir  \n");

    //检查目录 
    //char ch,infile[128],outfile[50];
    struct dirent *ptr;
    DIR *dir;
    filelist.clear();
    dir=opendir(InterText::offline_pcap_dir->c_str());
    while((ptr=readdir(dir))!=NULL)
    {   

        //跳过'.'和'..'两个目录
        if(ptr->d_name[0] == '.')
            continue;
        //   检测文件是否存在

        if(cmp_wiat_end(ptr->d_name,".pcap") || cmp_wiat_end(ptr->d_name,".cap"))
        {

            filelist.push_back(*InterText::offline_pcap_dir + string(ptr->d_name) );
        }
    }   
    closedir(dir);  

}

//将file_pcap_parse返回值修改为bool用以判断执行结果。
//filename 输入的包文件
//return 0 成功
//       >0 打开文件失败
//       <0 打开文件后，读取过程有异常
int pcap_data_offline::file_pcap_parse(string filename )
{
    // 28dd----
    int ret = 0;
    char sz_error[PCAP_ERRBUF_SIZE];
    pcap_t* pPcap = pcap_open_offline(filename.c_str(), sz_error);
    //对pcap_open后的返回值进行判断。
    if(pPcap)
    {       
        //cout << "parse_open success." << endl;
        // printf("file=[%s]\n",itr->c_str());
        int32_t PKT_CNT_ALL = -1;
        //static  int nRetCode = pcap_loop(pPcap, PKT_CNT_ALL, pcap_data_offline::call_back, (u_char *) pPcap);

        pcap_data_offline::bNeedInitTime=true;


        int nRetCode = pcap_loop(pPcap, PKT_CNT_ALL, pcap_data_offline::call_back, (u_char *)NULL );
        if (nRetCode < 0)
        {
            printf("PCAP LOOP ERROR: %s \r\n", pcap_geterr(pPcap));
            // 写日志 ，打开文件失败 
            
            //phl 2016-7-25出错的包统一关闭并移走。 
            //pcap_close(pPcap);
            //return false;
            ret = -1;
            //phl 2016-7-25出错的包统一关闭并移走。 
        }
        pcap_close(pPcap);

        // 移动文件 
        if(InterText::b_offline_remove_pcap )
        {
            string target = *InterText::offline_pcap_save;

            //    target +=*itr;
            string tmp = filename;

            target+="/";
            //提取文件名
            //
            target += string(tmp,InterText::offline_pcap_dir->size(),tmp.size());

            rename(tmp.c_str(), target.c_str());
        }
    }
    else
    {
        //cout << "parseopen false." << endl;
        ret = 1;
    }
    return ret;
}
void pcap_data_offline::pcap_parse() 
{
    // 读取目录下的所有 pcap 和 cap 文件
    // static int i =1;
    struct timeval tv ;
    gettimeofday(&tv,NULL);
    pcap_data_offline::send_begin_time = tv.tv_sec * 1000000 + tv.tv_usec ; 
    pcap_data_offline::sum_byte_num  = 0 ;

    uint64_t begin_time;
    for(;;)
    {
        gettimeofday(&tv,NULL);
        begin_time = tv.tv_sec * 1000000 + tv.tv_usec ; 
        
        check_dir();
        // 开始读取数据包   
        list<string>::iterator itr = filelist.begin() ;
        int w=0;
        int x=0;
        int y=0;
        for(;itr!= filelist.end();itr++)
        {              
            cout << "File "<< *itr << " will be read." << endl;
            system("date");
            cout << "filename is " << *itr << endl;
            //当file_pcap_parse返回为true时才会进行统计。
            //phl 2016-7-25 出错的包统一日志记录
            int ret = file_pcap_parse(*itr);
            system("date");
            if(ret == 0)
            {
                cout << "File is "<< *itr << " and was read successfully." << endl;
                ++w;
            } 
            if(ret > 0)
            {
                cout << "File is "<< *itr << " and was opened failed." << endl;
                ++x;
            }
            if(ret < 0)
            {
                cout << "File is "<< *itr << " and was opened successfully but read failed." << endl;
                ++y;
            }
            //phl 2016-7-25 出错的包统一日志记录
        }
        if(w>0 || y>0)
        {
            struct timeval ts ;
            gettimeofday(&ts,NULL);
            uint64_t end_time = ts.tv_sec * 1000000 + ts.tv_usec ; 
            printf("本次扫描目录发送文件数量[%d]个,但其中[%d]个文件读取有异常。共计耗时[%llu]s.\r\n",  w+y,y,(end_time - begin_time) /1000000 );
            system("date");
            /*printf(" 自从开机以来累计发送总量 %llu bit, %llu M, 发送时间 %llu s , 平均速度 %llu  mbps \n" , 
                pcap_data_offline::sum_byte_num * 8 ,
                pcap_data_offline::sum_byte_num /1000000 ,
                (end_time - pcap_data_offline::send_begin_time) /1000000 ,  
                pcap_data_offline :: sum_byte_num * 8 / (end_time - pcap_data_offline::send_begin_time)) ;*/
            LOG(INFO) << " 累计发送总量 :" << pcap_data_offline::sum_byte_num * 8 <<"bit, "<<pcap_data_offline::sum_byte_num /1000000 <<"M , 发送时间 "<< (end_time - pcap_data_offline::send_begin_time) /1000000 << " s , 平均速度 " << pcap_data_offline :: sum_byte_num * 8 / (end_time - pcap_data_offline::send_begin_time)  <<" mbps " ;
            //abort();
        }
    }         
}

/* 时间值比较大小 */  
//by phl 2016-8-8
int TimeCompare(const struct timeval *tv1, const struct timeval *tv2)  
{  
    /* 如果秒值不一致则秒值大者较大 */  
    if (tv1->tv_sec > tv2->tv_sec)  
        return 1;  
    else if (tv1->tv_sec < tv2->tv_sec)  
        return -1;  
    /* 秒值相同的，微秒值较大者较大 */  
    else if (tv1->tv_usec > tv2->tv_usec)  
        return 1;  
    else if (tv1->tv_usec < tv2->tv_usec)  
        return -1;  
    /* 秒值和微秒值皆相同者等值 */  
    else  
        return 0;  
} 


/* 计算两个时间的差值 */  
//by phl 2016-8-8
void TimeSubstract(const struct timeval *tv1, const struct timeval *tv2, struct timeval *tvres)  
{  
    /* 变量声明 */  
    const struct timeval *tmptv1, *tmptv2;  
    int cmpres;  
      
    /* 比较tv1和tv2，将较大值赋给tmptv1，较小值赋给tmptv2 */  
    cmpres = TimeCompare(tv1, tv2);  
    if (cmpres > 0) {  
        tmptv1 = tv1;  
        tmptv2 = tv2;  
    }   
    else {  
        tmptv1 = tv2;  
        tmptv2 = tv1;    
    }  
  
    /* 做差时存在借位的情况 */  
    if (tmptv1->tv_usec < tmptv2->tv_usec) {  
        /* 结果的秒数多减1，借给微秒 */  
        tvres->tv_sec = tmptv1->tv_sec - tmptv2->tv_sec - 1;  
        /* 微秒做减法时，先加上借来的一秒（1000000微秒） */  
        tvres->tv_usec = tmptv1->tv_usec + 1000000 - tmptv2->tv_usec;  
    /* 不存在借位的情况 */  
    } else {  
        /* 对应的秒和微秒分别做差 */  
        tvres->tv_sec = tmptv1->tv_sec - tmptv2->tv_sec;  
        tvres->tv_usec = tmptv1->tv_usec - tmptv2->tv_usec;  
    }  
}



void pcap_data_offline::call_back(u_char * user , const struct pcap_pkthdr * hdr ,const u_char * pkt)
{
    //printf("************************************************\n");
    static int l = 0 ;
    //回调函数  
    //by phl 2016-8-8
    if(InterText::i_send_byte_num < 0 )
    {
        //InterText:: b_remove_updata_time = true 
        //都更改为设备时间，保证数据包链路的超时工作正常
        //模拟时间序列模式
        //最初的设备时间
        static  struct timeval firstPktLocalTime;
        //最初的pcap时间
        static  struct timeval firstPktFileTime;
        //static bool bInitFirst=false;
        static struct timeval localPass ; 
        static struct timeval filePass ; 
        
        struct timeval tv ;
        if(true == bNeedInitTime)
        {
            gettimeofday(&firstPktLocalTime,NULL);
            firstPktFileTime = hdr->ts;
            bNeedInitTime =false;  
        }
        TimeSubstract(&firstPktFileTime,&hdr->ts, &filePass) ;
        for(;;)
        {
            gettimeofday(&tv,NULL);
            TimeSubstract(&firstPktLocalTime,&tv, &localPass) ;
            //本地经历时间大于文件数据包时间差额
            if(TimeCompare(&localPass, &filePass)  >= 0)
            {
                break;
            }
            usleep(100) ;
        }
        char * p = new char[hdr->len+1];
        if (p == NULL)//这5行同上
        {
            return ;
        }
        
        
        memset(p, 0, hdr->len+1);
        memcpy(p,pkt,hdr->len);
        NodeData *pNode = new NodeData(p,hdr->len,InterText::PluginID);
        pNode -> p_CEnteranceBase = p_this;
        pNode -> ts = tv;
        pSortQueue -> push_block((work_data *)pNode, l++);
        InterText::recved_sum ++;
        pcap_data_offline::sum_byte_num += hdr->len ;
        /*
        if(pcap_data_offline:: sum_byte_num %10000 == 0)  
        {
            pcap_data_offline::send_speed_control( ) ;
        }
        */
        //parse_main_handle::get_instance()->handle(hdr->len,(char *)pkt,hdr->ts);
    }
    //by phl 2016-8-8
    else if(InterText:: b_remove_updata_time ) 
    {
        struct timeval tv ;
        gettimeofday(&tv,NULL);

        char * p = new char[hdr->len+1];
        if (p == NULL)//下边5行是用来解决webmail_plugin.cpp中get_host以及get_url中进行无效读以及访问无效空间
        {
            return ;
        }
        memset(p, 0, hdr->len+1);
        memcpy(p,pkt,hdr->len);
        NodeData *pNode = new NodeData(p,hdr->len,InterText::PluginID);
        pNode -> p_CEnteranceBase = p_this;
        pNode -> ts = tv;
        InterText::recved_sum ++;
        pcap_data_offline::sum_byte_num += hdr->len ;
        pSortQueue -> push_block((work_data *)pNode, l++);
        if(InterText:: i_push_packet_num %10000 == 0)  
        {
            pcap_data_offline::send_speed_control( ) ;
        }
        //        LOG(INFO) <<"offline 放入队列数据包  "  <<packet_num   ;
        //parse_main_handle::get_instance()->handle(hdr->len,(char *)pkt,tv);
    }
   
    else 
    {

        char * p = new char[hdr->len+1];
        if (p == NULL)//这5行同上
        {
            return ;
        }
        memset(p, 0, hdr->len+1);
        memcpy(p,pkt,hdr->len);
        NodeData *pNode = new NodeData(p,hdr->len,InterText::PluginID);
        pNode -> p_CEnteranceBase = p_this;
        pNode -> ts = hdr->ts;
        pSortQueue -> push_block((work_data *)pNode, l++);
        InterText::recved_sum ++;
        if(pcap_data_offline:: sum_byte_num %10000 == 0)  
        {
            pcap_data_offline::send_speed_control( ) ;
        }
        //parse_main_handle::get_instance()->handle(hdr->len,(char *)pkt,hdr->ts);
    }

}


void pcap_data_offline::send_speed_control( )
{
    for(;InterText::i_send_byte_num>0 ;)
    {
        struct timeval ts ;
        gettimeofday(&ts,NULL);
        uint64_t end_time = ts.tv_sec * 1000000 + ts.tv_usec ;
        uint64_t sec  = (end_time - pcap_data_offline::send_begin_time ) ;
        if(  sec - 100 > 0  && (pcap_data_offline::sum_byte_num * 8 ) / (sec -  100)  >  InterText::i_send_byte_num ) 
        {
            usleep(10) ;
        }
        else {
            break ;
        }
    }
}


