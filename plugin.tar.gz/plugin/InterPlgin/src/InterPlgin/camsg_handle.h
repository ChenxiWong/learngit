// Last Update:2015-09-10 17:57:40
/**
 * @file camsg_handle.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-20
 */

#ifndef CAMSG_HANDLE_H
#define CAMSG_HANDLE_H
#include <ZMPNMsg.pb.h>
#include <dlfcn.h>
#include <string>
using namespace std;
typedef  CANmsg* (*CAmsg_new_ptr)();
class camsg_handle 
{
    private :
        camsg_handle();
        void * handle;
        CAmsg_new_ptr ptr_new;
    public:
        ~camsg_handle();
        static camsg_handle * get_instance();
        CANmsg * CAmsg_create();
};


#endif  /*CAMSG_HANDLE_H*/
