// Last Update:2015-09-22 11:08:49
/**
 * @file out_put_data.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-09
 */
#include "out_put_data.h"
#include "InterText.h"
#include <commit_tools.h>
#include <data_interface_base.h>

//#include "zmq_client.h"
void out_put_data::handle(void * data , int b_out_type,TCFDATALIST * plist)
{
    if (b_out_type == NETSEND)
    {
        net_str * p_net = (net_str *)data;
        // 判断是否是写文件 ，写文件要取出数据

        uint64_t  file_id = 0;
        bool bMsgEnd = true;
                   // 组织数据-
       // net_data * p_data  = new net_data(p_net->msg);
           //对文件名做crc32，并进行存储
        if(p_net ->msg ->type() == 6 ) // 判断是否是--
        {
             file_id = p_net->msg->file().file_id();
        }
        if(p_net ->msg ->type() == 7)
        {
           file_id = p_net->msg->qq_file().file_id();   
        }
        if(p_net ->msg ->type() == 1)
        {
            file_id = p_net->msg->eml().file_id() ;
        }
         //----------------------------------------------- 
         CFDataMsg * p_msg = new CFDataMsg;
         p_msg -> SendType =  0x01;
         p_msg -> MsgCrc = file_id;
         p_msg -> sign =  1 ; 
         if(p_net ->msg ->type() == 6  && p_net->msg->file().has_offise()) 
         {
             p_msg -> sign =    BIGFILE ;
         }
         if((p_net ->msg ->type() == 6 && p_net->msg->file().b_end())|| (p_net ->msg ->type() ==  7 && p_net->msg->qq_file().b_end()) || (p_net ->msg ->type() ==  1 && p_net->msg->eml().b_end()) )

         {
            p_msg -> bMsgEnd  =  true;
         }
         p_msg -> pMsg = (CANmsg*)p_net -> msg;
         plist->push_back(p_msg);
         // 
         delete p_net;
    }

}






