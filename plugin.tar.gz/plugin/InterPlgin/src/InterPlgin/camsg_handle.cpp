// Last Update:2015-09-10 17:58:08
/**
 * @file camsg_handle.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-20
 */
#include "camsg_handle.h"
#include <stdio.h>
#include <stdlib.h>

camsg_handle::camsg_handle()
{
    //打开 npr_protobuf     
    string path = getenv("NPR_ROOT");
    path  += "/lib/libnpr_protobuf.so";
    handle = dlopen(path.c_str(),RTLD_LAZY);
    if(handle == NULL)
    { 
        printf("dlopen [%s] error is %s ",path.c_str(),dlerror());
        abort();
    }
    ptr_new = (CAmsg_new_ptr)dlsym(handle , "CAmsg_New");
    if(ptr_new == NULL)
    {
        printf("dlsym CAmsg_New error is %s ",dlerror());
        abort();
    }
}
camsg_handle::~camsg_handle()
{
    if(handle != NULL) 
        dlclose(handle);
}
camsg_handle * camsg_handle::get_instance()
{
    static  camsg_handle ingletion;
    return &ingletion;
}


CANmsg * camsg_handle::CAmsg_create()
{
    return ptr_new(); 
}






