/*
 * pcap_push.h
 *
 *  Created on: 2016年4月12日
 *      Author: cuixiaobo
 */

/*
#ifndef PLUGIN_INTERPLGIN_SRC_INTERPLGIN_PCAP_PUSH_H_
#define PLUGIN_INTERPLGIN_SRC_INTERPLGIN_PCAP_PUSH_H_
*/

#if !defined(_PCAP_PUSH_H_)
#define _PCAP_PUSH_H_

//#include "InterPlugin.h"
//#include "thread_pushpcap.h"
#include "threadpool.h"
#include "pcap.h"
#include <packet.h>
#include <stdlib.h>
#include <time.h>

class Pcap_cont : public work_data
{
    public:
        virtual ~Pcap_cont()
        {
            /*if(pData != NULL)
              delete pData;*/
            pData = NULL;
        }
        c_packet * pData ;
        /* int iFileID;
           string sFileName ;
           string RowFileName ;
           bool bEnd;
        //*********************
        string  Pcap_cont;*/
};


class thread_write_file_data:public work_data
{
    public:
       // c_packet *data;
       char * buf;
       int len  ;
       uint64_t tv;
       struct timeval ts;
       int hash;
       char flag;
       //存包对象指针的索引
       int pFileIndex;
       thread_write_file_data(c_packet *net_data)
       {
            //data = net_data;
           buf = new char[net_data->buff_len];
           len = net_data->buff_len;
           memcpy(buf,net_data->buff,len);
           tv = net_data->m_timeval;
           ts = (net_data->m_ts);
           flag = 0;
           type = DATA;
           hash = net_data -> hash();

       }
      virtual   ~thread_write_file_data()
        {
          if(buf != NULL)
              delete [] buf;
        }
};

class thread_write_file : public work_base
{
    public:

        thread_write_file();
        virtual ~thread_write_file();

        virtual void _Work(work_data * &pworkdata);
        virtual void reload();

        virtual void timeout();
    private:
        void write_packet_file_p(write_buf_file *p_file_real,thread_write_file_data *pdata);
        int c_write_data(char *p_data,int len);
        struct write_buf_file *p_file;
        struct write_buf_file *p_file_pcap;
        struct write_buf_file *p_file_all_pcap;
        //ip列表存包对象
        struct write_buf_file *p_file_ip_pcap;
        //  void send_data(thread_write_file_data *p_file_data);
        //  thread_pool thpool;
};

class thread_write_file_fun
{
    public:
        ~thread_write_file_fun();
        static thread_write_file_fun * get_instrance() {
            static thread_write_file_fun instrance;
            return &instrance;
        }
        void send_data(thread_write_file_data *p_file_data);
        thread_write_file_fun();
        void set_pthread_pool_fun();
        void Timeout();
    private:
        thread_pool thpool;
        thread_write_file **pp_work;
        int int_num_thread;
};

#endif /* PLUGIN_INTERPLGIN_SRC_INTERPLGIN_PCAP_PUSH_H_ */
