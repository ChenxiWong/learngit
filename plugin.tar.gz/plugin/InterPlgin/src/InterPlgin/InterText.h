// Last Update:2016-04-06 14:07:19
/**
 * @file InterText.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-25
 */

#ifndef INTER_TEXT_H
#define INTER_TEXT_H
#include <stdint.h>
#include <string>
#include <pthread.h>
#include <sys/syscall.h>
#include <protocol_parse_base_handle.h>

#include "saveip.h"

using namespace std;
class InterText {
    public:
    static __thread  uint64_t  recved;//PFRING收包数 
    static   uint64_t  recved_sum;//PFRING收包数 
    static __thread  uint64_t dropped ; // PFRING 收包失败数 

    static __thread string   *network_card ;// PFRING 监控的网卡 
    static __thread int       PluginID; // 插件ID 
    static __thread uint64_t  bytes; //PFRING 收到的字节数 
    static  int       thread_session ; //线程的session数
    static __thread string  * sz_plugin_path; //二级处理插件路径



//dpdk init args
    static string * network_pcipath_all ;
	static int MemSize;
	static int externalMbuf;

	static int rxq;
	static int txq;	
	static int	mtu;

	static char *  m_LcoreMask;
	static char *  save_all_pcap_name;
	static char *  save_ip_pcap_name;
	static char *  save_pfring_lost_name;
	static char *  save_pcap_lost_name;
	static char *  save_pcap_lost_path;
	static int MemChannel;
	static int rxDesc;
	static int txDesc;
	static int pktBurset;
	static int freeQueuePkts;
	static int workersum;
	/*-----------------end------------------*/
//end dpdk init args


//dpdk statistic

    static uint64_t  d_recved;
    static uint64_t d_dropped_all ;
    static uint64_t d_imiss ;
    static uint64_t d_ibadlen ;
    static uint64_t d_ibadcrc ;
    static uint64_t d_ibytes; 
//end dpdk statistic

    //_______________________ 
    //static uint64_t timeout ; // 超时事件

    static __thread string * sNPRRoot ; // 超时事件

    static  __thread int* iTimeOut ; 
    static  __thread int* iTcpTimeOut ; 
    static  __thread int* iUdpTimeOut ; 

// 文件读取  ------------- 
    static  __thread string *  offline_pcap_dir ;//文件读取目录 
    static  __thread bool     b_offline_remove_pcap ; // 是否转移文件
    static  __thread string  * offline_pcap_save ; //转移目标文件夹
/*
    static  __thread string  * save_pcap_lost_path ; //包输出
    static  __thread string  * save_pfring_lost_name ; //包输出
    static  __thread string  * save_pcap_lost_name ; //包输出
*/
    static  __thread bool      b_remove_updata_time ; // 是否更新时间
    static  int      ethDriverType ; // 是否更新时间
    static void * driverObj;
    static  string   line_num ; //
    static  string  device_num;
    static void  * p_attch      ; 
    static  int   i_push_packet_num  ;
    static  int   i_sort_packet_num ; 
    static  int   i_sort_null_num ; 
    static  int   i_sort_suess_num ; 
    static  int   i_sort_fail_num  ; 



    //session  丢包数 
    static  uint64_t  i_session_lost_pocket_num ;
    static  uint64_t  i_handle_lost_pocket_num ;
    static  uint64_t  i_protocol_pocket_num ;
    // 
    //捕包线程数
    static uint64_t thread_pcap_lost_num;
    //队列长度
    static uint64_t queue_len;
   //是否存包
    static int save_pcap_flag;

   //使用求模的方式，抽样保存数据包，配置文件指定模数，模后为0则保存该数据包
    static int saveall_pcap_mod;
	//保存指定的ip列表，用来判断是否保存某一个数据包
    static CSaveSpecialIp *  save_pcap_ip;
    // 测试服务---- 读包流量控制 
    //小于零时，安装pcap包的时间戳控制发送数据包
    //by phl 2016-8-8
    static  int   i_send_byte_num ; 
};






#endif  /*INTER_TEXT_H*/
