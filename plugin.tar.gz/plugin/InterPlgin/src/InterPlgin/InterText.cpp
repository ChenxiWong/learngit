// Last Update:2016-07-04 08:29:20
/**
 * @file InterText.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-25
 */

#include "InterText.h"
static int int_TCP_tmp = 6;
static int int_UDP_tmp = 6;
static int int_tmp = 6;
__thread uint64_t InterText::recved = 0 ; // pfring收包统计 
uint64_t InterText::recved_sum  = 0 ; // pfring收包统计 
__thread uint64_t InterText::dropped = 0 ; // pfring丢包统计 
__thread string * InterText::network_card = NULL;// PFring 抓包的网卡 
__thread int      InterText::PluginID = 10001; //c插件ID 
__thread uint64_t InterText::bytes = 0;   // 收到的字节数
int      InterText::thread_session = 0 ;// 线程的session数
__thread string * InterText::sz_plugin_path = NULL;// 处理插件路径
__thread string * InterText::sNPRRoot = NULL; // 

__thread int* InterText:: iTimeOut = &int_tmp;
__thread int* InterText:: iTcpTimeOut = &int_TCP_tmp;
__thread int* InterText:: iUdpTimeOut = &int_UDP_tmp;



//dpdk init args

string * InterText::network_pcipath_all=NULL;
int InterText::MemSize=512;
int InterText::externalMbuf=0;

int InterText::rxq=1;
int InterText::txq=1; 
int InterText::mtu=1520;
char * InterText::m_LcoreMask = new char [2048];
char * InterText::save_all_pcap_name = new char [200];
char * InterText::save_ip_pcap_name = new char [200];
char * InterText::save_pfring_lost_name = new char [200];
char * InterText::save_pcap_lost_name = new char [200];
char * InterText::save_pcap_lost_path = new char [200];
int InterText::MemChannel=4;
int InterText::rxDesc=16384;
int InterText::txDesc=128;
int InterText::pktBurset=64;
int InterText::freeQueuePkts=0;	
int InterText::workersum=0;
//end init args

//dpdk statistic
 uint64_t  InterText::d_recved= 0;
 uint64_t InterText::d_dropped_all= 0 ;
 uint64_t InterText::d_imiss = 0;
 uint64_t InterText::d_ibadlen = 0;
 uint64_t InterText::d_ibadcrc = 0;
 uint64_t InterText:: d_ibytes= 0;
//end statistic


__thread  string *  InterText::offline_pcap_dir  = NULL;
__thread bool      InterText::b_offline_remove_pcap  = true; // 是否转移文件
__thread  string *  InterText::offline_pcap_save  = NULL; // 转移目标文件夹
/*__thread  string *  InterText::save_pcap_lost_path  = NULL; // 转移目标文件夹
__thread  string *  InterText::save_pfring_lost_name  = NULL;
__thread  string *  InterText::save_pcap_lost_name  = NULL;*/
__thread bool      InterText:: b_remove_updata_time  = true; // 是更新时间

int      InterText::ethDriverType = 0 ; // 是更新时间
void *   InterText::driverObj=NULL;

string  InterText::line_num = "" ;
string  InterText::device_num= "";

int       InterText::i_push_packet_num = 0 ;  // 接受到的包数
int       InterText::i_sort_packet_num = 0 ; //分检接受到的数据 
int       InterText::i_sort_null_num = 0 ; //分检接受到的空指针 
int       InterText::i_sort_suess_num = 0 ; // 分检成功的数据 
int       InterText::i_sort_fail_num = 0 ; // 分检失败的数据 


uint64_t  InterText :: i_session_lost_pocket_num  = 0 ;
uint64_t  InterText :: i_handle_lost_pocket_num  = 0 ;
uint64_t  InterText :: i_protocol_pocket_num  = 0 ;

uint64_t   InterText::thread_pcap_lost_num = 0;
uint64_t   InterText::queue_len = 0;
int        InterText::save_pcap_flag = 0;
int        InterText::saveall_pcap_mod = 1;
CSaveSpecialIp *  InterText::save_pcap_ip=NULL;

//改为支持时间实时模式
//by phl 2016-8-8
int   InterText::i_send_byte_num  = 700; 

void *  InterText::p_attch = NULL;
