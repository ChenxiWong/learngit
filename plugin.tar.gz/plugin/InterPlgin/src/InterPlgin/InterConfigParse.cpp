// Last Update:2016-06-15 16:18:52
/**
 * @file CIneterConfigParse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-02
 */
#include "InterConfigParse.h"
#include <sstream>
using namespace std;

void itoa(int n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}

void assemble_path(string & path, int t)
{
    path += "[";
    string seq;
    itoa(t, seq);
    path += seq;
    path += "]";
}

CIneterConfigParse::CIneterConfigParse()
{

}

CIneterConfigParse::~CIneterConfigParse()
{

}
//void  CIneterConfigParse::getDpdkInitArgs(xml_parse & xml)

void   CIneterConfigParse::getDpdkInitArgs(xml_parse &xml)
{
    char * p_value = (char *)xml.get_value("/config/inter/dpdk/bind_pciPath");
    if(p_value !=NULL)
    {
        if(InterText::network_pcipath_all == NULL)
        {
            InterText::network_pcipath_all = new string();
        }
        *InterText::network_pcipath_all= p_value;
    }
    p_value = (char *)xml.get_value("/config/inter/dpdk/memHuge");
    if(p_value !=NULL)
    {
        InterText::MemSize= atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/inter/dpdk/externalMbuf");
    if(p_value !=NULL)
    {
        InterText::externalMbuf= atoi(p_value);
    }


}
void CIneterConfigParse::parse(string xmlstr)
{
    xml_parse  xml; 
    if(InterText::network_card == NULL) 
    {
        InterText::network_card =  new string("");
    }
    if(InterText::iTimeOut == NULL) 
    {
        InterText::iTimeOut =  new int(0);
    }
    if(InterText::iTcpTimeOut == NULL) 
    {
        InterText::iTcpTimeOut =  new int(0);
    }
    if(InterText::iUdpTimeOut == NULL) 
    {
        InterText::iUdpTimeOut =  new int(0);
    }
    if(InterText::sz_plugin_path == NULL) 
    {
        InterText::network_card =  new string("");
    }
    if(InterText::sNPRRoot == NULL) 
    {
        InterText::network_card =  new string("");
    }
    if(InterText::offline_pcap_dir == NULL) 
    {
        InterText::offline_pcap_dir =  new string("");
    }
    if(InterText::offline_pcap_save  == NULL) 
    {
        InterText::offline_pcap_save  =  new string("");
    }   
    /*if(InterText::save_pcap_lost_path  == NULL)
    {
        InterText::save_pcap_lost_path  =  new string("");
    }
    if(InterText::save_pfring_lost_name  == NULL)
    {
        InterText::save_pfring_lost_name  =  new string("");
    }
    if(InterText::save_pcap_lost_name  == NULL)
    {
        InterText::save_pcap_lost_name  =  new string("");
    }*/
    if(InterText::network_pcipath_all == NULL) 
    {
        InterText::network_pcipath_all =  new string("");
    }
    string tmp = "" ;
    xml.set_file_path(xmlstr.c_str()); 
    // 收数据插件的
    char * p_value = (char *)xml.get_value("/config/inter/thread_session");
    if(p_value !=NULL)
    {
        InterText::thread_session  = atoi(p_value);
    }

    //发送插件目录
    p_value = (char *)xml.get_value("/config/inter/plugin_path");
    if(p_value !=NULL)
    {
        *InterText::sz_plugin_path  = p_value;
    }
    //网卡 
    p_value = (char *)xml.get_value("/config/inter/netcard");
    if(p_value !=NULL)
    {
        *InterText::network_card   = p_value;
    }
    // 超时 
    p_value = (char *)xml.get_value("/config/inter/time_out");
    if(p_value !=NULL)
    {
        *(InterText::iTimeOut) = atoi(p_value);
    }
    // 超时 
    p_value = (char *)xml.get_value("/config/inter/tcp_time_out");
    if(p_value !=NULL)
    {
        *(InterText::iTcpTimeOut) = atoi(p_value);
    }
    // 超时 
    p_value = (char *)xml.get_value("/config/inter/udp_time_out");
    if(p_value !=NULL)
    {
        *(InterText::iUdpTimeOut) = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/inter/line_num");
    if(p_value !=NULL)
    {
        InterText::line_num = p_value;
    }
    p_value = (char *)xml.get_value("/config/inter/device_num");
    if(p_value !=NULL)
    {
        InterText::device_num = p_value;
    }

    p_value = (char *)xml.get_value("/config/inter/drivertype");
    if(p_value !=NULL)
    {
        InterText::ethDriverType = atoi(p_value);
    }

    
    if(InterText::ethDriverType == DPDK_DRIVER ||InterText::ethDriverType == DPDK_2_DRIVER )
    {
        getDpdkInitArgs(xml);
    }

    if( InterText::ethDriverType != PFRING_DRIVER
        &&  InterText::ethDriverType != DPDK_DRIVER 
        &&  InterText::ethDriverType != DPDK_2_DRIVER )
    {
        p_value = (char *)xml.get_value("/config/inter/offline/removefile");
        if(p_value !=NULL)
        {
            tmp = p_value;
            if(tmp == "true")
                InterText::b_offline_remove_pcap = true;
            else 
                InterText::b_offline_remove_pcap = false;

        }
        p_value = (char *)xml.get_value("/config/inter/offline/cap_files");
        if(p_value !=NULL)
        {
            *InterText::offline_pcap_dir = p_value;
        }

        p_value = (char *)xml.get_value("/config/inter/offline/save_files");
        if(p_value !=NULL)
        {
            *InterText::offline_pcap_save = p_value;
        }

        p_value = (char *)xml.get_value("/config/inter/offline/send_speed");
        if(p_value !=NULL)
        {
            InterText::i_send_byte_num = atoi(p_value);
        }


        p_value = (char *)xml.get_value("/config/inter/offline/updata_time");
        if(p_value !=NULL)
        {

            tmp = p_value;
            if(tmp == "true")
                InterText::b_remove_updata_time = true;
            else 
                InterText::b_remove_updata_time = false;
        }

    }
     p_value = (char *)xml.get_value("/config/inter/pcap_save/save_pcap_lost_path");
   if(p_value !=NULL)
    {
    memcpy(InterText::save_pcap_lost_path,p_value,strlen(p_value));
    InterText::save_pcap_lost_path[strlen(p_value)] = '\0';
    }

    p_value = (char *)xml.get_value("/config/inter/pcap_save/save_pcaps");
    if(p_value !=NULL)
    {
        InterText::save_pcap_flag = atoi(p_value);
        //2016-7-11 保存原始数据包，依照ip或散列抽样
        if(  InterText::save_pcap_flag == 1)
        {           
            p_value = (char *)xml.get_value("/config/inter/pcap_save/save_all_pcap_mod");
            if(p_value !=NULL)
            {
                InterText::saveall_pcap_mod =  atoi(p_value);
            }
        }
        if(  InterText::save_pcap_flag == 5)
        {
            //读取ip列表的配置文件名字
            p_value = (char *)xml.get_value("/config/inter/pcap_save/save_ip_pcap_list");
            if(p_value !=NULL)
            {
                InterText::save_pcap_ip =  new CSaveSpecialIp;
                assert(InterText::save_pcap_ip);
                string file  = *InterText::sNPRRoot+p_value;
                //初始化ip列表。
                InterText::save_pcap_ip->Init(file);
            }   
        }
        //2016-7-11 
    }
    


    p_value = (char *)xml.get_value("/config/inter/pcap_save/save_all_pcap_name");
    if(p_value !=NULL)
    {
        memcpy(InterText::save_all_pcap_name,p_value,strlen(p_value));
        InterText::save_all_pcap_name[strlen(p_value)] = '\0';
    }

    p_value = (char *)xml.get_value("/config/inter/pcap_save/save_pfring_lost_name");
    if(p_value !=NULL)
    {
        memcpy(InterText::save_pfring_lost_name,p_value,strlen(p_value));
        InterText::save_pfring_lost_name[strlen(p_value)] = '\0';
    }

    p_value = (char *)xml.get_value("/config/inter/pcap_save/save_pcap_lost_name");
    if(p_value !=NULL)
        {
        memcpy(InterText::save_pcap_lost_name,p_value,strlen(p_value));
        InterText::save_pcap_lost_name[strlen(p_value)] = '\0';
        }

    p_value = (char *)xml.get_value("/config/inter/pcap_save/thread_pcap_lost_num");
    if(p_value !=NULL)
        {
            InterText::thread_pcap_lost_num = atoi(p_value);
        }
    p_value = (char *)xml.get_value("/config/inter/pcap_save/queue_len");
    if(p_value !=NULL)
        {
            InterText::queue_len = atoi(p_value);
   }
  
  p_value = (char *)xml.get_value("/config/inter/pcap_save/save_ip_pcap_name");
  if(p_value !=NULL)
  {
      memcpy(InterText::save_ip_pcap_name,p_value,strlen(p_value));
      InterText::save_ip_pcap_name[strlen(p_value)] = '\0';
  }
}
