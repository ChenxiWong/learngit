// Last Update:2016-04-19 15:19:47
/**
 * @file pcap.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2016-04-04
 */

#ifndef PCAP_H
#define PCAP_H

#include <stdio.h>
#include "InterText.h"

struct write_buf_file {
    FILE* fp  ;
    char* buffer ; 
    int  bufflen  ; 
    void (*destroy)( struct write_buf_file * p_file);
    void (*init)( struct write_buf_file * p_file ,int nlen , char * name );
    int (*write_packet_file)(struct write_buf_file * p_file ,char * data, int nlen,struct timeval  ts) ;
    int sumlen  ; 
    //char * p_file_name ;
    //20160714 ���ı�������Ϊstring*
    std::string * p_strfile_name ;

};
void buf_file_init( struct write_buf_file * p_write_struct , int b_no_buf, char * p_file_name);
void buf_file_destroy(struct write_buf_file * p_file);


#endif  /*PCAP_H*/
