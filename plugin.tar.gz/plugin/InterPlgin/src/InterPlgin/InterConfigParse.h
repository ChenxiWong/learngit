// Last Update:2016-04-01 11:38:06
/**
 * @file CIneterConfigParse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-02
 */

#ifndef INTER_CIneterConfigParse_H
#define INTER_CIneterConfigParse_H

#include <xml_parse.h>
#include <string>
#include "InterText.h"
#include <stdlib.h>
using namespace std;

#define PFRING_DRIVER 1
#define DPDK_DRIVER 2
#define DPDK_2_DRIVER 3

class CIneterConfigParse {
    public:
        CIneterConfigParse();
        ~CIneterConfigParse();
        void parse(string xmlstr);
        void  getDpdkInitArgs(xml_parse &xml) ;
        
    private :

};

void assemble_path(string & path, int t);

#endif  /*CIneterConfigParse_H*/
