// Last Update:2016-02-26 16:29:34
/**
 * @file telnet_plugin.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-29
 */

#ifndef TELNET_PLUGIN_H
#define TELNET_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "telnet_str.h"
#include <tcp_recombine.h>
#include <map>
#include <list>

#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;

#define CMD_STATE 1
#define USER_NAME_STATE 2
#define USER_PASSWD_STATE 3
#define LOGEDIN_FIRST_STATE 4
#define LOGEDIN_FIN_STATE 5

static char TELNET_NO_NULL[1]={0} ;

extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info *);
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

typedef list<char> str_list;

class telnet_plugin :public protocol_parse_base_handle{
    public:
        telnet_plugin();
        ~telnet_plugin();
        virtual void reload();
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);

        map <rule_node_offist * , int  >  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;

    private:

        void init_telnet_session(telnet_session * p_telnet_session);

        bool search_cmd(char const * begin, char const * end, string const & str);
        char const * search_cmd2(char const * begin, char const * end, string const & str);

        uint32_t  telnet_time_out; // 单位s
        int       data_interface_type ;

        uint32_t begin_len;
        char * begin_data;

        xml_parse  xml;
        uint64_t begin_time;
        uint32_t row;
        uint32_t max_row;
        uint32_t max_time_scr;

        string file_path;
        string file_name;
        string file_data;
        str_list passwd_list;
        str_list user_list;

        w_file_str *file_str;
};
static attach_info * p_attach_info ;
#endif  /*TELNET_PLUGIN_H*/
