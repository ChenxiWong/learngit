// Last Update:2015-04-29 20:20:07
/**
 * @file telnet_str.h
 * @brief telnet Session 定义
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-27
 */

#ifndef TELNET_STR_H
#define TELNET_STR_H

#include <session.h>
#include <stdint.h>
#include <string> 
#include <list> 
using namespace std;



class telnet_session
{
    public:
       uint64_t requst_time;
       uint64_t response_time;
       string   *username;
       string   *passwd;
       uint32_t   b_available;

       bool b_c2s; // 方向判断，是不是C -> s
       uint32_t  len;
       char *  p_data;
       char proto_state;
};

#endif  /*TELNET_STR_H*/
