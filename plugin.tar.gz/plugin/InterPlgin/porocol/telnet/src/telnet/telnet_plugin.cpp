// Last Update:2016-03-08 15:31:16
/**
 * @file telnet_plugin.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-29
 */

#include "telnet_plugin.h"
#include "commit_tools.h"
#include <algorithm>
#include <functional>
#include <sys/stat.h>
#include <string>

//#include "shm_statistics.h"


//static unsigned long long *plugin_shmid_telnet = NULL;
//static unsigned long long *plugin_shmid_telnet1 = NULL;

#define TELNETDEFINEPORT 23         //根据端口号识别协议
// 一下为 协议解析过程中的一些关键字
string const input_pattern("输入"); // 暂时没有用到
static char input_pattern_char1[] = {0xca,0xe4,0xc8,0xeb,0x00}; // “输入”  GBK2312编码
string const input_pattern_asc1 = input_pattern_char1;
string const user_pattern2("代号");
static char  user_pattern_char2[] = {0xb4,0xfa,0x00};     //“代”  GBK2312编码
string const user_pattern_asc2 = user_pattern_char2;
string const user_pattern3("帐号");
static char  user_pattern_char3[] = {0xd5,0xca,0x00};  // GBK2312编码  "帐"
string const user_pattern_asc3 = user_pattern_char3;
string const passwd_pattern3("密码");
static char  passwd_pattern_char3[] = {0xc3,0xdc,0xc2,0xeb,0x00};   // GBK2312编码  “密码”
string const passwd_pattern_asc3 = passwd_pattern_char3;
string const user_pattern("login:");
string const passwd_pattern("\n\rpassword: ");
string const passwd_pattern2("口令");
string const failed_login("Login Failed");
static char failed_login_char1[] = {0xc3,0xdc,0xc2,0xeb,0xca,0xe4,0xc8,0xeb,0x00}; // “密码输入”（错误）  GBK2312编码
string const failed_login_pattern_asc1 = failed_login_char1;
static char success_login_char1[] = {0xff,0xfa,0x1f,0x00};    //成功标志的一部分 并无实际意义
string const success_login_pattern_asc1=success_login_char1;
static char success_login_char2[]={0x1b,0x5b,0x48,0x1b,0x5b,0x4a,0x00};
string const success_login_pattern_asc2=success_login_char2;
//  以下针对输入错误的登录名 的关键字
static char error_id[] = {0xce,0xde,0x00};        // GB2312 "无"
string const error_id_pattern = error_id;
static char error_id1[] = {0xb4,0xed,0xce,0xf3,0x00}; // GB2312 "错误"
string const error_id_pattern1 = error_id1;
extern "C" {
#include<ctype.h>     // 引入一个便准C 的库函数
    int get_plugin_id()
    {
        return 5;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p ; 
        return new  telnet_plugin();
    }
}
char * cmd_fetch(char * &data,int len , telnet_session * p_telnet_session)
{
    if(len<2 || data==NULL)
        return NULL;
    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_cmd =data ;
    p_telnet_session->p_data = splits_string(p_cmd,0x20);

    if((uint32_t)len > strlen(p_cmd)+1)
        p_telnet_session->len = (uint32_t)len -strlen(p_cmd) -1;
    return p_cmd;
}
telnet_plugin::telnet_plugin()
{
    data_interface_type = FILESEND;
    telnet_time_out = 60;
    row = 0;
    max_row = 9999;
    max_time_scr = 1;
    file_path = "";
    file_name = "";
    reload();
}
telnet_plugin::~telnet_plugin()
{
}
void telnet_plugin::reload()
{
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");   // 获取配置
    config_path += "conf/telnet_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" ) 
        {
            data_interface_type = NETSEND;
        }
    }
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        telnet_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if(p_value != NULL)
    {
        max_row = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if(p_value != NULL)
    {
        max_time_scr = atoi(p_value);
    }
}
void telnet_plugin::init_telnet_session(telnet_session * p_telnet_session)
{
    p_telnet_session->requst_time = 0;
    p_telnet_session->response_time = 0;

    p_telnet_session->p_data = NULL;
    p_telnet_session->len = 0;

    p_telnet_session->proto_state = CMD_STATE;    // 初始化 状态为 CMD_STATE

    if(p_telnet_session->username == NULL)
    {
        p_telnet_session->username = new string();
    }
    *(p_telnet_session->username) =  "";

    if(p_telnet_session->passwd == NULL)
        p_telnet_session->passwd =  new string();
    *(p_telnet_session->passwd )=  "";
}
bool telnet_plugin::potocol_identify(session * p_session, c_packet * p_packet)  // 协议识别
{
    if(!p_packet->b_is_tcp)
    {
        return false;
    }
    // 用端口判断是否是TELNET协议
    if(ntohs(p_session->srcport) == TELNETDEFINEPORT)
    {
        p_session->b_src_is_ser  = true;
        telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
        init_telnet_session(p_telnet_session);
        return true;
    }
    else if(ntohs(p_session->dstport) == TELNETDEFINEPORT)
    {
        p_session->b_src_is_ser = false;
        telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
        init_telnet_session(p_telnet_session);
        return true;
    }
    return false;
}
void telnet_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_packet == NULL)
        return;
    telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
    // 连接 去除
    if(!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }
    // 连接 去除  
    if(p_packet->p_tcphdr->fin == 1)
    {
        if(p_session->client.get_data_len() > 0 || p_session->server.get_data_len())
        {
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
        return;
    }
    if((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) ||
            (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port() ) )
    {
        p_telnet_session->b_c2s = false;
    }
    else
    {
        p_telnet_session->b_c2s = true;
    }
    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len;
    if(len == 0)
        return;
    char * p_data =(char *)p_packet -> p_app_data;
    if(p_data == NULL)
        return;
    // seq 判断 
    if(p_telnet_session->b_c2s) // 目标是server  ， 数据是 client的 
    {
        p_telnet_session->requst_time = p_session ->packet_time;
        p_session->client.add_tcp_packet(len, p_data, seq);   // 重新组包
        //判断包是否连续
        p_telnet_session->p_data = p_session->client.get_tcp_data(p_telnet_session->len);
        if(p_telnet_session->proto_state==USER_NAME_STATE || p_telnet_session->proto_state==USER_PASSWD_STATE)
        {
            // 组包，对客户端输入的用户名，密码进行数据缓存，一起输出
            int len = p_telnet_session->len;
            if(len > 2)
            {
                if(*p_telnet_session->p_data == -1)
                {
                    SET_EXPORT(p_session);
                }else if( *(p_telnet_session->p_data+len-2)=='\r' &&
                        (*(p_telnet_session->p_data+len-1)=='\n'  || *(p_telnet_session->p_data+len-1)=='\x00'))
                {
                    SET_EXPORT(p_session);
                }
                else if( *(p_telnet_session->p_data+len-1)=='\r')
                {
                    SET_EXPORT(p_session);
                }
                else if( *(p_telnet_session->p_data+len-1)=='\x0a')
                {
                    SET_EXPORT(p_session);
                }
            }
            return;
        }
        if(p_telnet_session->len > 2)
        {
            SET_EXPORT(p_session);
            return;
        }
    }
    else
    {
        p_telnet_session->response_time = p_session->packet_time;
        p_session->server.add_tcp_packet(len, p_data, seq);
        //判断包是否连续
        p_telnet_session->p_data= p_session->server.get_tcp_data(p_telnet_session->len);
        if(p_telnet_session->len > 8) // ..login: , 主要是对客户端输入的用户名服务器应答的单个字符的数据进行缓存
        {
            SET_EXPORT(p_session);
            return;
        }
    }
    return;
}

void telnet_plugin::pococol_parse_handle(session * p_session)
{
    telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
    if(p_telnet_session->p_data==NULL || p_telnet_session->len==0)
    {
        return;
    }
    begin_len = p_telnet_session->len;
    begin_data =  p_telnet_session->p_data;
    if(p_telnet_session->b_c2s)
    {
        switch(p_telnet_session->proto_state)
        {
            case USER_NAME_STATE:
                {
                    if(*begin_data =='\xff')    // 丢弃无用的包
                    {
                        p_session->client.clear_buf();
                        return;
                    }
                    for(uint32_t i=0; i<begin_len; ++i,++begin_data)
                    {
                        if((*begin_data=='\b'||*begin_data=='\x7f') && !user_list.empty())
                            user_list.pop_back();
                        else if((*begin_data)=='\r'|| (*begin_data)=='\n')
                        {
                            if(!user_list.empty())
                            {
                                string user = "";
                                str_list::iterator b = user_list.begin();
                                str_list::iterator e = user_list.end();
                                for(; b!=e; ++b)
                                {
                                    user += *b;
                                    *b = 0 ;
                                }
                                user_list.clear();
                                if(user.length() > 50) // 设置最大长度，防止取出的是乱码
                                    user = "";
                                *(p_telnet_session->username) = user;
                               // telnet_counter tlnt(&plugin_shmid_telnet,&plugin_shmid_telnet1);
                                //tlnt.cnt_atomic_operate_add1(1);
                                p_telnet_session->proto_state = USER_PASSWD_STATE;
                            }
                            if(i+2<=begin_len && (*(begin_data+1)=='\n') )
                            {
                                ++i;
                                ++begin_data;
                            }
                        }
                        else if( isgraph(*begin_data))
                        {
                            user_list.push_back(*begin_data);
                        }
                    }
                    p_session->client.clear_buf();
                    return;
                }
                break;

            case USER_PASSWD_STATE:
                {
                    if((*(p_telnet_session->username)).empty())
                        SET_SESSION_OVER(p_session);

                    for(uint32_t i=0; i<begin_len; ++i,++begin_data)
                    {
                        if((*begin_data=='\b' || *begin_data=='\x7f') && !passwd_list.empty())
                            passwd_list.pop_back();
                        else if((*begin_data)=='\r' || (*begin_data)=='\n')
                        {
                            if(!passwd_list.empty())
                            {
                                string pwd = "";
                                str_list::iterator b = passwd_list.begin();
                                str_list::iterator e = passwd_list.end();
                                for(; b!=e; ++b)
                                {
                                    pwd += *b;
                                }
                                passwd_list.clear();
                                char * data = new char[pwd.size()+1];
                                strcpy(data, pwd.c_str());
                                *(p_telnet_session->passwd) = data;
                                p_telnet_session->proto_state = LOGEDIN_FIRST_STATE;
                                delete []data;
                                data = NULL;
                            }
                            if(i+2<=begin_len && (*(begin_data+1)=='\n'))
                            {
                                ++i;
                                ++begin_data;
                            }
                        }
                        else if(isgraph(*begin_data))
                        {
                            passwd_list.push_back(*begin_data);
                        }
                    }

                    p_session->client.clear_buf();
                    return;
                }
                break;
            case LOGEDIN_FIRST_STATE:
                {
                    // ff fa 18 00 41 4e 53 49  ff f0   标示成功登陆
                    // ff fa 1f 00 50 00 1a ff  f0
                    // ff fa 1f 00 50 00 19 ff  f0
                    char const * pos2 =search_cmd2(begin_data,begin_data+begin_len,success_login_pattern_asc1);
                    if((pos2 != (begin_data+begin_len))&&((*(pos2+3)=='\x00')
                                &&(*(pos2+7)=='\xff')&&(*(pos2+8)=='\xf0')))
                    {
                        // 输出数据
                        p_session->send_len = 1;
                        p_telnet_session->b_available = 1;
                       // telnet_counter tlnt(&plugin_shmid_telnet, &plugin_shmid_telnet1);
                        //tlnt.cnt_atomic_operate_add(1);
                        p_session->p_send_buf = TELNET_NO_NULL;
                        p_session->client.clear_buf();
                        p_telnet_session->proto_state = CMD_STATE;
                        SET_SESSION_OVER(p_session);
                        return;
                    }
                    if(begin_len < 9)
                    {
                        p_session->client.clear_buf();
                        return;
                    }
                    if((((*begin_data)=='\xff') && (*(begin_data+1)=='\xfa') && (*(begin_data+2)=='\x18')&& (*(begin_data+3)=='\x00')
                                && (*(begin_data+4)=='\x41') && (*(begin_data+5)=='\x4e')&& (*(begin_data+6)=='\x53')
                                && (*(begin_data+7)=='\x49') && (*(begin_data+8)=='\xff')&& (*(begin_data+9)=='\xf0'))
                            ||(((*begin_data)=='\xff')&&(*(begin_data+1)=='\xfa')&&(*(begin_data+2)=='\x1f')
                                &&(*(begin_data+3)=='\x00')&&(*(begin_data+7)=='\xff') && (*(begin_data+8)=='\xf0')))
                    {
                        // 输出数据
                        p_telnet_session->b_available = 1;
                        p_session->send_len = 1;
                        p_session->p_send_buf = TELNET_NO_NULL;
                      //  telnet_counter tlnt(&plugin_shmid_telnet, &plugin_shmid_telnet1);
                        //tlnt.cnt_atomic_operate_add(1);
                        p_session->client.clear_buf();
                        p_telnet_session->proto_state = CMD_STATE;
                        SET_SESSION_OVER(p_session);
                        return;
                    }
                    p_telnet_session->b_available = 0;
                    p_session->send_len = 1;
                    p_session->p_send_buf = TELNET_NO_NULL;
                    p_session->client.clear_buf();
                    p_telnet_session->proto_state = CMD_STATE;
                    SET_SESSION_OVER(p_session);
                }
                break;
            default:
                break;
        }
        p_session->client.clear_buf();
    }
    else
    {
        switch(p_telnet_session->proto_state)
        {
            case CMD_STATE:
                {
                    if(begin_len < user_pattern.length())
                    {
                        p_session->server.clear_buf();
                        return;
                    }
                    bool ret = search_cmd(begin_data, begin_data+begin_len, user_pattern);
                    bool ret1=search_cmd(begin_data, begin_data+begin_len,input_pattern_asc1+user_pattern_asc3);
                    bool ret2=search_cmd(begin_data, begin_data+begin_len,input_pattern_asc1+user_pattern_asc2);
                    if(!ret && !ret1 && !ret2  )
                    {
                        p_session->server.clear_buf();
                        return;
                    }

                    p_telnet_session->proto_state = USER_NAME_STATE;
                    p_session->server.clear_buf();
                }
                break;

            case USER_PASSWD_STATE:
                {
                    if(begin_len < passwd_pattern.length())
                    {
                        p_session->server.clear_buf();
                        return;
                    }
                    bool ret3 = search_cmd(begin_data,begin_data+begin_len,error_id_pattern);
                    bool ret4 = search_cmd(begin_data,begin_data+begin_len,error_id_pattern1);
                    if(ret3 || ret4)
                    {
                        p_telnet_session->b_available = 0;
                        p_session->send_len = 1;
                        p_session->p_send_buf = TELNET_NO_NULL;
                        p_telnet_session->proto_state = USER_NAME_STATE;
                        p_session->server.clear_buf();
                        return;
                    }
                    bool ret = search_cmd(begin_data, begin_data+begin_len, passwd_pattern);
                    bool ret1 = search_cmd(begin_data,begin_data+begin_len,input_pattern_asc1+passwd_pattern_asc3);
                    if(!ret && !ret1)
                    {
                        p_session->server.clear_buf();
                        return;
                    }
                    p_telnet_session->proto_state = USER_PASSWD_STATE;
                    p_session->server.clear_buf();
                    return;
                }
                break;

            case LOGEDIN_FIRST_STATE:
                {
                    // ff fa 18 01 ff f0 
                    if(begin_len < failed_login.length())
                    {
                        p_session->server.clear_buf();
                        return;
                    }
                    char const * b = begin_data;
                    char const * e = begin_data+begin_len;
                    char const * r = search_cmd2(b, e, failed_login);
                    if(r != e && r!=NULL)
                    {
                        // 输出数据
                        p_telnet_session->b_available = 0;
                        p_session->send_len = 1;
                        p_session->p_send_buf = TELNET_NO_NULL;
                        // 判断是否有后续的输入
                        r += failed_login.length();
                        char const * m = search_cmd2(r, e, user_pattern);
                        if(m != e && m!=NULL)
                        {
                            p_telnet_session->proto_state = USER_NAME_STATE;
                            p_session->server.clear_buf();
                            return;
                        }
                    }
                    char const* pos =search_cmd2(b,e,failed_login_pattern_asc1);
                    if(pos !=e && pos !=NULL)
                    {
                        // 输出数据
                        p_telnet_session->b_available = 0;
                        p_session->send_len = 1;
                        p_session->p_send_buf = TELNET_NO_NULL;
                        pos +=failed_login_pattern_asc1.length();
                        // 请输入
                        bool ret =search_cmd(pos,e,user_pattern);
                        if(ret)
                        {
                            p_telnet_session->proto_state = USER_NAME_STATE;
                            p_session->server.clear_buf();
                            p_session->client.clear_buf();
                            return;
                        }
                        bool ret1 = search_cmd(pos,e,input_pattern_asc1+user_pattern_asc2);
                        if(ret1)
                        {
                            p_telnet_session->proto_state = USER_NAME_STATE;
                            p_session->server.clear_buf();
                            p_session->client.clear_buf();
                            return;
                        }
                        bool ret2=search_cmd(pos,e,input_pattern_asc1+user_pattern_asc3);
                        if(ret2)
                        {
                            p_telnet_session->proto_state = USER_NAME_STATE;
                            p_session->server.clear_buf();
                            p_session->client.clear_buf();
                            return;
                        }
                        p_session->server.clear_buf();
                        p_session->client.clear_buf();
                        p_telnet_session->proto_state = CMD_STATE;
                        SET_SESSION_OVER(p_session);
                        return;
                    }
                    // \r\nLast login:  也标示成功登i陆
                    string login_str = "Last login:";
                    r = search_cmd2(b, e, login_str);
                    if(r!=e && r!=NULL)
                    {
                        // 输出数据
                        p_telnet_session->b_available = 1;
                        p_session->send_len = 1;
//                        telnet_counter tlnt(&plugin_shmid_telnet, &plugin_shmid_telnet1);
//                        tlnt.cnt_atomic_operate_add(1);
                        p_session->p_send_buf = TELNET_NO_NULL;
                        p_session->server.clear_buf();
                        p_telnet_session->proto_state = CMD_STATE;
                        SET_SESSION_OVER(p_session);
                        return;
                    }
                    // 新格式的数据包结束标记, 1b 5b 48 1b 5b 4a
                    //跳过回车换行和服务器可能返回的多个*
                    bool cterm_ret = search_cmd(begin_data,begin_data+begin_len,success_login_pattern_asc2);
                    if(cterm_ret)
                    {
                        // 输出数据
                        p_session->send_len = 1;
                        p_telnet_session->b_available = 1;
//                        telnet_counter tlnt(&plugin_shmid_telnet, &plugin_shmid_telnet1);
//                        tlnt.cnt_atomic_operate_add(1);
                        p_session->p_send_buf = TELNET_NO_NULL;
                        p_session->server.clear_buf();
                        p_telnet_session->proto_state = CMD_STATE;
                        SET_SESSION_OVER(p_session);
                        return;
                    }
                    p_telnet_session->b_available = 1;
                    p_session->send_len = 1;
                    p_session->p_send_buf = TELNET_NO_NULL;
                    p_session->client.clear_buf();
                    p_telnet_session->proto_state = CMD_STATE;
                    SET_SESSION_OVER(p_session);
                    return;
                }
                break;
            default:
                break;
        }

        p_session->server.clear_buf();
        return;
    }
}
void telnet_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
    data_interface m_data;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND)
    {
        if(p_session->send_len!=0 && p_session->p_send_buf!=NULL)
        {
            m_data.b_out_type = FILESEND;

            string requst_time;
            DNUMTOSTR(p_telnet_session->requst_time, requst_time);
            struct timeval tv ;
            gettimeofday(&tv, NULL);
            uint64_t u64_time = tv.tv_sec * 100000 + tv.tv_sec;

            if(file_path.empty())
            {
                // 文件相对路径
                file_path = "/";
                file_path += get_year_month();
                file_path += get_day_hour();
                file_path += get_min_sec();

                file_name = date_time();
                file_name += "-";
                file_name += requst_time;
                begin_time = u64_time;
                file_data= "";
                row = 0;
                file_str = new w_file_str;
            }
            file_str->finished = false;
            if(row==max_row || u64_time-begin_time > max_time_scr * 100000)
            {
                file_str->finished = true;
            }
            string telnet_file_name = file_name;
            telnet_file_name += ".telnet";
            file_str->file_path = file_path;
            file_str->file_name.swap(telnet_file_name);

            // 申请内存存储数据，写文件后自动析构
            {
                if(row > 0)
                    file_data +="\n[telnet]\n";
                else
                    file_data +="[telnet]\n";
                row ++;
                // 拷贝数据 
                requst_time = date_time3(p_telnet_session->requst_time);
                file_data += requst_time;
                file_data += "\n";
                // 用户名和密码 
                file_data += *(p_telnet_session->username);
                file_data += "\n";
                file_data += *(p_telnet_session->passwd);
                file_data += "\n";
                if(p_session -> b_src_is_ser)
                {
                    // 客户端 IP 
                    file_data += p_session->dstip.ip_str();
                    file_data += ":";
                    string dst_port = "";
                    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
                    file_data += dst_port;
                    file_data += "\n";
                    // DNS IP
                    file_data += p_session->srcip.ip_str();
                    file_data += ":";
                    string src_port = "";
                    DNUMTOSTR(ntohs(p_session->srcport), src_port);
                    file_data += src_port;
                    file_data += "\n";
                }
                else
                {
                    // 客户端 IP 
                    file_data += p_session->srcip.ip_str();
                    file_data += ":";
                    string src_port = "";
                    DNUMTOSTR(ntohs(p_session->srcport), src_port);
                    file_data += src_port;
                    file_data += "\n";
                    // TELNET IP
                    file_data += p_session->dstip.ip_str();
                    file_data += ":";
                    string dst_port = "";
                    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
                    file_data += dst_port;
                    file_data += "\n";
                }
                if(!file_str->finished)
                {
                    if(file_data.length() < 1024*1024 )
                    {
                        return;
                    }
                    else
                    {
                        file_str->finished = true;
                    }
                }
                if(file_str->finished)
                {
                    char * telnet_file_data = new char[file_data.length()+1];
                    strcpy(telnet_file_data,file_data.c_str());
                    file_str->file_data = telnet_file_data;
                    file_str->datalen = file_data.length();
                }
            }
            m_data.data = file_str;
            p_list -> push_back(m_data);
            if(file_str->finished)
            {
                file_path = "";
                file_name = "";
                begin_time = u64_time;
            }
        }
    }
    else if (data_interface_type == NETSEND)
    {
        if((*p_telnet_session->username).empty())
	{
            return;
	}
        net_str * p_net =  new  net_str;
        p_net -> msg = new CAmsg;
        p_net->msg->Clear();
        // 设置 
        p_net->msg->set_type(2); // telnet

        telnet_msg* p_telnet = p_net->msg->mutable_telnet();
        Comm_msg* p_comm =  p_telnet -> mutable_comm_msg();
        // 公共 消息 
        if(p_session -> b_src_is_ser)
        {
            p_comm ->set_src_port(ntohs(p_session->dstport));
            p_comm ->set_dst_ip(p_session->srcip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->srcport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->dstip.ip_str());
            }
        }
        else
        {
            // 客户端 IP 
            p_comm ->set_src_port(ntohs(p_session->srcport));
            p_comm ->set_dst_ip(p_session->dstip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->dstport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->srcip.ip_str());
            }
        }
        p_comm ->set_time(p_telnet_session->requst_time);
        //  域名 
        string user_name = *p_telnet_session->username;
        string user_pass = *p_telnet_session->passwd;
        //erase_not_ascii(user_name);
        //erase_not_ascii(user_pass);
        p_telnet->set_username(user_name);
        p_telnet->set_password(user_pass);
        //p_telnet->set_is_valid(p_telnet_session->b_available);
        if (p_telnet_session->b_available)
        {
            p_telnet->set_is_valid(2);
        }
        else
        {
            p_telnet->set_is_valid(1);
        }
        p_attach_info -> p_protocal -> PotocolStatistics(2,1,0,1);
        cout<<user_name<<endl<<user_pass<<endl;
        p_net ->datalen += 20 + user_name.length() + user_pass.length();
        // 接口 
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }

    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    p_session->client.clear_buf();
    if(p_telnet_session->b_available == 0 )
    {
        return;
    }
    SET_SESSION_OVER(p_session);
}

void telnet_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > telnet_time_out *100000)
    {
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
}

void telnet_plugin::resources_recovery(session * p_session)
{
    telnet_session * p_telnet_session = (telnet_session *)p_session->expansion_data;
    if(p_telnet_session -> username != NULL)
        delete p_telnet_session -> username;
    p_telnet_session -> username = NULL;

    if(p_telnet_session -> passwd != NULL)
        delete p_telnet_session->passwd;
    p_telnet_session->passwd = NULL;
}

bool telnet_plugin::search_cmd(char const * begin, char const * end, string const & str)
{
    char const ch = *(str.c_str());
    char const * r = find(begin, end, ch);
    uint32_t len = str.length();
    for(; r!=end && r!=NULL; )
    {
        if(r+len<end && memcmp(r, str.c_str(), len) == 0)
        {
            break;
        }
        else
        {
            if(r+len > end)
            {
                r = end;
                break;
            }
            else
            {
                ++r;
                r = find(r, end, ch);
            }
        }
    }
    if(r==end || r==NULL)
        return false;
    else
        return true;
}

char const * telnet_plugin::search_cmd2(char const * begin, char const * end, string const & str)
{
    char const ch = *(str.c_str());
    char const * r = find(begin, end, ch);
    uint32_t len = str.length();
    for(; r!=end && r!=NULL; )
    {
        if(r+len<end && memcmp(r, str.c_str(), len) == 0)
        {
            break;
        }
        else
        {
            if(r+len > end)
            {
                r = end;
                break;
            }
            else
            {
                ++r;
                r = find(r, end, ch);
            }
        }
    }
    return r;
}
