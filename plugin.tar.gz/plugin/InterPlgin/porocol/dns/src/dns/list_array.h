#ifndef __LISTARRAY_H__
#define __LISTARRAR_H__
#include <vector>
#include <list>
#include <algorithm>
using namespace std;
#define MAXVECTORNUM 1000
//static char LIST_NO_NULL[1]={0};

template <class T>
class ListArrayHead
{
public:
    ListArrayHead()
    {
    };
    ~ListArrayHead()
    {

    };
	 vector<T> DVector;
	 T pHead;
	 T pEnd;
};

template <class T>  
class  ListArray
{
public:
	ListArray()
	{
		//ListArrayHead Head;
		LAList.clear();
	};
	~ListArray() 
	{
		typename list<ListArrayHead<T> > :: iterator iter  = LAList.begin();
	}; 
	
	static bool comp(T x, T y)
	{
		return(x > y);
	};
	
	
	bool AddData(T data)
    {    
	    typename list<ListArrayHead<T> > :: iterator iter_l;
		typename vector<T>::iterator iter_v;
		if( (LAList.begin() == LAList.end()) || (((LAList.begin())->pHead) < data) )        //listΪ�ջ�������ݵ�����ֵ���,�½� ListArrayHead ���� 
        {
		    ListArrayHead<T> ListArrayHead_first;
		    ListArrayHead_first.DVector.push_back(data);
			ListArrayHead_first.pHead = ListArrayHead_first.DVector.front();
			ListArrayHead_first.pEnd  = ListArrayHead_first.DVector.back(); 
			LAList.push_front(ListArrayHead_first);
			return true;
	    }
        else                         
		{
			for(iter_l = LAList.begin(); iter_l != LAList.end();)  //����list 
            {
		        if( ((iter_l->pHead) < data) || ((++iter_l) == LAList.end()) )  //�ҵ�list����λ��
       	        {
                    iter_l--;
		            if(iter_l->DVector.size() < MAXVECTORNUM)  //�����ǰvectorδ������������
				    {
                        iter_v = lower_bound(iter_l->DVector.begin(),iter_l->DVector.end(),data,comp); 
						if(iter_v == iter_l->DVector.end())        // �������δ�ҵ�����λ�ã������β 
					    {
						    iter_l->DVector.push_back(data);           								
					    }  
						else if((*iter_v) == data)     //�����ظ����� 
						{
						    return false;
						}
						else
						{
							iter_l->DVector.insert(iter_v ,data) ;
						}
					    iter_l->pHead = iter_l->DVector.front();
					    iter_l->pEnd =  iter_l->DVector.back();
                        return true;
				    } 
				    else           //��ǰvector�����½�ListArrayHead 
				    {
				    	ListArrayHead<T> ListArrayHead_node;
				    	iter_v = lower_bound(iter_l->DVector.begin(),iter_l->DVector.end(),data,comp);
				    	if(iter_v == iter_l->DVector.end())        // �������δ�ҵ�����λ�ã�������ListArrayHead�� 
				    	{
					    	ListArrayHead_node.DVector.push_back(data);
					    	ListArrayHead_node.pHead = ListArrayHead_node.DVector.front();
					    	ListArrayHead_node.pEnd  = ListArrayHead_node.DVector.back();
					    	LAList.insert((++iter_l), ListArrayHead_node);
                            return true;
				    	}	
						else if((*iter_v) == data)             //ɾ���ظ����� 
                        {
                            return false;
                        }							    
						else
						{								
							ListArrayHead_node.DVector.insert(ListArrayHead_node.DVector.begin(), iter_v ,iter_l->DVector.end());
							ListArrayHead_node.pHead = ListArrayHead_node.DVector.front();
							ListArrayHead_node.pEnd  = ListArrayHead_node.DVector.back();
							iter_l->DVector.erase(iter_v ,iter_l->DVector.end());
							iter_l->DVector.push_back(data);
							iter_l->pHead = iter_l->DVector.front();
					        iter_l->pEnd =  iter_l->DVector.back();
                            LAList.insert((++iter_l), ListArrayHead_node);
                            return true;
					    }
			    	}	
		    	}		    	
	        }            
		}
        return false;
    };
    
	bool FindData(T& data)
	{
//		bool res = false;
		typename list<ListArrayHead<T> > :: iterator iter_l;
		typename vector<T>::iterator iter_v;
		for(iter_l = LAList.begin(); iter_l != LAList.end() ; ++iter_l)  
		{
			if(((iter_l->pHead) >= data) && ((iter_l->pEnd) <= data)) 
			{
                iter_v = lower_bound(iter_l->DVector.begin(),iter_l->DVector.end(),data,comp);
			    if((iter_v != iter_l->DVector.end()) && ((*iter_v) == data))
			    {
			    	return true;			
			    }
			    break;
			}
		}
		return false;
	};
	
	
/*	T* FindAndDeleData(T& data)
	{
		T* res = NULL;
		typename list<ListArrayHead<T> > :: iterator iter_l;
		typename vector<T*>::iterator iter_v;
		for(iter_l = LAList.begin(); iter_l != LAList.end() ; ++iter_l)  
		{
			if((*(iter_l->pHead) >= data) && (*(iter_l->pEnd) <= data)) 
			{
                iter_v = lower_bound(iter_l->DVector.begin(),iter_l->DVector.end(),&data,comp);
				if((iter_v != iter_l->DVector.end())&&(*(*iter_v) == data))
				{
					res = *iter_v;
//                  delete (*iter_v);
					iter_l->DVector.erase(iter_v);                       //ɾ�� 
					iter_l->pHead = iter_l->DVector.front();
					iter_l->pEnd =  iter_l->DVector.back();
                    if(iter_l->DVector.begin() == iter_l->DVector.end()) //�����ǰvector��û��Ԫ�أ�ɾ����ǰvector����Ӧ�� ListArrayHead
                    {
                       	LAList.erase(iter_l);
					}						
				}
				break;
			}
		}
		return res;		  		  
	};
*/	
	
	
/*	void DelData(T& data)
	{
		typename list<ListArrayHead<T> > :: iterator iter_l;
		typename vector<T*>::iterator iter_v;
		for(iter_l = LAList.begin(); iter_l != LAList.end() ; ++iter_l)  
		{
			if((*(iter_l->pHead) >= data) && (*(iter_l->pEnd) <= data)) 
			{
                iter_v = lower_bound(iter_l->DVector.begin(),iter_l->DVector.end(),&data,comp);
				if((iter_v != iter_l->DVector.end())&&(*(*iter_v) == data))
				{
//					delete (*iter_v);
					iter_l->DVector.erase(iter_v);                       //ɾ�� 
					iter_l->pHead = iter_l->DVector.front();
					iter_l->pEnd =  iter_l->DVector.back();
                    if(iter_l->DVector.begin() == iter_l->DVector.end()) //�����ǰvector��û��Ԫ�أ�ɾ����ǰvector����Ӧ�� ListArrayHead
                    {
                       	LAList.erase(iter_l);
					}					
				}
				break;
			}
		}						
	};
	
*/
/*    void display()
    {
    	typename list<ListArrayHead<T> > :: iterator iter_l;
		typename vector<T*>::iterator iter_v;
		for(iter_l = LAList.begin(); iter_l != LAList.end() ; ++iter_l)  
		{
			for(iter_v = iter_l->DVector.begin(); iter_v != iter_l->DVector.end() ; ++iter_v)
			{
				printf("%d,",*(*iter_v));
			}
			printf("\n");
		}
	};
*/
    void clear()
    {

    	typename list<ListArrayHead<T> > :: iterator iter_l;
//		typename vector<T*>::iterator iter_v;
		for(iter_l = LAList.begin(); iter_l != LAList.end() ; ++iter_l)  
		{
//			for(iter_v = iter_l->DVector.begin(); iter_v != iter_l->DVector.end() ; ++iter_v)
//			{
//				printf("%d,",*(*iter_v));
//			}
//			printf("\n");
            iter_l->DVector.clear();
            iter_l->pHead = 0;
            iter_l->pEnd = 0;
		}
        LAList.clear();
	};
    
private:
	list <ListArrayHead<T> > LAList;
};
#endif

// ����








