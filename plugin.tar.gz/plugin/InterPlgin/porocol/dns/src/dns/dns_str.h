// Last Update:2015-06-23 13:37:49
/**
 * @file dns_str.h
 * @brief DNS Session 定义
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-14
 */

#ifndef DNS_STR_H
#define DNS_STR_H

#include <session.h>

#include <stdint.h>

#include <string> 
#include <list> 


#define  DNS_ANSWERS_TYPE_CNAME 0x0005
#define  DNS_ANSWERS_TYPE_IP    0x0001

#define  DNS_ANSWERS_CLASS_NS 0x0005
#define  DNS_AUTHORITYS_CLASS_NS 0x0002
using namespace std;

typedef struct {
    uint16_t transanction_id;
    uint16_t flags;
    uint16_t questions;
    uint16_t answer_rrs;
    uint16_t authority_rrs;
    uint16_t addtional_rrs;
} dns_head;

class c_quest {
    public:
        c_quest(){
            url ="";
            des_type = 0;
            dns_quest_class = 0;
        };
        string url;
        uint16_t des_type;
        uint16_t dns_quest_class;
};

class c_answers {
    public:
        c_answers(){
            url = "";
            c_answ_type = 0;
            c_answ_in = 0 ;
            c_answ_ttl = 0;
            c_answ_len = 0;
            priname_or_ip = "";
        };
        string url;
        uint16_t c_answ_type;
        uint16_t c_answ_in;
        uint32_t c_answ_ttl;
        uint16_t c_answ_len;
        string    priname_or_ip;
};

class c_authoritys
{
    public:
        c_authoritys()
        {
            url = "";
            c_answ_type = 0;
            c_answ_in = 0 ;
            c_answ_ttl = 0;
            c_answ_len = 0;
            priname_or_ip = "";
        };

        string url;
        uint16_t c_answ_type;
        uint16_t c_answ_in;
        uint32_t c_answ_ttl;
        uint16_t c_answ_len;
        string  priname_or_ip;
};

class c_addtionals
{
    public:
        c_addtionals()
        {
            url = "";
            c_answ_type = 0;
            c_answ_in = 0 ;
            c_answ_ttl = 0;
            c_answ_len = 0;
            priname_or_ip = "";
        };

        string url;
        uint16_t c_answ_type;
        uint16_t c_answ_in;
        uint32_t c_answ_ttl;
        uint16_t c_answ_len;
        string  priname_or_ip;
};

class dns_session
{
    public:
       uint64_t requst_time;
       uint64_t response_time;
       dns_head * p_dns_head;
       c_quest * p_quest;
       c_answers * p_c_answers;
       c_authoritys * p_c_authoritys;
       c_addtionals * p_c_addtionals;
       uint16_t quest_num; //请求个数 
       uint16_t answer_num; //应答个数 
       uint16_t authority_num; // 验证信息
       uint16_t addtional_num; // 附加信息
       bool b_c2s; // 方向判断，是不是C -> s
       uint8_t  * p_data;
       uint32_t  len;
};

#endif  /*DNS_STR_H*/
