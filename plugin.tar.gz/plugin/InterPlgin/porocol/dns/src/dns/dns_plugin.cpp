// Last Update:2016-02-26 16:22:12
/**
 * @file dns_plugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-14
 */
#include "list_array.h"
#include "dns_plugin.h"
#include <commit_tools.h>
//#include "config_text.h"
#include <sys/stat.h>
#include <sys/time.h>
#define DNSDEFINEPORT 53
extern "C" {
    int get_plugin_id()
    {
        return 2;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p ; 
        return new  dns_plugin();
    }
}

/// 输出yyyy-mm-dd-hh-mm-ss 格式的日期信息

dns_plugin::dns_plugin()
{
    data_interface_type = FILESEND;
    dns_time_out = 60;
    update_time = 60;
    last_update_time = 0;
    dns_count =0;
    max_dns_num = 1000000;
    row = 0;
    max_row = 9999;
    max_time_scr = 1;
    file_path = "";
    file_name = "";
//    msg = NULL;
    reload();
}
dns_plugin::~dns_plugin()
{
    off_string_map.clear();
    dns_array.clear();
}
void dns_plugin::reload()
{
        xml_parse  xml;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/dns_plugin.xml";
     xml.set_file_path(config_path.c_str());
     char * p_value = (char *)xml.get_value("/config/send_data_type");
     string tmp = "";
     if(p_value != NULL)
     {
         tmp = p_value;
         if(tmp == "file") // 文件接口 
         {
             data_interface_type = FILESEND;
         }
         else if(tmp == "net" ) 
         {
             data_interface_type = NETSEND;
         }
     }
     p_value = (char *)xml.get_value("/config/time_out");
     if(p_value != NULL)
     {
         dns_time_out = atoi(p_value);
     }
     p_value = (char *)xml.get_value("/config/max_row");
     if(p_value != NULL)
     {
         max_row= atoi(p_value);
     }
     p_value = (char *)xml.get_value("/config/max_time");
     if(p_value != NULL)
     {
         max_time_scr= atoi(p_value);
     }
     p_value = (char *)xml.get_value("/config/update_time");
     if(p_value != NULL)
     {
         update_time= atoi(p_value);
     }
     p_value = (char *)xml.get_value("/config/max_dns_num");
     if(p_value != NULL)
     {
         max_dns_num= atoi(p_value);
     }
}

void dns_plugin::init_dns_session(dns_session * p_dns_session)
{
    p_dns_session -> p_dns_head = NULL;
    p_dns_session -> p_quest  = NULL;
    p_dns_session -> p_c_answers = NULL;

    p_dns_session -> requst_time = 0;

    p_dns_session -> response_time = 0;

    p_dns_session -> quest_num = 0;

    p_dns_session -> answer_num = 0;

    p_dns_session -> authority_num = 0;

    p_dns_session -> addtional_num = 0;

    p_dns_session -> p_data = NULL;

    p_dns_session -> len = 0;
}

bool dns_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(p_session==NULL || p_packet==NULL)
        return false;

    //printf("dns_plugin::potocol_identify \n");

    // 只有端口判断是否是DNS 协议--
    if(ntohs(p_session ->srcport)== DNSDEFINEPORT )
    {
        p_session -> b_src_is_ser  = true;
        dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
        init_dns_session(p_dns_session);
        return true;
    }
    else if(ntohs(p_session -> dstport) ==DNSDEFINEPORT)
    {
        p_session -> b_src_is_ser = false;
        dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
        init_dns_session(p_dns_session);
        return true;
    }
    return false;
}

void dns_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session==NULL || p_packet==NULL)
    {
        return;
    }

    dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
    // 连接 去除  

    // m_pop3_parse.pop3_potocol_sign_judge(p_session,p_packet,p_dns_session);
    if((p_session->srcport==p_packet->get_src_port() &&  p_session -> b_src_is_ser )
            || (p_session -> b_src_is_ser==false  && p_session->dstport==p_packet->get_src_port() )  )
    {
        p_dns_session ->b_c2s = false;
    }
    else
    {
        SET_SESSION_OVER(p_session);
        p_dns_session ->b_c2s = true;
        // 不处理  c-> S 的数据 
        return ;
    }
    p_dns_session->requst_time = p_session ->packet_time;
    // 加入数据 
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    if(len >= MAXTCPBUF)
    {
        SET_SESSION_OVER(p_session);
        return ;
    }
    if(len == 0)
    {
        return ;
    }

    char * p_data =(char *)p_packet -> p_app_data; 
    if(p_dns_session->b_c2s==false && p_data!=NULL)
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_dns_session->p_data = (uint8_t *)p_session->server.get_tcp_data(p_dns_session->len);
        if(p_dns_session->len > 0 && p_dns_session->p_data != NULL)
        {
            SET_EXPORT(p_session);
            SET_SESSION_OVER(p_session);
            return ;
        }
    }
    SET_SESSION_OVER(p_session);
    return ;
}

void dns_plugin::pococol_parse_handle(session * p_session)
{
    if(p_session == NULL)
    {
        return;
    }

    dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
    if(p_dns_session==NULL || p_dns_session->p_data==NULL)
    {
        return;
    }

    begin_len = p_dns_session->len ;
    begin_data =  p_dns_session->p_data;
    p_end =  begin_data + begin_len;
    off_string_map.clear();
    // 连接 去除  
    if(p_dns_session->len > sizeof(dns_head))
    {
        uint8_t * p = p_dns_session->p_data;
        if(p == NULL)
        {
            return;
        }

        p_dns_session ->p_dns_head = (dns_head * )p;
        p += sizeof(dns_head);
        uint32_t len = p_dns_session->len - sizeof(dns_head);
        // 
        p_dns_session -> quest_num  = (uint16_t)ntohs(p_dns_session ->p_dns_head -> questions);
        p_dns_session -> answer_num = (uint16_t)ntohs(p_dns_session ->p_dns_head->answer_rrs);
        p_dns_session -> authority_num = (uint16_t)ntohs(p_dns_session ->p_dns_head->authority_rrs);
        p_dns_session -> addtional_num = (uint16_t)ntohs(p_dns_session ->p_dns_head->addtional_rrs);
        if(p_dns_session -> quest_num > begin_len || p_dns_session->answer_num > begin_len || p_dns_session -> quest_num == 0 || p_dns_session->answer_num == 0)
        {
            return;
        }

        p = dns_quest_parse(p_session,p_dns_session,p ,len);
        if(p>=p_end || (p!=NULL && p < begin_data))
        {
            return ;
        }

       // if(p == NULL)  return ;  
        if(len > 0 && p != NULL)
        {
            p = dns_answers_parse(p_session,p_dns_session,p ,len);
            //if(p == NULL)  return ;  
            //if(p >= p_end || p < begin_data)  return ;
            if(p>=p_end || (p!=NULL && p < begin_data))
            {
                return ;
            }
        }
        if(p_dns_session->p_quest == NULL ||p_dns_session->p_quest->url.size() >  2028)
        {
            return;
        }
        if(p_dns_session->p_c_answers== NULL) 
        {
            return;
        }
        // 解析author
        if(len > 0 && p != NULL)
        {
            p = dns_authority_parse(p_session,p_dns_session,p ,len);
            //if(p >= p_end || p < begin_data)  return ;
            //if(p >= p_end)  return ;
            if(p>=p_end || (p!=NULL && p < begin_data))
            {
                return ;
            }
        }

        // 解析附加信息
        if(len > 0 && p != NULL)
        {
            p = dns_addtional_parse(p_session,p_dns_session,p ,len);
            //if(p >= p_end || p < begin_data)  return ;
            //if(p >= p_end)  return ;
            if(p>=p_end || (p!=NULL && p < begin_data))
            {
                return ;
            }
        }
        // p_session ->  p_dns_session->len = 
        if(p_dns_session->p_c_answers->url != "")
        {
            struct timeval tv ;
            gettimeofday(&tv,NULL);
            uint64_t current_time = tv.tv_sec * 1000000 + tv.tv_usec ;
            if(((current_time >last_update_time) && (current_time - last_update_time > update_time *1000000))||dns_count == max_dns_num)
            {
                dns_array.clear();
                last_update_time = current_time;
                dns_count = 0;
            }
            uint32_t dns_crc32;
//            char dns_string[300] = "\0";
            char* dns_string = (char*) calloc(1,((p_dns_session->p_c_answers->url).length()+50));
            strcat(dns_string, (p_dns_session->p_c_answers->url).c_str());
            strcat(dns_string, p_session->srcip.ip_str());
            strcat(dns_string, p_session->dstip.ip_str());
            int str_len;
            str_len = strlen(dns_string);
            dns_crc32 = crc32( (unsigned char*)(dns_string), str_len);
            free(dns_string);
            if(dns_array.AddData(dns_crc32))
            {
                dns_count++;
                p_session->send_len = p_dns_session->len;
                p_session->p_send_buf = (char *)p_dns_session -> p_data;
            }
        }      // 组织发送数据 
    }
}

uint8_t * dns_plugin::dns_quest_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len)
{
    if(p_session==NULL || p_dns_session==NULL)
    {
        return NULL;
    }

    int i  = 0 ; 
    uint8_t * p = buf;
    if(p == NULL)
    {
        return NULL;
    }
    if(p_dns_session->quest_num==0 || p_dns_session->quest_num+10 > begin_len)
    {
        return NULL;
    }
    if(p_dns_session->quest_num < 1)
    {
        return NULL;
    }
    p_dns_session -> p_quest = new c_quest[p_dns_session->quest_num];
    c_quest * p_quest = p_dns_session -> p_quest;
    for(;i < p_dns_session -> quest_num  ;i++ )
    {
        if(len<=0 || p==NULL)
        {
            return NULL;
        }
        //p_dns_session -> p_quest -> url = (char *)p;
        //   p ++;len --; // 跳过一个字节
        if(begin_len < len)
        {
            return NULL;
        }
        p = dns_url_parse_string(p,len, p_quest -> url,begin_len - len,0);
        if(len <= 0 || p ==NULL)
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }

        p ++;
        len --; // 跳过一个字节
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // 跳过string 长度的字节 

        if(len<2 || p==NULL)
        {
            return NULL;
        }
        //  des_type 
        p_quest->des_type = ntohs(*(uint16_t*)p);
        p += 2;
        len -= 2;
        //    dns_quest_class 
        if(len <= 0 || p_quest->des_type==0)
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        if(len < 2 || p==NULL)
        {
            return NULL;
        }
        p_quest->dns_quest_class  = ntohs(*(uint16_t*)p);
        p += 2;
        len -= 2;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }

        if(i+1 == p_dns_session -> quest_num)
        {
            break;
        }

        p_quest ++;
    }
    return p;
}

uint8_t * dns_plugin::dns_url_parse_string(uint8_t * buf, uint32_t & len ,string & url,uint32_t strat_len,int num)
{
    if(buf == NULL)
    {
        return NULL;
    }

    if(len > begin_len )
    {
        return NULL;
    }
    if(len>1 && *buf == 0xc0) 
    {
        buf++;
        len --;
        if(buf >= p_end || buf < begin_data)
        {
            return NULL;
        }
    }
    if(num > 10)
    {
        return NULL;
    }
    uint8_t * p = buf;
    int i = 0;
    while(len>1 && p!=NULL && *p != 0x0)
    {
        if(*p==0xC0) 
        {
            if(len < 1)
            {
                return NULL;
            }

            len --;
            p++;
            if(p >= p_end || p < begin_data || p==NULL)
            {
                return NULL;
            }
            uint8_t off = * p;
            if(off > begin_len  || off > 0xC0 || off == 0 )
            {
                return NULL;
            }

            if(begin_len < off)
            {
                return NULL;
            }

            uint32_t l =  begin_len - off;
            if(l > begin_len ) return NULL;
            string tmp ="";
            if(len  > off) 
            {
                return NULL;
            }
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }
            dns_url_parse_string(begin_data + off ,l,tmp,off ,++num );
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }

            if(i > 0)
            {
                url += ".";
            }
            url += tmp;
            i++;
            if(len < 1)
            {
                return NULL;
            }
            len --;
            p++;
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }
            // 只r容许出现一个指针
            if(off_string_map.size() > 100)
            {
                return NULL;
            }
            off_string_map.insert(pair<uint32_t,string>(strat_len ,url));
            return p ;
        }
        else
        {
            if(len <= 0 || p==NULL) 
            {
                break;
            }
            uint8_t c_len = *p; 
            p++;
            len--;
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }
            if(c_len> begin_len  || c_len > 0xC0)
            {
                return NULL;
            }
            if(c_len > len)
//            if((char *)p-(char *)buf+c_len > len)
            {
                return NULL;
            }
            string tmp((char *)p,0,c_len);
            if(i > 0)
            {
                url += ".";
            }
            url += tmp;
            i++;

            /*if( len < c_len)
            {
                return NULL;
            }*/

            len -= c_len;
            p += c_len;
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }
        }
        if(url.length() > begin_len)
        {
            return NULL;
        }
        if(len <= 0)
        {
            break;
        }
    }

    off_string_map.insert(pair<uint32_t,string>(strat_len ,url));
    if(off_string_map.size() > 100)
    {
        return NULL;
    }
    return p;
}

uint8_t * dns_plugin::dns_answers_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len)
{
    if(p_session==NULL || p_dns_session==NULL)
    {
        return NULL;
    }

    int i  = 0 ; 
    uint8_t * p = buf;
    if(p == NULL)
    {
        return NULL;
    }

    if(p_dns_session->answer_num > begin_len || p_dns_session->answer_num==0)
    {
        return NULL;
    }
    p_dns_session -> p_c_answers = new c_answers[p_dns_session->answer_num];
    c_answers * p_c_answers = p_dns_session -> p_c_answers;
    for(;i < p_dns_session -> answer_num ;i++ )
    {
        if(len>1 && *p == 0xC0)
        {
            p++ ;
            len-- ;
            if(p >= p_end || p < begin_data || len<1 || p==NULL)
            {
                return NULL;
            }
            uint32_t off = *p;
            map<uint32_t,string>::iterator iter = off_string_map.find(off);
            if(iter != off_string_map.end())
            {
                p_c_answers -> url = iter ->second;
            }

            p++;
            len--;
            //if(p >= p_end || p < begin_data)  return NULL;
            if(p >= p_end || p < begin_data || len<1 || p==NULL)
            {
                return NULL;
            }
        }
        else
        {
            //if(begin_len > len)
            if(begin_len < len)
            {
                return NULL;
            }
            p = dns_url_parse_string(p ,len,p_c_answers -> url,begin_len - len,0 );
            if(p == NULL)
            {
                return NULL;
            }
        }
        if(len <= 2|| p==NULL)
        {
            return NULL;
        }
        // c_answ_type
        p_c_answers->c_answ_type = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_in
        if(len <= 2 || p==NULL)
        {
            return NULL;
        }
        p_c_answers->c_answ_in = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -=2 ;

        if(len <= 4 || p==NULL)
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_ttl
        p_c_answers ->c_answ_ttl = ntohl(*(uint32_t*)p);
        p += 4 ;
        len -=4 ;
        // c_answ_len
        if(len <= 2 || p==NULL)
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        p_c_answers ->c_answ_len = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2 ;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }

        //    priname_or_ip  
        if(len <= 0) 
        {
            return NULL;
        }
        if(p_c_answers->c_answ_type == DNS_ANSWERS_TYPE_CNAME)
        {
            uint32_t l = p_c_answers ->c_answ_len;
            if(l > begin_len )
            {
                return NULL;
            }
            if(begin_len < len)
            {
                return NULL;
            }

            dns_url_parse_string(p,l,p_c_answers ->priname_or_ip,begin_len -len,0);
            //p += p_c_answers ->c_answ_len;
            //len -= p_c_answers ->c_answ_len; 
            //if(p >= p_end || p < begin_data)  return NULL;
        }
        else if (p_c_answers->c_answ_type == DNS_ANSWERS_TYPE_IP && len>3 && p!=NULL)
        {
            uint32_t i_ip = (*(uint32_t *)p);
            c_ip class_ip (i_ip);
            p_c_answers ->priname_or_ip = class_ip.ip_str();
        }

        if(len < p_c_answers ->c_answ_len)
        {
            return NULL;
        }

        p += p_c_answers ->c_answ_len;
        len -= p_c_answers ->c_answ_len;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }

        if(i+1 == p_dns_session -> answer_num)
            break;

        p_c_answers ++;
    }
    return p;
}

uint8_t * dns_plugin::dns_authority_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len)
{
    if(p_session==NULL || p_dns_session==NULL)
    {
        return NULL;
    }

    int i  = 0 ; 
    uint8_t * p = buf;
    if(p == NULL)
    {
        return NULL;
    }
    if(p_dns_session->authority_num > begin_len || p_dns_session->authority_num==0)
    {
        return NULL;
    }
    p_dns_session -> p_c_authoritys = new c_authoritys[p_dns_session->authority_num];
    c_authoritys * p_c_authoritys = p_dns_session -> p_c_authoritys;
    for(; i<p_dns_session->authority_num; i++)
    {
        if(len>1 && *p==0xC0)
        {
            p++ ; len -- ;
            if(p >= p_end || p < begin_data )
            {
                return NULL;
            }

            if(len<1 || p==NULL)
            {
                return NULL;
            }
            uint32_t off = *p;
            map<uint32_t,string>::iterator iter = off_string_map.find(off);
            if(iter != off_string_map.end())
            {
                p_c_authoritys -> url = iter ->second;
            }
            if(len < 1)
            {
                return NULL;
            }
            p++;
            len--;
            if(p >= p_end || p < begin_data)
            {
                return NULL;
            }
            if(len<1 || p==NULL)
            {
                return NULL;
            }
        }
        else
        {
            //if(begin_len > len)
            if(begin_len < len)
            {
                return NULL;
            }
            p = dns_url_parse_string(p, len, p_c_authoritys -> url, begin_len-len, 0);
            if(p == NULL)
            {
                return NULL;
            }
        }
        if(len <= 2 || p==NULL)
        {
            return NULL;
        }
        // c_answ_type
        p_c_authoritys->c_answ_type = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -=2 ;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_in
        if(len <= 2 || p==NULL)
        {
            return NULL;
        }
        p_c_authoritys->c_answ_in = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2 ;

        if(len <= 4  || p==NULL)
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_ttl
        p_c_authoritys ->c_answ_ttl = ntohl(*(uint32_t*)p);
        p += 4 ;
        len -=4 ;
        // c_answ_len
        if(len <= 2  || p==NULL) 
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        p_c_authoritys->c_answ_len = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -=2 ;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }

        //    priname_or_ip  
        if(len <= 0)
        {
            return NULL;
        }
        if(p_c_authoritys->c_answ_type == DNS_AUTHORITYS_CLASS_NS)
        {
            uint32_t l = p_c_authoritys->c_answ_len;
            if(l > begin_len )
            {
                return NULL;
            }
            if(begin_len < len)
            {
                return NULL;
            }

            dns_url_parse_string(p, l, p_c_authoritys->priname_or_ip, begin_len-len, 0);
        }
        else if (p_c_authoritys->c_answ_type == DNS_ANSWERS_TYPE_IP && len>3 && p!=NULL)
        {
            uint32_t i_ip = (*(uint32_t *)p);
            c_ip class_ip (i_ip);
            p_c_authoritys->priname_or_ip = class_ip.ip_str();
        }

        if(len < p_c_authoritys->c_answ_len)
        {
            return NULL;
        }

        p += p_c_authoritys->c_answ_len;
        len -= p_c_authoritys->c_answ_len;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        if(i+1 == p_dns_session -> authority_num)
            break;
        p_c_authoritys ++;
    }
    return p;
}

uint8_t * dns_plugin::dns_addtional_parse(session * p_session, dns_session *p_dns_session, uint8_t * buf, uint32_t & len)
{
    if(p_session==NULL || p_dns_session==NULL)
    {
        return NULL;
    }

    int i = 0 ;
    uint8_t * p = buf;
    if(p == NULL)
    {
        return NULL;
    }

    if((p_dns_session->addtional_num > begin_len) ||( p_dns_session->addtional_num ==0))  return NULL;
    p_dns_session->p_c_addtionals = new c_addtionals[p_dns_session->addtional_num];
    c_addtionals * p_c_addtionals = p_dns_session->p_c_addtionals;
    for(;i < p_dns_session -> addtional_num ;i++ )
    {
        if(len>1 && *p==0xC0)
        {
            p++;
            len--;
            if(p >= p_end || p < begin_data || len<1 || p==NULL)
            {
                return NULL;
            }
            uint32_t off = *p;
            map<uint32_t,string>::iterator iter = off_string_map.find(off);
            if(iter != off_string_map.end())
            {
                p_c_addtionals -> url = iter ->second;
            }

            p++;
            len--;
            //if(p >= p_end || p < begin_data)  return NULL;
            if(p >= p_end || p < begin_data || len<1 || p==NULL)
            {
                return NULL;
            }
        }
        else
        {
            //if(begin_len > len)
            if(begin_len < len)
            {
                return NULL;
            }
            p = dns_url_parse_string(p, len, p_c_addtionals->url, begin_len-len, 0);
            if(p == NULL)
            {
                return NULL;
            }
        }
        if(len <= 2 || p==NULL)
        {
            return NULL;
        }
        // c_answ_type
        p_c_addtionals->c_answ_type = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2 ;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_in
        if(len<=2 || p==NULL)
        {
            return NULL;
        }
        p_c_addtionals->c_answ_in = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2 ;

        if(len <= 4 || p==NULL)
        {
            return NULL;
        }

        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        // c_answ_ttl
        p_c_addtionals ->c_answ_ttl = ntohl(*(uint32_t*)p);
        p += 4 ;
        len -= 4 ;
        // c_answ_len
        if(len <= 2 || p==NULL) 
        {
            return NULL;
        }
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        p_c_addtionals ->c_answ_len = ntohs(*(uint16_t*)p);
        p += 2 ;
        len -= 2 ;
        if(p >= p_end || p < begin_data || p==NULL)
        {
            return NULL;
        }

        //    priname_or_ip  
        if(len <= 0) 
        {
            return NULL;
        }

        if(p_c_addtionals->c_answ_type == DNS_ANSWERS_TYPE_CNAME)
        {
            uint32_t l = p_c_addtionals ->c_answ_len;
            if(l > begin_len)
            {
                return NULL;
            }
            if(begin_len < len)
            {
                return NULL;
            }
            dns_url_parse_string(p, l, p_c_addtionals->priname_or_ip, begin_len-len, 0);
        }
        else if ((p_c_addtionals->c_answ_type == DNS_ANSWERS_TYPE_IP) && (len>3)&&(p != NULL))
        {
            uint32_t i_ip = (*(uint32_t *)p);
            c_ip class_ip (i_ip);
            p_c_addtionals ->priname_or_ip = class_ip.ip_str();
        }

        if(len < p_c_addtionals ->c_answ_len)
        {
            return NULL;
        }

        p += p_c_addtionals ->c_answ_len;
        len -= p_c_addtionals ->c_answ_len;
        if(p >= p_end || p < begin_data)
        {
            return NULL;
        }
        if(i+1 == p_dns_session -> addtional_num)
            break;
        p_c_addtionals ++;
    }
    return p;
}

void dns_plugin::potocol_data_handle(session* p_session,list<data_interface> * p_list)
{
    if(p_session == NULL)
        return;

    dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
    if(p_dns_session == NULL)
        return;

    data_interface m_data ;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
        if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
        {
            m_data.b_out_type = FILESEND;

            string requst_time;
            DNUMTOSTR(p_dns_session->requst_time, requst_time);
            struct timeval tv ;
            gettimeofday(&tv,NULL);
            uint64_t u64_time = tv.tv_sec * 1000000 + tv.tv_sec;
             
            if(file_path.empty() )
            {
            // 文件相对路径
                file_path = "/";
                file_path += get_year_month();
                file_path += get_day_hour();
                file_path += get_min_sec();

                file_name = date_time();
                file_name += "-";
                file_name += requst_time;
                begin_time = u64_time;
                file_data= "";
                row = 0;
                file_str = new w_file_str;

            }
            file_str->finished = false;
            if(row == max_row || u64_time - begin_time > max_time_scr * 1000000) 
            {
                file_str->finished = true;
            }
            // 把path 和name 写入dns_session 里面
            //memcpy(p_dns_session->file_name, file_name.data(), file_name.size());

            string eml_name = file_name;
            eml_name += ".dns";
            // 生成eml 文件
            file_str->file_path = file_path;
            file_str->file_name.swap(eml_name);

            // 申请内存存储数据，写文件后自动析构
            {
                if(row > 0)
                    file_data +="\n[dns]\n";
                else
                    file_data +="[dns]\n";
                row ++;
                // 组数数据 
                // 拷贝数据 
                // 时间
                requst_time = date_time3(p_dns_session->requst_time);
                file_data += requst_time;
                file_data += "\n";
                // 域名 
                file_data += p_dns_session->p_quest->url;
                file_data += "\n";
                // 域名IP // 
                int i = 0;
                int itc = 0;
                string tmp = "";
                int i_ns = 0;
                if(p_dns_session->p_c_answers != NULL)
                {
                    for(i= 0; i < p_dns_session->answer_num; i++)
                    {
                        if( p_dns_session->p_c_answers[i]. c_answ_type == DNS_ANSWERS_TYPE_IP )
                        {
                            if(itc > 0) 
                                file_data +="|";
                            file_data += p_dns_session->p_c_answers[i].priname_or_ip;
                            itc ++ ;
                        }
                        if( p_dns_session->p_c_answers[i]. c_answ_in == DNS_ANSWERS_CLASS_NS )
                        {
                            if(i_ns > 0) 
                                tmp += "|";
                            tmp += p_dns_session->p_c_answers[i].url;
                            i_ns++;
                        }


                    }
                }
                file_data += "\n";
                if(p_session -> b_src_is_ser) 
                {
                    // 客户端 IP 
                    file_data += p_session->dstip.ip_str();
                    file_data +="\n";
                    // DNS IP
                    file_data += p_session->srcip.ip_str();
                    file_data +="\n";
                }
                else {
                    // 客户端 IP 
                    file_data += p_session->srcip.ip_str();
                    file_data +="\n";
                    // DNS IP
                    file_data += p_session->dstip.ip_str();
                    file_data +="\n";
                }
                // 域名授权单位 
                file_data += tmp; 
                file_data += "\n";

                if(!file_str->finished)
                {
                    if(file_data.length() < 1024*1024 ) 
                    {
                        return ;
                    }
                    else 
                    {
                        file_str->finished = true;
                    }
                }
                //附加信息


                if(file_str->finished )
                {
                    char * dns_file_data = new char[file_data.length() +1 ];
                    strcpy(dns_file_data,file_data.c_str());
                    file_str->file_data = dns_file_data;
                    file_str->datalen = file_data.length();
                }
            }

            m_data.data = file_str;
            p_list -> push_back(m_data);
            if(file_str->finished  )
            {
                file_path = "";
                file_name = "";
                begin_time = u64_time;
            }

        }
    }
    else if (data_interface_type == NETSEND)
    {
        net_str * p_net =  new  net_str;
        p_net -> msg = new CAmsg;
        p_net->msg->Clear();
        // 设置 
        p_net->msg->set_type(4); // dns 
        p_net->datalen = 0;
        dns_msg* p_dns = p_net->msg->mutable_dns();

        Comm_msg* p_comm =  p_dns -> mutable_comm_msg();
        // 公共 消息 
        if(p_session -> b_src_is_ser)
        {
            // 客户端 IP 
            p_comm ->set_dst_ip(p_session->srcip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->srcport));
            // DNS IP
            //p_comm ->set_src_ip(p_session->dstip.ip_str());
            p_comm ->set_src_port(ntohs(p_session->dstport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->dstip.ip_str());
            }
        }
        else {
            // 客户端 IP 
            p_comm ->set_src_port(ntohs(p_session->srcport));
            // DNS IP
            p_comm ->set_dst_ip(p_session->dstip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->dstport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->srcip.ip_str());
            }
        }
        p_comm ->set_time(p_dns_session->requst_time);
        //  域名 
        p_dns -> set_domain_name(p_dns_session->p_quest->url); 
        // 域名 IP 
        // 域名IP // 
        int i = 0;
        int itc = 0;
        string  domain_ip = "";
        string tmp = "";
        int i_ns = 0;
        if(p_dns_session->p_c_answers != NULL )
        {
            for(i= 0; i < p_dns_session->answer_num; i++)
            {
                if( p_dns_session->p_c_answers[i]. c_answ_type == DNS_ANSWERS_TYPE_IP )
                {
                    if(itc > 0)
                    {
                        domain_ip +="|";
                    }

                    domain_ip += p_dns_session->p_c_answers[i].priname_or_ip;
                    itc ++ ;
                }
                if( p_dns_session->p_c_answers[i]. c_answ_in == DNS_ANSWERS_CLASS_NS )
                {
                    if(i_ns > 0)
                    {
                        tmp += "|";
                    }
                    tmp += p_dns_session->p_c_answers[i].url;
                    i_ns++;
                }
            }
        }
        // 
        if(domain_ip.empty())
        {
            delete p_net -> msg;
            delete p_net;
            return;
        }

        p_dns ->set_domain_ip(domain_ip);
        // 
        if(p_dns_session->p_c_authoritys != NULL )
        {
            domain_ip = "";
            tmp = "";
            i_ns = 0;
            itc = 0;
            for(i= 0; i < p_dns_session->authority_num; i++)
            {
                if(p_dns_session->p_c_authoritys[i].c_answ_type == DNS_AUTHORITYS_CLASS_NS)
                {
                    if(itc > 0)
                    { 
                        domain_ip +="|";
                    }
                    domain_ip += p_dns_session->p_c_authoritys[i].priname_or_ip;
                    itc ++ ;
                }
                if(p_dns_session->p_c_authoritys[i].c_answ_in == DNS_ANSWERS_TYPE_IP)
                {
                    if(i_ns > 0)
                    {
                        tmp += "|";
                    }
                    tmp += p_dns_session->p_c_authoritys[i].url;
                    i_ns++;
                }
            }
            if(!domain_ip.empty())
            {
                p_dns->set_auth(domain_ip);
            }
            else
            {
                p_dns->set_auth(tmp);
            }
        }
        else
        {
            p_dns->set_auth(tmp);
        }

        if(p_dns_session->p_c_addtionals != NULL )
        {
            domain_ip = "";
            tmp = "";
            i_ns = 0;
            itc = 0;
            for(i= 0; i < p_dns_session->addtional_num; i++)
            {
                if( p_dns_session->p_c_addtionals[i].c_answ_type == DNS_ANSWERS_TYPE_IP)
                {
                    if(itc > 0)
                    {
                        domain_ip +="|";
                    }
                    domain_ip += p_dns_session->p_c_addtionals[i].priname_or_ip;
                    itc ++ ;
                }
                if( p_dns_session->p_c_addtionals[i].c_answ_in == DNS_ANSWERS_CLASS_NS)
                {
                    if(i_ns > 0)
                    {
                        tmp += "|";
                    }
                    tmp += p_dns_session->p_c_addtionals[i].url;
                    i_ns++;
                }
            }
            if(!domain_ip.empty())
            {
                p_dns ->set_addition(domain_ip);
            }
            else
            {
                p_dns ->set_addition(tmp);
            }
        }
        p_attach_info -> p_protocal -> PotocolStatistics(4,1,0,1);

        p_net ->datalen = 20 + p_dns_session->p_quest->url.length() + domain_ip.length() + tmp.length();
        // 接口 
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;

        p_list -> push_back(m_data);
    }

    p_session->send_len = 0;
    p_session->p_send_buf = NULL;

    p_session->server.clear_buf();
}

void dns_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(p_session)
        return;

    if(check_time - p_session->last_packet_time > dns_time_out *1000000)
    {
        if(p_session ->client.get_data_len() > 0)
        {
            // 开始超市 处理  
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
    }
    //p_session->last_packet_time = check_time;
}

void dns_plugin::resources_recovery(session * p_session)
{
    if(p_session == NULL)
        return;

    dns_session * p_dns_session = (dns_session *)p_session->expansion_data;
    if(p_dns_session == NULL)
        return;

    if(p_dns_session->p_quest != NULL)
        delete [] p_dns_session->p_quest;
    p_dns_session->p_quest = NULL;

    if(p_dns_session ->p_c_answers != NULL)
        delete [] p_dns_session ->p_c_answers;
    p_dns_session ->p_c_answers = NULL;

    if(p_dns_session ->p_c_authoritys != NULL)
        delete [] p_dns_session ->p_c_authoritys;
    p_dns_session ->p_c_authoritys = NULL;

    if(p_dns_session ->p_c_addtionals != NULL)
        delete [] p_dns_session ->p_c_addtionals;
    p_dns_session ->p_c_addtionals = NULL;
}

