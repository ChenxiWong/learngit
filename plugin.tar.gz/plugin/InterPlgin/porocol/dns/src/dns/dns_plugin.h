// Last Update:2016-02-26 16:17:17
/**
 * @file dns_plugin.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-14
 */

#ifndef DNS_PLUGIN_H
#define DNS_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "dns_str.h"
#include <tcp_recombine.h>
#include <map>


#include <ac_rule.h>
#include <DFI_config_parse.h>


using namespace std;

extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info *);
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class dns_plugin :public protocol_parse_base_handle{
    public:
        dns_plugin();
        ~dns_plugin();
        virtual void reload() ;
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);
        
        map <rule_node_offist * , int  >  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;
   
    private:

        void init_dns_session(dns_session * p_dns_session);
        uint32_t  dns_time_out; // 单位s
        int       data_interface_type ; //
        uint8_t * dns_quest_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len);
        uint8_t * dns_answers_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len);
        uint8_t * dns_authority_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len);
        uint8_t * dns_addtional_parse(session * p_session,dns_session *p_dns_session ,uint8_t * buf,uint32_t & len);
        uint8_t * dns_url_parse_string(uint8_t * buf, uint32_t & len ,string & url,uint32_t  strat_len,int num);
        map<uint32_t,string>off_string_map;

        uint32_t begin_len ;

        uint8_t  * begin_data;
        uint8_t  * p_end;
        xml_parse  xml;
        // 
        uint64_t begin_time;
        uint32_t row;
        uint32_t max_row;
        uint32_t max_time_scr;

        string file_path;
        string file_name;
        string file_data ;

        w_file_str *file_str ;
//        CAmsg *msg;
        ListArray<uint32_t> dns_array;
        uint64_t max_dns_num;
        uint32_t dns_count;
        uint64_t update_time;
        uint64_t last_update_time;
};
static attach_info * p_attach_info ; 
#endif  /*dns_PLUGIN_H*/
