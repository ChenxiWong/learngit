// Last Update:2015-05-15 16:51:59
/**
 * @file imap_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-17
 */

#ifndef IMAP_PARSE_H
#define IMAP_PARSE_H
#include "mail_cmd_marge.h"
#include <commit_tools.h>

class imap_parse : public mail_cmd_marge {
    public:
        imap_parse();
        ~imap_parse();
        bool imap_potocol_identify(session* p_session, c_packet* p_packet);
        void imap_potocol_sign_judge(session* p_session, c_packet* p_packet,mail_session * p_mail_session);
        void imap_handle(session* p_session,mail_session * p_mail_session);
    private:
       // char * p_cmd_begin = NULL;
};


#endif  /*imap_PARSE_H*/
