// Last Update:2015-05-15 16:54:12
/**
 * @file smtp_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-14
 */

#ifndef SMTP_PARSE_H
#define SMTP_PARSE_H
#include "mail_cmd_marge.h"
#include <commit_tools.h>

#define USER_NAME_STATE 3
#define USER_PASSWD_STATE 4
#define MIME_END_STATE 5

class CSmtpParse : public mail_cmd_marge {
    public:
        CSmtpParse();
        ~CSmtpParse();
        bool smtp_potocol_identify(session* p_session, c_packet* p_packet);
        void smtp_potocol_sign_judge(session* p_session, c_packet* p_packet, mail_session * p_mail_session);
        void smtp_handle(session* p_session, mail_session * p_mail_session);
    private:
};


#endif  /*POP3_PARSE_H*/
