// Last Update:2016-03-22 15:13:19
/**
 * @file pop3_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-08
 */
#include "pop3_parse.h"
#include <iostream>
using namespace std;
#define DEFINEPORT  110
char * cmd_fetch1 (char * &data,int len , mail_session * p_mail_session)
{
    if(len<2 || data==NULL)
        return NULL;

    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_cmd =data ;
    int front_len = strlen(p_cmd);
    p_mail_session->p_data = splits_string(p_cmd,0x20);
    if((uint32_t)len > strlen(p_cmd)+1)
        p_mail_session->len = (uint32_t)len -strlen(p_cmd) -1;
    int back_len = strlen(p_cmd);
    if((front_len == (back_len+1))||(front_len == back_len))
    {
        return NULL;
    }
    return p_cmd;
}

char * cmd_fetch (char * &data,int len , mail_session * p_mail_session)
{
    if(len<2 || data==NULL)
        return NULL;

    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_cmd =data ;
    p_mail_session->p_data = splits_string(p_cmd,0x20);
    if((uint32_t)len > strlen(p_cmd)+1)
        p_mail_session->len = (uint32_t)len -strlen(p_cmd) -1;
    return p_cmd;
}

char* data_fetch(char* data)
{
    char* p_data = strchr(data, 0x20);
    return p_data ;

}
char * return_value_fatch(char * data , int len  , mail_session * p_mail_session)
{
    if(len<2 || data==NULL)
        return NULL;

    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_re = data;
    p_mail_session->p_data = splits_string(p_re,0x0a);
    if((uint32_t)len > strlen(p_re)+1)
        p_mail_session->len = (uint32_t)len -strlen(p_re) -1;
    return p_re;
}

// USER 命令解析 
void cmd_user_parse(char * data,int len , mail_session * p_mail_session,session * p_session)
{
    // 提取用户名 
    *(p_mail_session->username) = data;
}

// PASSWD命令解析
void cmd_passwd_parse(char * data , int len ,mail_session * p_mail_session,session * p_session)
{
    *( p_mail_session->passwd) = data;
}

// USER 新命令解析
void cmd_user_new_parse(char * data,int len , mail_session * p_mail_session,session * p_session)
{
    // 提取用户名 
    p_mail_session->proto_state = MIME_PARSE_CONTINUE_STATE;
    if (strncmp(data, "LOGIN", 5) == 0)
    {
        p_mail_session->proto_state = POP_CMD_USER_NAME;
        p_session->client.clear_buf();
    }
}

// LIST  命令 解析 
//RETR 命令 
void cmd_retr_parse(char * data,int len ,mail_session * p_mail_session,session * p_session)
{
    p_mail_session->proto_state = DATA_PARSE_STATE;
    p_session->server.clear_buf();
    p_session->client.clear_buf();
    //  p_mail_session->requst_time = p_session -> last_packet_time;
}


pop3_parse::pop3_parse()
{
    cmd_handle_map.clear();
    cmd_handle handle;
    // USER 
    handle.cmd_param_handle = (ptr_cmd_handle)cmd_user_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("USER"),handle));
    cmd_handle_map.insert(pair<string,cmd_handle>(string("user"),handle));
    // PASSWD 

    handle.cmd_param_handle = (ptr_cmd_handle)cmd_passwd_parse ;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("PASS"),handle));
    cmd_handle_map.insert(pair<string,cmd_handle>(string("pass"),handle));

    // RETR 
    handle.cmd_param_handle = (ptr_cmd_handle)cmd_retr_parse ;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("RETR"),handle));
    cmd_handle_map.insert(pair<string,cmd_handle>(string("retr"),handle));

    // 新的数据格式的口令字
    handle.cmd_param_handle = (ptr_cmd_handle)cmd_user_new_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("AUTH"),handle));
}
pop3_parse::~pop3_parse()
{

}
bool pop3_parse::pop3_potocol_identify(session * p_session , c_packet * p_packet)
{
    // 只有端口判断是否是pop3 协议  
    if(ntohs(p_session ->srcport)== DEFINEPORT )
    {
        p_session -> b_src_is_ser  = true;
        return true;
    }
    else if(ntohs(p_session -> dstport) ==DEFINEPORT)
    {
        p_session -> b_src_is_ser = false;
        return true;
    }
    return false;
}

void pop3_parse::pop3_potocol_sign_judge(session* p_session, c_packet* p_packet,mail_session * p_mail_session)
{
    //  判断方向 
    if((p_session->srcport== p_packet->get_src_port() &&  p_session -> b_src_is_ser )  ||
            (p_session -> b_src_is_ser  == false  && p_session->dstport ==  p_packet->get_src_port() )  )
    {
        p_mail_session ->b_c2s = false;
    }
    else {
        p_mail_session ->b_c2s = true;
    }

    if(p_packet==NULL || p_packet->p_app_data==NULL)
            return ;

    if(memcmp(p_packet -> p_app_data,"+OK core mail\r\n",15) == 0 || memcmp(p_packet -> p_app_data,"QUIT\r\n",6) == 0)
    {
    	return ;
    }
    // 判断 是否完整
    if(p_mail_session->proto_state == CMD_PARSE_STATE ||
            p_mail_session->proto_state == DATA_PARSE_STATE ||
            p_mail_session->proto_state == MIME_PARSE_CONTINUE_STATE)
    {
        if((p_mail_session->proto_state == CMD_PARSE_STATE || p_mail_session->proto_state == MIME_PARSE_CONTINUE_STATE)&&
                p_mail_session ->b_c2s == false )
        {
            return ;
        }
        // 判断命令是否完整 
        if(judge_cmd_data_end(p_packet,p_session,p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }
    else {
        // 判断MIME是否完整 
        if(judge_mime_end(p_packet,p_session,p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }
    return ;
}
void pop3_parse::pop3_handle(session * p_session ,mail_session * p_mail_session)
{
    //if(p_mail_session -> p_data == NULL && p_mail_session->len == 0 )
    if(p_mail_session -> p_data == NULL || p_mail_session->len == 0 )
    {
        return;
    }
    if(p_mail_session->b_c2s) {

        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    if(p_mail_session->len >2)
                    {
                        char * p= cmd_fetch1(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if(p == NULL)
                        {
                            p_session->client.clear_buf();
                            return;
                        }

                        string tmp = p;
                        if( tmp == "TOP")
                        {
                            if( p+4 == NULL)
                            {
                                p_session->client.clear_buf();
                                return;
                            }
                            char* p_third = data_fetch(p+4);
                            if( p_third == NULL)
                            {
                                p_session->client.clear_buf();
                                return;
                            }
                            else
                            {
                                p_third +=1;
                            }
                            if( *p_third != '0')
                            {
                                p_mail_session->proto_state = DATA_PARSE_STATE;
                                p_session->server.clear_buf();
                                p_session->client.clear_buf();
                            }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            sz_cmd_handle(tmp,p_mail_session,p_session);
                        }
                        p_mail_session->requst_time = p_session -> packet_time;
                    }
                    else
                    {
                        p_session->client.clear_buf();
                        return;
                    }
                }
                break;
            case DATA_PARSE_STATE:
                {
                    //        data_handle(p_mail_session);
                }

                break;
            case MIME_PARSE_STATE:
                {
                    // 清理包 
                    if(p_mail_session->len >2)
                    {
                        char * p= cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if(p == NULL)
                        {
                            p_session->client.clear_buf();
                            return;
                        }

                        string tmp = p;
                        //if(tmp != p_mail_session->p_data) // 
                        //到处一封邮件

                        p_mail_session->b_end_file = true;
                        p_session -> p_send_buf = p_session ->server.get_tcp_data(p_session -> send_len);
                        if((p_session->send_len>=5) && cmpn_wiat_end(p_session->p_send_buf, p_session->send_len - 5,"\r\n.\r\n")) //判断邮件是否写入完成 
                        {
                            p_mail_session -> b_end_file = true;
                            p_mail_session->b_mime_end = true;
                            p_session->send_len -= 5;
                            // mime邮件导入写入完成标志 
                            //    return true;
                        }

                        if(p_session -> send_len == 0) 
                        {
                            p_session -> p_send_buf = NO_NULL;
                            p_session -> send_len = 1;
                        }
                        if(tmp == "RETR")
                        {
                            p_mail_session->proto_state = DATA_PARSE_STATE;
                        }
                        else
                        {
                            if( tmp == "TOP")
                            {
                                if( p+4 == NULL)
                                {
                                    p_session->client.clear_buf();
                                    return;
                                }
                                char* p_third = data_fetch(p+4);
                                if( p_third == NULL)
                                {
                                    p_session->client.clear_buf();
                                    return;
                                }
                                else
                                {
                                    p_third +=1;
                                }
                                if( *p_third != '0')
                                {
                                    p_mail_session->proto_state = DATA_PARSE_STATE;
                                    break;
                                }
                            }
                            p_mail_session->proto_state = CMD_PARSE_STATE;
                        }
                    }
                    //p_session -> p_send_buf = p_session ->server.get_tcp_data(p_session -> send_len);
                    //p_session->server.clear_buf();
                }
                break;

            case MIME_PARSE_CONTINUE_STATE:
                {
                    //        data_handle(p_mail_session);
                    if(p_mail_session->len < 3)
                        return;
                    int int_out_byte;
                    string user_pass = base64_decode(p_mail_session->p_data, p_mail_session->len-2, int_out_byte);
                    char* p_str_start = const_cast<char*>(user_pass.c_str());
                    p_mail_session->username->clear();
                    p_mail_session->passwd->clear();
                    p_str_start += strlen(p_str_start) + 1;
                    *(p_mail_session->username) = p_str_start;
                    p_str_start += strlen(p_str_start) + 1;
                    *(p_mail_session->passwd) = p_str_start;
                    p_mail_session->proto_state = CMD_PARSE_STATE;

                }

                break;

            case POP_CMD_USER_NAME:
                {
                    if(p_mail_session->len < 3)
                        return;
                    int int_out_byte;
                    string user_pass = base64_decode(p_mail_session->p_data, p_mail_session->len-2, int_out_byte);
                    char* p_str_start = const_cast<char*>(user_pass.c_str());
                    p_mail_session->username->clear();
                    *(p_mail_session->username) = p_str_start;
                    p_mail_session->proto_state = POP_CMD_PWD;
                    p_session->client.clear_buf();
                }

                break;

            case POP_CMD_PWD:
                {
                    if(p_mail_session->len < 3)
                        return;
                    int int_out_byte;
                    string user_pass = base64_decode(p_mail_session->p_data, p_mail_session->len-2, int_out_byte);
                    char* p_str_start = const_cast<char*>(user_pass.c_str());
                    p_mail_session->passwd->clear();
                    *(p_mail_session->passwd) = p_str_start;
                    p_mail_session->proto_state = CMD_PARSE_STATE;
                }

                break;
            default:
                break;
        }
        p_session->client.clear_buf();
    }
    else { // s2c 
        p_mail_session->response_time = p_session -> packet_time;
        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    data_handle(p_mail_session,p_session);
                    break;
                }
            case DATA_PARSE_STATE:
                {
                    // 判断是否是 OK 
                    if(p_mail_session->len >= 5)
                    {
                        if((*(p_mail_session->p_data+3)=='\r') && (*(p_mail_session->p_data+4)=='\n')&&(strncmp(p_mail_session->p_data, "+OK", 3) == 0))
                        {
                            p_mail_session->proto_state = MIME_PARSE_STATE; 
                            p_mail_session -> b_mime_info = true;
                            p_mail_session->b_mime_end = false;
                            p_mail_session ->b_end_file = false;
                            // 设置 mime 开始的 
                            uint32_t   nextseq =  p_session ->server.get_next_seq();
                            p_session->server.clear_buf();
                            p_session->server.add_tcp_packet(0, p_mail_session -> p_data, nextseq);
                        }
                        //if(strncmp(p_mail_session -> p_data ,"+OK \r\n",6)== 0)
                        else if(strncmp(p_mail_session -> p_data ,"+OK ",4)== 0)
                        {
                            p_mail_session->proto_state = MIME_PARSE_STATE;
                            p_mail_session -> b_mime_info = true;
                            p_mail_session->b_mime_end = false;
                            p_mail_session ->b_end_file = false;
                            // 设置 mime 开始的 
                            uint32_t   nextseq =  p_session ->server.get_next_seq();
                            p_session->server.clear_buf();
                            //if(p_mail_session ->len == 6)
                            if(p_mail_session->len==6 && (*(p_mail_session->p_data+4)=='\r') && (*(p_mail_session->p_data+5)=='\n'))
                            {
                                p_session->server.add_tcp_packet(0, p_mail_session -> p_data, nextseq);

                            }
                            else
                            {
                                // 查找\r\n 
                                char *mid = strstr(p_mail_session-> p_data, "\r\n");
                                if(mid != NULL)
                                {
                                    uint32_t len = mid-p_mail_session-> p_data+2;
                                    if(p_mail_session ->len == len)
                                    {
                                        p_session->server.add_tcp_packet(0, p_mail_session -> p_data,nextseq);
                                    }
                                    else if(p_mail_session->len > len)
                                    {
                                        p_session->server.add_tcp_packet(p_mail_session->len-len, p_mail_session->p_data+len, nextseq+len);

                                        p_session -> p_send_buf = p_session ->server.get_tcp_data(p_session -> send_len);
                                        p_mail_session ->p_data  = p_session -> p_send_buf ;
                                        m_mime_parse(p_mail_session);
                                        if(p_mail_session ->b_end_file )
                                        {
                                        	p_mail_session -> b_mime_info = true;
                                        }
                                        if(p_mail_session->b_mime_end )
                                        {
                                        	p_mail_session->proto_state = CMD_PARSE_STATE;
                                        }
                                       /* string tmp;
													 tmp.insert(tmp.end(),buffer,buffer + p_mail_session->len);
													 *(p_mail_session->file_content) += tmp;
                                       // memcpy(p_mail_session -> p_remain_data,buffer,p_mail_session->len);
                                       // p_mail_session -> p_remain_data = ;
                                        p_mail_session->remain_len = p_mail_session->len;*/
                                        p_session->server.clear_buf();
                                    }
                                }
                            }
                        }
                        return ;

                    }
                    else {
                    }

                    break;
                }
            case MIME_PARSE_STATE:
                { 
                    // mime 文件 ，写入文件 
                    //
                    p_session -> p_send_buf = p_session ->server.get_tcp_data(p_session -> send_len);
                    if(p_session -> p_send_buf != NULL && p_session -> send_len != 0)
                    {
                        if(memcmp(p_session -> p_send_buf,"+OK byebye!\r\n",13) == 0)
                        {
                        	p_session -> p_send_buf = NULL;
                        	p_session -> send_len = 0;
                        	return;
                        }
                    }
                    p_mail_session ->p_data  = p_session -> p_send_buf ;
                    m_mime_parse(p_mail_session);
                    if(p_mail_session ->b_end_file ) 
                    {
                        p_mail_session -> b_mime_info = true;
                    }
                    if(p_mail_session->b_mime_end )
                    {
                        p_mail_session->proto_state = CMD_PARSE_STATE;
                    }
                    // printf("tttttttttttttttttttttttttttttttt\n");
                    return ;
                }
            default:
                break; 

        }
        p_session->server.clear_buf();

    }

}

//viod cmd_OK_handle()
// 
