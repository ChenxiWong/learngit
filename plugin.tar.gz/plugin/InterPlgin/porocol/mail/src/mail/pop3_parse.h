// Last Update:2015-04-08 18:00:55
/**
 * @file pop3_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-08
 */

#ifndef POP3_PARSE_H
#define POP3_PARSE_H
#include "mail_cmd_marge.h"
#include <commit_tools.h>

class pop3_parse : public mail_cmd_marge {
    public:
        pop3_parse();
        ~pop3_parse();
        bool pop3_potocol_identify(session* p_session, c_packet* p_packet);
        void pop3_potocol_sign_judge(session* p_session, c_packet* p_packet,mail_session * p_mail_session);
        void pop3_handle(session* p_session,mail_session * p_mail_session);
    private:
};


#endif  /*POP3_PARSE_H*/
