// Last Update:2016-03-10 17:28:07
/**
 * @file mail_cmd_marge.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-07
 */
#include "mail_cmd_marge.h"
mail_cmd_marge::mail_cmd_marge()
{
    // cmd_handle_map.;
}

mail_cmd_marge::~mail_cmd_marge()
{
    // cmd_handle_map.;
}

void mail_cmd_marge::add_cmd_handle_map(string c_cmd , cmd_handle handle)
{
    cmd_handle_map.insert(pair<string,cmd_handle>(c_cmd,handle));
}

void mail_cmd_marge::sz_cmd_handle(string & c_cmd , mail_session * p_mail_session,session * p_session)
{

    map<string,cmd_handle>::iterator it = cmd_handle_map.find(c_cmd);
    if(it != cmd_handle_map.end())
    {
        p_mail_session ->phandle = it->second;
        if(p_mail_session->phandle.cmd_param_handle != NULL)
        {
            p_mail_session->phandle.cmd_param_handle(p_mail_session->p_data,p_mail_session->len,p_mail_session,p_session);
        }
    }
    return;
}

void mail_cmd_marge::data_handle(mail_session * p_mail_session,session * p_session)
{
    if(p_mail_session->phandle.cmd_return_handle != NULL)
        p_mail_session->phandle.cmd_return_handle(p_mail_session->p_data,p_mail_session->len,p_mail_session,p_session);
    return;
}

// 判断是否 邮件结束   
bool mail_cmd_marge::judge_cmd_data_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session)
{
    if(p_packet==NULL || p_packet->p_app_data==NULL)
        return false;

    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    if(len == 0) return false;
    char * p_data =(char *)p_packet -> p_app_data;
    //uint32_t packet_len = 0;
    // seq 判断 
    if(p_mail_session ->b_c2s) // 目标是server  ， 数据是 client的 
    {
        p_session->client.add_tcp_packet(len,p_data,seq);
        //p_mail_session->client_last_seq = seq;
        //判断包是否连续
        p_mail_session -> p_data= p_session->client.get_tcp_data(p_mail_session->len);
        if(p_mail_session->len > 2)
        {
            // 末尾是否有/r/n 
            return ((p_mail_session->len>=2) && cmpn_wiat_end(p_mail_session -> p_data,p_mail_session->len -2 , "\r\n"));
        }
    }
    else  {
        p_session->server.add_tcp_packet(len,p_data,seq);
        //判断包是否连续
        p_mail_session -> p_data= p_session->server.get_tcp_data(p_mail_session->len);
         if(p_mail_session->len  + 1520 > MAXTCPBUF)
         {
              return true;
         }
        if(p_mail_session->len > 2)
        {
            //末尾是否有有/r/n
            return ((p_mail_session->len>=2) && cmpn_wiat_end(p_mail_session -> p_data,p_mail_session->len -2 , "\r\n"));
        }
    }
}

bool mail_cmd_marge::judge_append_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session)
{
    if(p_packet==NULL || p_packet->p_app_data==NULL)
        return false;
        // 协议识别的方向 --- 需要判断方向
        uint32_t seq = p_packet->get_seqnumber();
        uint16_t len = p_packet->app_data_len ;
    if(len >= MAXTCPBUF)
    {
        return false;
    }
    if(len == 0 )
    {
        p_mail_session->p_data= p_session->server.get_tcp_data(p_mail_session->len);
        return false;
    }
    char * p_data =(char *)p_packet -> p_app_data;

    if(p_mail_session ->b_c2s && p_mail_session->proto_type==MAIL_IMAP && len >= p_mail_session->remain_len )
   {
       p_session->server.add_tcp_packet(len - 2,p_data,seq);
       p_mail_session->p_data= p_session->server.get_tcp_data(p_mail_session->len);
       p_mail_session->proto_state = MIME_PARSE_STATE;
       return true;
   }
    else
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        if(p_mail_session->remain_len > len)
        {
            p_mail_session->remain_len -= len;
        }
        if(p_mail_session->len  + 1520 > MAXTCPBUF)
        {
            //if(p_mail_session-> proto_state == MAIL_IMAP)
            if(p_mail_session-> proto_type == MAIL_IMAP)
            {
                //p_mail_session -> imap_mime_len -= p_mail_session -> len;
            }
            return true;
        }
        return false;
    }
}


bool mail_cmd_marge::judge_mime_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session)
{
    if(p_packet==NULL || p_packet->p_app_data==NULL)
        return false;
    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    if(len >= MAXTCPBUF) 
    {
        return false;
    }
    if(len == 0 ) return false;
    char * p_data =(char *)p_packet -> p_app_data;
    //uint32_t packet_len = 0;
    //if(p_mail_session ->b_c2s) // 目标是server  ， 数据是 client的 
    if(p_mail_session ->b_c2s && (p_mail_session->proto_type==MAIL_POP3 || p_mail_session->proto_type==MAIL_IMAP))
    {
        p_session->client.add_tcp_packet(len,p_data,seq);
        p_mail_session->p_data= p_session->client.get_tcp_data(p_mail_session->len);
        return true;
    }
    else if(p_mail_session->proto_type == MAIL_STMP)
    {
        if(p_mail_session ->b_c2s)
        {
            if(len == 5)
            {
                if((len>=5) && cmpn_wiat_end(p_data, len-5,"\r\n.\r\n"))
                {
                    p_mail_session -> b_end_file = true;
                    p_mail_session->b_mime_end = true;
                    return true;
                }
            }

            p_session->client.add_tcp_packet(len,p_data,seq);
            p_mail_session->p_data= p_session->client.get_tcp_data(p_mail_session->len);
            if(p_mail_session -> len > 0  &&   p_mail_session->b_mime_end )
            {
                return true;
            }
            if(p_mail_session->len  + 1520 > MAXTCPBUF)
            {
                return true;
            }
            return false;
        }
        else 
        {
            p_session->server.add_tcp_packet(len,p_data,seq);
            p_mail_session->p_data= p_session->server.get_tcp_data(p_mail_session->len);
            return true;
        }
    }
    else
    {
        if(len == 5)
        {
            if((len>=5) && cmpn_wiat_end(p_data, len-5,"\r\n.\r\n")) //判断邮件是否写入完成 
            {
                p_mail_session -> b_end_file = true;
                p_mail_session->b_mime_end = true;
                len -=5;
                // mime邮件导入写入完成标志 
                return true;

            }
        }
        /*if( (len>=5) && cmpn_wiat_end(p_data, len-5,"\r\n.\r\n")) //判断邮件是否写入完成 
          {
          if(len == 5)
          {
          return true;
          }
          p_mail_session -> b_end_file = true;
          p_mail_session->b_mime_end = true;
          len -=5;
        // mime邮件导入写入完成标志 

        }*/
        /*
        p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        int pre_len = p_mail_session->len;
        if (p_mail_session->proto == MAIL_IMAP && p_mail_session->imap_mime_len < p_mail_session->len+len && 
                ( (p_mail_session->remain_seq == 0) || (p_mail_session->remain_seq != 0 && p_mail_session->remain_seq+pre_len == seq) ))
        {
            p_session->server.add_tcp_packet(p_mail_session->imap_mime_len - p_mail_session->len, p_data, seq);
        }
        else
        {
            p_session->server.add_tcp_packet(len, p_data, seq);
        }
        */
        p_session->server.add_tcp_packet(len, p_data, seq);
        p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        if(p_mail_session -> len > 0  &&   p_mail_session->b_mime_end )
        {
            return true;
        }
        if(p_mail_session->len  + 1520 > MAXTCPBUF)
        {
            if(p_mail_session-> proto_type == MAIL_IMAP)
            {
                //p_mail_session -> imap_mime_len -= p_mail_session -> len;
            }
            return true;
        }
        /*
        if(p_mail_session->proto_type==MAIL_IMAP && p_mail_session->imap_mime_len<=p_mail_session->len)
        {
            return true;
        }
        */

        if (p_mail_session->proto == MAIL_IMAP && p_mail_session->imap_mime_len <= p_mail_session->len)
        {
            p_mail_session -> b_end_file = true;
            uint32_t begin_seq = p_session->server.get_begin_seq();
            uint32_t int_remain_seq;
            uint16_t int_remain_len;
            char * p_remain_data = NULL;
            //if(len - (p_mail_session->imap_mime_len-pre_len) >= 3)
            if(p_mail_session->len >= p_mail_session->imap_mime_len + 3)
            {
                int_remain_seq = begin_seq + p_mail_session->imap_mime_len + 3;
                int_remain_len = p_mail_session->len - p_mail_session->imap_mime_len - 3;
                p_remain_data = p_mail_session->p_data + p_mail_session->imap_mime_len + 3;
                //int_remain_seq = seq + p_mail_session->imap_mime_len-pre_len + 3;
                //int_remain_len = len - (p_mail_session->imap_mime_len-pre_len) - 3;
                //p_remain_data = p_data + p_mail_session->imap_mime_len-pre_len + 3;
            }
            else
            {
                int_remain_seq = begin_seq + p_mail_session->imap_mime_len;
                int_remain_len = p_mail_session->len - p_mail_session->imap_mime_len;
                p_remain_data = p_mail_session->p_data + p_mail_session->imap_mime_len;
                //int_remain_seq = seq + p_mail_session->imap_mime_len-pre_len;
                //int_remain_len = len - (p_mail_session->imap_mime_len-pre_len);
                //p_remain_data = p_data + p_mail_session->imap_mime_len-pre_len;
            }

            // 判定内容是否是固定格式, * 2 FETCH (UID 1384 RFC822.SIZE 2187 BODY[] {2187}
            //if(p_remain_data!=NULL && *p_remain_data != '*')
            if(int_remain_len > 0 && p_remain_data!=NULL && *p_remain_data != '*')
            {
                p_mail_session->remain_seq = 0;
                p_mail_session->remain_len = 0;
                p_mail_session->p_remain_data = NULL;
                // 7 OK UID FETCH completed
                p_mail_session->b_mime_end = true;
                //p_mail_session->proto_state = CMD_PARSE_STATE;
                return true;
            }

            if(p_remain_data != NULL)
            {
                p_mail_session->remain_seq = int_remain_seq;
                p_mail_session->remain_len = int_remain_len;
                p_mail_session->p_remain_data = p_remain_data;
            }

            return true;
        }
    }
    return false;
}

void mail_cmd_marge::m_mime_parse(mail_session * p_mail_session)
{
    // 判断是否 解析 mime 头 
    /*if(p_mail_session -> b_mime_info ) 
      {
      char * p_end = strstr(p_mail_session->p_data ,"\r\n\r\n");
      if(p_end != NULL)
      {
      mime_parse.mime_keyvalue_parse(p_mail_session->p_data,p_end,p_mail_session);
      p_mail_session -> b_mime_info = false;
      }

      } */
}

void mail_cmd_marge::mime_send_data()
{
}

