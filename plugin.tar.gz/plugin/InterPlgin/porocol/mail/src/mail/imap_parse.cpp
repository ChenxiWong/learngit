// Last Update:2016-04-07 17:51:55
/**
 * @file imap_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-17
 */
#include "imap_parse.h"
#include <stdio.h>
#include <stdlib.h>

#define DEFINEIMAPPORT  143
using namespace std;
char * imap_cmd_fetch(char * &data,int len , mail_session * p_mail_session)
{
    if (data == NULL || len < 2)
    {
        return NULL;
    }
    p_mail_session->p_cmd_begin  = data;
    //if (data == NULL) return NULL;
    if(data[len-1]=='\r' && data[len]=='\n')
    {
        data[len-2] = 0x0; // 去除末尾的/r/n
        len -= 2 ;
    }
    else
    {
        data[len] = 0x0;
    }

    //跳过第一个 标记。 该标记作用未知  ，用空格分割 
    char * p_cmd =data ;
    p_mail_session->p_data = splits_string(p_cmd,0x20);
    if (p_cmd == NULL)
        return "";
    if ((uint32_t)len < strlen(p_cmd)+1)
        return "";

    len -= strlen(p_cmd)+1;
    // 解析真正的命令 
    p_cmd = p_mail_session->p_data;
    if (p_cmd  == NULL) return "";
    p_mail_session->p_data= splits_string(p_cmd,0x20);
    //if (data == NULL)
    if (p_mail_session->p_data == NULL)
        return "";
    if ((uint32_t)len < strlen(p_cmd)+1)
        return "";
    p_mail_session->len = (uint32_t)len -strlen(p_cmd) -1;
    return p_cmd;
}

char * imap_return_value_fatch(char * data , int len  , mail_session * p_mail_session)
{
    //datdda[len-2] = 0x0; // 去除末尾的/r/n
    if (data == NULL || len  < 2)
    {
        return NULL;
    }
    char * p_re = data;
    char * p = strstr(data,"\r\n");
    if (p != NULL)
    {
        *p = 0x0;
    }
    if ((uint32_t)len < strlen(p_re)+1)
        return NULL;
    len -=  strlen(p_re)+1;
    return p+1;
}

// USER 命令解析  PASSWD命令解析
void imap_cmd_user_parse(char * data,int len , mail_session * p_mail_session,session * p_session)
{
    if (data == NULL)
        return;

    // 提取用户名   " " 中间的数据 
    char * p =  splits_string(data,0x20);
    if (p == NULL)
    {
        return;
    }
    if (*data == '"')
    {
        char * q = data;
        if (len < 1)
            return;
        ++q;
        char * q_ = splits_string(q, 0x22);
        if (q_ == NULL)
            return;
        *(p_mail_session->username) = q;
    }
    else
    {
        *(p_mail_session->username) = data;
    }

    if (*p == '"')
    {
        if (p-data >= len)
            return;

        ++p;
        char * q = splits_string(p, 0x22);
        if (q == NULL)
            return;

        *(p_mail_session->passwd) =  p;
    }
    else
    {
        *(p_mail_session->passwd) =  p;
    }
}
// LIST  命令 解析 
//UID  FETCH BOY
void imap_cmd_uid_parse(char * data,int len ,mail_session * p_mail_session,session * p_session)
{
    if (data == NULL)
        return;

    char * p = data ;
    char *p_value  = splits_string(p,0x20);
    if (strncmp(p_mail_session->p_cmd_begin ,"polb",4) == 0)
    {
        return ;
    }

    if (len>5 && strncmp(p,"FETCH",5) == 0)
    {
        if (strncmp(p_mail_session->p_cmd_begin ,"guwz",4)== 0) // panduan
        {
            p_mail_session->proto_state = CMD_PARSE_STATE;
            return;
        }
        else
        {
            // yp0z UID FETCH 1302247527 (BODY.PEEK[] UID)
            // C51 UID FETCH 1431654230 (UID RFC822.SIZE FLAGS BODY.PEEK[HEADER])
            // C21 UID FETCH 1431654263 (UID BODY.PEEK[])
            if (p-data+6 >= len)
                return;

            p += 6;
            p_value  = splits_string(p, 0x20);
            if (p_value == NULL) return;
            //if ((len>=17 && strncmp(p_value,"(BODY.PEEK[] UID)",17)==0) || (len>=41 && strncmp(p_value,"(UID RFC822.SIZE FLAGS BODY.PEEK[HEADER])",41)==0))
            if ((len>=17) && (strncmp(p_value,"(BODY.PEEK[] UID)",17)==0 || strncmp(p_value,"(UID BODY.PEEK[]",16)==0))
            {
               p_mail_session->proto_state = DATA_PARSE_STATE;
            }
        }
    }
    else if (len>5 && strncmp(p,"fetch",5) == 0)
    {
        if (strncmp(p_mail_session->p_cmd_begin ,"guwz",4)== 0) // panduan
        {
            p_mail_session->proto_state = CMD_PARSE_STATE;
            return;
        }
        else
        {
            // 8   UID fetch 1361932627 (UID RFC822.SIZE BODY.PEEK[])
            if (p-data+6 >= len)
                return;

            p += 6;
            p_value  = splits_string(p, 0x20);
            if (p_value == NULL) 
            {
                return;
            }

            if ((len>=29) && (strncmp(p_value,"(UID RFC822.SIZE BODY.PEEK[])", 29)==0 ))
            {
               p_mail_session->proto_state = DATA_PARSE_STATE;
            }
        }
    }
}

void imap_uid_return_parse(char * data,int len ,mail_session * p_mail_session,session * p_session)
{
    if (data == NULL)
        return;

    char * p = data ;
    char * p_value  = splits_string(p,0x20);
    if (p_value == NULL) return ;
    p = splits_string(p_value,0x20);
    if (p == NULL) return ;
    if ((len>p-data+5) && (strncmp(p, "FETCH", 5)==0))
    {
        //解析到协议长度 
        char * q  = strchr(p,'{');
        if (q != 0x0)
        {
            char * q_ = strchr(q+1, '}');
            if (q_ != 0x0 && q_>q+1)
            {
                string str(q+1, 0, q_-q-1);
                p_mail_session->imap_mime_len = atoi(str.c_str());
                p_mail_session->proto_state = MIME_PARSE_STATE;
            }
        }
    }
}

void imap_cmd_append_parse(char * data,int len ,mail_session * p_mail_session,session * p_session)
{
    if(data == NULL)
        return;
    char * p = data;
    char * p_value = splits_string(p,0x20);
    if(p_value == NULL)
        return;
    if(len > 4 && strncmp(p_value+2,"Seen",4) == 0)
    {
        char * q = strchr(p_value,'{');
        if(q!= 0x0)
        {
            char * q_tail = strstr(p_value+1,"+}");
            if(q_tail != 0x0)
            {
                if(q_tail > q+1)
                {
                    string str(q+1,0,q_tail-q-1);
                    p_mail_session->imap_mime_len = atoi(str.c_str());
                    p_mail_session->proto_state = APPEND_PARSE_STATE;
                }
                if(len-(q_tail+2-data) > 4 && strncmp(q_tail+2,"\r\nTo",4) == 0)
                {
                    p_mail_session->file_length = len-(q_tail+4-data);
                    p_mail_session->p_remain_data = q_tail+ 4;
                }
            }
            else
           {
               q_tail = strchr(p_value+1,'}');
               if(q_tail == 0x0)
                {
                    return;
                }

                   if(q_tail > q+1)
               {
                       string str(q+1,0,q_tail-q-1);
                       p_mail_session->imap_mime_len = atoi(str.c_str());
                       p_mail_session->proto_state = APPEND_PARSE_STATE;
               }
                   if(len-(q_tail+2-data) > 4 && strncmp(q_tail+2,"\r\nTo",4) == 0)
               {
                       p_mail_session->file_length = len-(q_tail+4-data);
                       p_mail_session->p_remain_data = q_tail+ 4;
               }
           }
        }
    }
}

imap_parse::imap_parse()
{
    cmd_handle_map.clear();
    cmd_handle handle;
    // LOGIN
    handle.cmd_param_handle = (ptr_cmd_handle)imap_cmd_user_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("LOGIN"),handle));

    // UUID BODY 
    handle.cmd_param_handle = (ptr_cmd_handle)imap_cmd_uid_parse ;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("UID"),handle));

    //append
    handle.cmd_param_handle = (ptr_cmd_handle)imap_cmd_append_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("append"),handle));

    // 新的数据格式
    // LOGIN
    handle.cmd_param_handle = (ptr_cmd_handle)imap_cmd_user_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("login"),handle));
}

imap_parse::~imap_parse()
{
}

bool imap_parse::imap_potocol_identify(session * p_session , c_packet * p_packet)
{
    // 只有端口判断是否是imap 协议  
    if (ntohs(p_session->srcport)== DEFINEIMAPPORT )
    {
        p_session->b_src_is_ser  = true;
        return true;
    }
    else if (ntohs(p_session->dstport) == DEFINEIMAPPORT)
    {
        p_session->b_src_is_ser = false;
        return true;
    }
    return false;
}

void imap_parse::imap_potocol_sign_judge(session* p_session, c_packet* p_packet,mail_session * p_mail_session)
{
    p_mail_session->proto = MAIL_IMAP;
    /*char * p_tmp = strstr((char*)p_packet->p_app_data, "OK Fetch completed");
    if ( p_tmp != NULL)
    {
        char *p_tmp_c = strstr(p_tmp-16, "\r\n)\r\n");
        if (p_tmp_c != NULL)
        {
            p_tmp += 18;
            uint32_t len_tmp = 0;
            for(;len_tmp < 30; ++len_tmp)
            {
                *(p_tmp - len_tmp) = 0x20;
            }
            len_tmp = 0;
        }
    }*/

    //  判断方向 
    if ((p_session->srcport== p_packet->get_src_port() &&  p_session->b_src_is_ser )  || 
            (p_session->b_src_is_ser  == false  && p_session->dstport ==  p_packet->get_src_port() )  )
    {
        p_mail_session->b_c2s = false;
    }
    else
    {
        p_mail_session->b_c2s = true;
    }
    // 判断 是否完整
    if (p_mail_session->proto_state == CMD_PARSE_STATE )
    {
        // 判断命令是否完整 
        if (judge_cmd_data_end(p_packet,p_session,p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }
    else if ( p_mail_session->proto_state == DATA_PARSE_STATE)
    {
        //if (p_packet==NULL && p_packet->p_app_data==NULL)
        if (p_packet==NULL || p_packet->p_app_data==NULL)
            return;
        char * data = (char *)p_packet->p_app_data;
        uint32_t len = p_packet->app_data_len;
        char * p = strstr(data,"\r\n");
        char * q = data;
        for(;p != NULL && (*(p-1) != '}');)         //应对一种特殊情况   
        {
            q = p;
            p = strstr(p+1,"\r\n");
        }
        if (p != NULL)
        {
            *p = 0x0;
            //p += 2;
            int fetch_len = p - q;
            if (fetch_len<2 || len<fetch_len-2)
                return;
            //len = len - (p-data) -2;
            uint32_t total_cmd_len = p - data;
            imap_uid_return_parse(q ,fetch_len ,p_mail_session,p_session);
            if (p_mail_session->proto_state == MIME_PARSE_STATE)
            {
                uint32_t seq = p_packet->get_seqnumber() + total_cmd_len +2 ;
                if (p_packet->app_data_len < total_cmd_len+2)
                    return;
                uint16_t len = p_packet->app_data_len  - total_cmd_len - 2;
                char * p_data =(char *)p_packet->p_app_data + total_cmd_len +2 ;
                p_session->server.clear_buf();
                p_session->server.add_tcp_packet(len, p_data,seq);
                if (p_mail_session->imap_mime_len!= 0 && p_mail_session->imap_mime_len < len)
                {
                    SET_EXPORT(p_session);
                    p_session->server.clear_buf();
                    p_session->server.add_tcp_packet(p_mail_session->imap_mime_len, p_data, seq);
                    
                    // 变更新的缓存数据
                    if(len - p_mail_session->imap_mime_len >= 3)
                    {
                        p_mail_session->remain_seq = seq + p_mail_session->imap_mime_len+3; // 要加判定
                        p_mail_session->remain_len = len - p_mail_session->imap_mime_len-3;
                        p_mail_session->p_remain_data = p_data + p_mail_session->imap_mime_len+3;
                    }
                    else
                    {
                        p_mail_session->remain_seq = seq + p_mail_session->imap_mime_len; // 要加判定
                        p_mail_session->remain_len = len - p_mail_session->imap_mime_len;
                        p_mail_session->p_remain_data = p_data + p_mail_session->imap_mime_len;
                    }

                    p_mail_session->b_end_file = true;
                    //p_session->p_send_buf = p_session->server.get_tcp_data(p_session->send_len);
                    //p_mail_session->proto_state = CMD_PARSE_STATE;
                    if(strstr(p_mail_session->p_remain_data, "OK Fetch completed") != NULL)
                    {
                        p_mail_session->b_mime_end = true;
                    }
                    p_mail_session->proto_state = MIME_PARSE_STATE;
                }
                p_mail_session->requst_time = p_session->packet_time;
                return ;
            }
        }
        p_mail_session->proto_state = DATA_PARSE_STATE;
    }
    else if ( p_mail_session->proto_state == MIME_PARSE_CONTINUE_STATE)
    {
        p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        if (p_mail_session->len > 0 && p_packet->app_data_len>0)
        {
            p_session->server.add_tcp_packet(p_packet->app_data_len, (char *)p_packet->p_app_data, p_packet->get_seqnumber());
            p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        }
        if (p_packet == NULL || p_packet->p_app_data == NULL)
            return;
        char * data = (char *)p_mail_session->p_data;
        if (data == NULL)
            return;
        if(p_mail_session->len > 3 && data[0]== ')' && data[1]=='\r' && data[2]=='\n')
        {
            data += 3;
            p_mail_session->len -= 3;
        }

        uint32_t len = p_mail_session->len;
        char * p = strstr(data, "\r\n");
        if (p != NULL)
        {
            *p = 0x0;
            p += 2;
            int fetch_len = strlen(data);
            if (fetch_len<2 || len<fetch_len-2)
                return;

            imap_uid_return_parse(data ,fetch_len ,p_mail_session,p_session);
            if (p_mail_session->proto_state == MIME_PARSE_STATE)
            {
                uint32_t seq = p_mail_session->remain_seq + fetch_len + 2;
                if (len < fetch_len+2)
                    return;
                uint16_t len2 = len - fetch_len - 2;
                char * p_data = p_mail_session->p_data + fetch_len +2 ;
                p_session->server.clear_buf();
                if (p_mail_session->imap_mime_len!= 0 && p_mail_session->imap_mime_len < len2 )
                {
                    p_session->server.add_tcp_packet(p_mail_session->imap_mime_len, p_data, seq);
                }
                else
                {
                    p_session->server.add_tcp_packet(len2, p_data, seq);
                    // 变更新的缓存数据
                    p_mail_session->remain_seq = seq;
                    p_mail_session->remain_len = len2;
                    p_mail_session->p_remain_data = p_data;
                }

                if (p_mail_session->imap_mime_len!= 0 && p_mail_session->imap_mime_len < len2)
                {
                    SET_EXPORT(p_session);
                    p_mail_session->b_end_file = true;
                    if(p_mail_session->imap_mime_len+3 < len2 && *(p_data+p_mail_session->imap_mime_len+3)!='*')
                    {
                        p_mail_session->remain_seq = 0;//一次接收邮件结束，8 OK Fetch completed
                        p_mail_session->b_mime_end = true;
                    }
                    else //一次接收邮件继续
                    {
                        // 变更新的缓存数据
                        if(len2-p_mail_session->imap_mime_len >= 3)
                        {
                            p_mail_session->remain_seq = seq+p_mail_session->imap_mime_len+3;
                            p_mail_session->remain_len = len2-p_mail_session->imap_mime_len-3;
                            p_mail_session->p_remain_data = p_data+p_mail_session->imap_mime_len+3;
                        }
                        else
                        {
                            p_mail_session->remain_seq = seq+p_mail_session->imap_mime_len;
                            p_mail_session->remain_len = len2-p_mail_session->imap_mime_len;
                            p_mail_session->p_remain_data = p_data+p_mail_session->imap_mime_len;
                        }
                    }

                    p_mail_session->proto_state = MIME_PARSE_STATE;
                }
                p_mail_session->requst_time = p_session->packet_time;
                return ;
            }
        }
        p_mail_session->proto_state = DATA_PARSE_STATE;
    }
    else if( p_mail_session->proto_state == APPEND_PARSE_STATE)
    {
        if(p_packet == NULL || p_packet->p_app_data == NULL)
            return;
        if(p_packet->app_data_len == 0)
            return;
        char * data = (char *)p_packet->p_app_data;
        uint32_t len = p_packet->app_data_len;
        uint32_t seq = p_packet->get_seqnumber();

        p_session->server.clear_buf();
        if(p_mail_session->file_length > 0 && p_mail_session->p_remain_data != NULL)
        {
            uint32_t seq_pre = seq - p_mail_session->file_length;
            p_session->server.add_tcp_packet(p_mail_session->file_length,p_mail_session->p_remain_data,seq_pre);
            p_mail_session->p_remain_data = NULL;
            p_mail_session->file_length = 0;
        }

        p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
        if(p_mail_session->len >= p_mail_session->imap_mime_len)
        {
            SET_EXPORT(p_session);
            p_mail_session->b_end_file = true;
            p_mail_session->b_mime_end = true;
            p_mail_session->proto_state = MIME_PARSE_STATE;

            p_mail_session->requst_time = p_session->packet_time;
            return;
        }

        if(len == 22 && (strncmp(data,"+ Ready for argument\r\n",22) == 0))
        {
            return;
        }

        p_session->server.add_tcp_packet(len,data,seq);

        if(p_mail_session->imap_mime_len != 0 /*&& p_mail_session->imap_mime_len < len*/)
        {
            p_session->server.clear_buf();
            p_session->server.add_tcp_packet(len,data,seq);
            p_mail_session->p_data = p_session->server.get_tcp_data(p_mail_session->len);
            if(len >= p_mail_session->imap_mime_len)
            {
                SET_EXPORT(p_session);
                p_mail_session->b_end_file = true;
                p_mail_session->b_mime_end = true;
                p_mail_session->proto_state = MIME_PARSE_STATE;
            }
            else
            {
                p_mail_session->remain_len = p_mail_session->imap_mime_len - len;
                p_mail_session->proto_state = APPEND_PARSE_END_STATE;
            }

            p_mail_session->requst_time = p_session->packet_time;
            return;
        }
        //p_mail_session->proto_state = DATA_PARSE_STATE;
        p_mail_session->proto_state = APPEND_PARSE_STATE;
    }
    else if(p_mail_session->proto_state == APPEND_PARSE_END_STATE)
    {
       if(judge_append_end(p_packet,p_session,p_mail_session))
       {
           SET_EXPORT(p_session);
       }
    }
    else {
        // 判断MIME是否完整 
        if (judge_mime_end(p_packet,p_session,p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }
    return ;
}

void imap_parse::imap_handle(session * p_session ,mail_session * p_mail_session)
{
    //if (p_mail_session->p_data == NULL && p_mail_session->len == 0 )
    if (p_mail_session->p_data == NULL || p_mail_session->len == 0 )
    {
        if(p_mail_session->b_end_file && p_mail_session -> eml_length > 0 )
        {
            p_session -> p_send_buf = NO_NULL;
            p_session -> send_len = 1;
        }
        return;
    }
    p_mail_session->p_cmd_begin = NULL;
    if (p_mail_session->b_c2s) {

        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    if (p_mail_session->len >2)
                    {
                        if (p_mail_session->p_data == NULL)
                            return;
                        char * p= imap_cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if (p == NULL)
                            return ;
                        string tmp = p;
                        sz_cmd_handle(tmp,p_mail_session,p_session);
                        p_mail_session->requst_time = p_session->packet_time;
                    }
                }
                break;
            case DATA_PARSE_STATE:
                {
                    //        data_handle(p_mail_session);
                }

                break;
            case MIME_PARSE_STATE:
                {
                    // 收到客户端消息， yp0z UID FETCH 1302247527 (BODY.PEEK[] UID)，输出上一封邮件数据
                    if (p_mail_session->len >2)
                    {
                        if (p_mail_session->p_data == NULL)
                            return;
                        /*char * p= imap_cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if (p == NULL)
                            return ;*/
                        string tmp = p_mail_session->p_data;//p;
                        if (true)
                        {
                            //导出上一封邮件
                            p_mail_session->b_end_file = true;
                            p_session->p_send_buf = p_session->server.get_tcp_data(p_session->send_len);
                            if (p_session->send_len == 0)
                            {
                                p_session->p_send_buf = NO_NULL;
                                p_session->send_len = 1;
                            }
                        }

                        p_mail_session->proto_state = CMD_PARSE_STATE;
                        sz_cmd_handle(tmp,p_mail_session,p_session);
                    }
                }
                break;
            default:
                break;
        }
        p_session->client.clear_buf();
    }
    else { // s2c
        p_mail_session->response_time = p_session->packet_time;
        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    if (p_mail_session->len >2)
                    {
                        if (p_mail_session->p_data == NULL)
                            return;
                        char * p= imap_cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if (p == NULL)
                            return;
                        string tmp = p;
                        sz_cmd_handle(tmp,p_mail_session,p_session);
                        //p_mail_session->requst_time = p_session->packet_time;
                    }
                    //data_handle(p_mail_session,p_session);
                    break;
                }
            case DATA_PARSE_STATE:
                {
                    // 判断是否是 OK
                    if (p_mail_session->len >= 6)
                    {
                        if (strncmp(p_mail_session->p_data ,"+OK \r\n",6)== 0)
                        {
                            p_mail_session->proto_state = MIME_PARSE_STATE;
                            p_mail_session->b_mime_info = true;
                            p_mail_session->b_mime_end = false;
                            p_mail_session->b_end_file = false;
                            // 设置 mime 开始的 
                            uint32_t   nextseq =  p_session->server.get_next_seq();
                            p_session->server.clear_buf();
                            if (p_mail_session->len == 6)
                            {
                                p_session->server.add_tcp_packet(0,p_mail_session->p_data,nextseq);
                            }
                            else
                            {
                                p_session->server.add_tcp_packet(p_mail_session->len - 6,p_mail_session->p_data+6,nextseq + 6);
                            }
                        }
                        return ;
                    }
                    else {
                    }

                    break;
                }
            case MIME_PARSE_STATE:
                {
                    // mime文件内容写入文件
                    p_session->p_send_buf = p_session->server.get_tcp_data(p_session->send_len);
                    p_mail_session->p_data  = p_session->p_send_buf ;
                    if(p_mail_session -> imap_mime_len < p_session->send_len)
                    {
                        p_session->send_len = p_mail_session -> imap_mime_len;
                    }
                    else
                    {
                        p_mail_session -> imap_mime_len -= p_session->send_len;
                    }
                    m_mime_parse(p_mail_session);
                    if (p_mail_session->b_end_file)
                    {
                        p_mail_session->b_mime_info = true;
                    }
                    if (p_mail_session->b_mime_end )
                    {
                        p_mail_session->proto_state = CMD_PARSE_STATE;
                    }
                    return;
                }
            default:
                break;
        }
        p_session->server.clear_buf();
    }
}

//viod cmd_OK_handle()
