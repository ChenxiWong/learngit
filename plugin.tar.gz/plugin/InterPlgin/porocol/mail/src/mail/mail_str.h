// Last Update:2016-04-07 17:52:52
/**
 * @file mail_str.h
 * @brief  邮件协议的存储文件
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-07
 */

#ifndef MAIL_STR_H
#define MAIL_STR_H
#include <string>
#include <stdint.h>
#include <list>
#include <session.h>
using namespace std;
#define MAIL_NUKOWN 0
#define MAIL_POP3 1
#define MAIL_STMP 2
#define MAIL_IMAP 3


#define CMD_PARSE_STATE 0 
#define DATA_PARSE_STATE 1
#define MIME_PARSE_STATE 2
#define MIME_PARSE_CONTINUE_STATE 5
#define APPEND_PARSE_STATE 6
#define APPEND_PARSE_END_STATE 7
#define POP_CMD_USER_NAME 8
#define POP_CMD_PWD 9
static char NO_NULL[1]={0} ;
typedef void (*ptr_cmd_handle)(char * data,int len,void  * p_mail_session,session * p_session);
class  cmd_handle{
    public :
        ptr_cmd_handle cmd_param_handle;
        ptr_cmd_handle cmd_return_handle;
};
//  
typedef  list<string> str_list;
class mail_session 
{
    public:
        uint64_t requst_time;
        uint64_t response_time;
        string   *username;
        string   *passwd;
        string   *bcc;
        //str_list *   to_email;
        //str_list *   cc_email;
        //str_list *   bcc_email;


        // 协议的状态  
        int  proto_state;
        // 协议的状态  
        int  proto;
        // 协议状态处理函数
        cmd_handle   phandle ;
        // 最后包的seq 号 
        uint32_t client_last_seq;
        uint32_t server_last_seq;

        uint32_t  len ;
        char *    p_data;

        string *file_name ; 
        string *file_path;
        uint32_t  eml_length ; 
     //   string *file_content;
        uint32_t file_length;

        uint32_t imap_mime_len ;
        // 协议类型 
        char proto_type;
        bool b_mime_end; // mime 状态结束  
        bool b_end_file; // 一个 mime 文件结束 
        bool b_mime_info; // 是否需要取发信人等信息  
        bool b_c2s; // 方向标示
        bool b_write_passwd; //记录是否写了密码 

        // 新格式增加缓存包标识
        uint32_t remain_seq;
        uint16_t remain_len;
        char * p_remain_data;

        char * p_cmd_begin;
        //uint32_t eml_length;
};

#endif  /*MAIL_STR_H*/
