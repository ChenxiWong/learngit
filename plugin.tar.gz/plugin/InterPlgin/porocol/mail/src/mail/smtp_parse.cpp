// Last Update:2016-03-23 10:34:27
/**
 * @file CSmtpParse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-14
 */

#include "smtp_parse.h"
#include <vector>
#include <iostream>
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

#define DEFINEPORT  25

using namespace std;

char * smtp_cmd_fetch(char * &data,int len , mail_session * p_mail_session)
{
    if(data == NULL  || len < 2)
    {
        return NULL;
    }
    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_cmd =data ;
    p_mail_session->p_data = splits_string(p_cmd,0x20);
    if((uint32_t)len >= strlen(p_cmd)+1)
        p_mail_session->len = (uint32_t)len -strlen(p_cmd) -1;
    return p_cmd;
}

char * smtp_return_value_fatch(char * data , int len  , mail_session * p_mail_session)
{
    if(len < 2 || data == NULL)
    {
        return NULL;
    }
    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_re = data;
    p_mail_session->p_data = splits_string(p_re,0x0a);
    if((uint32_t)len >= strlen(p_re)+1)
        p_mail_session->len = (uint32_t)len -strlen(p_re) -1;
    return p_re;
}

// PASSWD命令解析
void cmd_user_passwd_parse(char * data, int len, mail_session * p_mail_session, session * p_session)
{
    if(len<12 || data==NULL)
    {
        return;
    }
    // 重置用户状态
    if((strncmp(data, "VXNlcm5hbWU6", 12)==0) || (strncmp(data, "dXNlcm5hbWU6", 12)==0))
    {
        p_mail_session->proto_state = USER_NAME_STATE;
    }
    else if(strncmp(data, "UGFzc3dvcmQ6", 12) == 0)
    {
        p_mail_session->proto_state = USER_PASSWD_STATE;
    }
}

// PASSWD新格式命令解析
void cmd_user_passwd2_parse(char * data, int len, mail_session * p_mail_session, session * p_session)
{
    if (len < 6 || data == NULL)
    {
        return;
    }
    //AUTH PLAIN AHJ1bmZvcnRlc3RAc2luYS5jb20AMXFhejJ3c3g=
    // 重置用户状态
    if (strncmp(data, "PLAIN ", 6) == 0)
    {
        int int_out_byte;
        string user_pass = base64_decode(p_mail_session->p_data+6, p_mail_session->len-6, int_out_byte);
        // 解析用户名和密码:   \000runfortest@sina.com\000\061qaz2wsx\000\000
        char str_pattern = '\000';

        int pos = user_pass.find(str_pattern, 0);
        if (pos == string::npos)
        {
            return;
        }

        pos += 1;
        int pos2 = user_pass.find(str_pattern, pos);
        if (pos2 == string::npos)
        {
            return;
        }

        string str_user_name = user_pass.substr(pos, pos2-pos);
        pos2 += 1;
        pos = user_pass.find(str_pattern, pos2);
        if (pos == string::npos)
        {
            return;
        }

        string str_pass = user_pass.substr(pos2, pos-pos2);

        p_mail_session->username->clear();
        *(p_mail_session->username) = str_user_name;
        *(p_mail_session->passwd) = str_pass;
        p_mail_session->proto_state = CMD_PARSE_STATE;
    }
    else if ((strncmp(data, "login ", 6) == 0) || (strncmp(data, "LOGIN ", 6) == 0))
    {
        int int_out_byte;
        string str_user_name = base64_decode(p_mail_session->p_data+6, p_mail_session->len-6, int_out_byte);
        char str_pattern = '\000';

        int pos = str_user_name.find(str_pattern, 0);
        if (pos != string::npos)
        {
            str_user_name = str_user_name.substr(0, pos);
        }
        *(p_mail_session->username) = str_user_name;
        p_mail_session->proto_state = CMD_PARSE_STATE;
    }
    else if (strncmp(data, "LOGIN", 5) == 0)
    {
        p_mail_session->proto_state = CMD_PARSE_STATE;
    }
    else
    {
        return;
    }
}

// RCPT TO:  如果没有取到密码则bcc也跳过不取
void bcc_parse(char * data, int len, mail_session * p_mail_session, session * p_session)
{
    //if(data == NULL || (*(p_mail_session->passwd)).empty()) 
    if(data == NULL)
        return;

    string tmp;
    char *mid = strchr(data, '<');
    if(mid != NULL)
    {
        char *end = strchr(++mid, '>');
        if(end != NULL)
        {
            string tmp = *(p_mail_session->bcc);
            string bcc(mid, 0, end-mid);
            if(!tmp.empty())
            {
                tmp += ";";
            }
            tmp += bcc;
            *(p_mail_session->bcc) = tmp;
            //p_mail_session->proto_state = CMD_PARSE_STATE;
        }
    }
}

//DATA 命令
void data_parse(char * data, int len, mail_session * p_mail_session, session * p_session)
{
    p_mail_session->proto_state = DATA_PARSE_STATE;
}

CSmtpParse::CSmtpParse()
{
    cmd_handle_map.clear();
    cmd_handle handle;

    // USER, PASSWD 
    handle.cmd_param_handle = (ptr_cmd_handle)cmd_user_passwd_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("334"),handle));

    // RCPT TO:
    handle.cmd_param_handle = (ptr_cmd_handle)bcc_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("RCPT"),handle));

    // DATA 
    handle.cmd_param_handle = (ptr_cmd_handle)data_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("DATA"),handle));

    // USER, PASSWD  格式：AUTH PLAIN AHJ1bmZvcnRlc3RAc2luYS5jb20AMXFhejJ3c3g=
    handle.cmd_param_handle = (ptr_cmd_handle)cmd_user_passwd2_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string,cmd_handle>(string("AUTH"),handle));

    // rcpt TO: 现场发现新格式
    handle.cmd_param_handle = (ptr_cmd_handle)bcc_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string, cmd_handle>(string("rcpt"), handle));

    // data 现场数据发现新格式
    handle.cmd_param_handle = (ptr_cmd_handle)data_parse;
    handle.cmd_return_handle = NULL;
    cmd_handle_map.insert(pair<string, cmd_handle>(string("data"), handle));
}

CSmtpParse::~CSmtpParse()
{

}

bool CSmtpParse::smtp_potocol_identify(session * p_session, c_packet * p_packet)
{
    // 只有端口判断是否是smtp 协议  
    if(ntohs(p_session->srcport) == DEFINEPORT )
    {
        p_session->b_src_is_ser = true;
        return true;
    }
    else if(ntohs(p_session->dstport) == DEFINEPORT)
    {
        p_session->b_src_is_ser = false;
        return true;
    }

    return false;
}

void CSmtpParse::smtp_potocol_sign_judge(session* p_session, c_packet* p_packet, mail_session * p_mail_session)
{
    //  判断方向 
    if((p_session->srcport==p_packet->get_src_port() &&  p_session->b_src_is_ser)  ||
            (p_session->b_src_is_ser == false && p_session->dstport==p_packet->get_src_port() )  )
    {
        p_mail_session->b_c2s = false;
    }
    else
    {
        p_mail_session->b_c2s = true;
    }

    // 判断 是否完整
    if(p_mail_session->proto_state == MIME_PARSE_STATE || p_mail_session->proto_state==MIME_END_STATE)
    {
        // 判断MIME是否完整 
        if(judge_mime_end(p_packet, p_session, p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }
    else
    {
        // 判断命令是否完整 
        if(judge_cmd_data_end(p_packet, p_session, p_mail_session))
        {
            SET_EXPORT(p_session);
        }
    }

    return;
}

// smtp 处理协议
void CSmtpParse::smtp_handle(session * p_session, mail_session * p_mail_session)
{
    //if(p_mail_session->p_data==NULL && p_mail_session->len==0 )
    if(p_mail_session->p_data==NULL || p_mail_session->len==0 )
    {
        return;
    }

    if(p_mail_session->b_c2s)
    {
        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    if(p_mail_session->len > 3)
                    {
                        char * p= smtp_cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if(p == NULL)
                        {
                            p_mail_session->proto_state = CMD_PARSE_STATE;
                            return;
                        }
                        string tmp = p;
                        sz_cmd_handle(tmp,p_mail_session,p_session);
                        p_mail_session->requst_time = p_session -> packet_time;
                    }
                }
                break;

            case USER_NAME_STATE:
                {
                    if(p_mail_session->len >= 5)
                    {
                        // 提取用户名
                        int out_byte;
                        char * pos = strstr(p_mail_session->p_data, "\r\n");
                        if(pos != NULL)
                        {
                            p_mail_session->len = pos - p_mail_session->p_data;
                        }
                        string user_name = base64_decode(p_mail_session->p_data, p_mail_session->len, out_byte);
                        p_mail_session->username->clear();
                        *(p_mail_session->username) = user_name;
                        *(p_mail_session->passwd) = "";
                        if(p_mail_session->requst_time == 0)
                        {
                            p_mail_session->requst_time = p_session -> packet_time;
                        }
                        p_mail_session->proto_state = CMD_PARSE_STATE;
                    }
                }
                break;

            case USER_PASSWD_STATE:
                {
                    if(p_mail_session->len >= 5)
                    {
                        // 提取用户名
                        if (strncmp(p_mail_session->p_data, "RCPT TO", 7)  == 0)
                        {
                            *(p_mail_session->passwd) = "";
                            string tmp;
                            char *mid = strchr(p_mail_session->p_data, '<');
                            if(mid != NULL)
                            {
                                char *end = strchr(++mid, '>');
                                if(end != NULL)
                                {
                                    string tmp = *(p_mail_session->bcc);
                                    string bcc(mid, 0, end-mid);
                                    if(!tmp.empty())
                                    {
                                        tmp += ";";
                                    }
                                    tmp += bcc;
                                    *(p_mail_session->bcc) = tmp;
                                }
                            }
                        }
                        else
                        {
                            int out_byte;
                            char * pos = strstr(p_mail_session->p_data, "\r\n");
                            if(pos != NULL)
                            {
                                p_mail_session->len = pos - p_mail_session->p_data;
                            }
                            string passwd = base64_decode(p_mail_session->p_data, p_mail_session->len, out_byte);
                            if( *(p_mail_session->passwd) == "")
                            {
                                p_mail_session->passwd->clear();
                                *(p_mail_session->passwd) = passwd;
                            }
                        }
                        p_mail_session->proto_state = CMD_PARSE_STATE;
                    }
                }
                break;

            case MIME_PARSE_STATE:
                {
                    p_session->p_send_buf = p_session->client.get_tcp_data(p_session->send_len);

                    if(p_session->send_len >= 5)
                    {
                        if((p_session->send_len>=5) && cmpn_wiat_end(p_mail_session->p_data, p_session->send_len-5,"\r\n.\r\n")) //判断邮件是否写入完成 
                        {
                            p_mail_session->proto_state = MIME_END_STATE;
                            p_mail_session -> b_end_file = true;
                            p_mail_session->b_mime_end = true;

                            if(p_session->send_len  == 5)
                            {
                                p_session -> p_send_buf = NO_NULL;
                                p_session -> send_len = 1;
                            }
                        }
                    }
                }
                return ;
                //break;
            default:
                break;
        }

        p_session->client.clear_buf();
    }
    else
    { // s2c 
        p_mail_session->response_time = p_session->packet_time;
        switch(p_mail_session->proto_state)
        {
            case CMD_PARSE_STATE:
                {
                    if(p_mail_session->len >2)
                    {
                        char * p= smtp_cmd_fetch(p_mail_session->p_data , p_mail_session->len , p_mail_session);
                        if(p == NULL)
                        {
                            p_mail_session->proto_state = CMD_PARSE_STATE;
                            return ;
                        }
                        string tmp = p;
                        sz_cmd_handle(tmp,p_mail_session,p_session);
                    }
                }
                break;

            case DATA_PARSE_STATE:
                {
                    // 判断是否是 OK 
                    if(p_mail_session->len >= 4)
                    {
                        if(strncmp(p_mail_session->p_data , "354 ", 4) == 0)
                        {
                            p_mail_session->proto_state = MIME_PARSE_STATE; 
                            p_mail_session->b_mime_info = false;
                            p_mail_session->b_mime_end = false;
                            p_mail_session->b_end_file = false;
                            p_session->server.clear_buf();
                            p_session->client.clear_buf();
                        }
                    }
                }
                break;

            case MIME_PARSE_STATE:
                {
                    p_session->p_send_buf = p_session->client.get_tcp_data(p_session->send_len);
                    if(p_session->send_len == 0)
                    {
                        p_session -> p_send_buf = NULL;
                        p_session -> send_len = 1;
                    }
                    p_mail_session -> b_end_file = true;
                    p_mail_session->b_mime_end = true;

                    p_mail_session ->p_data  = p_session ->p_send_buf;
                    p_mail_session->proto_state = CMD_PARSE_STATE;
                }
                return;

            default:
                break;
        }

        p_session->server.clear_buf();
    }

    return;
}
