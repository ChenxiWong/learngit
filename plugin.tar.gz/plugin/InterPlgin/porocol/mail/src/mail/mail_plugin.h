// Last Update:2016-03-01 13:47:35
/**
 * @file mail_plugin.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-07
 */

#ifndef MAIL_PLUGIN_H
#define MAIL_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include "pop3_parse.h"
#include "smtp_parse.h"
#include "imap_parse.h"
#include <iomanip>
#include <sstream>
#include <xml_parse.h>

#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;

extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach( attach_info * p);
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class mail_plugin :public protocol_parse_base_handle{
    public:
        mail_plugin();
        ~mail_plugin();
        virtual void reload() ;
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);
        attach_info * p_attach_info ; 

        map <rule_node_offist * , int  >  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;

    private:
        void init_mail_session(mail_session * p_mail_session);
        pop3_parse m_pop3_parse;
        imap_parse m_imap;
        CSmtpParse m_smtp_parse;
        xml_parse  xml;

        uint32_t  pop3_time_out; // 单位s
        int       data_interface_type ; //
};

#endif  /*MAIL_PLUGIN_H*/
