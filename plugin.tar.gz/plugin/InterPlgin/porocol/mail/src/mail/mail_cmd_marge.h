// Last Update:2015-04-24 17:53:12
/**
 * @file mail_cmd_marge.h
 * @brief  解析邮件协议的命令  ，map 的格式来存储邮件  
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-07
 */

#ifndef MAIL_CMD_MARGE_H
#define MAIL_CMD_MARGE_H
#include <string>
#include <stdio.h>
#include <map>
#include "mail_str.h"
//#include "mime_head_parse.h"
#include <commit_tools.h>
#include <session.h>
#include <packet.h>
class mail_cmd_marge {
    public:
        //struct mail_cmd_marge * 
        mail_cmd_marge();
        ~mail_cmd_marge();
        void add_cmd_handle_map(string c_cmd, cmd_handle handle);
        void sz_cmd_handle(string &c_cmd,mail_session * p_mail_session,session * p_session);
        void data_handle(mail_session * p_mail_session,session * p_session);
        // 判断 命令结束  
        bool judge_cmd_data_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session);
        bool judge_mime_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session);
       // bool judge_write_file(char * data, int len , mail_session * p_mail_session);
        bool judge_append_end(c_packet * p_packet , session * p_session ,mail_session * p_mail_session);
       // 判断邮件内容结束 
        void m_mime_parse(mail_session * p_mail_session);
        map<string,cmd_handle> cmd_handle_map;
    private:
        //mime_head_parse mime_parse;
        void mime_send_data();



};
#endif  /*MAIL_CMD_PARSE_H*/
