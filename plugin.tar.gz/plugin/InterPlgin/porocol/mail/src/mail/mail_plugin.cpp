// Last Update:2016-03-24 17:04:17
/**
 * @file mail_plugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-07
 */

#include "mail_plugin.h"
#include <commit_tools.h>
//#include "config_text.h"
#include <sys/stat.h>

extern "C" {
    int get_plugin_id()
    {
        return 1;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        mail_plugin * p_plugin  =    new  mail_plugin();
        if(p_plugin != NULL) 
        {
            p_plugin -> p_attach_info = p ;
        }
        return p_plugin;
    }
}

/// 输出yyyy-mm-dd-hh-mm-ss 格式的日期信息

mail_plugin::mail_plugin()
{
    data_interface_type = FILESEND;
    reload();
}

mail_plugin::~mail_plugin()
{
}

void mail_plugin::reload()
{
    //添加 配置 文件 
    pop3_time_out = 60; 
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/mail_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    string tmp = "";
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" ) 
        {
            data_interface_type = NETSEND;
        }
    }
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        pop3_time_out = atoi(p_value);
    }
}

void mail_plugin::init_mail_session(mail_session * p_mail_session)
{
    p_mail_session->requst_time = 0;
    p_mail_session->response_time = 0 ;
    if(p_mail_session -> username  == NULL)
    {
        p_mail_session -> username =  new string();
    }
    *(p_mail_session -> username) =  "";
    if(p_mail_session -> passwd == NULL)
        p_mail_session -> passwd =  new string();
    *(p_mail_session -> passwd )=  "";
    if(p_mail_session -> bcc == NULL)
        p_mail_session -> bcc =  new string();
    *(p_mail_session -> bcc )=  "";
    /*if(p_mail_session -> from_email == NULL)
      {
      p_mail_session -> from_email = new string();
      }
     *(p_mail_session -> from_email) = "";
     if(p_mail_session ->to_email == NULL)
     {
     p_mail_session->to_email = new str_list;
     } 
     p_mail_session->to_email->clear();
     if(p_mail_session->cc_email == NULL)
     {
     p_mail_session->cc_email = new str_list;
     }
     p_mail_session->cc_email->clear();

     if(p_mail_session -> bcc_email  == NULL)
     {
     p_mail_session->bcc_email = new str_list;
     }*/
    if(p_mail_session ->file_name == NULL)
    {
        p_mail_session -> file_name = new string();
    }
    *(p_mail_session ->file_name) = "";
    if(p_mail_session ->file_path == NULL)
    {
        p_mail_session ->file_path = new string();
    }
    *(p_mail_session -> file_path) ="";
    //p_mail_session -> bcc_email ->clear();
    p_mail_session -> proto_state = CMD_PARSE_STATE ;
    p_mail_session -> phandle.cmd_param_handle = NULL;
    p_mail_session -> phandle.cmd_return_handle = NULL;

    p_mail_session -> client_last_seq = 0;
    p_mail_session -> server_last_seq = 0;

    p_mail_session -> len = 0;
    p_mail_session -> p_data = NULL;
    p_mail_session-> p_cmd_begin = NULL;

    //p_mail_session -> proto_type = MAIL_NUKOWN;
    p_mail_session -> b_mime_end = false;
    p_mail_session -> b_write_passwd= false;
    p_mail_session -> eml_length = 0 ; 
}

bool mail_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(!p_packet -> b_is_tcp)
    {
        return false;
    }
    // pop3 协议判断  
    if(m_pop3_parse.pop3_potocol_identify(p_session ,p_packet))
    {
        //
        mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
        init_mail_session(p_mail_session);
        p_mail_session -> proto_type = MAIL_POP3;
        return true;
    }
    else if(m_imap.imap_potocol_identify(p_session ,p_packet))
    {
        mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
        init_mail_session(p_mail_session);
        p_mail_session -> proto_type = MAIL_IMAP;
        return true;
    } 
    else if(m_smtp_parse.smtp_potocol_identify(p_session ,p_packet))
    {
        mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
        init_mail_session(p_mail_session);
        p_mail_session -> proto_type = MAIL_STMP;
        return true;
    }
    return false;
}

void mail_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session == NULL)
        return;

    mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
    if(!p_packet -> b_is_tcp || p_packet -> p_tcphdr  == NULL)
    {
        return;
    }
    p_attach_info -> p_protocal -> PotocolHandlePacketStatistics (1) ;
    // 连接 去除  
    if(p_packet -> p_tcphdr -> fin == 1) 
    {
        if(p_session ->client.get_data_len() > 0 || p_session ->server.get_data_len() || !p_mail_session->file_path->empty() )
        {
            p_mail_session->b_end_file = true;
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
        return ;
    }
    if(p_mail_session -> proto_type == MAIL_POP3)
    {
        m_pop3_parse.pop3_potocol_sign_judge(p_session,p_packet,p_mail_session);
    }
    else if(p_mail_session -> proto_type == MAIL_STMP)
    {
        m_smtp_parse.smtp_potocol_sign_judge(p_session, p_packet, p_mail_session);
    }
    else if(p_mail_session -> proto_type == MAIL_IMAP)
    {
        m_imap.imap_potocol_sign_judge(p_session, p_packet, p_mail_session);
    }
}

void mail_plugin::pococol_parse_handle(session * p_session)
{
    mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
    // 连接 去除  
    if(p_mail_session -> proto_type == MAIL_POP3)
    {
        m_pop3_parse.pop3_handle(p_session,p_mail_session);
    }
    if(p_mail_session -> proto_type == MAIL_STMP)
    {
        m_smtp_parse.smtp_handle(p_session,p_mail_session);
    }
    if(p_mail_session -> proto_type == MAIL_IMAP)
    {
        m_imap.imap_handle(p_session,p_mail_session);
    }
    if(p_mail_session->b_end_file  ) 
    {
        if(!p_mail_session->file_path->empty() && (p_session->send_len == 0 || p_session->p_send_buf == NULL))
        {
            p_session->send_len =1;
            p_session->p_send_buf = NO_NULL;
        }
    }
}

void mail_plugin::potocol_data_handle(session* p_session,list<data_interface> * p_list)
{
    mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
    data_interface m_data;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
        if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
        {
            m_data.b_out_type = FILESEND;

            string file_path;
            string file_name;
            if(p_mail_session->file_path->empty())
            {
                string requst_time;
                DNUMTOSTR(p_mail_session->requst_time, requst_time);

                // 文件相对路径
                //file_path = "/";
                file_path += get_year_month();
                file_path += get_day_hour();
                file_path += get_min_sec();

                file_name = date_time();
                file_name += "-";
                file_name += requst_time;
                // 把path 和name 写入mail_session 里面
                //memcpy(p_mail_session->file_name, file_name.data(), file_name.size());
                *(p_mail_session->file_name) = file_name;
                //memcpy(p_mail_session->file_path, file_path.data(),file_path.size());
                *(p_mail_session->file_path) = file_path;
            }
            else
            {
                file_path = *p_mail_session->file_path;
                file_name = *p_mail_session->file_name;
            }

            string eml_name = file_name;
            eml_name += ".eml";
            // 生成eml 文件
            w_file_str *file_str = new w_file_str;
            file_str->file_path = file_path;
            file_str->file_name.swap(eml_name);

            // 申请内存存储数据，写文件后自动析构
            if( p_session->p_send_buf[0] == 0x0 && p_session -> send_len == 1)
            {
                file_str->datalen =  0 ;
                file_str->file_data = NULL;
            }
            else {
                char * eml_file_data = new char[p_session->send_len];
                if(eml_file_data == NULL)
                    return;
                memcpy(eml_file_data, p_session->p_send_buf,p_session->send_len);
                file_str->file_data = eml_file_data;
                file_str->datalen = p_session->send_len;
            }

            file_str->finished = p_mail_session->b_end_file;

            m_data.data = file_str;

            p_list -> push_back(m_data);
            if(p_mail_session->b_end_file) 
            {
                // 生成关联的四元组文件
                file_str = new w_file_str;
                file_name += ".txt";
                file_str->file_path.swap(file_path);
                file_str->file_name.swap(file_name);

                // 拼装数据,格式： xxx.xxx.xxx.xxx:xxx /n xxx.xxx.xxx.xxx:xxx
                string port = "";
                DNUMTOSTR(ntohs(p_session->srcport), port);

                string index_data = p_session->srcip.ip_str();
                index_data += ":";
                index_data += port;
                index_data += "\n";
                port="";
                DNUMTOSTR(ntohs(p_session->dstport), port);
                index_data += p_session->dstip.ip_str();
                index_data += ":";
                index_data += port;
                // 申请内存空间存储数据，写文件后自动析构
                char * index_file_data = new char[index_data.size()+1];
                if(index_file_data == NULL)
                    return;

                strcpy(index_file_data, index_data.c_str());

                file_str->file_data = index_file_data;
                file_str->datalen = index_data.size();
                file_str->finished = p_mail_session->b_end_file;
                m_data.data = file_str;
                p_list -> push_back(m_data);
                if(p_mail_session->b_end_file)
                {
                    p_mail_session->file_path->clear();
                    p_mail_session->file_name->clear();
                    p_mail_session -> eml_length = 0 ;
                }
            }
        }
        if(!p_mail_session->b_write_passwd && !p_mail_session->passwd->empty())
        {
            data_interface m_data ;
            m_data.b_out_type = FILESEND;

            string requst_time;
            DNUMTOSTR(p_mail_session->requst_time, requst_time);

            // 文件相对路径
            string file_path;// = "/";
            file_path += get_year_month();
            file_path += get_day_hour();
            file_path += get_min_sec();


            string file_name = date_time();
            file_name += "-";
            file_name += requst_time;
            file_name += ".psw";
            // 生成eml 文件
            w_file_str *file_str = new w_file_str;
            file_str->file_path.swap(file_path);
            file_str->file_name.swap(file_name);
            // file_str->file_path = file_path;
            //file_str ->file_name = file_name;

            // 申请内存存储数据，写文件后自动析构, 
            // 数据格式：timestamp /n abc@efg.com /n password/n

            string file_data;
            requst_time = date_time2(p_mail_session->requst_time/100000);
            file_data += requst_time;
            file_data += "\n";
            file_data += *(p_mail_session->username);
            file_data += "\n";
            file_data += *(p_mail_session->passwd);

            char * pwd_file_data = new char[file_data.size()+1];
            if(pwd_file_data == NULL)
                return;
            strcpy(pwd_file_data, file_data.c_str());

            file_str->file_data = pwd_file_data;
            file_str->datalen = file_data.size();
            file_str->finished = true;//p_mail_session->b_end_file;
            m_data.data = file_str;
            p_list -> push_back(m_data);
            p_mail_session->b_write_passwd = true;
        }
    }
    else if (data_interface_type == NETSEND)
    {
        net_str * p_net =  new  net_str;
        p_net -> msg = new CAmsg;
        p_net->msg->Clear();
        // 设置 
        p_net->msg->set_type(1); // mail

        eml_msg* p_mail = p_net->msg->mutable_eml();
        Comm_msg* p_comm =  p_mail -> mutable_comm_msg();
        // 公共 消息 
        if(p_session -> b_src_is_ser)
        {
            p_comm ->set_src_port(ntohs(p_session->dstport));
            p_comm ->set_dst_ip(p_session->srcip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->srcport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->dstip.ip_str());
            }
        }
        else
        {
            p_comm ->set_src_port(ntohs(p_session->srcport));
            p_comm ->set_dst_ip(p_session->dstip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->dstport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->srcip.ip_str());
            }
        }
        p_comm ->set_time(p_mail_session->requst_time);
        // 文件id 
        p_mail->set_file_id(p_mail_session->requst_time);
        // 文件结束标识
        //p_mail->set_b_end(p_mail_session->b_end_file);
        p_mail->set_b_end(p_mail_session->b_end_file);
        // 用户名 
        p_mail->set_username(*p_mail_session->username);
        // 密码
        p_mail->set_passwd(*p_mail_session->passwd);

        // 文件数据内容
        if(p_session->p_send_buf != NULL)
        {
            p_mail->set_data(p_session->p_send_buf, p_session->send_len);
            p_mail_session -> eml_length += p_session->send_len ;
        }

        // to,cc,bcc
        p_mail->set_bcc(*p_mail_session->bcc);
        // 接口 
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }

    if(p_mail_session->b_end_file )
    {
        p_mail_session->proto_state = CMD_PARSE_STATE;
        p_mail_session -> eml_length = 0 ;
        p_mail_session->requst_time = p_session -> packet_time;
        p_mail_session->b_end_file = false;
        p_mail_session->b_mime_end = false;
        p_attach_info -> p_protocal -> PotocolStatistics (1,1,0 ,0) ;
        p_mail_session-> imap_mime_len = 0;
        p_session->server.clear_buf();
        p_session->client.clear_buf();
    }
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    if(p_mail_session ->proto_type == MAIL_POP3 || p_mail_session ->proto_type == MAIL_IMAP)
    {
    	  if(p_mail_session ->proto_type == MAIL_POP3)
    	  {
    		  p_mail_session->proto_state = MIME_PARSE_STATE;
    	  }
        p_session->server.clear_buf();
    }
    else if(p_mail_session ->proto_type == MAIL_STMP)
    {
        p_session->client.clear_buf();
    }
}

void mail_plugin::time_out(session * p_session,uint64_t check_time)
{
    //printf("%lu - %lu = %lu > %lu \n",check_time,p_session->last_packet_time,check_time - p_session->last_packet_time,pop3_time_out *100000);
    if(check_time - p_session->last_packet_time > pop3_time_out *100000)
    {

        //        ZERO_S_SIGN(p_session);

        if(p_session ->server.get_data_len() > 2)
        {
            // 开始超市 处理  
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
    }  
    //p_session->last_packet_time = check_time;
}

void mail_plugin::resources_recovery(session * p_session)
{
    mail_session * p_mail_session = (mail_session *)p_session->expansion_data;
    if(p_mail_session -> username != NULL)
        delete p_mail_session -> username;
    p_mail_session -> username = NULL;

    if(p_mail_session -> passwd != NULL)
        delete p_mail_session->passwd;
    p_mail_session->passwd = NULL;

    if(p_mail_session -> bcc != NULL)
        delete p_mail_session->bcc;
    p_mail_session->bcc = NULL;
   /* 
       if(p_mail_session -> from_email != NULL)
       delete p_mail_session -> from_email;

       if(p_mail_session -> to_email != NULL)
       delete p_mail_session -> to_email;

       if(p_mail_session -> cc_email != NULL)
       delete  p_mail_session -> cc_email  ;

       if(p_mail_session -> bcc_email != NULL)
       delete  p_mail_session -> bcc_email  ;
       */
    if(p_mail_session-> file_path != NULL)
        delete p_mail_session-> file_path;
    p_mail_session-> file_path = NULL;
    
    if(p_mail_session-> file_name != NULL)
        delete p_mail_session-> file_name;
    p_mail_session-> file_name = NULL;
}

