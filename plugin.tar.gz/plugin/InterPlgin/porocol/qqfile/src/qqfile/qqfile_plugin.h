// Last Update:2016-02-26 16:28:04
/**
 * @file qqfile_plugin.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */

#ifndef QQFILE_PLUGIN_H
#define QQFILE_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "qqfile_str.h"
#include <tcp_recombine.h>
#include <map>
#include "qqfile_tcp.h"
#include "qqfile_udp.h"


#include <ac_rule.h>
#include <DFI_config_parse.h>


using namespace std;


extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info * );
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class qqfile_plugin :public protocol_parse_base_handle{
    public:
        qqfile_plugin();
        ~qqfile_plugin();
        virtual void reload();
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);


        map <rule_node_offist * , int  >  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;

    private:

        void init_qqfile_session(qqfile_session * p_qqfile_session);
        uint32_t  qqfile_time_out; // 单位s
        int       data_interface_type ;

        uint32_t begin_len;
        char  * begin_data;

        uint64_t begin_time;
        uint32_t row;
        uint32_t max_row;
        uint32_t max_time_scr;

        string file_path;

        qqfile_tcp m_qqfile_tcp;
        qqfile_udp m_qqfile_udp;
        w_file_str *file_str;
        //CAmsg * msg ;
};

static attach_info  * p_attach_info ;
#endif  /*qqfile_PLUGIN_H*/
