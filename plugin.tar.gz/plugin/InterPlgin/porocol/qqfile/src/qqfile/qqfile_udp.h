// Last Update:2015-06-19 14:00:25
/**
 * @file qqfile_udp.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-30
 */

#ifndef QQFILE_UDP_H
#define QQFILE_UDP_H

#include "qqfile_str.h"
#include "analyzer_buf.h"
using namespace std;
class qqfile_udp 
{
    public:
        qqfile_udp();
        ~qqfile_udp();
        bool potocol_identify(session * p_session, c_packet * p_packet);
        void potocol_sign_judge(session * p_session, c_packet * p_packet);
        void pococol_parse_handle(session * p_session);
    private :
        bool qqfile_ddm_parse(session * p_session,qqfile_session *p_qqfile_session ,analyzer_buff & ddlbuf );
        bool qqfile_text_identify(session * p_session, c_packet * p_packet);
        analyzer_buff tmpbuf;
        analyzer_buff m_buf;
        char parse_buf[65536];
        uint32_t parse_len ; 
        uint16_t  time_state ;
};


#endif  /*QQFILE_UDP_H*/
