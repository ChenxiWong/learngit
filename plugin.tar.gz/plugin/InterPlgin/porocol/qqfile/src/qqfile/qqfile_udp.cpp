// Last Update:2015-07-23 22:27:41
/**
 * @file qqfile_udp.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-30
 */



#include "qqfile_udp.h"
#define QQUDPDEFINEPORT 8000

qqfile_udp::qqfile_udp()
{
    memset(parse_buf, 0, sizeof(char)*65536);
}

qqfile_udp::~qqfile_udp()
{
}

bool qqfile_udp::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(p_session==NULL || p_packet==NULL)
    {
        return false;
    }

    if(p_packet->b_is_tcp)
    {
        p_session->b_src_is_ser  = true;
        return qqfile_text_identify(p_session,p_packet);
    }
    // 用端口判断是否是qqfile协议
    if(ntohs(p_session->srcport) == QQUDPDEFINEPORT)
    {
        return false;
    }
    else if(ntohs(p_session->dstport) == QQUDPDEFINEPORT)
    {
        // 协议识别的方向 --- 需要判断方向
        p_session->b_src_is_ser = false;
        return qqfile_text_identify(p_session,p_packet);
    }
    return false;
}

bool qqfile_udp::qqfile_text_identify(session * p_session, c_packet * p_packet)
{
    uint16_t len = p_packet->app_data_len;
    if(len < 7)
    {
        return false;
    }

    char * p_data =(char *)p_packet -> p_app_data;
    if(p_data == NULL)
        return false;

    // 第一个包 判断是否不是 以 0x04 0x36 0x07 开头
    // 判断是否是 第五个
    time_state = *((uint16_t*)(&p_data[1]));
    if(p_data[0]==0x04 && p_data[5]==0x0&&p_data[6]<0x04)
    {
        //取长度 
        uint16_t dmmlen = ntohs(*(short *)(p_data+3));
        // 判断长度
        if(dmmlen > 0x0F00 )  return false;
        if(dmmlen < 21)  return false ;
        if(dmmlen > len )   return true;
        if(dmmlen == len ) return true;
        if(len > dmmlen+21)
        {
            p_data += dmmlen ;

            if(p_data[0]==0x04 && *((uint16_t*)((&p_data[1]))) == time_state &&p_data[5]==0x0&&p_data[6]<0x04)
            {
                uint16_t dmmlen2 = ntohs(*(short *)(p_data+3));
                if(dmmlen2 > 0x0F00 )  return false;
                if(dmmlen2 < 21)  return false ;
                return true;
            }
        }
        return true;
    }
    return false;
}

void qqfile_udp::potocol_sign_judge(session * p_session , c_packet * p_packet)
{
    if(p_packet == NULL)
    {
        return;
    }

    uint16_t len = p_packet->app_data_len;
    if(len == 0)
    {
        return ;
    }

    char * p_data =(char *)p_packet -> p_app_data;
    if(p_data == NULL)
    {
        return;
    }
    uint32_t seq =  1;
    p_session->client.add_tcp_packet(len, p_data, seq);
    SET_EXPORT(p_session);
    //    SET_SESSION_OVER(p_session);
}

void qqfile_udp::pococol_parse_handle(session * p_session)
{
    if(p_session == NULL)
        return;

    parse_len = 0;
    char buffer[65535]; // 处理中间缓存区
    int buflen = 0;
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    p_qqfile_session->p_data = p_session->client.get_tcp_data(p_qqfile_session->len);
    if(p_qqfile_session->p_data==NULL || p_qqfile_session->len==0)
    {
        return;
    }

    p_qqfile_session->p_data = p_session->client.get_tcp_data(p_qqfile_session->len);

    if(p_qqfile_session->tmpbuf != NULL && p_qqfile_session->tmplen > 0 && p_qqfile_session->tmplen+p_qqfile_session->len<65535)
    {
        // 数据重组 
        memcpy(buffer,p_qqfile_session->tmpbuf,p_qqfile_session->tmplen);
        buflen = p_qqfile_session->tmplen;

        memcpy(buffer + buflen , p_qqfile_session->p_data ,p_qqfile_session->len);
        buflen += p_qqfile_session->len;
        p_qqfile_session->p_data = buffer;
        p_qqfile_session->len = buflen;
        p_qqfile_session->tmplen = 0 ;
        if(p_qqfile_session->tmpbuf != NULL)
        {
            delete [] p_qqfile_session->tmpbuf;
        }
        p_qqfile_session->tmpbuf = NULL;
    }

    // 判断是有开头
    m_buf.m_SetData(p_qqfile_session->len , (unsigned char *)p_qqfile_session->p_data);
    // 0x4 
    for(;m_buf.m_GetLen() > 21; )
    {
        tmpbuf.m_SetData(1,m_buf );
        if(tmpbuf.m_GetByte()!= 0x04)
        {
            return ;
        }
        tmpbuf.m_SetData(2,m_buf );
        tmpbuf.m_SetData(2,m_buf );
        uint16_t dmmlen = tmpbuf.m_GetNamberInt16N();
        if(dmmlen <= m_buf.m_GetLen()+5)
        {
            // 取类型
            tmpbuf.m_SetData(2, m_buf);
            bool b_do = false ;
            if(tmpbuf.m_GetNamberInt16N() == 0x03 )
            {
                b_do = true;
            }
            // 消息处理 
            analyzer_buff ddmbuf;
            if(dmmlen > 7)
            {
                ddmbuf.m_SetData(dmmlen - 7 , m_buf);
                if(b_do)
                {
                    qqfile_ddm_parse(p_session,p_qqfile_session,ddmbuf);
                }
            }
            else
            {
                p_session->client.clear_buf();
                return;
            }
        }
        else
        {
            // 消息不全 ， 回滚
            m_buf.m_Rollback(5);
            break;
        }
    }
    if(m_buf.m_GetLen() > 0 && m_buf.m_GetLen()<1024*1024*100)
    {
        //保存到tmpbuf
        p_qqfile_session->tmpbuf = (uint8_t *)new char [m_buf.m_GetLen()];
        memcpy(p_qqfile_session->tmpbuf,m_buf.m_GetData(),m_buf.m_GetLen());

        p_qqfile_session->tmplen = m_buf.m_GetLen();
    }
    if(parse_len > 0 && parse_len<65536)
    {
        p_session->p_send_buf = parse_buf;
        p_session->send_len = parse_len;
    }
    p_session->client.clear_buf();
}

bool qqfile_udp::qqfile_ddm_parse(session * p_session ,qqfile_session * p_qqfile_session , analyzer_buff & ddlbuf)
{
    // QQ 号码
    tmpbuf.m_SetData(2, ddlbuf);
    tmpbuf.m_SetData(4, ddlbuf);
    if(p_qqfile_session ->send_qq  == 0)
    {
        p_qqfile_session ->send_qq  = (uint64_t)tmpbuf.m_GetNamberInt32N();
        //printf("send QQ is %d\n",p_qqfile_session ->send_qq );
    }

    if(ddlbuf.m_GetLen() >= 30)
    {
        tmpbuf.m_SetData(30, ddlbuf); // 跳过长度  36
    }
    else
    {
        return true;
    }
    if(p_qqfile_session->file_name->size() > 0) // 判断文件名是否存在
    {
        tmpbuf.m_SetData(2, ddlbuf);
        tmpbuf.m_SetData(4, ddlbuf);
        if(tmpbuf.m_GetNamberInt32N() == 0)
        {
            p_qqfile_session->b_send_file = true;
            // 写数据
            if(ddlbuf.m_GetLen()<2 || ddlbuf.m_getpData()==NULL || parse_len+ddlbuf.m_GetLen()-1>65536)
            {
                return true;
            }

            memcpy(parse_buf + parse_len , ddlbuf.m_getpData(), ddlbuf.m_GetLen() -1);
            parse_len += ddlbuf.m_GetLen() -1;
            /*    if(ddlbuf.m_GetLen() -1 < 1000)
                  {
                  p_qqfile_session->b_end  =  true;
                  }*/
        }
        return true;
    }
    else if(ddlbuf.m_GetLen() == 560){
        // 找用户名
        tmpbuf.m_SetData(9, ddlbuf);
        tmpbuf.m_SetData(2, ddlbuf);
        if(tmpbuf.m_GetNamberInt16N() == 0x3e8)
        {
            CODEENC charactercode = CUNC;
            tmpbuf.m_SetData(400,ddlbuf);
            *p_qqfile_session->file_name = tmpbuf.m_GetData( &charactercode);
            //printf("%s\n",p_qqfile_session->file_name->c_str());
            return true;
        }
    }
    else {
        /*
           if(p_qqfile_session->file_name->size() > 0 || p_qqfile_session->b_send_file) 
           {
           p_qqfile_session->b_end  =  true;
           }
           */
    }
    return true;
}


