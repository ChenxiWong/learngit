// Last Update:2015-06-22 13:31:52
/**
 * @file qqfile_plugin.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */

#ifndef __ANALYZER_BUF__
#define __ANALYZER_BUF__
#include <string>
#include <stdio.h>
#include <arpa/inet.h>
#include <list>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <map>
#include <assert.h>
#include <sstream>
#include <iconv.h>
using namespace std;
#define DNUMTOSTR(n,s) \
	{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }
#define DNUMTOSTRFOLAT(n,s,i) \
	{  std::stringstream ss; \
    ss.precision(i); \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear();  }
#define BYTESWAP(C1,C2) \
{	char c = C1;\
	C1= C2; \
	C2= c; \
}
enum CODEENC{
	CUTF8  = 0 ,
	CUNC ,
	CGBK  ,
	ISO_8859_1 , 

	UNKNOWN = 65535
};
#define MAXCACHEBUFRES 1024*1024*24


#define LITENDIAN 1
#define BIGENDIAN 2
#define UNKOWNENDIAN 2
class convert_charset {
    public:
        convert_charset();
        ~convert_charset();
      // void convert((char *) m_pData, m_len, m_tmp, tmplen, "GBK", "UTF8");
       void convert(char * src ,unsigned  int &src_len, char * dst,  int &len, string src_char, string dst_char);
    private:
        void conv_open(string src_char ,string dst_char);
        string src_charset;
        string dst_charset;
        iconv_t cd;
};
typedef unsigned char byte;
static const std::string SPLITESTR = "^&^";
class analyzer_buff {
	public:
		analyzer_buff();
		analyzer_buff(unsigned int len);
		analyzer_buff(unsigned int len, unsigned char * data);
		~analyzer_buff();
		void m_SetLen(int len);
		bool m_SetData(int len, unsigned char * data);
		unsigned int m_GetLen();
		bool m_SetData(unsigned char * data);
		bool m_RebackData(int n);
		bool m_SetData(analyzer_buff &buf);
		bool m_SetData(int len, analyzer_buff &buf);
		void m_FormatStr();
		analyzer_buff &operator =(analyzer_buff & value);
		const char * m_GetData();
		const char * m_GetData(CODEENC* charactercode);
		unsigned char * m_getpData();
        void  m_Rollback(int len)
        {
            if(m_pData != NULL && m_len  != 0) 
            {
                m_pData -= len ;
                m_len += len ;
            }
        };
		byte m_GetByte();
		uint16_t m_GetNamberInt16H();
		const uint16_t m_GetNamberInt16N();
		uint64_t m_GetNamberInt48H();
		uint64_t m_GetNamberInt48N();
		uint32_t m_GetNamberInt32H();
		uint32_t m_GetNamberInt32N();
		uint64_t m_GetNamberInt64H();
		uint64_t m_GetNamberInt64N();
		uint64_t m_GetNamberInt(int iEndian);

		float m_GetNamberfloatH();
		float m_GetNamberfloatN();
		double m_GetNamberdoubleH();
		double m_GetNamberdoubleN();
		void m_BufOffist(unsigned int n);
		void StrLength();
	private:
		unsigned int m_len;
		unsigned char * m_pData;
		// char * m_tmp;
		std::string m_stmp;
		void  m_ReplaceAll(char * pdata , const char * old_value,const char * new_value, int len );
		std::string& m_ReplaceAll(std::string& str, const std::string& old_value,
					const std::string& new_value);
		int EncUnicodeToUtf8One(unsigned long unic, unsigned char *pOutput,int outSize); 
		int EncUnicodeToUtf8(unsigned char * inbuf , int inlen ,unsigned  char * outbuf , int outlen );
        char *m_tmp ;
};

CODEENC ZhCNcode(const char * src, int len);
#endif

