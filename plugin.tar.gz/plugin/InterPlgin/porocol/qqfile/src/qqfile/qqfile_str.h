// Last Update:2015-05-29 11:35:09
/**
 * @file qqfile_str.h
 * @brief qqfile Session 定义
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-27
 */

#ifndef QQFILE_STR_H
#define QQFILE_STR_H

#include <session.h>
#include <stdint.h>
#include <string> 
#include <list> 
using namespace std;
static char NO_NULL[1]= {0x0};
class qqfile_session
{
    public:
       uint64_t requst_time;
       uint64_t response_time;
       uint64_t  send_qq;
       uint64_t  recv_qq;
       uint32_t file_id;
       string   *file_name;
  //     string   *passwd;
       uint8_t *tmpbuf;
       uint32_t tmplen;
       uint32_t  len;
       char *  p_data;
       bool b_c2s; // 方向判断，是不是C -> s
       bool b_tcp; // 是不是TCP 的数据
       bool b_send_file;
       bool b_end;
};

#endif  /*qqfile_STR_H*/
