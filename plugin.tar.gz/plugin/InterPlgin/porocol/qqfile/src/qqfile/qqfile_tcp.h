// Last Update:2015-06-22 13:10:16
/**
 * @file qqfile_tcp.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */

#ifndef QQFILE_TCP_H
#define QQFILE_TCP_H
#include "qqfile_str.h"
#include "analyzer_buf.h"
using namespace std;
class qqfile_tcp 
{
    public:
        qqfile_tcp();
        ~qqfile_tcp();
        bool potocol_identify(session * p_session, c_packet * p_packet);
        void potocol_sign_judge(session * p_session, c_packet * p_packet);
        void pococol_parse_handle(session * p_session);
    private :
        bool qqfile_ddm_parse(session * p_session,qqfile_session *p_qqfile_session ,analyzer_buff & ddlbuf );
        bool qqfile_text_identify(session * p_session, c_packet * p_packet);
        //analyzer_buff tmpbuf;
        analyzer_buff m_buf;
        char parse_buf[65536];
        uint32_t parse_len ; 
};

#endif  /*QQFILE_TCP_H*/
