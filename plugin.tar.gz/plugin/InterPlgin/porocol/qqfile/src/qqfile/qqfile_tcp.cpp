// Last Update:2015-07-23 22:30:12
/**
 * @file qqfile_tcp.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */
#include "qqfile_tcp.h"
#define QQTCPDEFINEPORT 443
qqfile_tcp::qqfile_tcp()
{
    memset(parse_buf, 0, sizeof(char)*65536);
}
qqfile_tcp::~qqfile_tcp()
{
}
bool qqfile_tcp::potocol_identify(session * p_session, c_packet * p_packet)
{

    if(!p_packet->b_is_tcp)
    {
        return false;
    }
    // 用端口判断是否是qqfile协议
    if(ntohs(p_session->srcport) == QQTCPDEFINEPORT)
    {
        p_session->b_src_is_ser  = true;
        //qqfile potocol_identify 
        return qqfile_text_identify(p_session,p_packet);
    }
    else if(ntohs(p_session->dstport) == QQTCPDEFINEPORT)
    {
        // 协议识别的方向 --- 需要判断方向
        p_session->b_src_is_ser = false;
        return qqfile_text_identify(p_session,p_packet);
    }
    return false;
}

bool qqfile_tcp::qqfile_text_identify(session * p_session, c_packet * p_packet)
{
    uint16_t len = p_packet->app_data_len;
    if(len < 7)
        return false;

    char * p_data =(char *)p_packet -> p_app_data;
    if(p_data == NULL)
        return false;

    // 第一个包 判断是否不是 以 0x04 0x36 0x07 开头
    // 判断是否是 第五个

    uint16_t  time_state = *((uint16_t*)(&p_data[1]));
    if(p_data[0]==0x04 &&p_data[5]==0x0&&p_data[6]<0x04)
    {
        //取长度
        uint16_t dmmlen = ntohs(*(short *)(p_data+3));
        // 判断长度
        if(dmmlen > 0x0F00 )  return false;
        if(dmmlen < 21)  return false ;
        if(dmmlen > len )   return true;
        if(dmmlen == len ) return true;
        if( len > dmmlen+21)
        {
            p_data += dmmlen ;
            if(p_data[0]==0x04 && *((uint16_t*)((&p_data[1]))) == time_state&&p_data[5]==0x0&&p_data[6]<0x04)
            {
                uint16_t dmmlen2 = ntohs(*(short *)(p_data+3));
                if(dmmlen2 > 0x0F00 )  return false;
                if(dmmlen2 < 21)  return false ;
                return true;

            }

        }
        return true;

    }
    return false;
    // seq 判断 

}
void qqfile_tcp::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session==NULL || p_packet==NULL)
        return;

    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    // 连接 去除
    if(!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }
    // 连接 去除
    if(p_packet->p_tcphdr->fin == 1)
    {
        p_qqfile_session->b_end  =  true;
        SET_EXPORT(p_session);
        /*if(p_session->client.get_data_len()  || p_session->server.get_data_len())
          {
          SET_EXPORT(p_session);
          }*/
        SET_SESSION_OVER(p_session);
        return;
    }

    if((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) ||
            (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port() ) )
    {
        p_qqfile_session->b_c2s = false;
    }
    else
    {
        p_qqfile_session->b_c2s = true;
    }

    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len;

    if(len == 0)
        return;

    char * p_data =(char *)p_packet -> p_app_data;
    // seq 判断
    if(p_qqfile_session->b_c2s) // 目标是server ，数据是 client的
    {
        if(p_qqfile_session->requst_time == 0 )
            p_qqfile_session->requst_time = p_session ->packet_time;
        p_session->client.add_tcp_packet(len, p_data, seq);
        //判断包是否连续
        p_qqfile_session->p_data = p_session->client.get_tcp_data(p_qqfile_session->len);
        if(p_qqfile_session->len +1520> MAXTCPBUF)
        {
            SET_EXPORT(p_session);
            return;
        }
    }
    else
    {
        // 不处理回复的数据
    }

    return;
}


void qqfile_tcp::pococol_parse_handle(session * p_session)
{
    if(p_session == NULL)
        return;

    parse_len = 0;
    char buffer[100000]; // 处理中间缓存区
    int buflen = 0;
    uint16_t dmmlen = 0;
    analyzer_buff tmpbuf;
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    if(p_qqfile_session->p_data==NULL || p_qqfile_session->len==0)
    {
        if(p_qqfile_session->b_end  ==  true)
        {
            p_session->p_send_buf = NO_NULL;
            p_session->send_len = 1;
        }
        p_session->client.clear_buf();
        return;
    }
    if(p_qqfile_session->b_c2s)
    {
        p_qqfile_session->p_data= p_session->client.get_tcp_data(p_qqfile_session->len);

        if(p_qqfile_session->tmpbuf != NULL && p_qqfile_session->tmplen > 0 && p_qqfile_session->tmplen+ p_qqfile_session->len<100000)
        {
            // 数据重组
            memcpy(buffer,p_qqfile_session->tmpbuf,p_qqfile_session->tmplen);
            buflen = p_qqfile_session->tmplen;
            // 
            memcpy(buffer + buflen , p_qqfile_session->p_data ,p_qqfile_session->len);
            buflen += p_qqfile_session->len;
            p_qqfile_session->p_data = buffer;
            p_qqfile_session->len = buflen;
            p_qqfile_session->tmplen = 0 ;
            if(p_qqfile_session->tmpbuf != NULL)
                delete [] p_qqfile_session->tmpbuf;
            p_qqfile_session->tmpbuf = NULL;
        }

        // 判断是有开头
        m_buf.m_SetData(p_qqfile_session->len , (unsigned char *)p_qqfile_session->p_data);
        // 0x4 
        for(;m_buf.m_GetLen() > 21; )
        {
            tmpbuf.m_SetData(1,m_buf );
            if(tmpbuf.m_GetByte()!= 0x04)
            {
                if(p_qqfile_session->b_end  ==  true)
                {
                    p_session->p_send_buf = NO_NULL;
                    p_session->send_len = 1;
                }
                p_session->client.clear_buf();
                return ;
            }
            tmpbuf.m_SetData(2,m_buf );
          /*  if(tmpbuf.m_GetNamberInt16H() != time_state)
            {
                if(p_qqfile_session->b_end  ==  true) 
                {
                    p_session->p_send_buf = NO_NULL;
                    p_session->send_len = 1;
                }
                p_session->client.clear_buf();
                return ;
            }*/
            tmpbuf.m_SetData(2,m_buf );
            dmmlen =  0;
            dmmlen = tmpbuf.m_GetNamberInt16N();
           // printf("dmmlen = %d ,  m_buf.m_GetLen() = %d \n", dmmlen,  m_buf.m_GetLen());
            if(dmmlen <= m_buf.m_GetLen() +5)
            {
                // 取类型
                tmpbuf.m_SetData(2, m_buf);
                bool b_do = false ;
                if(tmpbuf.m_GetNamberInt16N() == 0x03 )
                {
                    b_do = true;
                }
                // 消息处理
                analyzer_buff ddmbuf;
                if(dmmlen < 7)
                {
                    p_session->client.clear_buf();
                    return;
                }
                ddmbuf.m_SetData(dmmlen - 7 , m_buf);
                if(b_do)
                {
                    qqfile_ddm_parse(p_session,p_qqfile_session,ddmbuf);
                }

            }
            else {
                // 消息不全 ， 回滚
                m_buf.m_Rollback(5);
                break;
            }
        }
        uint16_t m_buf_len = m_buf.m_GetLen();
        if(m_buf_len > 0 && m_buf_len<1024*1024*100)
        {
            //保存到tmpbuf
            p_qqfile_session->tmpbuf = (uint8_t *)new char [m_buf_len];
            memcpy(p_qqfile_session->tmpbuf,m_buf.m_getpData(),m_buf_len);

            p_qqfile_session->tmplen = m_buf_len;
        }
        if(parse_len > 0 && parse_len<65536)
        {
            p_session->p_send_buf = parse_buf;
            p_session->send_len = parse_len;
        }
    }
    if(p_qqfile_session->b_end  ==  true)
    {
        p_session->p_send_buf = NO_NULL;
        p_session->send_len = 1;
    }
    p_session->client.clear_buf();
}

bool qqfile_tcp::qqfile_ddm_parse(session * p_session ,qqfile_session * p_qqfile_session , analyzer_buff & ddlbuf)
{
    // QQ 号码
    analyzer_buff tmpbuf;
    tmpbuf.m_SetData(2, ddlbuf);
    tmpbuf.m_SetData(4, ddlbuf);
    //tmpbuf.m_SetData(4, ddlbuf);
    if(p_qqfile_session ->send_qq  == 0)
        p_qqfile_session ->send_qq  = (uint64_t)tmpbuf.m_GetNamberInt32N();

    if(ddlbuf.m_GetLen() >= 34)
        tmpbuf.m_SetData(34, ddlbuf); // 跳过长度  36
    else
        return true;
    if(p_qqfile_session->file_name->size() > 0) // 判断文件名是否存在
    {
        tmpbuf.m_SetData(2, ddlbuf);
        tmpbuf.m_SetData(4, ddlbuf);
        if(tmpbuf.m_GetNamberInt32N() == 0)
        {
            p_qqfile_session->b_send_file = true;
            // 写数据
            if(ddlbuf.m_GetLen()>1 && ddlbuf.m_getpData()!=NULL && parse_len + ddlbuf.m_GetLen()-1<65536)
            {
                memcpy(parse_buf + parse_len , ddlbuf.m_getpData(),ddlbuf.m_GetLen() -1);
                parse_len += ddlbuf.m_GetLen() -1;
            }
        }
        return true;
    }
    else if(ddlbuf.m_GetLen() == 560){
        // 找用户名
        tmpbuf.m_SetData(9, ddlbuf);
        tmpbuf.m_SetData(2, ddlbuf);
        if(tmpbuf.m_GetNamberInt16N() == 0x3e8)
        {
            tmpbuf.m_SetData(400,ddlbuf);
            CODEENC charactercode = CUNC;
            *p_qqfile_session->file_name = tmpbuf.m_GetData( &charactercode);
            //printf("***********%s\n",p_qqfile_session->file_name ->c_str());
        }
        return true;
    }
    /*
    if(p_qqfile_session->file_name->size() > 0 || p_qqfile_session->b_send_file) 
    {
        // p_qqfile_session->b_end  =  true;
    }*/
    return true;
}



