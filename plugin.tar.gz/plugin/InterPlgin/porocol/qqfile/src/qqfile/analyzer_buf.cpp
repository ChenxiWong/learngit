// Last Update:2015-06-24 14:44:21
/**
 * @file qqfile_plugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */

#include "analyzer_buf.h"
#define H5 0x1F
#define L3 0xE0
#define MAXTMPBUFLEN  65535


convert_charset::convert_charset()
{
    src_charset ="";
    dst_charset = "";
    cd = 0;
}

convert_charset::~convert_charset()
{
    if(cd != 0 )
        iconv_close(cd);
}
void convert_charset::conv_open(string  src_char ,string  dst_char)
{
    if(src_charset == src_char && dst_charset == dst_char) 
    {
        return ;
    }
    else {
        if(src_charset.length() > 0) 
        {
            iconv_close(cd);
            cd = 0;
        }
         cd = iconv_open( dst_char.c_str(), src_char.c_str());
         src_charset = src_char;
         dst_charset = dst_char;
    }
}
void convert_charset::convert(char *src ,unsigned int &src_len, char * dst, int &len, string  src_char, string dst_char)
{
    // 
    conv_open(src_char,dst_char);
    if ((iconv_t)-1 == cd)
    {
        len = 0;
        return ;
    }
    
    iconv(cd, &src, (size_t*)&src_len, &dst, (size_t*)&len); /* 执行转换 */

}

analyzer_buff::analyzer_buff()
{
	m_len = 0;
    m_pData = NULL;
    m_tmp = NULL;
}
//char [1024 * 1024];
analyzer_buff::analyzer_buff(unsigned int len) {
	m_len = len;
    m_tmp = NULL;
}
analyzer_buff::analyzer_buff(unsigned int len, unsigned char * data) {
	m_len = len;
	m_pData = data;
    m_tmp = NULL;
}
bool analyzer_buff::m_SetData(unsigned char * data) {
	m_pData = data;
	return true;
}
bool analyzer_buff::m_RebackData(int n) {
	m_len += n;
	m_pData -= n;
	return true;
}
analyzer_buff::~analyzer_buff() {

            if(m_tmp != NULL)
                delete [] m_tmp ;
            m_tmp = NULL;
}
void analyzer_buff::m_FormatStr() {
	while (*m_pData == 0x0 && m_len > 0) {
		m_pData++;
		m_len--;
	}
}

void analyzer_buff::m_SetLen(int len) {
	m_len = (unsigned int) len;
}
unsigned int analyzer_buff::m_GetLen() {
	return m_len;
}
bool analyzer_buff::m_SetData(int len, unsigned char * data) {
	m_len = len;
	m_pData = data;
	return true;
}
convert_charset cv;
const char * analyzer_buff::m_GetData() {
    if(m_tmp == NULL)
    {
	    m_tmp = new char[MAXTMPBUFLEN];
    }
	int tmplen = MAXTMPBUFLEN;
	CODEENC code = ZhCNcode((const char *) m_pData, m_len);
	if (code == CUTF8) {
		tmplen = m_len;
		memcpy(m_tmp,m_pData,m_len);
	} else if (code == CUNC) {
		cv.convert((char *) m_pData, m_len, m_tmp, tmplen, "UNICODE", "UTF8");
		//tmplen = EncUnicodeToUtf8(m_pData, m_len,(unsigned char *)m_tmp, tmplen);
	} else if (CGBK == code) {
		cv.convert((char *) m_pData, m_len, m_tmp, tmplen, string("GBK"), string("UTF8"));
	}
	m_tmp[tmplen] =0x0;
	m_ReplaceAll(m_tmp, "\r\n", "  ",2);
	return ( const char *)m_tmp;
}
void analyzer_buff::StrLength()
{
	if(m_pData !=NULL && m_len > 0)
	{
		uint32_t len = strlen((const char*)m_pData);
		if(len < m_len)
			m_len = len;
	}
}
const char * analyzer_buff::m_GetData(CODEENC *charactercode) {
	int code = *charactercode;
    if(m_tmp == NULL)
    {
	    m_tmp = new char[MAXTMPBUFLEN];
    }
	int tmplen = MAXTMPBUFLEN;
	if (code == 65535) {
		code = ZhCNcode((const char *) m_pData, m_len);
	}
	if (code == CUTF8 || ISO_8859_1 == code) {
		tmplen = m_len;
		memcpy(m_tmp,m_pData,m_len);
	} else if (code == CUNC) {
		//tmplen = EncUnicodeToUtf8(m_pData, m_len,(unsigned char *)m_tmp, tmplen);
		cv.convert((char *) m_pData, m_len, m_tmp, tmplen, "UNICODE", "UTF8");

	} else if (CGBK == code  ) {
		cv.convert((char *) m_pData, m_len, m_tmp, tmplen, "GBK", "UTF8");
	}
	m_tmp[tmplen] =0x0;
	//m_ReplaceAll(m_tmp, "\r\n", "  ",2);
	return ( const char *)m_tmp;
}

uint16_t analyzer_buff::m_GetNamberInt16H() {
	uint16_t * siTemp = (uint16_t *) m_pData;
	return *siTemp;
}
const uint16_t analyzer_buff::m_GetNamberInt16N() {
	uint16_t * siTemp = (uint16_t *) m_pData;
	uint16_t s = ntohs(*siTemp);
    return s;
}
uint32_t analyzer_buff::m_GetNamberInt32H() {
	int * iTemp = (int *) m_pData;
	return *iTemp;
}
uint32_t analyzer_buff::m_GetNamberInt32N() {
	int * iTemp = (int *) m_pData;
	return ntohl(*iTemp);
}
uint64_t analyzer_buff::m_GetNamberInt64H() {
	return  *(uint64_t *) (m_pData);
}
uint64_t analyzer_buff::m_GetNamberInt64N() {
	uint64_t iTemp1 = (uint64_t) ntohl(*(uint32_t *) (m_pData));
	uint64_t iTemp2 = (uint64_t) ntohl(*(uint32_t *) (m_pData + 4));
	return iTemp1 * 0xffffffff + iTemp1 + iTemp2;
}
uint64_t analyzer_buff::m_GetNamberInt48H()
{
	uint64_t iTemp1 = (uint64_t ) (*(uint32_t *)m_pData);
	uint64_t iTemp2 = (uint64_t) (*(uint16_t *) (m_pData + 4));
	return iTemp2 * 0xffffffff + iTemp2 + iTemp1;
}
uint64_t analyzer_buff::m_GetNamberInt48N()
{
	uint64_t iTemp1 = (uint64_t) ntohl(*(uint32_t *) (m_pData));
	uint64_t iTemp2 = (uint64_t) ntohs(*(uint16_t *) (m_pData + 4));
	return iTemp1 * 0xffff + iTemp1 + iTemp2;
}
uint64_t analyzer_buff::m_GetNamberInt(int iEndian){
	if(iEndian == LITENDIAN )
	{
		switch(m_len)
		{
			case 1:
				return (uint64_t)m_GetByte();
			case 2:
				return (uint64_t)m_GetNamberInt16N();
			case 4:
				return (uint64_t)m_GetNamberInt32N();
			case 6:
				return (uint64_t)m_GetNamberInt48N();
			case 8:
				return m_GetNamberInt64N();
			case 9:
				m_pData ++;
				return m_GetNamberInt64N();
			default:
				return 0;
		}
	}
	else if(iEndian == BIGENDIAN){
		switch(m_len)
		{
			case 1:
				return (uint64_t)m_GetByte();
			case 2:
				return (uint64_t)m_GetNamberInt16H();
			case 4:
				return (uint64_t)m_GetNamberInt32H();
			case 6:
				return (uint64_t)m_GetNamberInt48H();
			case 8:
				return m_GetNamberInt64H();
			case 9:
				m_pData ++;
				return m_GetNamberInt64H();
			default:
				return 0;
		}
	}
	return 0;
}
bool analyzer_buff::m_SetData(analyzer_buff &buf) {
	if (m_len > buf.m_len)
	  return false;
	m_SetData(buf.m_pData);
	buf.m_BufOffist(m_len);
	return true;
}
void analyzer_buff::m_BufOffist(unsigned int n) {
	this->m_pData += n;
	this->m_len -= n;
}

bool analyzer_buff::m_SetData(int len, analyzer_buff &buf) {
	if (len > buf.m_len)
	  return false;
	m_len = len;
	m_SetData(buf.m_pData);
	buf.m_BufOffist(m_len);
	return true;
}
float analyzer_buff::m_GetNamberfloatN() {
	// 交换 值
	BYTESWAP(m_pData[0],m_pData[3]);	
	BYTESWAP(m_pData[1],m_pData[2]);
	return *(float *) m_pData;	

}
float analyzer_buff::m_GetNamberfloatH() {
	return *(float *) m_pData;
}
double analyzer_buff::m_GetNamberdoubleN() {
	BYTESWAP(m_pData[0],m_pData[7]);	
	BYTESWAP(m_pData[1],m_pData[6]);	
	BYTESWAP(m_pData[2],m_pData[5]);	
	BYTESWAP(m_pData[3],m_pData[4]);	
	return *(double *) m_pData;
}
double analyzer_buff::m_GetNamberdoubleH() {
	return *(double *) m_pData;
}

CODEENC ZhCNcode(const char * src, int len) {
	int sig = 3;
	char iscode[] = { 1, 1, 1, 0x0 }; // 1 ==
	int i = 0;
	unsigned char * p = (unsigned char *) src;
	unsigned short pSh;
	unsigned char * pData = (unsigned char *) &pSh;
	//uncode
	for (i = 0; i < len;) {
		if (*p == 0x0)
		  return CUNC;
		if (i + 1 < len && *p == 0xff && *(p + 1) == 0xfe)
		  return CUNC;
		if (false) {
		} else {
			//unicode 汉字范围是 0x4E00 ~ 0x9FBF
			if (*p < 128) {
				if (i + 1 < len && *(p + 1) == 0x0) {
					return CUNC;
				}
			}

			pData[0] = *(p + 1);
			pData[1] = *p;
			if (iscode[CUNC] != 0
						&& ((pSh >= 0x3400 && pSh <= 0x4DB5) || (pSh >= 0x4E00 && pSh <= 0x9FBB)
							|| (pSh >= 0xF900 && pSh <= 0xFA2D) || (pSh >= 0xFA30 && pSh <= 0xFA6A)
							|| (pSh >= 0xFA70 && pSh <= 0xFAD9) || (pSh >= 0xFE00 && pSh <= 0xFFFE))) {
			} else {
				iscode[CUNC] = 0x0;
				sig--;
				break;
			}
			i += 2;
			p++;
			p++;
		}
	}
	int wlen = 0;
	p = (unsigned char *) src;
	bool sUtf8 = false;
	bool bT = true;
	int cnum = 0;
	for (i = 0; i < len;) {
		if (wlen != 0) {
			if (*p < 0x80 || *p >= 0xC0) {
				iscode[CUTF8] = 0;
				sig--;
				sUtf8 = false;
			}
			i++;
			wlen--;
			p++;
			continue;
		}
		if (sUtf8)
		  return CUTF8;
		if (*p >= 0xF8) // 5位不存在
		{
			iscode[CUTF8] = 0;
			sig--;
			break;
		}
		if (*p >= 0xF0) {
			bT = true;
			wlen = 3;
		} else if (*p >= 0xE0) {
			bT = true;
			wlen = 2;
		} else if (*p >= 0xC0) {

			cnum++;
			if (cnum > 2)
			  bT = true;
			else
			  bT = false;
			wlen = 1;
		} else if (*p < 0xA0) {

			wlen = 0;
		} else {
			iscode[CUTF8] = 0;
			sig--;
			break;
		}
		p++;
		i++;
	}
	for (i = 0; i < 3; i++) {
		if (iscode[i] != 0x0) {
			switch (i) {
				case CUTF8:
					if (bT)
					  return CUTF8;
					continue;
				case CUNC:
					return CUNC;
				case CGBK:
					return CGBK;
			}
		}
	}
	return CUTF8;
}
std::string& analyzer_buff::m_ReplaceAll(std::string& str, const std::string& old_value,
			const std::string& new_value) {

	while (true) {
		std::string::size_type pos(0);
		if ((pos = str.find(old_value)) != std::string::npos)
		  str.replace(pos, old_value.length(), new_value);
		else
		  break;
	}
	return str;
}
void  analyzer_buff::m_ReplaceAll(char * pdata , const char * old_value,
			const char * new_value, int len )
{
	//可以认为是字符串
	char * p  = strstr((char *)pdata , (char *)old_value);
	while( p != NULL){
		if(p != NULL)
		{
			strncpy(p,new_value,len);
		}
		p = strstr(p , old_value);
	}
}

analyzer_buff& analyzer_buff::operator =(analyzer_buff & value) {
	m_len = value.m_len;
	m_pData = value.m_pData;
    return *this;
}


unsigned char * analyzer_buff::m_getpData() {
	return m_pData;
}
byte analyzer_buff::m_GetByte() {
	return *m_pData;
}
/*
void  analyzer_buff::CacheDeCodew( char * outbuf , CODEENC charactercode)
{
	m_pInstance =  CSybaseBufferManger::GetInstance();
	char * m_tmp = (char *)m_pInstance->GetBuffer();
	int tmplen = m_pInstance->GetBufferMaxLen();
	if(charactercode == CUNC)
	{
		int len = 0;
		int i = 0;
		for(;i < m_len; i++)
		{
			if(m_pData[i] != 0x0)
			{
				m_tmp[len] = m_pData[i];
				len ++;
			}

		}
		m_pData = (unsigned char *)m_tmp;
		m_len = len;
	}
	//	m_pData = (unsigned char *)m_GetData(&charactercode);
	CacheDeCodew( outbuf );
}
void  analyzer_buff::CacheDeCodew( char * outbuf )
{
	int i = 0 ;
	int inlen = m_len;
	unsigned char *inbuf = m_pData;
	while (inlen > 0 )
	{
		inlen --;
		char C = inbuf[inlen];
		uint32_t LH5 = C & H5 ;
		uint32_t LL3 = C & L3;
		int l1 = (LH5 << 3) ;
		int l2 = (LL3 >> 5);    
		int l = l1 | l2 ;
		l -= inlen; 
		int p1 =l ^ 0xA7;
		outbuf[i]  = (l ^ 0xA7) &0xFF;
		i++; 
	}   
} */ 

/***************************************************************************** 
 * 将一个字符的Unicode(UCS-2和UCS-4)编码转换成UTF-8编码. 
 * 
 * 参数: 
 *    unic     字符的Unicode编码值 
 *    pOutput  指向输出的用于存储UTF8编码值的缓冲区的指针 
 *    outsize  pOutput缓冲的大小 
 * 
 * 返回值: 
 *    返回转换后的字符的UTF8编码所占的字节数, 如果出错则返回 0 . 
 * 
 * 注意: 
 *     1. UTF8没有字节序问题, 但是Unicode有字节序要求; 
 *        字节序分为大端(Big Endian)和小端(Little Endian)两种; 
 *        在Intel处理器中采用小端法表示, 在此采用小端法表示. (低地址存低位) 
 *     2. 请保证 pOutput 缓冲区有最少有 6 字节的空间大小! 
 ****************************************************************************/  
int analyzer_buff::EncUnicodeToUtf8One(unsigned long unic, unsigned char *pOutput,int outSize)
{  
	//   if(pOutput == NULL) return -1;
	//  assert(outSize >= 6);  

	if ( unic <= 0x0000007F )  
	{  
		// * U-00000000 - U-0000007F:  0xxxxxxx  
		*pOutput     = (unic & 0x7F);  
		return 1;  
	}  
	else if ( unic >= 0x00000080 && unic <= 0x000007FF )  
	{  
		// * U-00000080 - U-000007FF:  110xxxxx 10xxxxxx  
		*(pOutput+1) = (unic & 0x3F) | 0x80;  
		*pOutput     = ((unic >> 6) & 0x1F) | 0xC0;  
		return 2;  
	}  
	else if ( unic >= 0x00000800 && unic <= 0x0000FFFF )  
	{  
		// * U-00000800 - U-0000FFFF:  1110xxxx 10xxxxxx 10xxxxxx  
		*(pOutput+2) = (unic & 0x3F) | 0x80;  
		*(pOutput+1) = ((unic >>  6) & 0x3F) | 0x80;  
		*pOutput     = ((unic >> 12) & 0x0F) | 0xE0;  
		return 3;  
	}  
	else if ( unic >= 0x00010000 && unic <= 0x001FFFFF )  
	{  
		// * U-00010000 - U-001FFFFF:  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx  
		*(pOutput+3) = (unic & 0x3F) | 0x80;  
		*(pOutput+2) = ((unic >>  6) & 0x3F) | 0x80;  
		*(pOutput+1) = ((unic >> 12) & 0x3F) | 0x80;  
		*pOutput     = ((unic >> 18) & 0x07) | 0xF0;  
		return 4;  
	}  
	else if ( unic >= 0x00200000 && unic <= 0x03FFFFFF )  
	{  
		// * U-00200000 - U-03FFFFFF:  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  
		*(pOutput+4) = (unic & 0x3F) | 0x80;  
		*(pOutput+3) = ((unic >>  6) & 0x3F) | 0x80;  
		*(pOutput+2) = ((unic >> 12) & 0x3F) | 0x80;  
		*(pOutput+1) = ((unic >> 18) & 0x3F) | 0x80;  
		*pOutput     = ((unic >> 24) & 0x03) | 0xF8;  
		return 5;  
	}  
	else if ( unic >= 0x04000000 && unic <= 0x7FFFFFFF )  
	{  
		// * U-04000000 - U-7FFFFFFF:  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx  
		*(pOutput+5) = (unic & 0x3F) | 0x80;  
		*(pOutput+4) = ((unic >>  6) & 0x3F) | 0x80;  
		*(pOutput+3) = ((unic >> 12) & 0x3F) | 0x80;  
		*(pOutput+2) = ((unic >> 18) & 0x3F) | 0x80;  
		*(pOutput+1) = ((unic >> 24) & 0x3F) | 0x80;  
		*pOutput     = ((unic >> 30) & 0x01) | 0xFC;  
		return 6;  
	}  

	return 0;  
} 
int analyzer_buff::EncUnicodeToUtf8(unsigned char * inbuf , int inlen , unsigned char * outbuf , int outlen )
{
	int i = 0;
	long ust2code = 0;
	int len = 0;
	int sumlen = 0;
	for(;i<inlen && outlen - sumlen > 6; )
	{
		ust2code = (long)*(short*)(&inbuf[i]);
		len =EncUnicodeToUtf8One(ust2code,(unsigned char*)outbuf+sumlen,outlen - sumlen);
		sumlen+=len ;
		i++ ;
		i++;
	}
	return sumlen;
}

