// Last Update:2016-03-24 14:41:34
/**
 * @file qqfile_plugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-27
 */

#include "qqfile_plugin.h"
#include <commit_tools.h>
#include <sys/stat.h>
#include <commit_tools.h>

#define qqfileDEFINEPORT 21

extern "C" {
    int get_plugin_id()
    {
        return 6;
    }
    protocol_parse_base_handle * attach(attach_info * p )
    {
        p_attach_info = p ; 
        return new  qqfile_plugin();
    }
}


qqfile_plugin::qqfile_plugin()
{
    data_interface_type = NETSEND;
    qqfile_time_out = 60;
    row = 0;
    max_time_scr = 1;
    //msg = NULL;
    reload();
}
qqfile_plugin::~qqfile_plugin()
{
}

void qqfile_plugin::reload()
{
        xml_parse  xml;
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/qqfile_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" ) 
        {
            data_interface_type = NETSEND;
        }
    }

    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        qqfile_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if(p_value != NULL)
    {
        max_row = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if(p_value != NULL)
    {
        max_time_scr = atoi(p_value);
    }
}

void qqfile_plugin::init_qqfile_session(qqfile_session * p_qqfile_session)
{
    p_qqfile_session->requst_time = 0;
    p_qqfile_session->response_time = 0;

    p_qqfile_session->p_data = NULL;
    p_qqfile_session->len = 0;

    p_qqfile_session->b_send_file = false ;
    p_qqfile_session->b_end = false;

    if(p_qqfile_session->file_name  == NULL)
    {
        p_qqfile_session->file_name =  new string();
    }
    *(p_qqfile_session->file_name) =  "";

    p_qqfile_session->send_qq = 0;
    p_qqfile_session->recv_qq = 0;

    p_qqfile_session->tmpbuf = NULL;
    p_qqfile_session -> tmplen = 0;


}

bool qqfile_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{

    if(m_qqfile_tcp.potocol_identify(p_session,p_packet)) 
    {
        qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
        init_qqfile_session(p_qqfile_session);
        p_qqfile_session->b_tcp = true;
        return true;
    }
    else if(m_qqfile_udp.potocol_identify(p_session,p_packet)) 
    {
        qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
        init_qqfile_session(p_qqfile_session);
        p_qqfile_session->b_tcp = false;

        return true;
    }
    return false;
}

void qqfile_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    // 连接 去除
    if(p_packet->b_is_tcp  != p_qqfile_session->b_tcp  )
    {
        return;
    }
    if(p_packet->b_is_tcp )
    {
        
        return m_qqfile_tcp.potocol_sign_judge(p_session,p_packet);
        // 连接 去除  
    }
    else {
        return m_qqfile_udp.potocol_sign_judge(p_session,p_packet);

    }

    return;
}

void qqfile_plugin::pococol_parse_handle(session * p_session)
{
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    if(p_qqfile_session->b_tcp )
    {
        m_qqfile_tcp.pococol_parse_handle(p_session);
        // 连接 去除  
    }
    else {
        m_qqfile_udp.pococol_parse_handle(p_session);
    }
    if(p_qqfile_session->b_end ) 
    {
        if(p_session->send_len == 0 || p_session->p_send_buf == NULL)
        {
            p_session->send_len = 1 ;
            p_session->p_send_buf = NO_NULL;
        }

        p_qqfile_session->tmplen = 0;
        p_qqfile_session->tmpbuf = NULL;
    }

    return;
}

void qqfile_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    data_interface m_data ;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
        if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
        {
            m_data.b_out_type = FILESEND;

            string requst_time;
            DNUMTOSTR(p_qqfile_session->requst_time, requst_time);
            struct timeval tv ;
            gettimeofday(&tv, NULL);
            //uint64_t u64_time = tv.tv_sec * 1000000 + tv.tv_sec;

            if(file_path.empty())
            {
                // 文件相对路径
                /*file_path = "/";
                  file_path += get_year_month();
                  file_path += get_day_hour();
                  file_path += get_min_sec();

                  file_name = date_time();
                  file_name += "-";
                  file_name += requst_time;
                  begin_time = u64_time;
                  file_data= "";
                  row = 0;
                  file_str = new w_file_str;
                  */
            }


        }
    }
    else if (data_interface_type == NETSEND)
    {

        if((*p_qqfile_session->file_name).empty() )
            return;

        net_str * p_net =  new  net_str;
        p_net -> msg = new CAmsg;
        // 生成ID 
        if(p_qqfile_session->file_id == 0 )
        {
            string tmp = *p_qqfile_session->file_name ;
            string requst_time;
            DNUMTOSTR(p_qqfile_session->requst_time, requst_time);
            tmp += requst_time;
            p_qqfile_session->file_id = crc32((unsigned char *)tmp.c_str(),tmp.length());
        }
        p_net->msg->Clear();
        // 设置 
        p_net->msg->set_type(7); // qqfile

        qq_file_msg* p_qqfile = p_net->msg->mutable_qq_file();
        Comm_msg* p_comm =  p_qqfile -> mutable_comm_msg();
        // 公共 消息 
        if(p_session -> b_src_is_ser)
        {
            p_comm ->set_src_port(ntohs(p_session->dstport));
            p_comm ->set_dst_ip(p_session->srcip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
        }
        else
        {
            p_comm ->set_src_port(ntohs(p_session->srcport));
            p_comm ->set_dst_ip(p_session->dstip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
        }
        p_comm ->set_time(p_qqfile_session->requst_time);
        //  文件名
        p_qqfile->set_file_name(*p_qqfile_session->file_name);
        //文件ID 
        p_qqfile->set_file_id(p_qqfile_session->file_id);
        // 设置文件 是否结束

        if(p_qqfile_session ->b_end) 
        {
            p_qqfile->set_b_end(true);
            p_attach_info -> p_protocal -> PotocolStatistics(7,1,0,1);
        }
        else {
            p_qqfile->set_b_end(false);
        }
        // 设置解析的协议类型， 1 http 2 tcp 3 udp 
        if(p_qqfile_session->b_tcp) 
            p_qqfile->set_send_type(2);
        else 
            p_qqfile->set_send_type(3);
        // 设置文件内容    
        if(p_session -> send_len == 1 && p_session->p_send_buf==NO_NULL) 
        {
            p_qqfile->set_data(p_session->p_send_buf , 0);
        }
        else {
            p_qqfile->set_data(p_session->p_send_buf , p_session -> send_len);
        }
        //qqsend 
        p_qqfile ->set_send_qq(p_qqfile_session->send_qq);
        //cout << "qq  send qq:" << p_qqfile_session->send_qq << "recv qq" << p_qqfile_session->recv_qq<< endl;
        p_qqfile ->set_recv_qq(p_qqfile_session->recv_qq);
        p_net->datalen = 20 + 4 + p_session -> send_len;

        // 接口 
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }

    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    p_session->client.clear_buf();
}

void qqfile_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > qqfile_time_out *1000000)
    {
        // 开始超时处理
        qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
        p_qqfile_session->b_end  =  true;
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
    // p_session->last_packet_time = check_time;
}

void qqfile_plugin::resources_recovery(session * p_session)
{
    qqfile_session * p_qqfile_session = (qqfile_session *)p_session->expansion_data;
    if(p_qqfile_session -> file_name != NULL)
        delete p_qqfile_session -> file_name;
    if(p_qqfile_session -> tmpbuf != NULL)
        delete [] p_qqfile_session->tmpbuf;
}
