// Last Update:2016-03-08 15:24:40
/**
 * @file ftp_plugin.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-14
 */

#include "ftp_plugin.h"
#include <commit_tools.h>
#include <sys/stat.h>
//#include "shm_statistics.h"

#define FTPDEFINEPORT 21

static unsigned long long* plugin_shmid_ftp = NULL;
static unsigned long long* plugin_shmid_ftp1 = NULL;

extern "C" {
    int get_plugin_id()
    {
        return 4;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p ; 
        return new  ftp_plugin();
    }
}

char * cmd_fetch(char * &data,uint32_t len , ftp_session * p_ftp_session)
{
    if(data==NULL || len < 2)
        return NULL;

    data[len-2] = 0x0; // 去除末尾的/r/n
    char * p_cmd =data ;
    p_ftp_session->p_data = splits_string(p_cmd,0x20);
    if(len >strlen(p_cmd)+1)
    {
        p_ftp_session->len = len -strlen(p_cmd) -1;
        return p_cmd;
    }
    return NULL;
}

ftp_plugin::ftp_plugin()
{
    data_interface_type = FILESEND;
    ftp_time_out = 60;
    row = 0;
    max_row = 9999;
    max_time_scr = 1;
    file_path = "";
    file_name = "";
    //msg = NULL;
    reload();
}
ftp_plugin::~ftp_plugin()
{
}

void ftp_plugin::reload()
{
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/ftp_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" ) 
        {
            data_interface_type = NETSEND;
        }
    }

    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        ftp_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if(p_value != NULL)
    {
        max_row = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if(p_value != NULL)
    {
        max_time_scr = atoi(p_value);
    }
}

void ftp_plugin::init_ftp_session(ftp_session * p_ftp_session)
{
    p_ftp_session->requst_time = 0;
    p_ftp_session->response_time = 0;

    p_ftp_session->p_data = NULL;
    p_ftp_session->len = 0;

    p_ftp_session->is_pwd = false;

    if(p_ftp_session->username  == NULL)
    {
        p_ftp_session->username =  new string();
    }
    *(p_ftp_session->username) =  "";

    if(p_ftp_session->passwd == NULL)
        p_ftp_session->passwd =  new string();
    *(p_ftp_session->passwd )=  "";
}

bool ftp_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(!p_packet->b_is_tcp)
    {
        return false;
    }

    // 用端口判断是否是FTP协议
    if(ntohs(p_session->srcport) == FTPDEFINEPORT)
    {
        p_session->b_src_is_ser  = true;
        ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
        init_ftp_session(p_ftp_session);
        return true;
    }
    else if(ntohs(p_session->dstport) == FTPDEFINEPORT)
    {
        p_session->b_src_is_ser = false;
        ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
        init_ftp_session(p_ftp_session);
        return true;
    }
    return false;
}

void ftp_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session==NULL || p_packet==NULL)
        return;

    ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
    // 连接 去除
    if(!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }
    // 连接 去除  
    if(p_packet->p_tcphdr->fin == 1)
    {
        if(p_session->client.get_data_len() > 0 || p_session->server.get_data_len())
        {
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
        return;
    }

    if((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) ||
            (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port() ) )
    {
        p_ftp_session->b_c2s = false;
    }
    else
    {
        p_ftp_session->b_c2s = true;
    }

    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len;

    if(len == 0)
        return;

    char * p_data =(char *)p_packet -> p_app_data;
    if(p_data == NULL)
        return;

    // seq 判断 
    if(p_ftp_session->b_c2s) // 目标是server  ， 数据是 client的 
    {
        p_ftp_session->requst_time = p_session ->packet_time;
        p_session->client.add_tcp_packet(len, p_data, seq);
        //判断包是否连续
        p_ftp_session->p_data = p_session->client.get_tcp_data(p_ftp_session->len);
        if( p_ftp_session->len > 2 &&
                *(p_ftp_session->p_data + p_ftp_session->len -1) =='\x0a' &&
                *(p_ftp_session->p_data + p_ftp_session->len -2) == '\x0d')
        {
            SET_EXPORT(p_session);
            return;
        }
    }
    else
    {
        p_ftp_session->response_time = p_session->packet_time;
        p_session->server.add_tcp_packet(len, p_data, seq);
        //判断包是否连续
        p_ftp_session->p_data= p_session->server.get_tcp_data(p_ftp_session->len);
        if( p_ftp_session->len > 2 &&
                *(p_ftp_session->p_data + p_ftp_session->len -1) =='\x0a' &&
                *(p_ftp_session->p_data + p_ftp_session->len -2) == '\x0d')
        {
            SET_EXPORT(p_session);
            return;
        }
    }

    return;
}

void ftp_plugin::pococol_parse_handle(session * p_session)
{
    if(p_session == NULL)
        return;

    ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
    if(p_ftp_session->p_data==NULL || p_ftp_session->len==0)
    {
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        return;
    }
    /*if(p_ftp_session->p_data == NULL)
      {
      p_session->client.clear_buf();
      return;
      }*/

    begin_len = p_ftp_session->len;
    begin_data =  p_ftp_session->p_data;
    if(p_ftp_session->b_c2s)
    {
        // 解析数据，提取用户名和密码
        char * p = cmd_fetch(p_ftp_session->p_data, p_ftp_session->len, p_ftp_session);
        if(p == NULL)
        {
            p_session->client.clear_buf();
            return;
        }

        if(p_ftp_session->p_data == NULL)
        {
            p_session->client.clear_buf();
            return;
        }
        string tmp = p;
        if(tmp == "USER")
        {
            *(p_ftp_session->username) = p_ftp_session->p_data;
            if(*(p_ftp_session->username) == "anonymous")
            {
                *(p_ftp_session->username) = "";
                SET_SESSION_OVER(p_session);
            }
        }
        else if(tmp == "PASS")
        {
            if(p_ftp_session->username->empty())
            {
                SET_SESSION_OVER(p_session);
            }
            else
            {
                *(p_ftp_session->passwd) = p_ftp_session->p_data;
                //erase_not_ascii(*p_ftp_session->username);
                //erase_not_ascii(*p_ftp_session->passwd);
                p_ftp_session->is_pwd = true;
                //ftp_counter ftpcnt(&plugin_shmid_ftp, &plugin_shmid_ftp1);
                //ftpcnt.cnt_atomic_operate_add1(1);
            }
        }

        p_session->client.clear_buf();
    }
    else
    {
        if(p_ftp_session->is_pwd)
        {
            if((p_ftp_session->len>=3) && (strncmp(p_ftp_session->p_data , "230 User logged in", 3)==0))
            {
                p_session->send_len = p_ftp_session->len;
                p_session->p_send_buf = (char *)p_ftp_session->p_data;
                p_ftp_session->is_pwd = false;
                p_ftp_session->b_available = 1;
                //ftp_counter ftpcnt(&plugin_shmid_ftp, &plugin_shmid_ftp1);
                //ftpcnt.cnt_atomic_operate_add(1);
            }
            else
            {
                p_session->send_len = p_ftp_session->len;
                p_session->p_send_buf = (char *)p_ftp_session->p_data;
                p_ftp_session->is_pwd = false;
                p_ftp_session->b_available = 0;
            }
        }

        p_session->server.clear_buf();
    }
}

void ftp_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
    data_interface m_data ;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
        if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
        {
            m_data.b_out_type = FILESEND;

            string requst_time;
            DNUMTOSTR(p_ftp_session->requst_time, requst_time);
            struct timeval tv ;
            gettimeofday(&tv, NULL);
            uint64_t u64_time = tv.tv_sec * 100000 + tv.tv_sec;

            if(file_path.empty())
            {
                // 文件相对路径
                file_path = "/";
                file_path += get_year_month();
                file_path += get_day_hour();
                file_path += get_min_sec();

                file_name = date_time();
                file_name += "-";
                file_name += requst_time;
                begin_time = u64_time;
                file_data= "";
                row = 0;
                file_str = new w_file_str;
            }

            file_str->finished = false;
            if(row==max_row || u64_time-begin_time > max_time_scr * 100000) 
            {
                file_str->finished = true;
            }

            string ftp_file_name = file_name;
            ftp_file_name += ".ftp";
            file_str->file_path = file_path;
            file_str->file_name.swap(ftp_file_name);

            // 申请内存存储数据，写文件后自动析构
            {
                if(row > 0)
                    file_data +="\n[ftp]\n";
                else
                    file_data +="[ftp]\n";

                row ++;
                // 拷贝数据 
                requst_time = date_time3(p_ftp_session->requst_time);
                file_data += requst_time;
                file_data += "\n";
                // 用户名和密码 
                file_data += *(p_ftp_session->username);
                file_data += "\n";
                file_data += *(p_ftp_session->passwd);
                file_data += "\n";

                if(p_session -> b_src_is_ser) 
                {
                    // 客户端 IP 
                    file_data += p_session->dstip.ip_str();
                    file_data += ":";
                    string dst_port;
                    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
                    file_data += dst_port;
                    file_data += "\n";
                    // FTP IP
                    file_data += p_session->srcip.ip_str();
                    file_data += ":";
                    string src_port;
                    DNUMTOSTR(ntohs(p_session->srcport), src_port);
                    file_data += src_port;
                    file_data += "\n";
                }
                else
                {
                    // 客户端 IP 
                    file_data += p_session->srcip.ip_str();
                    file_data += ":";
                    string src_port;
                    DNUMTOSTR(ntohs(p_session->srcport), src_port);
                    file_data += src_port;
                    file_data += "\n";
                    // FTP IP
                    file_data += p_session->dstip.ip_str();
                    file_data += ":";
                    string dst_port;
                    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
                    file_data += dst_port;
                    file_data += "\n";
                }

                if(!file_str->finished)
                {
                    if(file_data.length() < 1024*1024 )
                    {
                        return;
                    }
                    else
                    {
                        file_str->finished = true;
                    }
                }

                if(file_str->finished)
                {
                    char * ftp_file_data = new char[file_data.length()+1];
                    strcpy(ftp_file_data,file_data.c_str());
                    file_str->file_data = ftp_file_data;
                    file_str->datalen = file_data.length();
                }
            }

            m_data.data = file_str;
            p_list -> push_back(m_data);
            if(file_str->finished)
            {
                file_path = "";
                file_name = "";
                begin_time = u64_time;
            }
        }
    }
    else if (data_interface_type == NETSEND)
    {
        if((*p_ftp_session->username).empty() || (*p_ftp_session->passwd).empty())
            return;

        net_str * p_net =  new  net_str;
        p_net -> msg = new CAmsg;
        p_net->msg->Clear();
        // 设置 
        p_net->msg->set_type(3); // ftp

        ftp_msg* p_ftp = p_net->msg->mutable_ftp();
        Comm_msg* p_comm =  p_ftp -> mutable_comm_msg();
        // 公共 消息 

        if(p_session -> b_src_is_ser) 
        {
            p_comm ->set_src_port(ntohs(p_session->dstport));
            p_comm ->set_dst_ip(p_session->srcip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->srcport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->dstip.ip_str());
            }
        }
        else
        {
            p_comm ->set_src_port(ntohs(p_session->srcport));
            p_comm ->set_dst_ip(p_session->dstip.ip_str());
            p_comm ->set_dst_port(ntohs(p_session->dstport));
            if(p_session->b_vpn)        //VPN消息
            {
                p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
            }
            else
            {
                p_comm ->set_src_ip(p_session->srcip.ip_str());
            }
        }
        p_comm ->set_time(p_ftp_session->requst_time);
        //  域名 
        string user_name = *p_ftp_session->username;
        string user_pass = *p_ftp_session->passwd;

        p_attach_info -> p_protocal -> PotocolStatistics(3,1,0,1);
        // 去除乱码
        //erase_not_ascii(user_name);
        //erase_not_ascii(user_pass);

        p_ftp->set_username(user_name);
        p_ftp->set_password(user_pass);
        //p_ftp->set_is_valid(p_ftp_session->b_available);
        if (p_ftp_session->b_available)
        {
            p_ftp->set_is_valid(2);
        }
        else
        {
            p_ftp->set_is_valid(1);
        }
        p_net->datalen = 20 + user_name.length() + user_pass.length();
        // 接口 
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }

    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    p_session->client.clear_buf();
    SET_SESSION_OVER(p_session);
}

void ftp_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > ftp_time_out *100000)
    {
        // 开始超时处理
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
}

void ftp_plugin::resources_recovery(session * p_session)
{
    ftp_session * p_ftp_session = (ftp_session *)p_session->expansion_data;
    if(p_ftp_session -> username != NULL)
        delete p_ftp_session -> username;
    p_ftp_session -> username = NULL;

    if(p_ftp_session -> passwd != NULL)
        delete p_ftp_session->passwd;
    p_ftp_session->passwd = NULL;
}
