// Last Update:2015-04-28 10:01:23
/**
 * @file ftp_str.h
 * @brief ftp Session 定义
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-27
 */

#ifndef FTP_STR_H
#define FTP_STR_H

#include <session.h>
#include <stdint.h>
#include <string> 
#include <list> 
using namespace std;

class ftp_session
{
    public:
       uint64_t requst_time;
       uint64_t response_time;
       string   *username;
       string   *passwd;
       uint32_t     b_available;

       bool b_c2s; // 方向判断，是不是C -> s
       bool is_pwd;
       uint32_t  len;
       char *  p_data;
};

#endif  /*FTP_STR_H*/
