// Last Update:2016-09-25 21:36:01
/**
 * @file l2tp_plugin.cpp
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-05-04
 */

#include "l2tp_plugin.h"
#include <commit_tools.h>
#include <sys/stat.h>
#include <clog.h>
#include <iostream>
//#include "shm_statistics.h"

#define L2TPDEFINEPORT 1701

static bool b_check_config = true;

extern "C"
{
    int get_plugin_id()
    {
        return 10003;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p;
        return new  l2tp_plugin();
    }
}


l2tp_plugin::l2tp_plugin()
{
    data_interface_type = FILESEND;
    l2tp_time_out = 1;
    reload();
}

l2tp_plugin::~l2tp_plugin()
{
}

void l2tp_plugin::reload()
{
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/l2tp_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" )
        {
            data_interface_type = NETSEND;
        }
    }
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        l2tp_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if(p_value != NULL)
    {
        max_row = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if(p_value != NULL)
    {
        max_time_scr = atoi(p_value);
    }
    //协议识别
    if(b_check_config)
    {
        b_check_config = false;
        string path = "/config/DFI";
        int num  = xml.get_value_count(path.c_str());
        for(int i = 0 ; i < num ; i++)
        {
            string xpath = path;
            xml.assemble_path(xpath, i);
            string type_path = xpath;
            type_path +="/type";
            char * value  = (char *)xml.get_value(type_path.c_str());
            int  type = 0 ;
            if(value  != NULL)
            {
                type  = atoi(value);
            }
            type_path = xpath;
            type_path +="/config_path";
            value  = (char *)xml.get_value(type_path.c_str());
            if(value  == NULL)
            {

                continue;
            }

            list<rule_node_offist * > node_list;
            int rule_num = 300 ;
            protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), rule_num);
            list<rule_node_offist * > ::iterator iter = node_list.begin();
            for(;iter != node_list.end(); iter ++)
            {
                rule_node_offist * p = *iter ;
                public_l2tp_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
            }
        }
    }
    feature_rule_map = & public_l2tp_feature_rule_map;
}

void l2tp_plugin::multimode_l2tp_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }
    p_session->is_l2tp = false;
    p_session->is_c2s = false;
    p_session->is_s2c = false;
    short num_short =ntohs(*((short*) (p_packet->p_app_data + 2)));

    if(num_short == p_packet->app_data_len)
    {
        p_session->is_l2tp = true;
        //暗示不需要判别方向问题
        return;
    }


    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet -> rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 1702)
            {
                p_session->is_c2s = true;
                p_session->is_l2tp = true;
                break;
            }
            else if(iter->second == 1703)
            {
                p_session->is_s2c = true;
                p_session->is_l2tp = true;
                break;
            }
        }
    }
    return ;
}


void l2tp_plugin::init_l2tp_session(l2tp_session * p_l2tp_session)
{
    p_l2tp_session->requst_time = 0;
    p_l2tp_session->response_time = 0;
    p_l2tp_session->pl_msg = new list<l2tp_message*>();
    p_l2tp_session->pl_msg->clear();
    p_l2tp_session->p_data = NULL;
    p_l2tp_session->data_len = 0;
    //p_l2tp_session->p_l2tp_message = NULL;
}

bool l2tp_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(p_packet->b_is_tcp)
    {
        return false;
    }
    /*
    // 用端口判断是否是l2tp协议
    if(ntohs(p_session->srcport) == L2TPDEFINEPORT || ntohs(p_session->dstport) == L2TPDEFINEPORT)
    {
    //p_session->b_src_is_ser  = true;
    l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
    init_l2tp_session(p_l2tp_session);
    return true;
    }
    */

    multimode_l2tp_identity(p_session, p_packet);
    if(p_session->is_l2tp)
    {
        //p_session->b_src_is_ser  = true;
        l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
        init_l2tp_session(p_l2tp_session);
        return true;
    }
    return false;
}

void l2tp_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session == NULL || p_packet == NULL )
    {
        return;
    }
    /*    p_session->packet_len += p_packet->buff_len;
          p_session->packet_num++;

          if(p_session->packet_begin_time == 0)
          {
          p_session->packet_begin_time = p_packet->m_timeval;
          p_session->packet_end_time = p_packet->m_timeval;
          }
          if(p_packet->m_timeval > p_session->packet_end_time )
          {
          p_session->packet_end_time = p_packet->m_timeval;
          }*/
    if(p_packet->b_is_tcp || p_packet->p_app_data == NULL || p_packet->app_data_len == 0)
    {
        return;
    }
    l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
    p_l2tp_session->p_data = (char *)p_packet->p_app_data;
    p_l2tp_session->data_len = p_packet->app_data_len;
    p_l2tp_session->packet_time = p_packet->m_timeval;
    //公共字段提取
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    //判断数据包的方向
    if((p_packet->get_src_port() == p_session->srcport) && (p_packet->get_src_ip() == p_session->srcip))
    {
        p_l2tp_session->b_pkt_direction = true;
    }
    else
    {
        p_l2tp_session->b_pkt_direction = false;
    }
    SET_EXPORT(p_session);
    return;
}

void l2tp_plugin::pococol_parse_handle(session * p_session)
{
    l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
    if(p_l2tp_session->p_data == NULL || p_l2tp_session->data_len == 0)
    {
        return;
    }
    //解析数据包的内容
    l2tp_message *p_l2tp_message = p_l2tp_session->l2tp_pkt_parse(p_l2tp_session->p_data, p_l2tp_session->data_len);
    if(p_l2tp_message != NULL)
    {
        if(p_l2tp_message->message_type == CONTROL_MESSAGE)
        {
            if(p_l2tp_session->pl_msg->empty()
                    && ((l2tp_control_msg*)p_l2tp_message)->control_message_type != START_CONTROL_CONNECTION_REQUEST
                    && ((l2tp_control_msg*)p_l2tp_message)->control_message_type != START_CONTROL_CONNECTION_REPLY)
            {
                //SET_SESSION_OVER(p_session);
                delete p_l2tp_message;
            }
            else
            {
                p_l2tp_session->pl_msg->push_back(p_l2tp_message);
            }
            if(((l2tp_control_msg*)p_l2tp_message)->control_message_type == STOP_CONTROL_CONNECTION_NOTIFICATION)
            {
                SET_SESSION_OVER(p_session);
            }
        }
        else
        {
            delete p_l2tp_message;
        }
    }

    if(IS_SESSION_OVER(p_session))              //session结束时统一输出
    {
        p_session->send_len = 1;
        p_session->p_send_buf = NO_NULL;
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
    }

    p_l2tp_session->packet_time = 0;
    p_l2tp_session->b_pkt_direction = false;
    p_l2tp_session->p_data = NULL;
    p_l2tp_session->data_len = 0;
}

void l2tp_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    int is_ipv6 ;
    int is_ipv4 ;
    uint32_t busy_time = 0;

    l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
    if(p_l2tp_session->pl_msg->empty())
    {
        return;
    }
    output_interface.init();
    //数据流方向初步判断（单向or双向）
    list<l2tp_message*>::iterator iter = p_l2tp_session->pl_msg->begin();
    bool b_msg_direction = (*iter)->b_direction;
    if(p_l2tp_session->pl_msg->size() > 1)
    {
        //output_interface.direction = 0;
        for(;iter != p_l2tp_session->pl_msg->end(); ++iter)
        {
            if((*iter)->b_direction != b_msg_direction)
            {
                output_interface.direction = 3;    //双向
                break;
            }
        }
    }
    //计算通信速率,检查消息类型
    /*uint64_t total_throughput = 0;
      for(iter = p_l2tp_session->pl_msg->begin(); iter != p_l2tp_session->pl_msg->end(); ++iter)
      {
      if((*iter)->message_type == CONTROL_MESSAGE)
      {
      total_throughput += ((l2tp_control_msg*)(*iter))->length;
      }
      else
      {
      return;
      }
      }
      uint64_t session_duration = ((*(p_l2tp_session->pl_msg->rbegin()))->packet_time - (*(p_l2tp_session->pl_msg->begin()))->packet_time);
      if(session_duration == 0)
      {
      output_interface.communication_rate = 0.000001;
      }
      else
      {
      output_interface.communication_rate = (double)total_throughput / (double)session_duration;
      }*/
    double session_duration = (double)(p_session->packet_end_time - p_session->packet_begin_time);
    if (session_duration != 0)
    {
        //output_interface.communication_rate = ((double)total_throughput / session_duration)*1000000;
        output_interface.communication_rate = ((double)p_session->packet_len / session_duration)*1000000;
    }
    else
    {
        output_interface.communication_rate = 1; 
    }

    //取session开始的时间,判断方向，协议版本
    iter = p_l2tp_session->pl_msg->begin();
    output_interface.time = (*iter)->packet_time;
    l2tp_control_msg* p_ctrl_msg = (l2tp_control_msg*)(*iter);
    //消息链表中第一个消息一定为START_CONTROL_CONNECTION_REQUEST或者START_CONTROL_CONNECTION_REPLY,方向判断方法：发送request方为client，发送reply方为server
    if((p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REQUEST && p_ctrl_msg->b_direction) || (p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REPLY && !p_ctrl_msg->b_direction))
    {
        output_interface.server_ip = p_session->dstip;
        output_interface.client_ip = p_session->srcip;
        output_interface.server_port = p_session->dstport;
        output_interface.client_port = p_session->srcport;
    }
    else
    {
        output_interface.server_ip = p_session->srcip;
        output_interface.client_ip = p_session->dstip;
        output_interface.server_port = p_session->srcport;
        output_interface.client_port = p_session->dstport;
    }


    output_interface.mac_line_num = p_session-> mac_line_num;
    output_interface.device_num = p_session-> device_num;
    if(output_interface.direction != 3)
    {
        output_interface.direction = (p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REQUEST ? 1:2);
    }
    output_interface.protocol_version = p_ctrl_msg->version;
    //解析消息(最简单的处理方式，以后根据需求变化需要进行重构)
    list<attribute_value_pair*>::iterator iter_avp;
    for(iter = p_l2tp_session->pl_msg->begin(); iter != p_l2tp_session->pl_msg->end(); ++iter)
    {
        p_ctrl_msg = (l2tp_control_msg*)(*iter);
        if(p_ctrl_msg->l_avp.empty())
        {
            continue;
        }
        for(iter_avp = p_ctrl_msg->l_avp.begin(); iter_avp != p_ctrl_msg->l_avp.end(); ++iter_avp)
        {
            switch((*iter_avp)->attribute_type)
            {
                case FRAMING_CAPABILITIES:
                    output_interface.framing_capabilities = ((avp_framing_capabilitie*)(*iter_avp))->framing_capabilitie;
                    break;
                case BEARER_CAPABILITIES:
                    output_interface.bearer_capabilities = ((avp_bearer_capabilities*)(*iter_avp))->bearer_capabilities;
                    break;
                case HOST_NAME:
                    if(((avp_host_name*)(*iter_avp))->p_host_name[0] != 0x00)
                    {
                        if(p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REQUEST)
                        {
                            output_interface.p_client_hostname = ((avp_host_name*)(*iter_avp))->p_host_name;
                        }
                        else if(p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REPLY)
                        {
                            output_interface.p_server_hostname = ((avp_host_name*)(*iter_avp))->p_host_name;
                        }
                        else
                        {
                            break;
                        }
                    }
                    break;
                case VENDOR_NAME:
                    if(((avp_vendor_name*)(*iter_avp))->p_vendor_name[0] != 0x00)
                    {
                        if(p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REQUEST)
                        {
                            output_interface.p_client_vendorname = ((avp_vendor_name*)(*iter_avp))->p_vendor_name;
                        }
                        else if(p_ctrl_msg->control_message_type == START_CONTROL_CONNECTION_REPLY)
                        {
                            output_interface.p_server_vendorname = ((avp_vendor_name*)(*iter_avp))->p_vendor_name;
                        }
                        else
                        {
                            break;
                        }
                    }
                    break;
                case CALLING_NUMBER:
                    if(((avp_calling_number*)(*iter_avp))->p_calling_number[0] != 0x00)
                    {
                        output_interface.p_calling_number = ((avp_calling_number*)(*iter_avp))->p_calling_number;
                    }
                    break;
                case PROXY_AUTHEN_TYPE:
                    output_interface.proxy_authen_type = ((avp_proxy_authen_type*)(*iter_avp))->proxy_authen_type;
                    break;
                case PROXY_AUTHEN_NAME:
                    if(((avp_proxy_authen_name*)(*iter_avp))->p_proxy_authen_name[0] != 0x00)
                    {
                        output_interface.p_proxy_authen_name = ((avp_proxy_authen_name*)(*iter_avp))->p_proxy_authen_name;
                    }
                    break;
                default:
                    break;
            }
        }
    }

    //add news common header
    classify_ip_kind_info(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
    output_interface.is_ipv4 = is_ipv4;
    output_interface.is_ipv6 = is_ipv6;
    output_interface.is_mpls = p_session->m_is_mpls;
    output_interface.n_label = p_session->m_label;
    output_interface.in_nerlabel = p_session->m_inner_label;
    output_interface.other_label = p_session->m_other_lable;
    output_interface.proto = p_session->proto_type;
    output_interface.total_payloadbytes = p_session->packet_len;
    output_interface.total_payloadpackets = p_session->packet_num;
    if(p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    output_interface.duration = busy_time;
    //将数据加入接口
    l2tp_interface_handling(p_list);
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    return;



    /*
       l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
       data_interface m_data ;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
    if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
    {
    m_data.b_out_type = FILESEND;

    string requst_time;
    DNUMTOSTR(p_l2tp_session->requst_time, requst_time);
    struct timeval tv ;
    gettimeofday(&tv, NULL);
    uint64_t u64_time = tv.tv_sec * 100000 + tv.tv_sec;

    if(file_path.empty())
    {
    // 文件相对路径
    file_path = "/";
    file_path += get_year_month();
    file_path += get_day_hour();
    file_path += get_min_sec();

    file_name = date_time();
    file_name += "-";
    file_name += requst_time;
    begin_time = u64_time;
    file_data= "";
    row = 0;
    file_str = new w_file_str;
    }

    file_str->finished = false;
    if(row==max_row || u64_time-begin_time > max_time_scr * 100000) 
    {
    file_str->finished = true;
    }

    string l2tp_file_name = file_name;
    l2tp_file_name += ".l2tp";
    file_str->file_path = file_path;
    file_str->file_name.swap(l2tp_file_name);

    // 申请内存存储数据，写文件后自动析构
    {
    if(row > 0)
    file_data +="\n[l2tp]\n";
    else
    file_data +="[l2tp]\n";

    row ++;
    // 拷贝数据 
    requst_time = date_time3(p_l2tp_session->requst_time);
    file_data += requst_time;
    file_data += "\n";
    // 用户名和密码 
    file_data += *(p_l2tp_session->username);
    file_data += "\n";
    file_data += *(p_l2tp_session->passwd);
    file_data += "\n";

    if(p_session -> b_src_is_ser) 
    {
    // 客户端 IP 
    file_data += p_session->dstip.ip_str();
    file_data += ":";
    string dst_port;
    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
    file_data += dst_port;
    file_data += "\n";
    // l2tp IP
    file_data += p_session->srcip.ip_str();
    file_data += ":";
    string src_port;
    DNUMTOSTR(ntohs(p_session->srcport), src_port);
    file_data += src_port;
    file_data += "\n";
}
else
{
    // 客户端 IP 
    file_data += p_session->srcip.ip_str();
    file_data += ":";
    string src_port;
    DNUMTOSTR(ntohs(p_session->srcport), src_port);
    file_data += src_port;
    file_data += "\n";
    // l2tp IP
    file_data += p_session->dstip.ip_str();
    file_data += ":";
    string dst_port;
    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
    file_data += dst_port;
    file_data += "\n";
}

if(!file_str->finished)
{
    if(file_data.length() < 1024*1024 )
    {
        return;
    }
    else
    {
        file_str->finished = true;
    }
}

if(file_str->finished)
{
    char * l2tp_file_data = new char[file_data.length()+1];
    strcpy(l2tp_file_data,file_data.c_str());
    file_str->file_data = l2tp_file_data;
    file_str->datalen = file_data.length();
}
}

m_data.data = file_str;
p_list -> push_back(m_data);
if(file_str->finished)
{
    file_path = "";
    file_name = "";
    begin_time = u64_time;
}
}
}
else if (data_interface_type == NETSEND)
{
    if((*p_l2tp_session->username).empty() || (*p_l2tp_session->passwd).empty())
        return;

    net_str * p_net =  new  net_str;
    p_net -> msg = new CAmsg;
    p_net->msg->Clear();
    // 设置 
    p_net->msg->set_type(3); // l2tp

    l2tp_message* p_l2tp = p_net->msg->mutable_l2tp();
    Comm_msg* p_comm =  p_l2tp -> mutable_comm_msg();
    // 公共 消息 

    if(p_session -> b_src_is_ser) 
    {
        p_comm ->set_src_port(ntohs(p_session->dstport));
        p_comm ->set_dst_ip(p_session->srcip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->srcport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->dstip.ip_str());
        }
    }
    else
    {
        p_comm ->set_src_port(ntohs(p_session->srcport));
        p_comm ->set_dst_ip(p_session->dstip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->dstport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->srcip.ip_str());
        }
    }
    p_comm ->set_time(p_l2tp_session->requst_time);
    //  域名 
    string user_name = *p_l2tp_session->username;
    string user_pass = *p_l2tp_session->passwd;

    p_attach_info -> p_protocal -> PotocolStatistics(3,1,0,1);
    // 去除乱码
    //erase_not_ascii(user_name);
    //erase_not_ascii(user_pass);

    p_l2tp->set_username(user_name);
    p_l2tp->set_password(user_pass);
    //p_l2tp->set_is_valid(p_l2tp_session->b_available);
    if (p_l2tp_session->b_available)
    {
        p_l2tp->set_is_valid(2);
    }
    else
    {
        p_l2tp->set_is_valid(1);
    }
    p_net->datalen = 20 + user_name.length() + user_pass.length();
    // 接口 
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}

p_session->send_len = 0;
p_session->p_send_buf = NULL;
p_session->client.clear_buf();
SET_SESSION_OVER(p_session);
*/
}

void l2tp_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > l2tp_time_out *1000000)
    {
        //开始超时处理
        //  printf("l2tp session time out!\n");
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
}

void l2tp_plugin::resources_recovery(session * p_session)
{
    l2tp_session * p_l2tp_session = (l2tp_session *)p_session->expansion_data;
    p_l2tp_session->display_l2tp_message_list();
    list<l2tp_message*>::iterator iter = p_l2tp_session->pl_msg->begin();
    for(;iter != p_l2tp_session->pl_msg->end(); ++iter)
    {
        //(*iter)->display();
        delete *iter;
    }
    p_l2tp_session->pl_msg->clear();
    delete p_l2tp_session->pl_msg;
}

//Summary:  L2TP插件接口数据处理函数
//Parameters:
//       p_list: 数据接口链表指针
//Return : 无
void l2tp_plugin::l2tp_interface_handling(list<data_interface> *p_list)
{
    data_interface m_data;
    if(data_interface_type == NETSEND)
    {
        net_str * p_net = new net_str;
        p_net->msg = new CAmsg;
        p_net->msg->Clear();
        p_net->msg->set_type(26); // l2tp

        l2tp_msg* p_l2tp = p_net->msg->mutable_l2tp();
        Comm_msg* p_comm = p_l2tp->mutable_comm_msg();
        //公共消息
        p_comm ->set_src_ip(output_interface.client_ip.ip_str());
        p_comm ->set_src_port(ntohs(output_interface.client_port));
        p_comm ->set_dst_ip(output_interface.server_ip.ip_str());
        p_comm ->set_dst_port(ntohs(output_interface.server_port));
        p_comm ->set_time(output_interface.time);

        p_comm ->set_line_num(output_interface.mac_line_num);
        p_comm ->set_dev_num(output_interface.device_num);
        p_comm->set_is_ipv4(output_interface.is_ipv4);
        p_comm->set_is_ipv6(output_interface.is_ipv6);
        p_comm->set_proto(output_interface.proto);
        p_comm->set_link_layer_type(0);
        p_comm ->set_is_mpls(output_interface.is_mpls);
        p_comm ->set_n_label(output_interface.n_label);
        p_comm ->set_inner_label(output_interface.in_nerlabel);
        p_comm ->set_other_label(output_interface.other_label);
        p_comm ->set_total_pay_load_bytes(output_interface.total_payloadbytes);
        p_comm ->set_tatal_pay_load_packets(output_interface.total_payloadpackets);
        p_comm ->set_duration(output_interface.duration);
        //l2tp消息
        p_l2tp->set_protocol_family(1210002);
        p_l2tp->set_communication_rate(output_interface.communication_rate);
        p_l2tp->set_direction(output_interface.direction);
        p_l2tp->set_protocol_version(output_interface.protocol_version);
        p_l2tp->set_framing_capabilities(output_interface.framing_capabilities);
        p_l2tp->set_bearer_capabilities(output_interface.bearer_capabilities);
        p_l2tp->set_proxy_authen_type(output_interface.proxy_authen_type);
        if(output_interface.p_server_hostname != NULL)
        {
            p_l2tp->set_server_hostname(output_interface.p_server_hostname);
        }
        if(output_interface.p_client_hostname != NULL)
        {
            p_l2tp->set_client_hostname(output_interface.p_client_hostname);
        }
        if(output_interface.p_server_vendorname != NULL)
        {
            p_l2tp->set_server_vendorname(output_interface.p_server_vendorname);
        }
        if(output_interface.p_client_vendorname != NULL)
        {
            p_l2tp->set_client_vendorname(output_interface.p_client_vendorname);
        }
        if(output_interface.p_calling_number != NULL)
        {
            p_l2tp->set_calling_number(output_interface.p_calling_number);
        }
        if(output_interface.p_proxy_authen_name != NULL)
        {
            p_l2tp->set_proxy_authen_name(output_interface.p_proxy_authen_name);
        }
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }
    return;
}








//Summary:  l2tp消息解析函数
//Parameters:
//       p_data: l2tp数据包数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，则返回一个指向l2tp_message的指针，若解析失败则返回NULL
l2tp_message* l2tp_session::l2tp_pkt_parse(const char* p_data, int16_t data_len)
{
    //if(p_data == NULL || data_len < 0 || (size_t)data_len < 2)
    if(p_data == NULL || (size_t)data_len < 2)
    {
        return NULL;
    }
    l2tp_message *p_l2tp_message = NULL;
    //解析标志字段
    uint16_t flag = ntohs(*(uint16_t*)p_data);
    uint16_t l2tp_version = flag & 0x000F;
    //判断消息类型，检查版本和标志位
    if((flag & 0x8000) == 0)                  //数据消息，暂不处理
    {
        return NULL;
    }
    else                                    //控制消息
    {
        if((flag & 0x4800) != 0x4800)                         //检查L标志位和S标志位，详见RFC3931 P11 和 RFC2661 P10
        {
            return NULL;
        }
        if(l2tp_version != 2 && l2tp_version != 3)                        //检查版本
        {
            return NULL;
        }
        p_l2tp_message = new l2tp_control_msg(packet_time, b_pkt_direction, l2tp_version);
    }
    if(!p_l2tp_message->msg_parse(p_data, data_len))
    {
        delete p_l2tp_message;
        return NULL;
    }
    return p_l2tp_message;
}

//Summary:  l2tp控制消息解析函数
//Parameters:
//       p_data: l2tp控制消息数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，返回true，若解析失败则返回false
bool l2tp_control_msg::msg_parse(const char* p_data, int16_t data_len)
{
    //if(p_data == NULL || data_len < 0 || (size_t)data_len < 12)
    if(p_data == NULL || (size_t)data_len < 12)
    {
        return false;
    }
    //解析消息头
    length = ntohs(*(uint16_t*)(p_data + 2));
    ns = ntohs(*(uint16_t*)(p_data + 8));
    nr = ntohs(*(uint16_t*)(p_data + 10));
    if(version == L2TPV2)
    {
        tunnel_id = ntohs(*(uint16_t*)(p_data + 4));
        session_id = ntohs(*(uint16_t*)(p_data + 6));
    }
    else if(version == L2TPV3)
    {
        control_connection_id = ntohl(*(uint32_t*)(p_data + 4));
    }
    else
    {
        return false;
    }
    if(length < data_len)                     //检查数据长度
    {
        return false;
    }
    p_data += 12;
    data_len -= 12;
    if(!avp_parse(p_data, data_len))                        //解析AVP
    {
        return false;
    }
    else
    {
        if(l_avp.empty())
        {
            return false;
        }
        list<attribute_value_pair*>::iterator iter = l_avp.begin();
        if((*iter)->attribute_type != MESSAGE_TYPE)
        {
            return false;
        }
        else
        {
            control_message_type = ((avp_message_type*)(*iter))->message_type;
        }
        return true;
    }
}

//Summary:  avp解析函数,解析结果会直接缓存入list l_avp中
//Parameters:
//       p_data: avp数据value内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，返回true，若解析失败则返回false
bool l2tp_control_msg::avp_parse(const char* p_data, int16_t data_len)
{
    bool b_avp_mandatory;
    bool b_avp_hidden;
    uint16_t avp_length;
    uint32_t avp_vendor_id;
    uint16_t avp_attribute_type;
    int16_t avp_attribute_value_offset;
    attribute_value_pair *p_avp;
    while(data_len > 0)
    {
        if(data_len < 6)
        {
            return false;
        }
        //解析avp头（Attribute Value之前的内容，详见RFC3931 P30）
        b_avp_mandatory = (((*p_data) & 0x80) != 0)? true:false;
        b_avp_hidden = (((*p_data) & 0x40) != 0)? true:false;
        avp_length = ntohs(*(uint16_t*)p_data);
        avp_length = avp_length & 0x03FF;
        avp_vendor_id = ntohs(*(uint16_t*)(p_data+2));
        avp_attribute_type = ntohs(*(uint16_t*)(p_data+4));
        if(data_len < avp_length)
        {
            return false;
        }
        if(avp_attribute_type == 58 && avp_vendor_id == 0)           //32位Vendor ID
        {
            if(data_len < 12)
            {
                return false;
            }
            avp_vendor_id = ntohl(*(uint32_t*)(p_data+6));
            avp_attribute_type = ntohs(*(uint16_t*)(p_data+10));
            avp_attribute_value_offset = 12;
        }
        else
        {
            avp_attribute_value_offset = 6;
        }
        if(!b_avp_hidden)
        {
            switch(avp_attribute_type)
            {
                case MESSAGE_TYPE:
                    p_avp = new avp_message_type(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case FRAMING_CAPABILITIES:
                    p_avp = new avp_framing_capabilitie(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case HOST_NAME:
                    p_avp = new avp_host_name(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case VENDOR_NAME:
                    p_avp = new avp_vendor_name(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case BEARER_CAPABILITIES:
                    p_avp = new avp_bearer_capabilities(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case BEARER_TYPE:
                    p_avp = new avp_bearer_type(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case CALLING_NUMBER:
                    p_avp = new avp_calling_number(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case FRAMING_TYPE:
                    p_avp = new avp_framing_type(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case PROXY_AUTHEN_TYPE:
                    p_avp = new avp_proxy_authen_type(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                case PROXY_AUTHEN_NAME:
                    p_avp = new avp_proxy_authen_name(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id);
                    break;
                default:
                    p_avp = new attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, avp_attribute_type);
                    break;
            }
            //增加异常判断
            if(avp_length > avp_attribute_value_offset)
            {
                if(!p_avp->avp_body_parse(p_data + avp_attribute_value_offset, avp_length - avp_attribute_value_offset))
                {
                    delete p_avp;
                    return false;
                }
            }
            else
            {
                delete p_avp;
                return false;
            }
        }
        else
        {
            if(avp_length == 0)
            {
                fprintf(stderr,"avp_length =  0\n");
            }
            p_avp = new attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, avp_attribute_type);
            LOG(INFO) << "l2tp_plugin.cpp new attribute_value_pair";
            if(avp_length < avp_attribute_value_offset)
            {
                delete p_avp;
                return false;
            }
        }
        l_avp.push_back(p_avp);
        p_data += avp_length;
        data_len -= avp_length;
        //防护内存泄露
        if(avp_length ==0)
        {   
            break;
        }
    }
    return true;
}



//打印函数，仅供调试使用
void l2tp_session::display_l2tp_message_list()
{/*
    list<l2tp_message*>::iterator iter = pl_msg->begin();
    for(int i=1;iter != pl_msg->end(); ++iter,++i)
    {
    printf("########## Message %d ##########\n",i);
    (*iter)->msg_display();
    printf("\n");
    }
    return;
    */
}
