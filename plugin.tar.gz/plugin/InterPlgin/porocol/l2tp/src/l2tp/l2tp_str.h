// Last Update:2016-06-16 12:05:03
/**
 * @file l2tp_str.h
 * @brief l2tp Session 定义
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-05-04
 */

#ifndef L2TP_STR_H
#define L2TP_STR_H

#include <session.h>
#include <stdint.h>
#include <string>
#include <list>

using namespace std;
static char NO_NULL[1]={0};

//控制消息类型宏定义  RFC3931 P10-11
#define START_CONTROL_CONNECTION_REQUEST        1
#define START_CONTROL_CONNECTION_REPLY          2
#define START_CONTROL_CONNECTION_CONNECTED      3
#define STOP_CONTROL_CONNECTION_NOTIFICATION    4
#define HELLO                                   6
#define OUTGOING_CALL_REQUEST                   7
#define OUTGOING_CALL_REPLY                     8
#define OUTGOING_CALL_CONNECTED                 9
#define INCOMING_CALL_REQUEST                   10
#define INCOMING_CALL_REPLY                     11
#define INCOMING_CALL_CONNECTED                 12
#define CALL_DISCONNECT_NOTIFY                  14
#define WAN_ERROR_NOTIFY                        15
#define SET_LINK_INFO                           16
#define EXPLICIT_ACKNOWLEDGEMENT                20

//消息类型定义 RFC3931 P11
#define DATA_MESSAGE        0
#define CONTROL_MESSAGE     1


//AVP属性类型宏定义 RFC3931 P36-59
//#define MESSAGE_TYPE 0




//L2TP版本宏定义
#define L2TPV2 2
#define L2TPV3 3


//AVP基类定义  RFC3931 P32
class attribute_value_pair
{
    public:
        attribute_value_pair(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id, uint16_t avp_attribute_type)
            :b_mandatory(b_avp_mandatory), b_hidden(b_avp_hidden), length(avp_length), vendor_id(avp_vendor_id), attribute_type(avp_attribute_type){};
        virtual ~attribute_value_pair(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            return true;
        };
        void avp_header_display()
        {
            printf("\tMandatory: %d, Hidden: %d, Vendor ID: %d, Attribute Type: %d\n",b_mandatory, b_hidden, vendor_id, attribute_type);
        };
        virtual void avp_body_display(){};
    public:
        bool b_mandatory;
        bool b_hidden;
        uint16_t length;
        uint32_t vendor_id;
        uint16_t attribute_type;
};


#define MESSAGE_TYPE 0
//message_type定义 RFC3931 P36    RFC2661 P17
class avp_message_type: public attribute_value_pair
{
    public:
        avp_message_type(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, MESSAGE_TYPE){};
        virtual ~avp_message_type(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 2)
            {
                return false;
            }
            message_type = ntohs(*(uint16_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tControl Message Type: %d\n", message_type);
        };
    public:
        uint16_t message_type;
};

#define FRAMING_CAPABILITIES 3
//framing_capabilities定义 RFC2661 P21
class avp_framing_capabilitie: public attribute_value_pair
{
    public:
        avp_framing_capabilitie(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, FRAMING_CAPABILITIES){};
        virtual ~avp_framing_capabilitie(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 4)
            {
                return false;
            }
            framing_capabilitie = ntohl(*(uint32_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tFraming Capabilities: %x\n", framing_capabilitie);
        };
    public:
        uint32_t framing_capabilitie;
};


#define HOST_NAME 7
//host_name  RFC3931 P44  RFC2661 P23
class avp_host_name: public attribute_value_pair
{
    public:
        avp_host_name(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, HOST_NAME), p_host_name(NULL){};
        virtual ~avp_host_name()
        {
            if(p_host_name != NULL)
            {
                delete []p_host_name;
            }
        };
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len <= 0)
            {
                return false;
            }
            p_host_name = new char[data_len+1];
            memcpy(p_host_name, p_data, data_len);
            p_host_name[data_len] = 0x00;
            host_name_len = data_len;
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tHost Name: %s\n", p_host_name);
        };
    public:
        char *p_host_name;
        int16_t host_name_len;
};

#define VENDOR_NAME 8
//Vendor Name RFC3931 P45 RFC2661 P24
class avp_vendor_name: public attribute_value_pair
{
    public:
        avp_vendor_name(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, VENDOR_NAME), p_vendor_name(NULL){};
        virtual ~avp_vendor_name()
        {
            if(p_vendor_name != NULL)
            {
                delete []p_vendor_name;
            }
        };
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len <= 0)
            {
                return false;
            }
            p_vendor_name = new char[data_len+1];
            memcpy(p_vendor_name, p_data, data_len);
            p_vendor_name[data_len] = 0x00;
            vendor_name_len = data_len;
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tVendor Name: %s\n", p_vendor_name);
        };
    public:
        char *p_vendor_name;
        int16_t vendor_name_len;
};

#define BEARER_CAPABILITIES 4
//Bearer Capabilities RFC2661 P21
class avp_bearer_capabilities: public attribute_value_pair
{
    public:
        avp_bearer_capabilities(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, BEARER_CAPABILITIES){};
        virtual ~avp_bearer_capabilities(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 4)
            {
                return false;
            }
            bearer_capabilities = ntohl(*(uint32_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tBearer Capabilities: %d\n", bearer_capabilities);
        };
    public:
        uint32_t bearer_capabilities;
};

#define BEARER_TYPE 18
//Bearer Type RFC2661 P29
class avp_bearer_type: public attribute_value_pair
{
    public:
        avp_bearer_type(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, BEARER_TYPE){};
        virtual ~avp_bearer_type(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 4)
            {
                return false;
            }
            bearer_type = ntohl(*(uint32_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tBearer Type: %d\n", bearer_type);
        };
    public:
        uint32_t bearer_type;
};

#define CALLING_NUMBER 22
//Calling Number RFC2661 P31
class avp_calling_number: public attribute_value_pair
{
    public:
        avp_calling_number(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, CALLING_NUMBER), p_calling_number(NULL){};
        virtual ~avp_calling_number()
        {
            if(p_calling_number != NULL)
            {
                delete []p_calling_number;
            }
        };
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len <= 0)
            {
                return false;
            }
            p_calling_number = new char[data_len+1];
            memcpy(p_calling_number, p_data, data_len);
            p_calling_number[data_len] = 0x00;
            calling_number_len = data_len;
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tCalling Number: %s\n", p_calling_number);
        };
    public:
        char *p_calling_number;
        int16_t calling_number_len;
};

#define FRAMING_TYPE 19
//Framing Type RFC2661 P30
class avp_framing_type: public attribute_value_pair
{
    public:
        avp_framing_type(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, FRAMING_TYPE){};
        virtual ~avp_framing_type(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 4)
            {
                return false;
            }
            framing_type = ntohl(*(uint32_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tFraming Type: %d\n", framing_type);
        };
    public:
        uint32_t framing_type;
};

#define PROXY_AUTHEN_TYPE 29
//Proxy Authen Type RFC2661 P36
class avp_proxy_authen_type: public attribute_value_pair
{
    public:
        avp_proxy_authen_type(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, PROXY_AUTHEN_TYPE){};
        virtual ~avp_proxy_authen_type(){};
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 2)
            {
                return false;
            }
            proxy_authen_type = ntohs(*(uint32_t*)p_data);
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tProxy Authen Type: %d\n", proxy_authen_type);
        };
    public:
        uint16_t proxy_authen_type;
};

#define PROXY_AUTHEN_NAME 30
//Proxy Authen Name RFC2661 P37
class avp_proxy_authen_name: public attribute_value_pair
{
    public:
        avp_proxy_authen_name(bool b_avp_mandatory, bool b_avp_hidden, uint16_t avp_length, uint32_t avp_vendor_id)
            :attribute_value_pair(b_avp_mandatory, b_avp_hidden, avp_length, avp_vendor_id, PROXY_AUTHEN_NAME), p_proxy_authen_name(NULL){};
        virtual ~avp_proxy_authen_name()
        {
            if(p_proxy_authen_name != NULL)
            {
                delete []p_proxy_authen_name;
            }
        };
        virtual bool avp_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len <= 0)
            {
                return false;
            }
            p_proxy_authen_name = new char[data_len+1];
            memcpy(p_proxy_authen_name, p_data, data_len);
            p_proxy_authen_name[data_len] = 0x00;
            proxy_authen_name_len = data_len;
            return true;
        };
        virtual void avp_body_display()
        {
            printf("\t\tProxy Authen Name: %s\n", p_proxy_authen_name);
        };
    public:
        char *p_proxy_authen_name;
        int16_t proxy_authen_name_len;
};





//l2tp消息类
class l2tp_message
{
    public:
        l2tp_message(uint64_t time, bool b_packet_direction, uint16_t protocol_version, uint16_t l2tp_message_type):packet_time(time), b_direction(b_packet_direction), message_type(l2tp_message_type), version(protocol_version){};
        virtual ~l2tp_message(){};
        virtual bool msg_parse(const char* p_data, int16_t data_len) = 0;          //消息体解析函数，纯虚函数
        virtual void msg_display(){};                                              //消息体打印函数，仅供调试使用
    public:
        uint64_t packet_time;                                                           //消息时间
        bool b_direction;                                                               //方向判断，true:方向与session相同，false:方向与session相反
        uint16_t message_type;                                                          //消息类型：控制消息or数据消息
        uint16_t version;                                                               //协议版本
};



//l2tp控制消息类   RFC3931 P11   RFC2661 P10
class l2tp_control_msg: public l2tp_message
{
    public:
        l2tp_control_msg(uint64_t time, bool b_packet_direction, uint16_t protocol_version):l2tp_message(time, b_packet_direction, protocol_version, CONTROL_MESSAGE),control_connection_id(0), tunnel_id(0), session_id(0){};
        virtual ~l2tp_control_msg()
        {
            list<attribute_value_pair*>::iterator iter = l_avp.begin();
            for(;iter != l_avp.end(); ++iter)
            {
                delete *iter;
            }
            l_avp.clear();
        };
        virtual bool msg_parse(const char* p_data, int16_t data_len);
        virtual void msg_display()
        {
            printf("Message Type: %d, Version: %d, NS: %d, NR: %d, Control Connection ID: %d, Tunnel ID: %d, Session ID: %d\n",message_type, version, ns, nr, control_connection_id, tunnel_id, session_id);
            list<attribute_value_pair*>::iterator iter = l_avp.begin();
            for(;iter != l_avp.end(); ++iter)
            {
                (*iter)->avp_header_display();
                (*iter)->avp_body_display();
            }
        };
    private:
        bool avp_parse(const char* p_data, int16_t data_len);
    public:
        uint16_t length;
        uint16_t ns;
        uint16_t nr;
        uint32_t control_connection_id;     //l2tpv3使用，l2tpv2空闲
        uint16_t tunnel_id;                 //l2tpv2使用，l2tpv3空闲
        uint16_t session_id;                //l2tpv2使用，l2tpv3空闲
        uint16_t control_message_type;
        list<attribute_value_pair*> l_avp;
};



//l2tp数据消息类   可在此处定义，继承l2tp消息类


//l2tp 输出接口类
class l2tp_output_interface
{
    public:
        l2tp_output_interface(){};
        ~l2tp_output_interface(){};
        void init()
        {
            direction = 0;
            communication_rate = 0;
            protocol_version = 0;

            framing_capabilities = 0;
            bearer_capabilities = 0;
            p_server_hostname = NULL;
            p_client_hostname = NULL;
            p_server_vendorname = NULL;
            p_client_vendorname = NULL;
            p_calling_number = NULL;
            proxy_authen_type = 0;
            p_proxy_authen_name = NULL;
            mac_line_num = "";
            device_num = "";
            dev_no = "";
            layer_type = 0;
            is_ipv4 = 0;
            is_ipv6 = 0;
            is_mpls = 0;
            n_label = 0;
            in_nerlabel = 0;
            other_label = 0;
            proto = 0;
            duration = 0;
            total_payloadbytes = 0;
            total_payloadpackets = 0;
        };
        //void message_handling(isakmp_message *p_msg, session* p_session);
    public:
        uint64_t time;
        c_ip server_ip;
        c_ip client_ip;
        uint16_t server_port;
        uint16_t client_port;
        uint8_t  direction;
        double communication_rate;
        uint16_t protocol_version;

        string mac_line_num = "";
        string device_num;
        //add new commonheader
        string dev_no;
        uint32_t layer_type;
        uint32_t is_ipv4;
        uint32_t is_ipv6;
        uint32_t is_mpls;
        uint32_t n_label;
        uint32_t in_nerlabel;
        uint32_t other_label;
        uint32_t proto;
        double  duration;
        //double ip_ju;
        //double ip_wd;
        uint32_t total_payloadbytes;
        uint32_t total_payloadpackets;

        uint32_t framing_capabilities;
        uint32_t bearer_capabilities;
        char *p_server_hostname;
        char *p_client_hostname;
        char *p_server_vendorname;
        char *p_client_vendorname;
        char *p_calling_number;
        uint32_t proxy_authen_type;
        char *p_proxy_authen_name;
};



//l2tp session类
class l2tp_session
{
    public:
        uint64_t requst_time;
        uint64_t response_time;
        list<l2tp_message*> *pl_msg;                                            //一个l2tp消息链表，存储所有接收到的l2tp消息

        int16_t data_len;
        char *p_data;
        uint64_t packet_time;
        bool b_pkt_direction;                                               //方向判断，true:方向与session一致，false:方向与session不一致
    public:
        l2tp_message *l2tp_pkt_parse(const char* p_data, int16_t data_len);     //l2tp数据包解析函数
        void display_l2tp_message_list();                                       //打印函数，仅供测试使用
};

#endif  /*L2TP_STR_H*/
