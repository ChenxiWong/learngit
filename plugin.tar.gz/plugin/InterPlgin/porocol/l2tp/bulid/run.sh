#!/bin/bash
make clean
make
cp -rf  $NPR_SDK/../plugin/InterPlgin/porocol/l2tp/lib/libl2tp.so  $NPR_ROOT/plugin/InterPlugin/

