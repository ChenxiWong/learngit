#ifndef SSH_STR_H
#define SSH_STR_H

#include<session.h>
#include<stdint.h>
#include<string>
#include<list>


#define KEI     20
#define NK      21

#define DHKEX_INIT 30
//#define DHKEX_REPLY 31
#define DHKEX_GEX_GROUP 31
#define DHKEX_GEX_INIT 32
#define DHKEX_GEX_REPLY 33


using namespace std;

#define SSH_BEGIN 0
#define SSH_END   1

static char NO_NULL[1]={0x0};

class ssh_output_interface
{
    public:
        ssh_output_interface(){};
        ~ssh_output_interface(){};
        void init()
        {
            direction=0;
            protocol_c=NULL;
            protocol_s=NULL;
            cookie=NULL;
            kex_algorithms_s_len=0;
            kex_algorithms_c_len=0;
            kex_algorithms_s=NULL;
            kex_algorithms_c=NULL;
            s_host_key_algorithms_len=0;
            s_host_key_algorithms=NULL;
            encryption_algorithms_c2s_len=0;
            encryption_algorithms_c2s=NULL;
            encryption_algorithms_s2c_len=0;
            encryption_algorithms_s2c=NULL;
            mac_algorithms_c2s_len=0;
            mac_algorithms_c2s=NULL;
            mac_algorithms_s2c_len=0;
            mac_algorithms_s2c=NULL;
            compression_algorithms_c2s_len=0;
            compression_algorithms_c2s=NULL;
            compression_algorithms_s2c_len=0;
            compression_algorithms_s2c=NULL;
            e_len=0;
            e=NULL;
            K_S_len=0;
            K_S=NULL;
            f_len=0;
            f=NULL;
            H_s_len=0;
            H_s=NULL;
            P_len=0;
            P=NULL;
            G_len=0;
            G=NULL;
            mac_line_number = "";
            device_num = "";
            layer_type = 0;
            is_ipv4 = 0;
            is_ipv6 = 0;
            is_mpls = 0;
            n_label = 0;
            in_nerlabel = 0;
            other_label = 0;
            proto = 0;
            duration = 0;
            total_payloadbytes = 0;
            total_payloadpackets = 0;
        };

        // void message_handling(ssh_message *p_msg, session* p_session);

    public:
        uint64_t time;
        c_ip server_ip;
        c_ip client_ip;
        uint16_t server_port;
        uint16_t client_port;
        string mac_line_number;
        string device_num;
        //新添公共字段
        string dev_no;
        uint32_t layer_type;
        uint32_t is_ipv4;
        uint32_t is_ipv6;
        uint32_t is_mpls;
        uint32_t n_label;
        uint32_t in_nerlabel;
        uint32_t other_label;
        uint32_t proto;
        double  duration;
        //double ip_ju;
        //double ip_wd;
        uint32_t total_payloadbytes;
        uint32_t total_payloadpackets;

        uint8_t  direction;
        double communication_rate;
        char  *protocol_c;
        char  *protocol_s;
        char * cookie;
        uint32_t kex_algorithms_s_len;
        uint32_t kex_algorithms_c_len;
        char * kex_algorithms_s;
        char * kex_algorithms_c;
        uint32_t s_host_key_algorithms_len;
        char * s_host_key_algorithms;
        uint32_t encryption_algorithms_c2s_len;
        char *encryption_algorithms_c2s;
        uint32_t encryption_algorithms_s2c_len;
        char *encryption_algorithms_s2c;
        uint32_t mac_algorithms_c2s_len;
        char *mac_algorithms_c2s;
        uint32_t mac_algorithms_s2c_len;
        char *mac_algorithms_s2c;
        uint32_t compression_algorithms_c2s_len;
        char *compression_algorithms_c2s;
        uint32_t compression_algorithms_s2c_len;
        char *compression_algorithms_s2c;
        uint32_t e_len;
        char *e;
        uint32_t K_S_len;
        char *K_S;
        uint32_t f_len;
        char *f;
        uint32_t H_s_len;
        char *H_s;
        uint32_t P_len;
        char *P;
        uint32_t G_len;
        char * G;

};






class  ssh_detail
{ 
    public:
        ssh_detail(){
        kex_algorithms_c=NULL;
        kex_algorithms_s=NULL;
        s_host_key_algorithms=NULL;
        encryption_algorithms_c2s=NULL;
        encryption_algorithms_s2c=NULL;
        mac_algorithms_c2s=NULL;
        mac_algorithms_s2c=NULL;
        compression_algorithms_c2s=NULL;
        compression_algorithms_s2c=NULL;
        languages_c2s=NULL;
        languages_s2c=NULL;
        e=NULL;
        K_S=NULL;
        f=NULL;
        H_s=NULL;
        P_len=0;
        P=NULL;
        G_len=0;
        G=NULL;
        MAC=NULL;
        payload=NULL;
        random_padding=NULL;
        cookie=NULL;
        }
        

    char *payload;
    char *random_padding;
    char *cookie;//random bytes   16

    uint32_t kex_algorithms_s_len;
    uint32_t kex_algorithms_c_len;
    char *kex_algorithms_c;
    char *kex_algorithms_s;
    uint32_t s_host_key_algorithms_len;
    char *s_host_key_algorithms;
    uint32_t encryption_algorithms_c2s_len;
    char *encryption_algorithms_c2s;
    uint32_t encryption_algorithms_s2c_len;
    char *encryption_algorithms_s2c;
    uint32_t mac_algorithms_c2s_len;
    char *mac_algorithms_c2s;
    uint32_t mac_algorithms_s2c_len;
    char *mac_algorithms_s2c;
    uint32_t compression_algorithms_c2s_len;
    char *compression_algorithms_c2s;
    uint32_t compression_algorithms_s2c_len;
    char *compression_algorithms_s2c;
    char  *languages_c2s;
    char  *languages_s2c;
    bool  first_kex_packet_follows;

    uint32_t e_len;
    char *e;
    uint32_t K_S_len;
    char *K_S;
    uint32_t f_len;
    char *f;
    uint32_t H_s_len;
    char *H_s;
    uint32_t P_len;
    char *P;
    uint32_t G_len;
    char *G;
    char *MAC;

};





class ssh_session
{
    public:
        uint64_t requst_time;
        uint64_t response_time;

        bool b_c2s;
        char* p_data;
        uint64_t packet_time;
        uint32_t len;
        uint64_t len_sum;
        uint64_t first_time;
        int first_time_flag;
        uint64_t last_time;
        string *protocol_c;
        string *protocol_s;



        uint32_t packet_length;
        char padding_length;
        int msgcode;
        /*        char *payload;
                  char *random_padding;

                  char *cookie;//random bytes   16
                  char *kex_algorithms;//秘钥租交换算法
                  char *s_host_key_algorithms;//服务器主机秘钥，正常情况用处不大，甚至可以不用
                  char *encryption_algorithms_c2s;//两端通信使用的加密算法
                  char  *encryption_algorithms_s2c;
                  char  *mac_algorithms_c2s;//数据校验用的hash算法
                  char  *mac_algorithms_s2c;
                  char  *compression_algorithms_c2s;//压缩算法
                  char  *compression_algorithms_s2c;
                  char  *languages_c2s;
                  char  *languages_s2c;
                  bool  first_kex_packet_follows;
        //       uint32_t       0;// (reserved for future extension)------


        char *e;

        char  *K_S;//主机公钥
        char *f;//服务器的dh公钥值，客户端收到后便能用f计算出同样的共享秘钥K
        char *s;//签名后的H
        */
        ssh_detail *p_ssh_detail;

        char *encrypted_p;
        char *MAC;
        int status; // 标记解析转态   ，    ssh_begin   表示可以进行ssh 解析  ssh_end 表示解析完成
        int is_link;
        int link_num;
        int direction;
};
#endif




















