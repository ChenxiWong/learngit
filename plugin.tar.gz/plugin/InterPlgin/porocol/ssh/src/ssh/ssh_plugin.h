#ifndef SSH_PLUGIN_H
#define SSH_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "ssh_str.h"
#include <tcp_recombine.h>
#include <commit_tools.h>
#include <map>

#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;


extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info * p );
};
class ssh_plugin:public protocol_parse_base_handle{
    public:
        ssh_plugin();
        ~ssh_plugin();
        virtual void reload();
        virtual bool potocol_identify(session *p_sess,c_packet *p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);

        void Client_Key_Exchange(ssh_session *,char *);
        void Server_Key_Exchange(ssh_session *,char *);
        void DH_Key_Exchange_Init(ssh_session *);
        void DH_Key_Exchange_Reply(ssh_session *);
        void DH_Key_Exchange_Group(ssh_session *);
        void New_keys(ssh_session *);
        // 后续迭代开发留存
        void Encrypted_packet(ssh_session *,char *);



        map <rule_node_offist * , int  >*  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;
        void multimode_ssh_identity(session* p_session, c_packet* p_packet);


  private:

        void  init_ssh_session(ssh_session *);

   void ssh_interface_handling(list<data_interface> * p_list);
    uint32_t  ssh_time_out; // 单位s
                int       data_interface_type ;

              //    uint32_t begin_len;
                  char  * begin_data;

                  xml_parse  xml;
                  uint64_t begin_time;
                  uint32_t row;
                  uint32_t max_row;
                  uint32_t max_time_scr;
           ssh_output_interface output_interface;
                  string file_path;
                  string file_name;
                  string file_data;
                  w_file_str *file_str;
               //CAmsg * msg ;

};

static attach_info * p_attach_info;
map <rule_node_offist * , int  >  public_ssh_feature_rule_map ;
#endif /*SSH_PLUGIN_H*/

