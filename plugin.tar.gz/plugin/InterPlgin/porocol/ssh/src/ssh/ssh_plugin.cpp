/*
 * @file ssh_plugin.cpp
 * @brief-
 * @author Zhou Juanjuan
 * @version 0.1.00
 * @date 2016-04-14
 */



#include "ssh_plugin.h"
#include<string.h>
#include <commit_tools.h>

#define SSHDEFINEPORT 22

static bool b_check_config  = true;

extern "C"{
int get_plugin_id()
{
    return 10011;
}
}

protocol_parse_base_handle *attach(attach_info *p)
{
    p_attach_info = p;
    return new ssh_plugin();
}


ssh_plugin::ssh_plugin()
{
    data_interface_type = FILESEND;
    ssh_time_out = 3;
    row = 0;
    max_row = 9999;
    file_path = "";
    file_name = "";
    reload();
}

ssh_plugin::~ssh_plugin()
{
}

void ssh_plugin::reload()
{
    string tmp = "";
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/ssh_plugin.xml";
    xml.set_file_path(config_path.c_str());
    //协议识别
    string path = "/config/DFI";
    int num  = xml.get_value_count(path.c_str());
    for(int i = 0 ; i < num ; i++)
    {
        string xpath = path;
        xml.assemble_path(xpath, i);
        string type_path = xpath;
        type_path +="/type";
        char * value  = (char *)xml.get_value(type_path.c_str());
        int  type = 0 ;
        if(value  != NULL)
        {
            type  = atoi(value);
        }
        type_path = xpath;
        type_path +="/config_path";
        value  = (char *)xml.get_value(type_path.c_str());
        if(value  == NULL)
        {

            continue;
        }

        list<rule_node_offist * > node_list;
        int rule_num = 500 ;
        protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), rule_num);
        list<rule_node_offist * > ::iterator iter = node_list.begin();
        for(;iter != node_list.end(); iter ++)
        {
            rule_node_offist * p = *iter ;
            public_ssh_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
        }
    }
    feature_rule_map = &public_ssh_feature_rule_map;
    char *p_value = (char *)xml.get_value("/config/send_data_type");
    if (p_value != NULL)
    {
        tmp = p_value;
        if (tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if (tmp == "net" )
        {
            data_interface_type = NETSEND;
        }
    }

    p_value = (char *)xml.get_value("/config/time_out");
    if (p_value != NULL)
    {
        ssh_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if (p_value!=NULL)
    {
        max_time_scr=atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if (p_value != NULL)
    {
        max_row = atoi(p_value);
    }
}

void ssh_plugin::init_ssh_session(ssh_session *p_ssh_session)
{
    p_ssh_session->packet_length = 0;
    p_ssh_session->padding_length = 0;
    p_ssh_session->msgcode = 0;
    p_ssh_session->len_sum = 0;

    if (p_ssh_session->protocol_c == NULL)
    {
        p_ssh_session->protocol_c = new string();
    }
    *(p_ssh_session->protocol_c) = "";
    if (p_ssh_session->protocol_s == NULL)
    {
        p_ssh_session->protocol_s = new string();
    }
    if (p_ssh_session->p_ssh_detail == NULL)
    {
        p_ssh_session->p_ssh_detail = new ssh_detail();
    }
    *(p_ssh_session->protocol_s) = "";
    p_ssh_session -> status = SSH_BEGIN;
    p_ssh_session->is_link = 0;
    p_ssh_session->link_num = 0;
    p_ssh_session->direction = 0;
}

void ssh_plugin::multimode_ssh_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }

    //添加方向判定
    p_session->is_ssh = false;
    p_session->is_c2s = false;
    p_session->is_s2c = false;
    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet -> rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 22)
            {
                p_session->is_ssh = true;
                return;
            }

        }
    }

    return ;
}
bool ssh_plugin::potocol_identify(session *p_session, c_packet *p_packet)
{
    if (!p_packet->b_is_tcp)
    {    
        return false;
    }    

    //特别注意：目前根据特征字符串无法明确标示数据包方向，待后续跟进更新。
    multimode_ssh_identity(p_session, p_packet);
    if(!p_session->is_ssh)return false;
    if ((p_session->client_ip == p_session->srcip) ||(ntohs(p_session->dstport) == SSHDEFINEPORT)) //(p_session->is_c2s)||
    {  
        p_session->b_src_is_ser = false;
        ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
        init_ssh_session(p_ssh_session);
        p_ssh_session->requst_time = p_session->packet_time;
        p_ssh_session->first_time = p_ssh_session->requst_time;
        return true;
    }
    else if((p_session->client_ip == p_session->dstip) || (ntohs(p_session->srcport) == SSHDEFINEPORT)) //(p_session->is_s2c)||
    {   
        p_session->b_src_is_ser = true;
        ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
        init_ssh_session(p_ssh_session);
        p_ssh_session->requst_time = p_session->packet_time;
        p_ssh_session->first_time = p_ssh_session->requst_time;
        return true;
    }else if(!p_session->direction_clarity)return false; // 为了代码思路清晰，故此添加这个略显累赘的表述。
    return false;
}


void ssh_plugin::potocol_sign_judge(session *p_session, c_packet *p_packet)
{
    if (p_session==NULL || p_packet==NULL)
    {
        return;
    }

    ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
    p_ssh_session->packet_time = p_packet->m_timeval;
    // 连接 去除
    if (!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }
    // 连接 去除  
    if (p_packet->p_tcphdr->fin == 1)
    {
        if (p_session->client.get_data_len() > 0 || p_session->server.get_data_len())
        {
            SET_EXPORT(p_session);
        }
        SET_SESSION_OVER(p_session);
        return;
    }
    if (p_ssh_session->status == SSH_END) 
    {
        SET_SESSION_OVER(p_session);
        return ;
    }
    if ((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) || 
            (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port() ) )
    {
       p_ssh_session->b_c2s = false;
    }
    else
    {
        p_ssh_session->b_c2s = true;
    }

    // 协议识别的方向 --- 需要判断方向
    uint32_t seq = p_packet->get_seqnumber();
    uint32_t len = p_packet->app_data_len;

    p_ssh_session->len_sum += len;

    if (len == 0)
    {   

        p_ssh_session->p_data = NULL;
        return;
    }
    //公共字段提取
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    /*  p_session->packet_len += p_packet->buff_len;
        ++p_session->packet_num;

        if (p_session->packet_begin_time == 0)
        {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
        }
        if (p_session->packet_end_time != 0)
        {
        p_session->packet_end_time = p_packet->m_timeval;
        }*/

    char *p_data = (char *)p_packet->p_app_data;
    if (p_data == NULL)
    {
        return;
    }

    if (p_ssh_session->b_c2s)//c2s方向
    {
        //组包
        p_session->client.add_tcp_packet(len, p_data, seq);
        p_ssh_session->p_data = p_session->client.get_tcp_data(p_ssh_session->len);
        if (p_ssh_session->p_data==NULL || p_ssh_session->len==0)
        {
            return;
        }

        if (p_ssh_session->direction == 0)
        {
            p_ssh_session->direction = 1;
        }
        else if (p_ssh_session->direction == 2)
        {
            p_ssh_session->direction = 3;
        }
        if (p_ssh_session->len>3 && strncmp(p_ssh_session->p_data,"SSH-",4) == 0)//版本协商包判断结束退出
        {
            //if (*(p_ssh_session->p_data + p_ssh_session->len -2) == '\x0d'||*(p_ssh_session->p_data + p_ssh_session->len -1) == '\x0a')
            if (*(p_ssh_session->p_data + p_ssh_session->len -1) == '\x0a')
            {
                SET_EXPORT(p_session);
            }
        }
        else if (p_ssh_session->len>5 && 
                (*(p_ssh_session->p_data+5)==KEI || 
                 *(p_ssh_session->p_data+5)==DHKEX_INIT || 
                 *(p_ssh_session->p_data+5)==DHKEX_GEX_INIT || 
                 *(p_ssh_session->p_data+5)==NK))
        {
            uint32_t len = p_ssh_session->len;
            uint32_t tmp = len ;
            if (len == 0)
            {
                return;
            }
            uint32_t offise = 0;
            for(; len > 0; )
            {
                if (offise < 0 || tmp < offise+4)
                {
                    return;
                }

                p_ssh_session-> packet_length = ntohl(*(uint32_t *)(p_data + offise));
                if (p_ssh_session-> packet_length == 0)
                {
                    return;
                }

                if (p_ssh_session->packet_length+4 < len)//判断处理连包
                {
                    offise += p_ssh_session-> packet_length+4;
                    len -= p_ssh_session-> packet_length+4;
                    p_ssh_session->is_link = 1;
                    ++p_ssh_session->link_num;
                }
                else if (p_ssh_session->packet_length+4 == len)//整包
                {
                    break;
                }
                else
                {   //不规范的连包
                    return;
                }
            }
            SET_EXPORT(p_session);
        }
        else
        {   //其他包结束退出
            p_session->client.clear_buf();
        }
    }
    else 
    {//s2c方向
        p_ssh_session->response_time = p_session->packet_time;
        //组包
        p_session->server.add_tcp_packet(len, p_data, seq);
        p_ssh_session->p_data = p_session->server.get_tcp_data(p_ssh_session->len);
        if (p_ssh_session->p_data==NULL || p_ssh_session->len==0)
        {
            return;
        }
        if (p_ssh_session->direction == 0)
        {
            p_ssh_session->direction = 2;
        }
        else if (p_ssh_session->direction == 1)
        {
            p_ssh_session->direction = 3;
        }

        if (p_ssh_session->len>3 && strncmp(p_ssh_session->p_data, "SSH-", 4) == 0)//版本协商包判断结束退出
        {
            //if (*(p_ssh_session->p_data + p_ssh_session->len -2) == '\x0d'||*(p_ssh_session->p_data + p_ssh_session->len -1) == '\x0a')
            if (*(p_ssh_session->p_data + p_ssh_session->len -1) == '\x0a')
            {
                SET_EXPORT(p_session);
            }
        }
        else if (p_ssh_session->len>6 &&
                (*(p_ssh_session->p_data+5)==KEI || 
                 *(p_ssh_session->p_data+5)==DHKEX_GEX_GROUP || 
                 *(p_ssh_session->p_data+5)==DHKEX_GEX_REPLY || 
                 *(p_ssh_session->p_data+5)==NK))
        {
            //int len = p_ssh_session->len;
            uint32_t len = p_ssh_session->len;
            uint32_t offise = 0;
            uint32_t tmp = len;
            for(; len>0 ;)
            {
                if (offise < 0 || tmp < offise+4)
                {
                    return;
                }

                p_ssh_session->packet_length = ntohl(*(uint32_t *)(p_data+offise));
                if (p_ssh_session->packet_length == 0)
                {
                    return;
                }

                if (p_ssh_session->packet_length+4 < len)  //连包 
                {
                    offise += p_ssh_session->packet_length+4;
                    len -= p_ssh_session->packet_length+4;
                    p_ssh_session->is_link = 1;
                    ++p_ssh_session->link_num;
                }
                else if (p_ssh_session-> packet_length+4 == len)//整包
                {
                    break;
                }
                else//不规范的连包
                {
                    return;
                }
            }
            SET_EXPORT(p_session);
        }
        else
        {//其他包判断结束退出
            p_session->server.clear_buf();
        }
    }

    return;
}

void ssh_plugin::Client_Key_Exchange(ssh_session *p_ssh_session, char *p)
{
    /*
     ** *****************************************************************************************
     * uint32_t       |uint8_t        |uint8_t  |16bytes cookie                   |
     * packet_length  |padding_length |msgcode  |                                 |random_padding
     *                |               |         |   kex_algorithms                |
     *                |               |         |   s_host_key_algorithms         |
     *                |               |         |   encryption_algorithms_c2s     |
     *                |               |         |   encryption_algorithms_s2c     |
     *                |               |         |   mac_algorithms_c2s            |
     *                |               |         |   mac_algorithms_s2c            |
     *                |               |         |   compression_algorithms_c2s    |
     *                |               |         |   compression_algorithms_s2c    |
     *                |               |         |                                 |
     *                |               |         |bool   first_kex_packet_follows  |
     *                |               |         |   random_padding                |
     **********************************************************************************************
     */
    uint32_t offset1 = 0,offset2 = 0;
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->padding_length = *(p+4);
    p_ssh_session->msgcode = *(p+5);
    p_ssh_session->p_ssh_detail->cookie = new char[16];
    memcpy(p_ssh_session->p_ssh_detail->cookie, p+6, 16);
    offset1 = ntohl(*(uint32_t *)(p+22));
    if (offset1>(p_ssh_session->len-26) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->kex_algorithms_c_len = offset1;
    p_ssh_session->p_ssh_detail->kex_algorithms_c = new char[offset1];
    memcpy(p_ssh_session->p_ssh_detail->kex_algorithms_c, p+26, offset1);

    offset2 = ntohl(*(uint32_t *)(p+26+offset1));

    if (offset2>(p_ssh_session->len-30-offset1) || offset2<0)
    {
        return;
    }
    /*p_ssh_session->p_ssh_detail->s_host_key_algorithms_len = offset2;
      p_ssh_session->p_ssh_detail->s_host_key_algorithms = new char[offset2];
      memcpy(p_ssh_session->p_ssh_detail->s_host_key_algorithms, p+30+offset1, offset2);
      */
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+30+offset1));

    if (offset2>(p_ssh_session->len-34-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->encryption_algorithms_c2s_len = offset2;
    p_ssh_session->p_ssh_detail->encryption_algorithms_c2s = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->encryption_algorithms_c2s, p+34+offset1, offset2);
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+34+offset1));

    if (offset2>(p_ssh_session->len-38-offset1) || offset2<0)
    {
        return;
    }
    /* p_ssh_session->p_ssh_detail->encryption_algorithms_s2c_len = offset2;
       p_ssh_session->p_ssh_detail->encryption_algorithms_s2c = new char[offset2];
       memcpy(p_ssh_session->p_ssh_detail->encryption_algorithms_s2c, p+38+offset1, offset2);
       */
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+38+offset1));

    if (offset2>(p_ssh_session->len-42-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->mac_algorithms_c2s_len = offset2;
    p_ssh_session->p_ssh_detail->mac_algorithms_c2s = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->mac_algorithms_c2s, p+42+offset1, offset2);

    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+42+offset1));
    if (offset2>(p_ssh_session->len-46-offset1) || offset2<0)
    {
        return;
    }
    /*p_ssh_session->p_ssh_detail->mac_algorithms_s2c_len = offset2;
      p_ssh_session->p_ssh_detail->mac_algorithms_s2c = new char[offset2];
      memcpy(p_ssh_session->p_ssh_detail->mac_algorithms_s2c, p+46+offset1, offset2);
      */
    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+46+offset1));
    if (offset2>(p_ssh_session->len-50-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->compression_algorithms_c2s_len = offset2;
    p_ssh_session->p_ssh_detail->compression_algorithms_c2s = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->compression_algorithms_c2s, p+50+offset1, offset2);

    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+50+offset1));
    if (offset2>(p_ssh_session->len-54-offset1) || offset2<0)
    {
        return;
    }
    /*   p_ssh_session->p_ssh_detail->compression_algorithms_s2c_len = offset2;
         p_ssh_session->p_ssh_detail->compression_algorithms_s2c = new char[offset2];
         memcpy(p_ssh_session->p_ssh_detail->compression_algorithms_s2c, p+54+offset1, offset2);
         */
    offset1 += offset2;
    p_ssh_session->p_ssh_detail->first_kex_packet_follows = *(p+62+offset1);
    offset2 = p_ssh_session->packet_length-offset1-63;
    if (offset2>(p_ssh_session->len-67-offset1) || offset2<0)
    {
        return;
    }
    return;
}
void ssh_plugin::Server_Key_Exchange(ssh_session *p_ssh_session, char *p)
{
    /*
     ** *****************************************************************************************
     * uint32_t       |uint8_t        |uint8_t  |16bytes cookie                   |
     * packet_length  |padding_length |msgcode  |                                 |random_padding
     *                |               |         |   kex_algorithms                |
     *                |               |         |   s_host_key_algorithms         |
     *                |               |         |   encryption_algorithms_c2s     |
     *                |               |         |   encryption_algorithms_s2c     |
     *                |               |         |   mac_algorithms_c2s            |
     *                |               |         |   mac_algorithms_s2c            |
     *                |               |         |   compression_algorithms_c2s    |
     *                |               |         |   compression_algorithms_s2c    |
     *                |               |         |                                 |
     *                |               |         |bool   first_kex_packet_follows  |
     *                |               |         |   random_padding                |
     **********************************************************************************************
     */
    uint32_t offset1 = 0,offset2 = 0;
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->padding_length = *(p+4);
    p_ssh_session->msgcode = *(p+5);
    /*   p_ssh_session->p_ssh_detail->cookie = new char[16];
         memcpy(p_ssh_session->p_ssh_detail->cookie, p+6, 16);
         */
    offset1 = ntohl(*(uint32_t *)(p+22));
    if (offset1>(p_ssh_session->len-26) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->kex_algorithms_s_len = offset1;
    p_ssh_session->p_ssh_detail->kex_algorithms_s = new char[offset1];
    memcpy(p_ssh_session->p_ssh_detail->kex_algorithms_s, p+26, offset1);

    offset2 = ntohl(*(uint32_t *)(p+26+offset1));

    if (offset2>(p_ssh_session->len-30-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->s_host_key_algorithms_len = offset2;
    p_ssh_session->p_ssh_detail->s_host_key_algorithms = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->s_host_key_algorithms, p+30+offset1, offset2);
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+30+offset1));

    if (offset2>(p_ssh_session->len-34-offset1) || offset2<0)
    {
        return;
    }
    /*p_ssh_session->p_ssh_detail->encryption_algorithms_c2s_len = offset2;
      p_ssh_session->p_ssh_detail->encryption_algorithms_c2s = new char[offset2];
      memcpy(p_ssh_session->p_ssh_detail->encryption_algorithms_c2s, p+34+offset1, offset2);
      */
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+34+offset1));

    if (offset2>(p_ssh_session->len-38-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->encryption_algorithms_s2c_len = offset2;
    p_ssh_session->p_ssh_detail->encryption_algorithms_s2c = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->encryption_algorithms_s2c, p+38+offset1, offset2);
    offset1 += offset2;

    offset2 = ntohl(*(uint32_t *)(p+38+offset1));

    if (offset2>(p_ssh_session->len-42-offset1) || offset2<0)
    {
        return;
    }
    /* p_ssh_session->p_ssh_detail->mac_algorithms_c2s_len = offset2;
       p_ssh_session->p_ssh_detail->mac_algorithms_c2s = new char[offset2];
       memcpy(p_ssh_session->p_ssh_detail->mac_algorithms_c2s, p+42+offset1, offset2);
       */
    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+42+offset1));
    if (offset2>(p_ssh_session->len-46-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->mac_algorithms_s2c_len = offset2;
    p_ssh_session->p_ssh_detail->mac_algorithms_s2c = new char[offset2];
    memset(p_ssh_session->p_ssh_detail->mac_algorithms_s2c,0x00,offset2+1);
    memcpy(p_ssh_session->p_ssh_detail->mac_algorithms_s2c, p+46+offset1, offset2);

    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+46+offset1));
    if (offset2>(p_ssh_session->len-50-offset1) || offset2<0)
    {
        return;
    }
    /*   p_ssh_session->p_ssh_detail->compression_algorithms_c2s_len = offset2;
         p_ssh_session->p_ssh_detail->compression_algorithms_c2s = new char[offset2];
         memcpy(p_ssh_session->p_ssh_detail->compression_algorithms_c2s, p+50+offset1, offset2);
         */
    offset1 += offset2;
    offset2 = ntohl(*(uint32_t *)(p+50+offset1));
    if (offset2>(p_ssh_session->len-54-offset1) || offset2<0)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->compression_algorithms_s2c_len = offset2;
    p_ssh_session->p_ssh_detail->compression_algorithms_s2c = new char[offset2];
    memcpy(p_ssh_session->p_ssh_detail->compression_algorithms_s2c, p+54+offset1, offset2);

    offset1 += offset2;
    p_ssh_session->p_ssh_detail->first_kex_packet_follows = *(p+62+offset1);
    offset2 = p_ssh_session->packet_length-offset1-63;
    if (offset2>(p_ssh_session->len-67-offset1) || offset2<0)
    {
        return;
    }
    return;
}

void ssh_plugin::DH_Key_Exchange_Init(ssh_session *p_ssh_session)
{
    if (!p_ssh_session)
    {
        return;
    }

    char *p = p_ssh_session->p_data;
    uint32_t len = p_ssh_session->len;
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }

    if(len < 10)
    {
        return;
    }

    p_ssh_session->padding_length = *(p+4);
    p_ssh_session->msgcode = *(p+5);
    if(p_ssh_session->msgcode!=30&&p_ssh_session->msgcode!=32)
    {
        return ;
    }
    uint32_t offset1 = 0;
    uint32_t offset2 = 0;
    offset1 = ntohl(*(uint32_t *)(p+6));
    if (offset1 < 0 || offset1+10 > p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->e_len = offset1;
    p_ssh_session->p_ssh_detail->e = new char[offset1];
    memcpy(p_ssh_session->p_ssh_detail->e, p+10, offset1);
    offset2 = p_ssh_session->packet_length-6-offset1;
    if (offset2 < 0 || offset2+offset1+10>p_ssh_session->len)
    {
        return;
    }
    return;
}

void ssh_plugin::DH_Key_Exchange_Reply(ssh_session *p_ssh_session)
{
    if (!p_ssh_session)
    {
        return;
    }

    char *p = p_ssh_session->p_data;
    uint32_t len = p_ssh_session->len;
    if (p == NULL || len < 10)
    {
        return;
    }
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->padding_length = *(p+4);
    p_ssh_session->msgcode = *(p+5);
    if(p_ssh_session->msgcode!=31&&p_ssh_session->msgcode!=33)
        //if(p_ssh_session->msgcode!=33)
    {
        return;
    }
    uint32_t offset1=0;
    uint32_t offset2=0;
    uint32_t offset3=0;
    offset1 = ntohl(*(uint32_t *)(p+6));
    if (offset1 < 0 || offset1+10 > p_ssh_session->len)
    {
        return;
    }

    p_ssh_session->p_ssh_detail->K_S_len = offset1;

    offset2 = ntohl(*(uint32_t*)(p+10+offset1));
    if (offset2 < 0 || offset2+offset1+14>p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->f_len = offset2;
    offset1 += offset2;

    offset3 = ntohl(*(uint32_t*)(p+14+offset1));
    if (offset3 < 0 || offset3+offset1+18 > p_ssh_session->len)
    {
        return;
    }
    p_ssh_session->p_ssh_detail->H_s_len = offset3;
    if(offset3==0)
    {
        p_ssh_session->p_ssh_detail->H_s=NULL;
        p_ssh_session->p_ssh_detail->P_len=p_ssh_session->p_ssh_detail->K_S_len;
        p_ssh_session->p_ssh_detail->P = new char[p_ssh_session->p_ssh_detail->P_len+1];
        memset(p_ssh_session->p_ssh_detail->P, 0x0, p_ssh_session->p_ssh_detail->P_len+1);
        memcpy(p_ssh_session->p_ssh_detail->P, p+10, p_ssh_session->p_ssh_detail->P_len);
        p_ssh_session->p_ssh_detail->G_len=p_ssh_session->p_ssh_detail->f_len;
        p_ssh_session->p_ssh_detail->G = new char[p_ssh_session->p_ssh_detail->f_len +1];
        memset(p_ssh_session->p_ssh_detail->G, 0x0, p_ssh_session->p_ssh_detail->f_len +1);
        memcpy(p_ssh_session->p_ssh_detail->G, p+14+p_ssh_session->p_ssh_detail->P_len, p_ssh_session->p_ssh_detail->f_len);
    }
    else
    {
        p_ssh_session->p_ssh_detail->K_S = new char[p_ssh_session->p_ssh_detail->K_S_len+1];
        memset(p_ssh_session->p_ssh_detail->K_S, 0x0, p_ssh_session->p_ssh_detail->K_S_len+1);
        memcpy(p_ssh_session->p_ssh_detail->K_S, p+10, p_ssh_session->p_ssh_detail->K_S_len);

        p_ssh_session->p_ssh_detail->f = new char[p_ssh_session->p_ssh_detail->f_len +1];
        memset(p_ssh_session->p_ssh_detail->f, 0x0, p_ssh_session->p_ssh_detail->f_len +1);
        memcpy(p_ssh_session->p_ssh_detail->f, p+14+p_ssh_session->p_ssh_detail->K_S_len, p_ssh_session->p_ssh_detail->f_len);

        p_ssh_session->p_ssh_detail->H_s = new char[p_ssh_session->p_ssh_detail->H_s_len+1];
        memset(p_ssh_session->p_ssh_detail->H_s, 0x0, p_ssh_session->p_ssh_detail->H_s_len+1);
        memcpy(p_ssh_session->p_ssh_detail->H_s, p+18+p_ssh_session->p_ssh_detail->K_S_len+p_ssh_session->p_ssh_detail->f_len,p_ssh_session->p_ssh_detail->H_s_len);
    }
    offset1 += offset3;

    offset2 = p_ssh_session->packet_length-14-offset1;
    if (offset2 < 0 || offset2+offset1+18 > p_ssh_session->len)
    {
        return;
    }

    return;
}

/*void ssh_plugin::DH_Key_Exchange_Group(ssh_session *p_ssh_session)
  {
  if (!p_ssh_session)
  {
  return;
  }

  char *p = p_ssh_session->p_data;
  uint32_t len = p_ssh_session->len;
  if (p == NULL || len < 10)
  {
  return;
  }
  p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
  if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
  {
  return;
  }
  p_ssh_session->padding_length = *(p+4);
  p_ssh_session->msgcode = *(p+5);
  if(p_ssh_session->msgcode!=31)
  {
  return;
  }
  uint32_t offset1=0;
  uint32_t offset2=0;
  offset1 = ntohl(*(uint32_t *)(p+6));
  if (offset1 < 0 || offset1+10 > p_ssh_session->len)
  {
  return;
  }

  p_ssh_session->p_ssh_detail->P_len = offset1;
  p_ssh_session->p_ssh_detail->P = new char[offset1+1];
  memset(p_ssh_session->p_ssh_detail->P, 0x0, offset1+1);
  memcpy(p_ssh_session->p_ssh_detail->P, p+10, offset1);

  offset2 = ntohl(*(uint32_t*)(p+10+offset1));
  if (offset2 < 0 || offset2+offset1+14>p_ssh_session->len)
  {
  return;
  }
  p_ssh_session->p_ssh_detail->G_len = offset2;
  p_ssh_session->p_ssh_detail->G = new char[offset2+1];
  memset(p_ssh_session->p_ssh_detail->G, 0x0, offset2+1);
  memcpy(p_ssh_session->p_ssh_detail->G, p+14+offset1, offset2);
  offset1 += offset2;

  offset2 = ntohl(*(uint32_t*)(p+14+offset1));
  if (offset2 < 0 || offset2+offset1+18 > p_ssh_session->len)
  {
  return;
  }

  return;
  }*/
void ssh_plugin::New_keys(ssh_session *p_ssh_session)
{
    if (!p_ssh_session)
    {
        return;
    }

    char *p = p_ssh_session->p_data;
    uint32_t len = p_ssh_session->len;
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }

    if(len < 6)
    {
        return;
    }

    p_ssh_session->padding_length = *(p+4);
    p_ssh_session->msgcode = *(p+5);
    //int offset = 0;
    //offset = p_ssh_session->packet_length-2;
    if (p_ssh_session->b_c2s)
    {
        p_ssh_session->status = SSH_END;
    }
    return;
}

// 后续迭代开发留存
void ssh_plugin::Encrypted_packet(ssh_session *p_ssh_session, char *p)
{
    p_ssh_session->packet_length = ntohl(*(uint32_t *)p);
    if (p_ssh_session->packet_length < 0 || p_ssh_session->packet_length > p_ssh_session->len)
    {
        return;
    }
    //uint32_t offset = 0;
    //offset = p_ssh_session->packet_length-20;

    return;
}

void ssh_plugin::pococol_parse_handle(session *p_session)
{
    if (p_session == NULL)
    {
        return;
    }
    ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
    if (p_ssh_session->p_data==NULL || p_ssh_session->len<6)
    {
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        return ;
    }

    char *p = p_ssh_session->p_data;
    uint32_t len = p_ssh_session->len;
    //char *p1 = p;
    int i = 0;
    if (p_ssh_session->b_c2s)
    {
        if (len > 3 && memcmp(p,"SSH-",4) == 0)
        {   *(p_ssh_session->protocol_c) = "";
            p_ssh_session->protocol_c->assign(p);
            string::size_type nPos = p_ssh_session->protocol_c->find("\n");
            if (nPos == string::npos)
            {
                nPos = p_ssh_session->protocol_c->find("\r");
                if (nPos == string::npos)
                {
                    return;
                }

                uint32_t nAll = p_ssh_session->protocol_c->size();
                if (nPos>0 && nPos<nAll)
                {
                    p_ssh_session->protocol_c->erase(nPos, nAll);
                }
            }
            else
            {
                string::size_type npos=0;
                npos = p_ssh_session->protocol_c->find("\r");
                if (npos != string::npos)
                {
                    uint32_t nAll = p_ssh_session->protocol_c->size();
                    if (nPos>0 && nPos<nAll)
                    {
                        p_ssh_session->protocol_c->erase(npos, nAll);
                    }
                }
                else
                {
                    uint32_t nAll = p_ssh_session->protocol_c->size();
                    if (nPos>0 && nPos<nAll)
                    {
                        p_ssh_session->protocol_c->erase(nPos, nAll);
                    }
                }
            }

        }
        else if (len > 6 && (*(p+5) == KEI))
        {
            Client_Key_Exchange(p_ssh_session,p);
        }
        else if (len > 6 && ((*(p+5) == DHKEX_INIT)||*(p+5) == DHKEX_GEX_INIT))
        {
            DH_Key_Exchange_Init(p_ssh_session);
        }
        else if (len > 6 && (*(p+5) == NK))
        {
            New_keys(p_ssh_session);
        }
        else
        {
            p_ssh_session->is_link = 0;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            return ;
        }

        if (p_ssh_session->is_link == 1)
        {
            SET_EXPORT(p_session);
            ++i;
            if (i == p_ssh_session->link_num)
            {
                p_ssh_session->is_link = 0;
                p_ssh_session->link_num = 0;
            }
        }

        SET_EXPORT(p_session);

        p_session->client.clear_buf();
        p_session->server.clear_buf();
    }
    else
    {
        if (len > 3 && memcmp(p,"SSH-",4) == 0)
        {   *(p_ssh_session->protocol_s)="";
            p_ssh_session->protocol_s->assign(p);
            string::size_type nPos=0;
            nPos = p_ssh_session->protocol_s->find("\n");
            if (nPos == string::npos)
            {
                nPos = p_ssh_session->protocol_s->find("\r");
                if (nPos == string::npos)
                {
                    return;
                }

                uint32_t nAll = p_ssh_session->protocol_s->size();
                if (nPos>0 && nPos<nAll)
                {
                    p_ssh_session->protocol_s->erase(nPos, nAll);
                }
            }
            else
            { 
                string::size_type  npos=0;
                npos = p_ssh_session->protocol_s->find("\r");
                if (npos != string::npos)
                {
                    uint32_t nAll = p_ssh_session->protocol_s->size();
                    if (nPos>0 && nPos<nAll)
                    {
                        p_ssh_session->protocol_s->erase(npos, nAll);
                    }
                }
                else
                {
                    uint32_t nAll = p_ssh_session->protocol_s->size();
                    if (nPos>0 && nPos<nAll)
                    {
                        p_ssh_session->protocol_s->erase(nPos, nAll);
                    }
                }
            }
        }
        else if (len > 6 && (*(p+5) == KEI))
        {
            Server_Key_Exchange(p_ssh_session, p);
        }
        else if (len > 6 && *(p+5) == DHKEX_GEX_REPLY||DHKEX_GEX_GROUP)
        {
            DH_Key_Exchange_Reply(p_ssh_session);
        }
        /* else if (len > 6 && (*(p+5) == DHKEX_GEX_GROUP))
           {
           DH_Key_Exchange_Group(p_ssh_session);
           }*/
        else if (len > 6 && (*(p+5) == NK))
        {
            New_keys(p_ssh_session);
        }
        else
        {
            p_ssh_session->is_link = 0;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            return ;
        }

        if (p_ssh_session->is_link == 1)
        {
            i++;
            if (i == p_ssh_session->link_num)
            {
                p_ssh_session->is_link = 0;
                p_ssh_session->link_num = 0;
            }

            SET_EXPORT(p_session);
        }
    }

    p_session->client.clear_buf();
    p_session->server.clear_buf();

    if (p_ssh_session->status == SSH_END)
    {
        p_ssh_session->last_time = p_session->packet_time;
        p_session -> p_send_buf = NO_NULL;
        p_session -> send_len = 5;
    }
    return;
}

void ssh_plugin::potocol_data_handle(session* p_session, list<data_interface> *p_list)
{
    int is_ipv6;
    int is_ipv4;
    uint32_t busy_time = 0;

    ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
    if ((p_ssh_session==NULL) || 
            (p_ssh_session->protocol_c->empty() && 
             p_ssh_session->protocol_s->empty() && 
             p_ssh_session->p_ssh_detail->kex_algorithms_c==NULL && 
             p_ssh_session->p_ssh_detail->kex_algorithms_s==NULL && 
             p_ssh_session->p_ssh_detail->e==NULL && 
             p_ssh_session->p_ssh_detail->K_S==NULL))
    {
        return;
    }

    output_interface.init();
    //bool b_msg_c2s = p_ssh_session->b_c2s;
    output_interface.direction = p_ssh_session->direction;

    //计算通信速率

    double session_duration = (double)(p_session->packet_end_time - p_session->packet_begin_time);
    if (session_duration != 0)
    {
        //output_interface.communication_rate = ((double)total_throughput / session_duration)*1000000;
        output_interface.communication_rate = ((double)p_session->packet_len / session_duration)*1000000;
    }
    else
    {
        output_interface.communication_rate = 1;
    }
    //解析消息(最简单的处理方式，以后根据需求变化需要进行重构)
    if(*(p_ssh_session->protocol_c) != "")
    {
    output_interface.protocol_c = (char *)p_ssh_session->protocol_c->c_str();
    }
    if(*(p_ssh_session->protocol_s) != "")
    {
    output_interface.protocol_s = (char *)p_ssh_session->protocol_s->c_str();
    }
    output_interface.cookie = p_ssh_session->p_ssh_detail->cookie;

    output_interface.kex_algorithms_c_len = p_ssh_session->p_ssh_detail->kex_algorithms_c_len;
    output_interface.kex_algorithms_s_len = p_ssh_session->p_ssh_detail->kex_algorithms_s_len;
    output_interface.kex_algorithms_c = p_ssh_session->p_ssh_detail->kex_algorithms_c;
    output_interface.kex_algorithms_s = p_ssh_session->p_ssh_detail->kex_algorithms_s;
    output_interface.s_host_key_algorithms_len = p_ssh_session->p_ssh_detail->s_host_key_algorithms_len;
    output_interface.s_host_key_algorithms = p_ssh_session->p_ssh_detail->s_host_key_algorithms;
    output_interface.encryption_algorithms_c2s_len = p_ssh_session->p_ssh_detail->encryption_algorithms_c2s_len;
    output_interface.encryption_algorithms_c2s = p_ssh_session->p_ssh_detail->encryption_algorithms_c2s;
    output_interface.encryption_algorithms_s2c_len = p_ssh_session->p_ssh_detail->encryption_algorithms_s2c_len;
    output_interface.encryption_algorithms_s2c = p_ssh_session->p_ssh_detail->encryption_algorithms_s2c;
    output_interface.mac_algorithms_c2s_len = p_ssh_session->p_ssh_detail->mac_algorithms_c2s_len;
    output_interface.mac_algorithms_c2s = p_ssh_session->p_ssh_detail->mac_algorithms_c2s;
    output_interface.mac_algorithms_s2c_len = p_ssh_session->p_ssh_detail->mac_algorithms_s2c_len;
    output_interface.mac_algorithms_s2c = p_ssh_session->p_ssh_detail->mac_algorithms_s2c;
    output_interface.compression_algorithms_c2s_len = p_ssh_session->p_ssh_detail->compression_algorithms_c2s_len;
    output_interface.compression_algorithms_c2s = p_ssh_session->p_ssh_detail->compression_algorithms_c2s;
    output_interface.compression_algorithms_s2c_len = p_ssh_session->p_ssh_detail->compression_algorithms_s2c_len;
    output_interface.compression_algorithms_s2c = p_ssh_session->p_ssh_detail->compression_algorithms_s2c;
    output_interface.e_len = p_ssh_session->p_ssh_detail->e_len;
    output_interface.e = p_ssh_session->p_ssh_detail->e;

    output_interface.K_S_len = p_ssh_session->p_ssh_detail->K_S_len;
    output_interface.K_S = p_ssh_session->p_ssh_detail->K_S;
    output_interface.f_len = p_ssh_session->p_ssh_detail->f_len;
    output_interface.f = p_ssh_session->p_ssh_detail->f;
    output_interface.H_s_len = p_ssh_session->p_ssh_detail->H_s_len;
    output_interface.H_s = p_ssh_session->p_ssh_detail->H_s;
    output_interface.P_len = p_ssh_session->p_ssh_detail->P_len;
    output_interface.P = p_ssh_session->p_ssh_detail->P;
    output_interface.G_len = p_ssh_session->p_ssh_detail->G_len;
    output_interface.G = p_ssh_session->p_ssh_detail->G;

    //取基本信息
    if (p_session->b_src_is_ser)
    {
        output_interface.client_port = p_session->dstport;
        output_interface.client_ip = p_session->dstip;
        output_interface.server_port = p_session->srcport;
        output_interface.server_ip = p_session->srcip;
    }
    else
    {
        output_interface.client_port = p_session->srcport;
        output_interface.client_ip = p_session->srcip;
        output_interface.server_port = p_session->dstport;
        output_interface.server_ip = p_session->dstip;
    }

    output_interface.mac_line_number = p_session->mac_line_num;
    output_interface.device_num = p_session-> device_num;
    output_interface.time = p_ssh_session->packet_time;
    classify_ip_kind_info(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
    output_interface.is_ipv4 = is_ipv4;
    output_interface.is_ipv6 = is_ipv6;
    output_interface.is_mpls = p_session->m_is_mpls;
    output_interface.n_label = p_session->m_label;
    output_interface.in_nerlabel = p_session->m_inner_label;
    output_interface.other_label = p_session->m_other_lable;
    output_interface.proto = p_session->proto_type;
    output_interface.total_payloadbytes = p_session->packet_len;
    output_interface.total_payloadpackets = p_session->packet_num;
    if (p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    output_interface.duration = busy_time;
    //将数据加入接口
    ssh_interface_handling(p_list);
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    SET_SESSION_OVER(p_session);
    return ;
}

void ssh_plugin::time_out(session* p_session, uint64_t check_time)
{
    ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
    if (check_time-p_session->last_packet_time > ssh_time_out*1000000)
    {   
        if (!p_ssh_session->protocol_c->empty() || 
                !p_ssh_session->protocol_s->empty() || 
                p_ssh_session->p_ssh_detail->kex_algorithms_c!=NULL || 
                p_ssh_session->p_ssh_detail->kex_algorithms_s!=NULL || 
                p_ssh_session->p_ssh_detail->e!=NULL || 
                p_ssh_session->p_ssh_detail->K_S!=NULL||p_ssh_session->p_ssh_detail->P!=NULL)
        {
            SET_EXPORT(p_session);
            SET_SESSION_OVER(p_session);
            p_session->send_len = 1;
            p_session->p_send_buf = NO_NULL;
        }
    }
}

void ssh_plugin::resources_recovery(session * p_session)
{
    ssh_session *p_ssh_session = (ssh_session *)p_session->expansion_data;
    if (p_ssh_session->protocol_c != NULL)
    {
        delete p_ssh_session->protocol_c;
    }
    p_ssh_session->protocol_c = NULL;

    if (p_ssh_session->protocol_s != NULL)
    {
        delete p_ssh_session->protocol_s;
    }
    p_ssh_session->protocol_s = NULL;

    if (p_ssh_session->p_ssh_detail->payload != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->payload;
    }
    p_ssh_session->p_ssh_detail->payload = NULL;

    if (p_ssh_session->p_ssh_detail->random_padding != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->random_padding;
    }
    p_ssh_session->p_ssh_detail->random_padding = NULL;

    if (p_ssh_session->p_ssh_detail->cookie != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->cookie;
    }
    p_ssh_session->p_ssh_detail->cookie = NULL;

    if (p_ssh_session->p_ssh_detail->kex_algorithms_c != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->kex_algorithms_c;
    }
    p_ssh_session->p_ssh_detail->kex_algorithms_c = NULL;
    if (p_ssh_session->p_ssh_detail->kex_algorithms_s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->kex_algorithms_s;
    }
    p_ssh_session->p_ssh_detail->kex_algorithms_s = NULL;

    if (p_ssh_session->p_ssh_detail->s_host_key_algorithms != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->s_host_key_algorithms;
    }
    p_ssh_session->p_ssh_detail->s_host_key_algorithms = NULL;

    if (p_ssh_session->p_ssh_detail->encryption_algorithms_c2s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->encryption_algorithms_c2s;
    }
    p_ssh_session->p_ssh_detail->encryption_algorithms_c2s = NULL;

    if (p_ssh_session->p_ssh_detail->encryption_algorithms_s2c != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->encryption_algorithms_s2c;
    }
    p_ssh_session->p_ssh_detail->encryption_algorithms_s2c = NULL;

    if (p_ssh_session->p_ssh_detail->mac_algorithms_c2s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->mac_algorithms_c2s;
    }
    p_ssh_session->p_ssh_detail->mac_algorithms_c2s = NULL;

    if (p_ssh_session->p_ssh_detail->mac_algorithms_s2c != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->mac_algorithms_s2c;
    }
    p_ssh_session->p_ssh_detail->mac_algorithms_s2c = NULL;

    if (p_ssh_session->p_ssh_detail->compression_algorithms_c2s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->compression_algorithms_c2s;
    }
    p_ssh_session->p_ssh_detail->compression_algorithms_c2s = NULL;

    if (p_ssh_session->p_ssh_detail->compression_algorithms_s2c != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->compression_algorithms_s2c;
    }
    p_ssh_session->p_ssh_detail->compression_algorithms_s2c = NULL;

    if (p_ssh_session->p_ssh_detail->languages_c2s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->languages_c2s;
    }
    p_ssh_session->p_ssh_detail->languages_c2s = NULL;

    if (p_ssh_session->p_ssh_detail->languages_s2c != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->languages_s2c;
    }
    p_ssh_session->p_ssh_detail->languages_s2c = NULL;

    if (p_ssh_session->p_ssh_detail->e != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->e;
    }
    p_ssh_session->p_ssh_detail->e = NULL;

    if (p_ssh_session->p_ssh_detail->K_S != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->K_S;
    }
    p_ssh_session->p_ssh_detail->K_S = NULL;

    if (p_ssh_session->p_ssh_detail->f != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->f;
    }
    p_ssh_session->p_ssh_detail->f = NULL;

    if (p_ssh_session->p_ssh_detail->H_s != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->H_s;
    }
    p_ssh_session->p_ssh_detail->H_s = NULL;

    if (p_ssh_session->p_ssh_detail->P != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->P;
    }
    p_ssh_session->p_ssh_detail->P = NULL;

    if (p_ssh_session->p_ssh_detail->G != NULL)
    {
        delete []p_ssh_session->p_ssh_detail->G;
    }
    p_ssh_session->p_ssh_detail->G = NULL;

    if (p_ssh_session->p_ssh_detail != NULL)
    {
        delete p_ssh_session->p_ssh_detail;
    }
    p_ssh_session->p_ssh_detail = NULL;
}

//SSH插件接口数据处理函数
void ssh_plugin::ssh_interface_handling(list<data_interface> *p_list)
{
    data_interface m_data;

    if (data_interface_type==NETSEND)
    {
        net_str *p_net = new net_str;
        p_net->msg = new CAmsg;
        p_net->msg->Clear();
        p_net->msg->set_type(28);//ssh  

        ssh_msg * p_ssh = p_net->msg->mutable_ssh();
        Comm_msg* p_comm = p_ssh->mutable_comm_msg();
        //公共消息
        p_comm ->set_src_ip(output_interface.client_ip.ip_str());
        p_comm ->set_src_port(ntohs(output_interface.client_port));
        p_comm ->set_dst_ip(output_interface.server_ip.ip_str());
        p_comm ->set_dst_port(ntohs(output_interface.server_port));
        p_comm ->set_line_num(output_interface.mac_line_number);
        p_comm ->set_dev_num(output_interface.device_num);
        p_comm ->set_time(output_interface.time);
        //add news common header
        p_comm->set_is_ipv4(output_interface.is_ipv4);
        p_comm->set_is_ipv6(output_interface.is_ipv6);
        p_comm->set_proto(output_interface.proto);
        p_comm->set_link_layer_type(0);
        p_comm ->set_is_mpls(output_interface.is_mpls);
        p_comm ->set_n_label(output_interface.n_label);
        p_comm ->set_inner_label(output_interface.in_nerlabel);
        p_comm ->set_other_label(output_interface.other_label);
        p_comm ->set_total_pay_load_bytes(output_interface.total_payloadbytes);
        p_comm ->set_tatal_pay_load_packets(output_interface.total_payloadpackets);
        p_comm ->set_duration(output_interface.duration);
        //SSH消息
        p_ssh->set_protocol_family(1210004);//
        p_ssh->set_communication_rate(output_interface.communication_rate);
        p_ssh->set_direction(output_interface.direction);
        if (output_interface.protocol_c != NULL)
        {
            p_ssh->set_protocol_c(output_interface.protocol_c);
        }
        if (output_interface.protocol_s != NULL)
        {
            p_ssh->set_protocol_s(output_interface.protocol_s);
        }
        if (output_interface.cookie != NULL)
        {
            p_ssh->set_cookie(output_interface.cookie, 16);
        }
        if (output_interface.kex_algorithms_c != NULL)
        {
            p_ssh->set_kex_algorithms_c(output_interface.kex_algorithms_c, output_interface.kex_algorithms_c_len);
        }
        if (output_interface.kex_algorithms_s != NULL)
        {
            p_ssh->set_kex_algorithms_s(output_interface.kex_algorithms_s, output_interface.kex_algorithms_s_len);
        }
        if (output_interface.s_host_key_algorithms != NULL)
        {
            p_ssh->set_s_host_key_algorithms(output_interface.s_host_key_algorithms,output_interface.s_host_key_algorithms_len);
        }
        if (output_interface.encryption_algorithms_c2s != NULL)
        {
            p_ssh->set_encryption_algorithms_c2s(output_interface.encryption_algorithms_c2s, output_interface.encryption_algorithms_c2s_len);
        }
        if (output_interface.encryption_algorithms_s2c != NULL)
        {
            p_ssh->set_encryption_algorithms_s2c(output_interface.encryption_algorithms_s2c, output_interface.encryption_algorithms_s2c_len);
        }
        if (output_interface.mac_algorithms_c2s != NULL)
        {
            p_ssh->set_mac_algorithms_c2s(output_interface.mac_algorithms_c2s, output_interface.mac_algorithms_c2s_len);
        }
        if (output_interface.mac_algorithms_s2c != NULL)
        {
            p_ssh->set_mac_algorithms_s2c(output_interface.mac_algorithms_s2c, output_interface.mac_algorithms_s2c_len);
        }
        if (output_interface.compression_algorithms_c2s != NULL)
        {
            p_ssh->set_compression_algorithms_c2s(output_interface.compression_algorithms_c2s, output_interface.compression_algorithms_c2s_len);
        }
        if (output_interface.compression_algorithms_s2c != NULL)
        {
            p_ssh->set_compression_algorithms_s2c(output_interface.compression_algorithms_s2c, output_interface.compression_algorithms_s2c_len);
        }
        if (output_interface.e != NULL)
        {
            p_ssh->set_e(output_interface.e, output_interface.e_len);
        }
        if (output_interface.K_S != NULL&&output_interface.f != NULL&&output_interface.H_s != NULL)
        {
            p_ssh->set_k_s(output_interface.K_S, output_interface.K_S_len);
        }
        if (output_interface.K_S != NULL&&output_interface.f != NULL &&output_interface.H_s != NULL)
        {
            p_ssh->set_f(output_interface.f, output_interface.f_len);
        }
        if (output_interface.K_S != NULL&&output_interface.f != NULL&&output_interface.H_s != NULL)
        {
            p_ssh->set_h_s(output_interface.H_s, output_interface.H_s_len);
        }
        if (output_interface.P_len >0)
        {
            p_ssh->set_p_len(output_interface.P_len);
        }
        if (output_interface.P != NULL)
        {
            p_ssh->set_p(output_interface.P, output_interface.P_len);
        }
        if (output_interface.G != NULL)
        {
            p_ssh->set_g(output_interface.G, output_interface.G_len);
        }

        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }
}

