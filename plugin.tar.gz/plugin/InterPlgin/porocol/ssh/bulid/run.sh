 make clean 
 make  
 cp ../lib/libssh.so ../../../../../DataAccessEngine/plugin/InterPlugin/. 
