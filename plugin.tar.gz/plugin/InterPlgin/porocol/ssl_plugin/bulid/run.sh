# Last Update:2016-10-22 11:15:45
#########################################################################
# File Name: run.sh
# Author: wangchenxi
# mail: chinawangchenxi@gmail.com
# Created Time: 2016年10月22日 星期六 11时15分45秒
#########################################################################
#!/bin/bash
make clean
  make
 cp ../lib/libssl_plugin.so $NPR_ROOT/plugin/InterPlugin/. 
