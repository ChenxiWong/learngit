//last Updata:
/**
 *@file ssl_plugin.cpp
 *@brief
 *@author Zhoujuanjuan
 *@modify by zq
 *@version:
 *@data 2016-06-28
 */

#include "ssl_plugin.h"
#include <commit_tools.h>
#include <string.h>

#define SSLDEFINEPORT 443

static bool b_check_config  = true;

extern "C"
{
    int get_plugin_id()
    {
        return 10010;
    }

    protocol_parse_base_handle *attach(attach_info *p)
    {
        p_attach_info = p;
        return new ssl_plugin();
    }
};

ssl_plugin::ssl_plugin()
{
    data_interface_type = FILESEND;
    ssl_time_out = 60;
    reload();
}

ssl_plugin::~ssl_plugin()
{

}

void ssl_plugin::reload()
{
    string tmp = "";
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/ssl_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char *p_value = (char *)xml.get_value("/config/send_data_type");
    if (p_value != NULL)
    {
        tmp = p_value;
        if (tmp == "file")//文件接口
        {
            data_interface_type = FILESEND;
        }
        else if (tmp == "net")
        {
            data_interface_type = NETSEND;
        }
    }

    if(b_check_config)
    {
        b_check_config = false;
        //协议识别
        string path = "/config/DFI";
        int num  = xml.get_value_count(path.c_str());
        for(int i = 0 ; i < num ; i++)
        {
            string xpath = path;
            xml.assemble_path(xpath, i);
            string type_path = xpath;
            type_path +="/type";
            char * value  = (char *)xml.get_value(type_path.c_str());
            int  type = 0 ;
            if(value  != NULL)
            {
                type  = atoi(value);
            }
            type_path = xpath;
            type_path +="/config_path";
            value  = (char *)xml.get_value(type_path.c_str());
            if(value  == NULL)
            {

                continue;
            }

            list<rule_node_offist * > node_list;
            int num_rule = 200 ;
            protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), num_rule);
            list<rule_node_offist * > ::iterator iter = node_list.begin();
            for(;iter != node_list.end(); iter ++)
            {
                rule_node_offist * p = *iter ;
                public_ssl_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
            }
        }
    }
    feature_rule_map = &public_ssl_feature_rule_map;
    p_value = (char *)xml.get_value("/config/time_out");
    if (p_value != NULL)
    {
        ssl_time_out = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/max_row");
    if (p_value != NULL)
    {
        max_row = atoi(p_value);
    }

    p_value = (char *)xml.get_value("/config/max_time");
    if (p_value != NULL)
    {
        max_time_src = atoi(p_value);
    }
}

void ssl_plugin::init_ssl_session(ssl_session *p_ssl_session)
{
    p_ssl_session->requst_time = 0;
    p_ssl_session->response_time = 0;
    p_ssl_session->sl_msg = new list<ssl_message *>();
    p_ssl_session->sl_msg->clear();
    p_ssl_session->p_data = NULL;
    p_ssl_session->data_len = 0;
}

void ssl_plugin::multimode_ssl_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }

    p_session->is_c2s = false;
    p_session->is_s2c = false;
    p_session->is_ssl = false;
    short num_short =ntohs(*((short*) (p_packet->p_app_data + 3)));
    if(num_short == p_packet->app_data_len || num_short == (p_packet->app_data_len - 5))
    {
        p_session->is_ssl = true;
    }
    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet -> rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 443)
            {
                p_session->is_ssl = true;
                if(p_session->is_c2s || p_session->is_s2c)break;
            }
            else if(iter->second == 444)
            {
                p_session->is_c2s = true;
                if(p_session->is_ssl)break;
            }
            else if(iter->second == 445)
            {
                p_session->is_s2c = true;
                if(p_session->is_ssl)break;
            }
        }
    }
    return ;
}

bool ssl_plugin::potocol_identify(session *p_session, c_packet *p_packet)
{
    if (!p_packet->b_is_tcp)
    {
        return false;
    }

    ssl_session *p_ssl_session = (ssl_session *)p_session->expansion_data;

    multimode_ssl_identity(p_session, p_packet);
    if(!p_session->is_ssl)return false; 
/*
int  p3 =0

    if(client_ip == srip || dstport)
        p_session->b_src_is_ser =??false
   else if (||)
        b_src_is_ser =ture;

   else{
      
       if(is_c2s )
            p3=1;
            
            
       if(is_s2c )
            p3=2;
            session->sre=packet_det
   }*/

    if((p_session->client_ip == p_session->srcip) || (ntohs(p_session->dstport) == SSLDEFINEPORT))//(p_session->is_c2s
    {   //printf("1\n");
        p_session->b_src_is_ser = false;
        init_ssl_session(p_ssl_session);
        return true;
    }else if ((p_session->client_ip == p_session->dstip) || (ntohs(p_session->srcport) == SSLDEFINEPORT) )//(p_session->is_s2c)||
    {  // printf("2\n");
        p_session->b_src_is_ser = true;
        init_ssl_session(p_ssl_session);
        return true;
    }else if(!p_session->direction_clarity)return false;
    return false;
}

void ssl_plugin::potocol_sign_judge(session * p_session, c_packet *p_packet)
{

    if (p_session==NULL || p_packet==NULL )
    {
        return;
    }
    /*
       p_session->packet_len += p_packet->buff_len;
       ++p_session->packet_num;

       if (p_session->packet_begin_time == 0)
       {
       p_session->packet_begin_time = p_packet->m_timeval;
       p_session->packet_end_time = p_packet->m_timeval;
       }

       if (p_packet->m_timeval > p_session->packet_end_time )
       {
       p_session->packet_end_time = p_packet->m_timeval;
       }
       */

    if (!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }

    if (p_packet->p_tcphdr->fin == 1)
    {
        ((ssl_session *)p_session->expansion_data)->p_data = NULL;
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
        return;
    }

    if (p_packet->p_app_data==NULL || p_packet->app_data_len==0)
    {
        return;
    }

    ssl_session *p_ssl_session = (ssl_session *)p_session->expansion_data;
    p_ssl_session->data_len = p_packet->app_data_len;
    p_ssl_session->packet_time = p_packet->m_timeval;
    //判断数据包的方向
   // if(p3==0)

   if ((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) ||
     (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port()))
    {
        p_ssl_session->b_c2s = false;
    }
    else
    {
        p_ssl_session->b_c2s = true;
    }
  /*  else if(p3==1)
    {
       
        == then b0c2s=true;
        session!=packet =false ?
    }
    else if ==2

            =false;
*/

   /* if((p_packet->get_src_port() == p_session->srcport) && (p_packet->get_src_ip() == p_session->srcip))
    {
        p_ssl_session->b_c2s = true;
    }
    else
    {
        p_ssl_session->b_c2s = false;
    }*/

    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len;
    if (len == 0)
    {
        p_ssl_session->p_data = NULL;
        return;
    }

    char *p_data = (char *)p_packet->p_app_data;
    if (p_data == NULL)
    {
        return;
    }
    //公共字段提取
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;

    if (p_ssl_session->b_c2s)//c2s方向
    {
        p_session->client.add_tcp_packet(len, p_data, seq);
        p_ssl_session->p_data = p_session->client.get_tcp_data(p_ssl_session->len);
        p_data = p_ssl_session->p_data;

        int len = p_ssl_session->len;
        int tmp = len;

        if (len == 0 || p_data==NULL)
        {
            return ;
        }

        int offset = 0;
        int i = 0;
        for(; len>0 ;)
        {
            if (offset < 0 || offset + 5 > tmp)
            {
                return ;
            }
            if(*(uint8_t *)(p_data+offset)==128)
            {
            p_ssl_session->msg_len = *(uint8_t *)(p_data+1+offset);
            i = 2;
            }
            else
            {
            p_ssl_session->msg_len = ntohs(*(uint16_t *)(p_data+3+offset));
            i = 5;
            }
            if (p_ssl_session->msg_len <= 0)
            {
                return;
            }
            if (p_ssl_session->msg_len+ i < len)
            {
                offset += p_ssl_session->msg_len+ i ;
                len -= p_ssl_session->msg_len+ i ;
            }
            else if (p_ssl_session->msg_len+i == len)
            {
                break;
            }
            else
            {
                return;
            }
        }

        SET_EXPORT(p_session);
    }
    else
    {
        p_session->server.add_tcp_packet(len, p_data, seq);
        p_ssl_session->p_data = p_session->server.get_tcp_data(p_ssl_session->len);
        p_data = p_ssl_session->p_data;
        if (p_ssl_session->p_data==NULL || p_ssl_session->len==0)
        {
            return;
        }
        int len = p_ssl_session->len;
        int tmp = len;
        int offset = 0;
        for (; len>0 ;)
        {
            if (offset < 0 || offset > tmp)
            {
                return ;
            }

            p_ssl_session->msg_len = ntohs(*(uint16_t *)(p_data+3+offset));
            if (p_ssl_session->msg_len == 0)
            {
                return;
            }
            if (p_ssl_session->msg_len+5 < len)
            {
                offset += p_ssl_session->msg_len+5;
                len -= p_ssl_session->msg_len+5;
            }
            else if (p_ssl_session->msg_len+5 == len)
            {
                break;
            }
            else
            {
                return;
            }
        }

        SET_EXPORT(p_session);
    }
    return;
}

void ssl_plugin::pococol_parse_handle(session * p_session)
{
    ssl_session *p_ssl_session = (ssl_session *)p_session->expansion_data;
    if (p_ssl_session->p_data==NULL || p_ssl_session->data_len==0)
    {
        if (IS_SESSION_OVER(p_session))
        {
            p_session->send_len = 1;
            p_session->p_send_buf = "l";
        }
        return;
    }

    //解析数据包的内容
    int offset = 0;
    int len = p_ssl_session->len;
    while(1)
    {
        if (offset > p_ssl_session->len)
        {
            if (p_ssl_session->b_c2s)
            {
                p_session->client.clear_buf();
            }
            else
            {
                p_session->server.clear_buf();
            }
            p_ssl_session->packet_time = 0;
            p_ssl_session->b_c2s = false;
            p_ssl_session->p_data = NULL;
            p_ssl_session->data_len = 0;
            return ;
        }

        ssl_message *p_ssl_msg = p_ssl_session->ssl_pkt_parse(p_ssl_session->p_data+offset, p_ssl_session->len-offset, p_ssl_session);
        if (p_ssl_msg != NULL)
        {
            p_ssl_session->sl_msg->push_back(p_ssl_msg);
            // printf("new p_ssl_session->sl_ms ->size = %d \n",p_ssl_session->sl_msg->size());
            if (p_ssl_msg->msg_sub_type == CLIENT_KEY_EXCHANGE)
            {
                SET_SESSION_OVER(p_session);
                p_session->send_len = 1;
                p_session->p_send_buf = "l";

            }
        }
        else
        {
            if (p_ssl_session->b_c2s)
            {
                p_session->client.clear_buf();
            }
            else
            {
                p_session->server.clear_buf();
            }
            p_ssl_session->packet_time = 0;
            p_ssl_session->b_c2s = false;
            p_ssl_session->p_data = NULL;
            p_ssl_session->data_len = 0;
            return ;
        }

        if(offset+5 > len)
        {
            return;
        }

        p_ssl_session-> msg_len = ntohs(*(uint16_t *)(p_ssl_session->p_data+offset+3));
        if (p_ssl_session->msg_len+5+offset == len)
        {
            break;
        }

        if(offset+p_ssl_session->msg_len+5 > len)
        {
            // break;
            return;
        }
        else
        {
            offset += p_ssl_session->msg_len+5;
        }
    }

    if (IS_SESSION_OVER(p_session))
    {
       p_session->send_len = 1;
        p_session->p_send_buf = "l";
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
    }

    if (p_ssl_session->b_c2s)
    {
        p_session->client.clear_buf();
    }
    else
    {
        p_session->server.clear_buf();
    }
 

    p_ssl_session->packet_time = 0;
    p_ssl_session->b_c2s = false;
    p_ssl_session->p_data = NULL;
    p_ssl_session->data_len = 0;
}

void ssl_plugin::potocol_data_handle(session* p_session,list<data_interface> *p_list)
{
    int is_ipv6;
    int is_ipv4;
    uint32_t busy_time = 0;

    ssl_session * p_ssl_session = (ssl_session *)p_session->expansion_data;
    if (p_ssl_session==NULL || p_ssl_session->sl_msg==NULL || p_ssl_session->sl_msg->empty())
    {
        return;
    }

    output_interface.init();
    //数据流方向初步判断（单向or双向）
    list<ssl_message*>::iterator iter = p_ssl_session->sl_msg->begin();
    bool b_msg_c2s = (*iter)->b_c2s;
    if (p_ssl_session->sl_msg->size() > 1)
    {
        bool b_msg_c2s = (*iter)->b_c2s;
        for(; iter != p_ssl_session->sl_msg->end(); ++iter)
        {
            if ((*iter)->b_c2s != b_msg_c2s)
            {
                output_interface.direction = 3;    //双向
                break;
            }
        }
    }

    if (output_interface.direction != 3)
    {
        if (b_msg_c2s)
        {
            output_interface.direction = 1;         //c2s
        }
        else
        {
            output_interface.direction = 2;         //s2c
        }
    }

    //取session开始的时间
    iter = p_ssl_session->sl_msg->begin();
    //计算通信速率



    double session_duration = (double)(p_session->packet_end_time - p_session->packet_begin_time);
    if (session_duration != 0)
    {
        //output_interface.communication_rate = ((double)total_throughput / session_duration)*1000000;
        output_interface.communication_rate = ((double)p_session->packet_len / session_duration)*1000000;
    }
    else
    {
        output_interface.communication_rate = 1;
    }





    //解析消息(最简单的处理方式，以后根据需求变化需要进行重构)
    for(iter = p_ssl_session->sl_msg->begin(); iter != p_ssl_session->sl_msg->end(); ++iter)
    {
        switch((*iter)->msg_sub_type)
        {
            case CLIENT_HELLO:
                {
                    ClientHello *s_message = (ClientHello *)(*iter);
                    output_interface.client_version_major = s_message->msg_body.client_version.major;
                    output_interface.client_version_minor = s_message->msg_body.client_version.minor;
                    if(s_message->msg_body.c_gmt_unix_time != "")
                    {
                        output_interface.c_gmt_unix_time = s_message->msg_body.c_gmt_unix_time;
                    }
                    //if(s_message->msg_body.random_bytes != 0)
                    //if(s_message->msg_body.random_bytes[0] != '\0')
                    if(s_message->msg_body.random_bytes!= 0)
                    {
                        string str(s_message->msg_body.random_bytes, s_message->msg_body.random_bytes+32);
                        output_interface.c_random_bytes=str;
                    }
                    output_interface.c_session_id_length = s_message->msg_body.session_id_length;
                    output_interface.c_session_id = s_message->msg_body.session_id;
                    output_interface.cipher_suites_length = s_message->msg_body.cipher_suites_length;
                    if(output_interface.cipher_suites_length!=0)
                    {
                      /*  string str(s_message->msg_body.cipher_suites,s_message->msg_body.cipher_suites+output_interface.cipher_suites_length);
                        output_interface.c_cipher_suites = str;
                     output_interface.c_cipher_suites = string((char *)s_message->msg_body.cipher_suites,0,output_interface.cipher_suites_length);
                    */
                     output_interface.c_cipher_suites = s_message->msg_body.cipher_suites;
                     }
                    output_interface.challenge_length=s_message->msg_body.challenge_length;
                    output_interface.challenge = s_message->msg_body.challenge;
                    output_interface.Server_Name_length = s_message->msg_body.server_name_length;
                    output_interface.c_Server_Name = s_message->msg_body.server_name;

                    break;
                }

            case SERVER_HELLO:
                {
                    ServerHello *s_message = (ServerHello *)(*iter);
                    output_interface.server_version_major = s_message->msg_body.server_version.major;
                    output_interface.server_version_minor = s_message->msg_body.server_version.minor;
                    if(s_message->msg_body.s_gmt_unix_time != "")
                    {
                        output_interface.s_gmt_unix_time = s_message->msg_body.s_gmt_unix_time;
                    }
                    if(s_message->msg_body.random_bytes != 0)
                    {
                        //memcpy(output_interface.s_random_bytes, s_message->msg_body.random_bytes, 28);
                        string str(s_message->msg_body.random_bytes, s_message->msg_body.random_bytes+32);
                        output_interface.s_random_bytes=str;
                    }
                    output_interface.s_session_id_length = s_message->msg_body.session_id_length;
                    output_interface.s_session_id = s_message->msg_body.session_id;
                    output_interface.s_cipher_suites = s_message->msg_body.cipher_suites;

                    break;
                }

            case CERTIFICATE:
                {
                    Certificate *s_message = (Certificate *)(*iter);
                    list<Certificate_body*>::iterator iter = s_message->certificate_list.begin();
                    for(; iter != s_message->certificate_list.end(); ++iter)
                    {
                        output_interface.certificate_list.push_back(*iter);
                    }
                    break;
                }

            case SERVER_KEY_EXCHANGE:
                {
                    ServerKeyExchange *s_message = (ServerKeyExchange *)(*iter);
                    output_interface.DH_s_pubkey_len = s_message->msg_body.DH_s_pubkey_len;
                    output_interface.DH_s_pubkey = s_message->msg_body.DH_s_pubkey;
                    output_interface.DH_s_Algorithm_hash = s_message->msg_body.DH_s_Algorithm_hash;
                    output_interface.DH_s_Algorithm_signature = s_message->msg_body.DH_s_Algorithm_signature;
                    output_interface.DH_s_signature_len = s_message->msg_body.DH_s_signature_len;
                    if (s_message->msg_body.DH_s_signature != NULL)
                    {
                        output_interface.DH_s_signature = s_message->msg_body.DH_s_signature;
                        // output_interface.DH_s_signature = NULL;
                    }
                    break;
                }

            case CLIENT_KEY_EXCHANGE:
                {
                    ClientKeyExchange *s_message = (ClientKeyExchange *)(*iter);
                    output_interface.DH_c_pubkey_len = s_message->msg_body.DH_c_pubkey_len;
                    output_interface.DH_c_pubkey = s_message->msg_body.DH_c_pubkey;
                    break;
                }

            default:
                {
                    break;
                }
        }
    }
    //取基本信息
    if (p_session->b_src_is_ser)
    {
        output_interface.client_port = p_session->dstport;
        output_interface.client_ip = p_session->dstip;
        output_interface.server_port = p_session->srcport;
        output_interface.server_ip = p_session->srcip;
        if (output_interface.direction == 2)
        {
            output_interface.client_port = p_session->srcport;
            output_interface.client_ip = p_session->srcip;
            output_interface.server_port = p_session->dstport;
            output_interface.server_ip = p_session->dstip;
        }
    }
    else
    {
        output_interface.client_port = p_session->srcport;
        output_interface.client_ip = p_session->srcip;
        output_interface.server_port = p_session->dstport;
        output_interface.server_ip = p_session->dstip;
    }

    classify_ip_kind_info(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
    output_interface.is_ipv4 = is_ipv4;
    output_interface.is_ipv6 = is_ipv6;
    output_interface.mac_line_number = p_session->mac_line_num;
    output_interface.device_num = p_session-> device_num;
    output_interface.is_mpls = p_session->m_is_mpls;
    output_interface.n_label = p_session->m_label;
    output_interface.in_nerlabel = p_session->m_inner_label;
    output_interface.other_label = p_session->m_other_lable;
    output_interface.proto = p_session->proto_type;
    output_interface.total_payloadbytes = p_session->packet_len;
    output_interface.total_payloadpackets = p_session->packet_num;
    if (p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    output_interface.duration = busy_time;
    iter = p_ssl_session->sl_msg->begin();
    output_interface.time = (*iter)->packet_time;
    //将数据加入接口
    ssl_interface_handling(p_list);
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    //SET_SESSION_OVER(p_session);

    return;
}

void ssl_plugin::time_out(session *p_session, uint64_t check_time)
{
    if (check_time-p_session->last_packet_time > ssl_time_out *1000000)
    {
        //开始超时处理
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
        p_session->send_len = 1;
        p_session->p_send_buf = "l";
    }
}

void ssl_plugin::resources_recovery(session * p_session)
{
    ssl_session * p_ssl_session = (ssl_session *)p_session->expansion_data;
    list<ssl_message*>::iterator iter = p_ssl_session->sl_msg->begin();
    for(; iter != p_ssl_session->sl_msg->end(); ++iter)
    {
        //printf("del p_ssl_session->sl_ms ->size = %d \n",p_ssl_session->sl_msg->size());
        delete *iter;
    }
    p_ssl_session->sl_msg->clear();
    delete p_ssl_session->sl_msg;
}

//Summary:SSL消息解析函数
ssl_message* ssl_session::ssl_pkt_parse(const char * p_data, int16_t data_len, ssl_session * p_ssl_session)
{
    if (p_data==NULL || data_len<0 || (size_t)data_len<sizeof(ssl_msg_header))
    {
        return NULL;
    }
    //解析消息头
    if(p_data + 5 == NULL)
    {
        return NULL;
    }
    struct ssl_msg_header msg_header = *(ssl_msg_header*)p_data;
    uint16_t message_length=0;
    if(msg_header.msg_type!=22&&(*(uint8_t *)p_data == 128))
      {
      message_length = *(uint8_t *)(p_data+1);
      msg_header.msg_type = 22;
      p_data += 2;
      data_len -= 2;
      }
      else
      {
    message_length = ntohs(msg_header.length);
    p_data += 5;//偏移ssl_msg_header长度
    data_len -= 5;//减去ssl_msg_header长度
    }
    switch(msg_header.msg_type)
    {
        case HANDSHAKE:
            {
                if (data_len<0 || (size_t)data_len<sizeof(ssl_ctrl_msg_header)||(p_data + sizeof(ssl_ctrl_msg_header))==NULL)
                {
                    return NULL;
                }
                struct ssl_ctrl_msg_header ctrl_msg_header = *(ssl_ctrl_msg_header*)p_data;
                p_data += sizeof(ssl_ctrl_msg_header);
                data_len -= sizeof(ssl_ctrl_msg_header);

                ssl_message *p_ssl_msg = NULL;
                if (p_ssl_session->state!=CLIENT_HELLO && 
                        p_ssl_session->state!=SERVER_HELLO && 
                        p_ssl_session->state!=CERTIFICATE && 
                        p_ssl_session->state!=SERVER_KEY_EXCHANGE && 
                        p_ssl_session->state!=CLIENT_KEY_EXCHANGE)
                {
                    p_ssl_session->state = CLIENT_HELLO;
                }

                switch(ctrl_msg_header.control_message_type)
                {
                    case CLIENT_HELLO:
                        {
                            if (p_ssl_session->state <= CLIENT_HELLO)
                            {
                                p_ssl_msg = new ClientHello(message_length, packet_time, b_c2s);
                                p_ssl_session->state = SERVER_HELLO;
                            }
                            else
                            {
                                return NULL;
                            }

                            break;
                        }

                    case SERVER_HELLO:
                        {
                            if (p_ssl_session->state <= SERVER_HELLO)
                            {
                                p_ssl_msg = new ServerHello(message_length, packet_time, b_c2s);
                                p_ssl_session->state = CERTIFICATE;
                            }
                            else
                            {
                                return NULL;
                            }
                            break;
                        }

                    case  CERTIFICATE:
                        {
                            if (p_ssl_session->state <= CERTIFICATE)
                            {
                                p_ssl_msg = new Certificate(message_length, packet_time, b_c2s);
                                if (b_c2s)
                                {
                                    p_ssl_session->state = CLIENT_KEY_EXCHANGE;
                                }
                                else// if (!b_c2s)
                                {
                                    p_ssl_session->state = SERVER_KEY_EXCHANGE;
                                }
                            }
                            else
                            {
                                return NULL;
                            }
                            break;
                        }

                    case  SERVER_KEY_EXCHANGE:
                        {
                            if (p_ssl_session->state <= SERVER_KEY_EXCHANGE)
                            {
                                p_ssl_msg = new ServerKeyExchange(message_length, packet_time, b_c2s);
                                p_ssl_session->state = CLIENT_KEY_EXCHANGE;
                            }
                            else
                            {
                                return NULL;
                            }
                            break;
                        }

                    case  CLIENT_KEY_EXCHANGE:
                        {
                            if (p_ssl_session->state <= CLIENT_KEY_EXCHANGE)
                            {
                                p_ssl_msg = new ClientKeyExchange(message_length, packet_time, b_c2s);
                            }
                            else
                            {
                                return NULL;
                            }

                            p_ssl_session->state = CLIENT_HELLO;
                            break;
                        }

                    default:
                        {
                            return NULL;
                        }
                }

                if(p_ssl_msg == NULL||p_data == NULL)
                {
                    return NULL;
                }
                if (!p_ssl_msg->msg_body_parse(p_data, data_len))
                {
                    delete p_ssl_msg;
                    return NULL;
                }
                return p_ssl_msg;
            }

        case APPLICATIONDATA: //目前不处理管理消息
            {
                return NULL;
            }

        case CHANGECIPHER:
            {
                return NULL;
            }

        case ALERT:
            {
                return NULL;
            }

        default:
            {
                return NULL;
            }
    }
}

bool Certificate:: Certificate_pkt_parse(const char *p_data, int16_t data_len)
{
    if (p_data == NULL)
    {
        return false;
    }

    uint32_t certi_len;
    if(data_len < 10)
    {
        return false;
    }
    uint32_t total_certi_len = ntohl(*(uint32_t*)(p_data+3));
    total_certi_len = total_certi_len >> 8;

    certi_len = ntohl(*(uint32_t *)(p_data+6));
    certi_len = certi_len >> 8;
    int offset = 0;
    offset += 6;
    Certificate_body *Cert = NULL;
    while(total_certi_len >= certi_len)
    {
        if(data_len < offset)
        {
            return false;
        }
        Cert = Certificate_parse(p_data+offset, data_len-offset);
        if (Cert != NULL)
        {
            certificate_list.push_back(Cert);
        }
        offset += (certi_len+3);
        if (total_certi_len+6 == offset)
        {
            break;
        }
        if (offset + 4 > data_len)
        {
            return false;
        }

        certi_len = ntohl(*(uint32_t*)(p_data+offset));
        certi_len = certi_len >> 8;
    }
    return true;
}

Certificate_body* Certificate::Certificate_parse(const char *p_data, int16_t data_len)//, struct Certificate_body  & Msg_body)
{
    if (p_data == NULL)
    {
        return NULL;
    }
    const char *Cert = p_data;
    const char *pTmp = Cert+3;
    uint32_t Certlen;
    string tmp;
    if(data_len < 7)
    {
        return NULL;
    }

    Certlen = ntohl(*(uint32_t*)(p_data));
    Certlen = Certlen >> 8;
    ////判断是否为DER编码的用户证书，并转化为X509结构体
    X509 *usrCert = d2i_X509(NULL, (const unsigned char **)&pTmp, Certlen);//DER编码转换为内部结构函数
    if (usrCert == NULL)
    {
        return NULL;
    }

    int entriesNum;
    X509_NAME_ENTRY *name_entry;
    long Nid;
    char msginfo[2048];
    int msginfoLen;

    Certificate_body * msg_body = new Certificate_body();
    if(data_len < 50)
    {
        return NULL;
    }

    msg_body->Certificate_Algorithm = string(Cert+38, 9);
    ASN1_INTEGER *Certificate_serialNumber = X509_get_serialNumber(usrCert);//获得证书序列号函数
    msg_body->Certificate_serialNumber = string((char*)Certificate_serialNumber->data, Certificate_serialNumber->length);

    X509_NAME *issuer = X509_get_issuer_name(usrCert);//获得证书颁发者信息函数
    entriesNum = sk_X509_NAME_ENTRY_num(issuer->entries);//获取X509_NAME条目个数
    for(int i=0; i<entriesNum; ++i)//循环读取各条目信息
    {
        name_entry = sk_X509_NAME_ENTRY_value(issuer->entries, i);//获取第i个条目值
        if(name_entry != NULL)
        {
            Nid = OBJ_obj2nid(name_entry->object);//获取对象ID
            msginfoLen = name_entry->value->length;
            /*   if(((char *)name_entry->value->data > p_data) && 
                 ((char *)name_entry->value->data+msginfoLen < p_data+data_len))
                 {
                 memcpy(msginfo, name_entry->value->data, msginfoLen);
                 msginfo[msginfoLen] = '\0';
                 }
                 else
                 {
                 msginfoLen = 0;
                 }

                 if(msginfoLen == 0)
                 {
                 continue;
                 }*/

            memset(msginfo,0x00,2048);
            if(0 <= msginfoLen <= 2048)
            {
                memcpy(msginfo, name_entry->value->data, msginfoLen);
                msginfo[msginfoLen] = '\0';
            }
            else if(msginfoLen > 2048 )
            {
                memcpy(msginfo, name_entry->value->data, 2048);
                msginfo[2048] = '\0';
            }
            else
            {
                continue;
            }

            switch(Nid)//根据NID打印出信息
            {
                case NID_countryName:
                    {
                        msg_body->issuer_CountryName = string(msginfo, 0,msginfoLen);
                        break;
                    }

                case NID_stateOrProvinceName://省
                    {
                        msg_body->issuer_ProvinceName = string(msginfo,0,msginfoLen);
                        break;
                    }

                case NID_localityName://地区
                    {
                        msg_body->issuer_localityName = string(msginfo,0,msginfoLen);
                        break;
                    }

                case NID_organizationName://组织
                    {
                        msg_body->issuer_organizationName = string(msginfo,0,msginfoLen);
                        break;
                    }

                case NID_organizationalUnitName://单位
                    {
                        msg_body->issuer_organizationalUnitName = string(msginfo,0,msginfoLen);
                        break;
                    }

                case NID_commonName://通用名
                    {
                        msg_body->issuer_commonName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_pkcs9_emailAddress://Mail
                    {
                        msg_body->issuer_emailAddress = string(msginfo,0, msginfoLen);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }
        }
    }

    X509_NAME *subject = X509_get_subject_name(usrCert);    //获得证书拥有者信息函数
    entriesNum = sk_X509_NAME_ENTRY_num(subject->entries);//获取X509_NAME条目个数
    for(int i=0; i<entriesNum; ++i)
    {
        name_entry = sk_X509_NAME_ENTRY_value(subject->entries, i);
        if(name_entry != NULL)
        {

            Nid = OBJ_obj2nid(name_entry->object);       
            msginfoLen = name_entry->value->length;
            // panding
            /*           if(((char *)name_entry->value->data > p_data) && 
                         ((char *)name_entry->value->data+msginfoLen < p_data+data_len))
                         {
                         memcpy(msginfo, name_entry->value->data, msginfoLen);
                         msginfo[msginfoLen] = '\0';
                         }
                         else
                         {
                         msginfoLen = 0;
                         }

                         if(msginfoLen == 0)
                         {
                         continue;
                         }
                         */
            memset(msginfo,0x00,2048);
            if(0 <= msginfoLen <= 2048)
            {
                memcpy(msginfo, name_entry->value->data, msginfoLen);
                msginfo[msginfoLen] = '\0';
            }
            else if(msginfoLen > 2048)
            {
                memcpy(msginfo, name_entry->value->data, 2048);
                msginfo[2048] = '\0';
            }
            else
            {
                continue ;
            }


            switch(Nid)
            {
                case NID_countryName://国家
                    {
                        msg_body->subject_countryName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_stateOrProvinceName://省
                    {
                        msg_body->subject_ProvinceName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_localityName://地区
                    {
                        msg_body->subject_localityName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_organizationName://组织
                    {
                        msg_body->subject_organizationName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_organizationalUnitName://单位
                    {
                        msg_body->subject_organizationalUnitName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_commonName://通用名
                    {
                        msg_body->subject_commonName = string(msginfo,0, msginfoLen);
                        break;
                    }

                case NID_pkcs9_emailAddress:
                    {
                        msg_body->subject_emailAddress = string(msginfo,0, msginfoLen);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }
        }
    }

    //获取证书生效日期
    ASN1_TIME *notBefore = X509_get_notBefore(usrCert);
    //if(((char*)notBefore->data > p_data) && 
    //     ((char*)notBefore->data+notBefore->length < p_data+data_len))
    msg_body->notBefore = string((char*)notBefore->data,0, notBefore->length);
    //获取证书过期日期
    ASN1_TIME *notAfter = X509_get_notAfter(usrCert);
    //if(((char*)notAfter->data > p_data) && 
    //      ((char*)notAfter->data+notAfter->length < p_data+data_len))
    msg_body->notAfter = string((char*)notAfter->data,0, notAfter->length);
    //获取证书公钥
    EVP_PKEY *PubKey = X509_get_pubkey(usrCert);
    char Certificate_PubKey[2048];
    char *Certi_pub = Certificate_PubKey;
    char*p_temp = Certificate_PubKey;
    //把证书公钥专为DER编码的数据
    if (PubKey != NULL)
    {
        msg_body->Certificate_PubKeyLength = i2d_PublicKey(PubKey, (unsigned char  **) &p_temp);
        // msg_body->Certificate_PubKey = string(Certificate_PubKey,0, msg_body->Certificate_PubKeyLength);
        if(msg_body->Certificate_PubKeyLength > 2048 )
        {
            return NULL;
        }
        msg_body->Certificate_PubKey = string(Certi_pub, Certi_pub+msg_body->Certificate_PubKeyLength);
        EVP_PKEY_free(PubKey);
    }

    /* ASN1_BIT_STRING *usage;
       if(usage = (ASN1_BIT_STRING *)X509_get_ext_d2i(usrCert,NID_key_usage,NULL,NULL))
       {
       if(usage->length >0)
       {
       usrCert->ex_kusage = usage->data[0];
       if(usage->length > 1)
       usrCert->ex_kusage|=usage->data[1]<<8;
       }
       else
       {
       usrCert->ex_kusage =0;
       usrCert->ex_flags |=EXFLAG_KUSAGE;
       }
       ASN1_BIT_STRING_free(usage);
       }*/
    char value[512]={0};
    ASN1_BIT_STRING *IASN1UsageStr;
    if(IASN1UsageStr = (ASN1_BIT_STRING *)X509_get_ext_d2i(usrCert,NID_key_usage,NULL,NULL))
    {
        char temp[32]={0};
        unsigned short usage = IASN1UsageStr->data[0];
        if(IASN1UsageStr->length>1)
        {
            usage|=IASN1UsageStr->data[1]<<8;
        }
        snprintf(temp,32,"%x",usage);

        if(usage&KU_DIGITAL_SIGNATURE)
        {
            strncat(value,"Digital Signature,",512);
        }
        if(usage&KU_NON_REPUDIATION)
        {
            strncat(value,"Non-Repudiation,",512);
        }
        if(usage&KU_KEY_ENCIPHERMENT)
        {
            strncat(value,"Key Encipherment,",512);
        }
        if(usage & KU_DATA_ENCIPHERMENT)
        {
            strncat(value,"Data Encipherment,",512);
        }
        if(usage & KU_KEY_AGREEMENT)
        {
            strncat(value,"key Agreement,",512);
        }
        if(usage & KU_KEY_CERT_SIGN)
        {
            strncat(value,"Certificate Signature,",512);
        }
        if(usage & KU_CRL_SIGN)
        {
            strncat(value,"CRL Signature,",512);
        }
        strncat(value,temp,512);
        //msg_body->kusage=value;
        msg_body->kusage = string((char*)value,0, 512);
        ASN1_BIT_STRING_free(IASN1UsageStr);

    }
    
     int k=0;
     char data[512]={0};
     EXTENDED_KEY_USAGE *extusage;

     extusage = (EXTENDED_KEY_USAGE *)X509_get_ext_d2i(usrCert,NID_ext_key_usage,NULL,NULL);
     if(extusage)
     {
     long id[]={OBJ_email_protect};

     for(k=0;k<sk_ASN1_OBJECT_num(extusage);k++)
     {
     int m=0;
     char obj_id[128] = {0};
     char obj_name[128] = {0};
     ASN1_OBJECT *obj=sk_ASN1_OBJECT_value(extusage,k);
     
     OBJ_obj2txt(obj_id,sizeof(obj_id),obj,1);
     OBJ_obj2txt(obj_name,sizeof(obj_name),obj,0);

     if(strlen(data)>0)
     {
     strncat(data,",",512);
     }
     strncat(data,obj_name,512);
     strncat(data,"(",512);
     strncat(data,obj_id,512);
     strncat(data,")",512);
     }
     msg_body->exkusage = string((char*)data,0, 512);
     sk_ASN1_OBJECT_pop_free(extusage,ASN1_OBJECT_free);
     }



      // HostnameValidationResult result = MatchNotFound; 
       int i;
       char dns[1024]={0};
       int san_names_nb = -1;
     //  stack_st_GENERAL_NAME *san_names=NULL;
       STACK_OF(GENERAL_NAME) *san_names=NULL;
       san_names = (stack_st_GENERAL_NAME *)X509_get_ext_d2i(usrCert,NID_subject_alt_name,NULL,NULL);
       if(san_names)
       {
       san_names_nb = sk_GENERAL_NAME_num(san_names);
       int j=0;
       for(i=0;i<san_names_nb;i++)
       {
      // const GENERAL_NAME *current_name = sk_X509_NAME_ENTRY_value(san_names,i);
        X509_NAME_ENTRY *current_name = sk_X509_NAME_ENTRY_value((stack_st_X509_NAME_ENTRY *)san_names,i);
      if(current_name->value->type == 22)
       {
        strncat(dns,(const char *)current_name->value->data,1024);
        if(j!=2)
        {
        strcat(dns,",");
        }
        j++;
       /*char * dns_name = (char *)ASN1_STRING_data((ASN1_STRING *)current_name->value->data);
       if(ASN1_STRING_length((const ASN1_STRING *)current_name->value->data)!=strlen(dns_name))
       {
       break;
       }
       else
       {
      // if(strcasecmp(hostname,dns_name)==0)
       {
       break;
       }
       }*/

       }
        if(j==3)
        {
        break;
        }
       }
        msg_body->dns_name = string((char*)dns,0, 1024);

       sk_GENERAL_NAME_pop_free(san_names,GENERAL_NAME_free);
    //return result;
       }


    //释放结构体内存
    X509_free(usrCert);

    return msg_body;
}

void ssl_session::display_ssl_msg_list()
{
    list<ssl_message *>::iterator iter = sl_msg->begin();
    //for(int i=1; iter!=sl_msg->end(); ++iter,++i)
    for(; iter!=sl_msg->end(); ++iter)
    {
        (*iter)->msg_header_display();
        (*iter)->msg_body_display();
    }
    return;
}

void ssl_plugin::ssl_interface_handling(list<data_interface> *p_list)
{
    data_interface m_data;
    if (data_interface_type == NETSEND)
    {
        net_str * p_net = new net_str;
        p_net->msg = new CAmsg;
        p_net->msg->Clear();
        p_net->msg->set_type(29); // ssl

        ssl_msg* p_ssl = p_net->msg->mutable_ssl();
        Comm_msg* p_comm = p_ssl->mutable_comm_msg();
        //公共消息
        p_comm ->set_src_ip(output_interface.client_ip.ip_str());
        p_comm ->set_src_port(ntohs(output_interface.client_port));
        p_comm ->set_dst_ip(output_interface.server_ip.ip_str());
        p_comm ->set_dst_port(ntohs(output_interface.server_port));
        p_comm ->set_line_num(output_interface.mac_line_number);
        p_comm ->set_dev_num(output_interface.device_num);
        p_comm ->set_time(output_interface.time);

        p_comm->set_is_ipv4(output_interface.is_ipv4);
        p_comm->set_is_ipv6(output_interface.is_ipv6);
        p_comm->set_proto(output_interface.proto);
        p_comm->set_link_layer_type(0);
        p_comm ->set_is_mpls(output_interface.is_mpls);
        p_comm ->set_n_label(output_interface.n_label);
        p_comm ->set_inner_label(output_interface.in_nerlabel);
        p_comm ->set_other_label(output_interface.other_label);
        p_comm ->set_total_pay_load_bytes(output_interface.total_payloadbytes);
        p_comm ->set_tatal_pay_load_packets(output_interface.total_payloadpackets);
        p_comm ->set_duration(output_interface.duration);

        //SSL消息
        p_ssl->set_protocol_family(1210012);
        p_ssl->set_communication_rate(output_interface.communication_rate);
        p_ssl->set_direction(output_interface.direction);
        if(output_interface.client_version_major!= 0 || output_interface.client_version_minor != 0)
        {
        p_ssl->set_client_version_major(output_interface.client_version_major);
        p_ssl->set_client_version_minor(output_interface.client_version_minor);
        }  
        if(output_interface.c_gmt_unix_time != "")
        {
            p_ssl->set_c_gmt_unix_time(output_interface.c_gmt_unix_time);
        }
        if(output_interface.c_random_bytes!= "")
        {
            //p_ssl->set_c_random_bytes(output_interface.c_random_bytes,28);
            p_ssl->set_c_random_bytes(output_interface.c_random_bytes);
        }
        if (output_interface.c_session_id != NULL)
        {
            p_ssl->set_c_session_id(output_interface.c_session_id,output_interface.c_session_id_length);
        }
        if (output_interface.cipher_suites_length > 1)
        {
            p_ssl->set_cipher_suites_length(output_interface.cipher_suites_length);
            /*if (output_interface.c_cipher_suites != NULL)
              {
              for(int i = 0; i<output_interface.cipher_suites_length/2; i++)
              {
              p_ssl->add_c_cipher_suites(ntohs(*(uint16_t*)(output_interface.c_cipher_suites+i)));
              }
              }*/
        }
        if(output_interface.c_cipher_suites!=NULL)
        {
            p_ssl->set_c_cipher_suites(output_interface.c_cipher_suites,output_interface.cipher_suites_length);
        }
        if (output_interface.c_Server_Name != NULL)
        {
            p_ssl->set_c_server_name(output_interface.c_Server_Name,output_interface.Server_Name_length);
        }
        if(output_interface.challenge != NULL)
        {
           p_ssl->set_challenge(output_interface.challenge,output_interface.challenge_length);
        }
        ssl_certificate* p_certificate = NULL;
        list<Certificate_body*>::iterator iter = output_interface.certificate_list.begin();
        for(; iter != output_interface.certificate_list.end(); ++iter)
        {
            p_certificate = p_ssl->add_certificate();
            p_certificate->set_certificate_algorithm((*iter)->Certificate_Algorithm);
            p_certificate->set_certificate_pubkeylength((*iter)->Certificate_PubKeyLength);
            p_certificate->set_certificate_pubkey((*iter)->Certificate_PubKey);
            p_certificate->set_issuer_countryname((*iter)->issuer_CountryName);
            p_certificate->set_issuer_provincename((*iter)->issuer_ProvinceName);
            p_certificate->set_issuer_localityname((*iter)->issuer_localityName);
            p_certificate->set_issuer_organizationname((*iter)->issuer_organizationName);
            p_certificate->set_issuer_organizationalunitname((*iter)->issuer_organizationalUnitName);
            p_certificate->set_issuer_commonname((*iter)->issuer_commonName);
            p_certificate->set_issuer_emailaddress((*iter)->issuer_emailAddress);
            p_certificate->set_subject_countryname((*iter)->subject_countryName);
            p_certificate->set_subject_provincename((*iter)->subject_ProvinceName);
            p_certificate->set_subject_localityname((*iter)->subject_localityName);
            p_certificate->set_subject_organizationname((*iter)->subject_organizationName);
            p_certificate->set_subject_organizationalunitname((*iter)->subject_organizationalUnitName);
            p_certificate->set_subject_commonname((*iter)->subject_commonName);
            p_certificate->set_subject_emailaddress((*iter)->subject_emailAddress);
            p_certificate->set_certificate_serialnumber((*iter)->Certificate_serialNumber);
            p_certificate->set_notbefore((*iter)->notBefore);
            p_certificate->set_notafter((*iter)->notAfter);
            p_certificate->set_kusage((*iter)->kusage);
            p_certificate->set_exkusage((*iter)->exkusage);
            p_certificate->set_dns_name((*iter)->dns_name);
        }
        if(output_interface.server_version_major!=0||output_interface.server_version_minor!=0)
        {
        p_ssl->set_server_version_major(output_interface.server_version_major);
        p_ssl->set_server_version_minor(output_interface.server_version_minor);
        }
        if(output_interface.s_gmt_unix_time != "")
        {
            p_ssl->set_s_gmt_unix_time(output_interface.s_gmt_unix_time);
        }
        if(output_interface.s_random_bytes!= "")
        {
            //p_ssl->set_s_random_bytes(output_interface.s_random_bytes,28);
            p_ssl->set_s_random_bytes(output_interface.s_random_bytes);//,28);
        }
        if (output_interface.s_session_id != NULL)
        {
            p_ssl->set_s_session_id(output_interface.s_session_id, output_interface.s_session_id_length);
        }
        if(output_interface.s_cipher_suites!= 0)
        {
            p_ssl->set_s_cipher_suites(ntohs((uint16_t)output_interface.s_cipher_suites));
        }
        if (output_interface.DH_s_pubkey != NULL)
        {
            p_ssl->set_dh_s_pubkey(output_interface.DH_s_pubkey,output_interface.DH_s_pubkey_len);
        }
        if(output_interface.DH_s_Algorithm_hash!=0)
        {
            p_ssl->set_dh_s_algorithm_hash(output_interface.DH_s_Algorithm_hash);
        }
        if(output_interface.DH_s_Algorithm_signature!=0)
        {
            p_ssl->set_dh_s_algorithm_signature(output_interface.DH_s_Algorithm_signature);
        }
        if (output_interface.DH_s_signature != NULL)
        {
            p_ssl->set_dh_s_signature(output_interface.DH_s_signature,output_interface.DH_s_signature_len);
        }
        if (output_interface.DH_c_pubkey != NULL)
        {
            p_ssl->set_dh_c_pubkey(output_interface.DH_c_pubkey, output_interface.DH_c_pubkey_len);
        }

        // 接口
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list->push_back(m_data);
    }
    return;
}

