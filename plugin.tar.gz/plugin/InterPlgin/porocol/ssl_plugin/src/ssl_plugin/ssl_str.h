
#ifndef SSL_STR_H
#define SSL_STR_H

#include<session.h>
#include<stdint.h>
#include<string>
#include<list>

#include <openssl/x509.h> 
#include <openssl/x509v3.h>
#include <openssl/pem.h>
#include <iostream>
#include <openssl/evp.h>
#include <stdio.h>
#include <time.h>

using namespace std;
#define HANDSHAKE           22
#define APPLICATIONDATA     23
#define CHANGECIPHER        20
#define ALERT               21

#define HELLO_REQUEST        0
#define CLIENT_HELLO         1
#define SERVER_HELLO         2
#define CERTIFICATE          11
#define SERVER_KEY_EXCHANGE  12
#define CERTIFICATE_REQUEST  13
#define SERVER_HELLO_DONE    14
#define CERTIFICATE_VERIFY   15
#define CLIENT_KEY_EXCHANGE  16
#define FINISHED             20


/*
#define NID_countryName                2.5.4.6
#define NID_stateOrProvinceName        
#define NID_localityName
#define NID_organizationName           2.5.4.10
#define NID_organizationalUnitName     2.5.4.11
#define NID_commonName                 2.5.4.3
#define NID_pkcs9_emailAddress        
*/


#pragma pack(push, 1)
struct ssl_msg_header
{   //uint8_t msg_length;
    //uint8_t message_type;
    uint8_t msg_type; /* handshake type */
    uint8_t version[2];
    uint16_t length; /* bytes in message */
};
#pragma pack(pop)

struct ssl_ctrl_msg_header
{
    uint8_t control_message_type;
};



class ssl_message
{
    public:
        ssl_message(uint16_t len,uint64_t time,bool b_packet_c2s,uint8_t ssl_msg_type,uint8_t ssl_msg_sub_type):message_length(len),packet_time(time),b_c2s(b_packet_c2s),msg_type(ssl_msg_type),msg_sub_type(ssl_msg_sub_type){};
        virtual ~ssl_message(){};
        virtual bool msg_body_parse(const char* p_data,int16_t data_len)=0;
        virtual void msg_body_display(){};
        void msg_header_display()
        {
            // fprintf(stderr,"    msg_type:  %d       msg_sub_type :  %d   \n",msg_type,msg_sub_type);
        };
    public:
        uint16_t message_length;
        uint64_t packet_time;
        bool b_c2s;
        uint8_t msg_type;
        uint8_t msg_sub_type;
};



class ClientHello:public ssl_message
{

    public:
        ClientHello(uint16_t len,uint64_t time,bool b_packet_c2s):ssl_message(len,time,b_packet_c2s,HANDSHAKE,CLIENT_HELLO){
            msg_body.session_id=NULL;
            msg_body.session_id_length=0;
            msg_body.cipher_suites=NULL;
            msg_body.server_name=NULL;
            msg_body.challenge=NULL;
            msg_body.client_version.major = 0;
            msg_body.client_version.minor = 0;
            msg_body.c_gmt_unix_time = "";
            msg_body.cipher_suites_length=0;
            msg_body.server_name_length=0;
            msg_body.challenge_length=0;
            memset(msg_body.random_bytes,0x00,32);
        };
        virtual ~ClientHello(){
            if(msg_body.session_id!= NULL)
            {       delete []msg_body.session_id;
            }
            msg_body.session_id=NULL;

            if(msg_body.cipher_suites!=NULL)
            {
               delete []msg_body.cipher_suites;
            }
            msg_body.cipher_suites=NULL;
           if(msg_body.server_name!=NULL)
            {
            delete []msg_body.server_name;
            }
            msg_body.server_name=NULL;
            if(msg_body.challenge!=NULL)
            {
            delete []msg_body.challenge;
            }
            msg_body.challenge=NULL;
        };
        virtual bool msg_body_parse(const char *p_data,int16_t data_len)
        {
            if((data_len<0)||(p_data==NULL))//||(size_t)data_len<sizeof(ClientHello_body))
            {return false;
            }
            int offset=0;
            
            
            
            if(*(uint8_t *)p_data==3&&(*(uint8_t *)(p_data +1)==3 ||(*(uint8_t *)(p_data +1)== 1)))
            {
            memcpy(&msg_body.client_version.major,p_data,1);
            if((data_len<offset))
            {
                return false;
            }
            memcpy(&msg_body.client_version.minor,p_data+1,1);
            msg_body.cipher_suites_length=ntohs(*(uint16_t *)(p_data+2));
            //memcpy(&(msg_body.session_id_length),p_data+4,2);
            if(p_data+4==NULL)
            {
            return false;
            }
            msg_body.session_id_length=ntohs(*(uint16_t *)(p_data+4));
            if(msg_body.session_id_length==0) 
            {
                msg_body.session_id=NULL;
            }
            else{
                msg_body.session_id=new char[msg_body.session_id_length];
                memcpy((char *)(msg_body.session_id),p_data+6,msg_body.session_id_length);
            }
            if(p_data+6+msg_body.session_id_length==NULL)
            {
            return false;
            }
            memset(msg_body.random_bytes,0x00,32);
            msg_body.challenge_length = ntohs(*(uint16_t *)(p_data+6+msg_body.session_id_length)); 
            if(msg_body.cipher_suites!=NULL)
                delete []msg_body.cipher_suites;
            if(p_data+8+msg_body.session_id_length==NULL)
            {
            return false;
            }
            msg_body.cipher_suites=new char[msg_body.cipher_suites_length];
            memset(msg_body.cipher_suites,0x00,msg_body.cipher_suites_length);
            memcpy(msg_body.cipher_suites,p_data+8+msg_body.session_id_length,msg_body.cipher_suites_length);
            msg_body.challenge=new char[msg_body.challenge_length];
            memset(msg_body.challenge,0x00,msg_body.challenge_length);
            memcpy(msg_body.challenge,p_data+8+msg_body.session_id_length+msg_body.cipher_suites_length,msg_body.challenge_length);
            msg_body.server_name = NULL; 
            return true; 
            }




            offset+=3;
            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&msg_body.client_version.major,p_data+offset,1);
            offset+=1;
            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&msg_body.client_version.minor,p_data+offset,1);
            if(msg_body.client_version.major>20||msg_body.client_version.minor>20)
            {
            return false;
            }
            //  msg_body.client_version=ntohs(*(uint16_t *)msg_body.client_version);
            offset+=1;

            if((data_len<offset+4)||(p_data+offset==NULL))
            {
                return false;
            }

            uint32_t c_unix_time=ntohl(*(uint32_t *)(p_data+offset));
            time_t time = c_unix_time;
            struct tm* p_time = localtime(&time);
            char buf[30];
            memset(buf,0x00,30);
            sprintf(buf,"%04d-%02d-%02d %02d:%02d:%02d", p_time->tm_year+1900, p_time->tm_mon+1, p_time->tm_mday, p_time->tm_hour, p_time->tm_min, p_time->tm_sec);
            msg_body.c_gmt_unix_time = buf;
            //memcpy(&(ntohl(*(uint32_t *)msg_body.gmt_unix_time),p_data+offset),4);
            //offset+=4;

            if((data_len<offset+32)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy((char *)(msg_body.random_bytes),p_data+offset,32);
            //  msg_body.random_bytes=p_data+offset;
            offset+=32;

            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&(msg_body.session_id_length),p_data+offset,1);
            offset+=1;

            if((data_len<offset+msg_body.session_id_length)||(p_data+offset==NULL))
            {
                return false;
            }
            //   memcpy((char *)msg_body.session_id,p_data+offset,msg_body.session_id_length);
            if(msg_body.session_id!=NULL)
                delete []msg_body.session_id;
            if(msg_body.session_id_length==0) 
            {
                msg_body.session_id=NULL;
            }
            else{
                msg_body.session_id=new char[msg_body.session_id_length];
                memcpy((char *)(msg_body.session_id),p_data+offset,msg_body.session_id_length);
            }
            // msg_body.session_id=(char *)(p_data+offset);
            offset+=msg_body.session_id_length;

            if((data_len<offset+2)||(p_data+offset==NULL))
            {
                return false;
            }
            msg_body.cipher_suites_length=ntohs(*(uint16_t *)(p_data+offset));
            //memcpy(&(msg_body.cipher_suites_length),ntohs(*(uint16_t *)p_data+offset),2);
            offset += 2;
            if((data_len<offset+ msg_body.cipher_suites_length)||(p_data+offset==NULL))
            {
                return false;
            }
            char * p =  (char  *) (p_data + offset ) ;
            if(msg_body.cipher_suites!=NULL)
                delete []msg_body.cipher_suites;
            /*msg_body.cipher_suites=new uint16_t[msg_body.cipher_suites_length/2];
            int i_offset = 0 ;
            for(int i=0;i<msg_body.cipher_suites_length/2;i++)
            {
                msg_body.cipher_suites[i]=*(uint16_t *)(p+i_offset);
                i_offset+=2;
            }*/
            msg_body.cipher_suites = new char[msg_body.cipher_suites_length];
            memcpy(msg_body.cipher_suites,p,msg_body.cipher_suites_length);
            offset += msg_body.cipher_suites_length;
            offset += 2;
            uint16_t ex_len_total= ntohs(*(uint16_t *)(p_data +offset));
            uint16_t len = data_len -offset;
            if(len >= ex_len_total)
            {
            offset+=2;
            while(len>0)
            {
            uint16_t type= ntohs(*(uint16_t *)(p_data + offset));
            offset+=2;
            uint16_t ex_len = ntohs(*(uint16_t *)(p_data +offset));
            offset+=2;
            if(type == 0)
            {
             msg_body.server_name_length=ntohs(*(uint16_t*)(p_data+offset+3));
             if(msg_body.server_name!=NULL)
             {
             delete []msg_body.server_name;
             }
             msg_body.server_name=new char[msg_body.server_name_length];
             memset(msg_body.server_name,0x00,msg_body.server_name_length);
             memcpy(msg_body.server_name,p_data+offset+5,msg_body.server_name_length);
             break;  
            }
            offset+=ex_len;
            len -=(2+2+ex_len);
            }
            }
            else
            {
            return false;
            }
            



            // fprintf(stderr,"!");
            // memcpy(&(msg_body.cipher_suites),ntohs(*(uint16_t *)p_data+offset),msg_body.cipher_suites_length/2);
            return true;
        };
        virtual void msg_body_display()
        {
            //  fprintf(stderr,"\tProtocolVersion: %d.%d\n\tgmt_unix_time: %d\n\trandom_byts: %s\n\tsession_id_length : %u\n\tsession_id : %s\n\tcipher_suites_length: %u\n\tcipher_suites: %u\n\t",msg_body.client_version.major,msg_body.client_version.minor,msg_body.gmt_unix_time,msg_body.random_bytes,msg_body.session_id_length,msg_body.session_id,msg_body.cipher_suites_length,msg_body.cipher_suites);

        };

    public:

        struct ProtocolVersion{
            uint8_t major;
            uint8_t minor;
        };
        //ProtocolVersion version = { 3, 3 }; /* TLS v1.2*/
        struct ClientHello_body
        {   //uint8_t length[3];
            ProtocolVersion client_version;
            string c_gmt_unix_time;
            char random_bytes[32];
            uint16_t session_id_length;
            char *session_id;
            uint16_t cipher_suites_length;
            //uint16_t *cipher_suites;
            char *cipher_suites;
            uint16_t server_name_length;
            char *server_name;
            uint16_t challenge_length;
            char *challenge;
        };
        struct ClientHello_body msg_body;

};

class ServerHello:public ssl_message
{

    public:
        ServerHello(uint16_t len,uint64_t time,bool b_packet_c2s):ssl_message(len,time,b_packet_c2s,HANDSHAKE,SERVER_HELLO){
            msg_body.session_id=NULL;
            msg_body.server_version.major = 0;
            msg_body.server_version.minor = 0;
            msg_body.cipher_suites = 0;
            msg_body.s_gmt_unix_time="";
            msg_body.session_id_length = 0;
            msg_body.cipher_suites=0;
            memset(msg_body.random_bytes,0x00,32);
        };
        virtual ~ServerHello(){
            if(msg_body.session_id!=NULL)
            {
                delete []msg_body.session_id;
            }
            msg_body.session_id=NULL;
        };
        virtual bool msg_body_parse(const char* p_data,int16_t data_len)
        {
            //      return true;
            if(data_len<0||p_data==NULL)//||(size_t)data_len<sizeof(ServerHello_body))
            {
                return false;
            }
            //   msg_body=*(ServerHello_body *)(p_data);
            int offset=0;
            offset+=3;
            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&msg_body.server_version.major,p_data+offset,1);
            offset+=1;

            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&msg_body.server_version.minor,p_data+offset,1);
            if(msg_body.server_version.major>20||msg_body.server_version.minor>20)
            {
            return false;
            }
            offset+=1;

            if((data_len<offset+4)||(p_data+offset==NULL))
            {
                return false;
            }
            uint32_t s_unix_time=ntohl(*(uint32_t *)(p_data+offset));
            time_t time = s_unix_time;
            struct tm* p_time = localtime(&time);
            char buf[30];
            memset(buf,0x00,30);
            sprintf(buf,"%04d-%02d-%02d %02d:%02d:%02d", p_time->tm_year+1900, p_time->tm_mon+1, p_time->tm_mday, p_time->tm_hour, p_time->tm_min, p_time->tm_sec);
            msg_body.s_gmt_unix_time = buf;
            //offset+=4;

            if((data_len<offset+32)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy((char *)(msg_body.random_bytes),p_data+offset,32);
            offset+=32;

            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&(msg_body.session_id_length),p_data+offset,1);
            offset+=1;

            if((data_len<offset+msg_body.session_id_length)||(p_data+offset==NULL))
            {
                return false;
            }
            if(msg_body.session_id != NULL)
                delete [] msg_body.session_id;
            if(msg_body.session_id_length==0)
            {
                msg_body.session_id=NULL;
            }
            else
            {msg_body.session_id=new char[msg_body.session_id_length];
                memcpy((char *)(msg_body.session_id),p_data+offset,msg_body.session_id_length);
            } 
            offset+=msg_body.session_id_length;

            if((data_len<offset+2)||(p_data+offset==NULL))
            {
                return false;
            }
            msg_body.cipher_suites=*(uint16_t *)(p_data+offset);



            return true;
        };
        virtual void msg_body_display()
        {
            //  fprintf(stderr,"ProtocolVersion:%d . %d\n\tgmt_unix_time: %d\n\trandom_byts: %s\n\tsession_id: %d\n\tcipher_suites:%d",msg_body.server_version.major,msg_body.server_version.minor,ntohl(msg_body.gmt_unix_time),msg_body.random_bytes,msg_body.session_id[msg_body.session_id_length],ntohs(msg_body.cipher_suites));
        };


    public:
        struct  ProtocolVersion{
            uint8_t major;
            uint8_t minor;
        };

        struct ServerHello_body
        {
            ProtocolVersion server_version;
            string s_gmt_unix_time;
            char random_bytes[32];
            uint8_t session_id_length;
            char *session_id;
            uint16_t cipher_suites;
        };

        struct ServerHello_body msg_body;
};


class Certificate_body
{
    public:
        Certificate_body(){};
        ~Certificate_body(){};
    public:
        string Certificate_Algorithm;
        uint64_t Certificate_PubKeyLength;
        string Certificate_PubKey;
        string issuer_CountryName;
        string issuer_ProvinceName;
        string issuer_localityName;
        string issuer_organizationName;
        string issuer_organizationalUnitName;
        string issuer_commonName;
        string issuer_emailAddress;
        string subject_countryName;
        string subject_ProvinceName;
        string subject_localityName;
        string subject_organizationName;
        string subject_organizationalUnitName;
        string subject_commonName;
        string subject_emailAddress;
        string Certificate_serialNumber;
        string notBefore;
        string notAfter;
        string kusage;
        string exkusage;
        string dns_name;
};



class Certificate:public ssl_message
{

    public:
        Certificate(uint16_t len,uint64_t time,bool b_packet_c2s):ssl_message(len,time,b_packet_c2s,HANDSHAKE,CERTIFICATE){certificate_list.clear();};
        virtual  ~Certificate(){
            list<Certificate_body*>::iterator iter = certificate_list.begin();
            for(;iter != certificate_list.end();iter++)
            {
                if((*iter) != NULL)
                {
                    delete(*iter);
                }
            }
            certificate_list.clear();

        };
        bool msg_body_parse(const char*p_data,int16_t data_len)
        {
            if(data_len<0)//||(size_t)data_len<sizeof(Certificate_body))
            {
                return false;
            }
            Certificate_pkt_parse(p_data,data_len);
            return true;
        };
        /*   virtual void msg_body_display()
             {
             fprintf(stderr,"",
             );
             }
             */
        //       int Certificate_parse(const char *p_data ,   struct Certificate_body  & msg_body );
        //struct Certificate_body  Certificate_parse(const char *p_data);*/
        //        void getCertificate_body(Certificate_body &certificate_bodyTmp);
        //list<X509*> certificate_list
        list<Certificate_body*> certificate_list;
    private :
        bool Certificate_pkt_parse(const char *p_data,int16_t data_len);
        Certificate_body *Certificate_parse(const char *p_data, int16_t data_len);
        /* 
           struct Certificate_body
           { //  X509 * usrCert;

        //uint8_t Certificate_len[3];//证书数据长度
        long version;//证书版本
        ASN1_INTEGER *Certificate_serialNumber;//证书序列号
        X509_NAME *issuer;//证书颁发者信息
        X509_NAME *subject;//证书拥有者信息
        ASN1_BIT_STRING *issuerUID;                          // 颁发者唯一标识    
        ASN1_BIT_STRING *subjectUID;                        // 持有者唯一标识  
        X509_VAL *validity;                                // 有效时间  
        //int entriesNum;
        //X509_NAME_ENTRY *name_entry;
        //long Nid;
        unsigned char msginfo[1024];
        //int msginfoLen;
        ASN1_TIME *notBefore; //保存证书有效期时间
        ASN1_TIME *notAfter;
        EVP_PKEY *PubKey; //保存证书公钥
        unsigned char Certificate_PubKey[2048];
        //   ASN1_BIT_STRING *Certificate_PubKey;
        int Certificate_PubKeyLength;
        int derpubkeyLen;
        unsigned char issuer_countryName[1024];
        unsigned char issuer_ProvinceName[1024];
        unsigned char issuer_localityName[1024];
        unsigned char issuer_organizationName[1024];
        unsigned char issuer_organizationalUnitName[1024];
        unsigned char issuer_commonName[1024];
        unsigned char issuer_emailAddress[1024];

        unsigned char subject_countryName[1024];
        unsigned char subject_ProvinceName[1024];
        unsigned char subject_localityName[1024];
        unsigned char subject_organizationName[1024];
        unsigned char subject_organizationalUnitName[1024];
        unsigned char subject_commonName[1024];
        unsigned char subject_emailAddress[1024];


        X509_ALGOR *sig_alg;//签名算法
        char Certificate_Algorithm[9];//Algorithm_id
        //            Certificate_PubKeyLength;
        //            Certificate_PubKey;
        //            uint8_t Certificate_signedCertificate_version;       
        //            char  Certificate_signedCertificate_serialNumber[16];
        //            char Certificate_Algorithm[9];
        //            char Certificate_validity[27];

        };
        struct Certificate_body msg_body;
        */
};


class ServerKeyExchange:public ssl_message
{
    public :
        ServerKeyExchange(uint16_t len,uint64_t time,bool b_packet_c2s):ssl_message(len,time,b_packet_c2s,HANDSHAKE,SERVER_KEY_EXCHANGE){
            msg_body.DH_s_pubkey=NULL;
            msg_body.DH_s_signature=NULL;
            msg_body.DH_s_Algorithm_hash=0;
            msg_body.DH_s_Algorithm_signature=0;
            msg_body.DH_s_pubkey_len=0;
            msg_body.DH_s_signature_len=0;
        };
        virtual ~ServerKeyExchange(){
            if(msg_body.DH_s_pubkey!=NULL)
                delete []msg_body.DH_s_pubkey;
            msg_body.DH_s_pubkey=NULL;

            if(msg_body.DH_s_signature!=NULL)
                delete[]msg_body.DH_s_signature;
            msg_body.DH_s_signature=NULL;

        };
        virtual bool msg_body_parse(const char * p_data,int16_t data_len)
        {
            if(data_len<0)//||(size_t)data_len<sizeof(ServerKeyExchange_body))
            {
                return false;
            }
            int offset=0;
            if(p_data==NULL)
            {
            return false;
            }
            if(p_data+4 == NULL)
            {
            return false;
            }
            uint32_t length =  ntohl(*(uint32_t*)(p_data+offset));
            length = length>>8;
            if(data_len < (length+4))
            {
            return false;
            }
            int16_t offset1=0;
            int16_t offset2=0;
            int16_t offset3=0;
            int16_t offset4=0;
            if(p_data+offset+3!=NULL)
            {
             offset1 = ntohs(*(uint16_t *)(p_data+offset+3));
            }
            if(p_data+offset+5+offset1!=NULL&&((p_data+offset+5+offset1+2)!=NULL)&&offset1>0)
            {
             offset2 = ntohs(*(uint16_t *)(p_data+offset+5+offset1));
            }
            if(p_data+offset+7+offset1+offset2!=NULL&&(p_data+offset+7+offset1+offset2+2)!=NULL&&offset2>0)
            {
             offset3 = ntohs(*(uint16_t *)(p_data+offset+7+offset1+offset2));
            }
            if(p_data+offset+9+offset1+offset2+offset3!=NULL&&(p_data+offset+9+offset1+offset2+offset3+2)!=NULL&&offset3>0)
            {
             offset4 = ntohs(*(uint16_t *)(p_data+offset+9+offset1+offset2+offset3));
            }
           if(length == (8+offset1+offset2+offset3+offset4)&&offset4>0)
           {
            msg_body.DH_s_pubkey_len = offset3;
            offset += (9+offset1+offset2);
            if(msg_body.DH_s_pubkey!=NULL)
                delete []msg_body.DH_s_pubkey;
            msg_body.DH_s_pubkey=new char[msg_body.DH_s_pubkey_len];
            memcpy((char *)msg_body.DH_s_pubkey,p_data+offset,msg_body.DH_s_pubkey_len);
            msg_body.DH_s_signature_len=offset4;
            offset+= (2+offset3);
            if(msg_body.DH_s_signature!=NULL)
                delete []msg_body.DH_s_signature;
            msg_body.DH_s_signature=new char[msg_body.DH_s_signature_len];
            memcpy((char *)msg_body.DH_s_signature,p_data+offset,msg_body.DH_s_signature_len);
           }
            else
            {
            offset+=6;
            if((data_len<offset+1)||(p_data+offset==NULL))
            {
                return false;
            }
            //memcpy(&(msg_body.DH_s_pubkey_len),p_data+offset,1);
            msg_body.DH_s_pubkey_len = *(uint8_t *)(p_data+offset);
            msg_body.DH_s_signature_len=ntohs(*(uint16_t *)(p_data+offset+3+msg_body.DH_s_pubkey_len));
            if(length!=(msg_body.DH_s_pubkey_len+msg_body.DH_s_signature_len+8))
            {
            return false;
            }
            offset+=1;
            if(data_len<msg_body.DH_s_pubkey_len+offset||(p_data+offset==NULL))
            {
                return false;
            }
            if(msg_body.DH_s_pubkey!=NULL)
                delete []msg_body.DH_s_pubkey;
            msg_body.DH_s_pubkey=new char[msg_body.DH_s_pubkey_len];
            memcpy((char *)msg_body.DH_s_pubkey,p_data+offset,msg_body.DH_s_pubkey_len);
            offset+=msg_body.DH_s_pubkey_len;
            if(data_len<offset+1||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&(msg_body.DH_s_Algorithm_hash),p_data+offset,1);
            offset+=1;
            if(data_len<offset+1||(p_data+offset==NULL))
            {
                return false;
            }
            memcpy(&(msg_body.DH_s_Algorithm_signature),p_data+offset,1);
            offset+=1;
            if(data_len<offset+2||(p_data+offset==NULL))
            {
                return false;
            }
            //msg_body.DH_s_signature_len=ntohs(*(uint16_t *)(p_data+offset));
            offset+=2;
            if(data_len<offset+msg_body.DH_s_signature_len||(p_data+offset==NULL))
            {
                return false;
            }
            if(msg_body.DH_s_signature!=NULL)
                delete []msg_body.DH_s_signature;
            msg_body.DH_s_signature=new char[msg_body.DH_s_signature_len];
            memcpy((char *)msg_body.DH_s_signature,p_data+offset,msg_body.DH_s_signature_len);
            }


            return true;
        };
        virtual void msg_body_display()
        {
            //     fprintf(stderr,"\tDH_s_pubkey_len:%d\n\tDH_s_pubkey:%d\n\tDH_s_Algorithm_hash:%d\n\tDH_s_Algorithm_signature:%d\n\tDH_s_signature_len:%d\n\tDH_s_signature:%d\n\t",msg_body.DH_s_pubkey_len,msg_body.DH_s_pubkey[msg_body.DH_s_pubkey_len],msg_body.DH_s_Algorithm_hash,msg_body.DH_s_Algorithm_signature,ntohs(msg_body.DH_s_signature_len),msg_body.DH_s_signature[ntohs(msg_body.DH_s_signature_len)]);

        };

    public:
        struct ServerKeyExchange_body
        {
            uint16_t DH_s_pubkey_len;
            char *DH_s_pubkey;
            uint8_t DH_s_Algorithm_hash;
            uint8_t DH_s_Algorithm_signature;
            uint16_t DH_s_signature_len;
            char *DH_s_signature;
        };
        struct ServerKeyExchange_body msg_body;
};




class ClientKeyExchange:public ssl_message
{
    public:
        ClientKeyExchange(uint16_t len,uint64_t time,bool b_packet_c2s):ssl_message(len,time,b_packet_c2s,HANDSHAKE,CLIENT_KEY_EXCHANGE){
            msg_body.DH_c_pubkey=NULL;
            msg_body.DH_c_pubkey_len=0;
        };
        virtual ~ClientKeyExchange(){
            if(msg_body.DH_c_pubkey!=NULL)
                delete []msg_body.DH_c_pubkey;
            msg_body.DH_c_pubkey=NULL;
        };
        virtual bool msg_body_parse(const char *p_data,int16_t data_len)
        {
            if(data_len<0||(p_data==NULL))//||(size_t)data_len<sizeof(ClientKeyExchange_body))
            {
                return false;
            }
            int offset=0;
            uint32_t total_len;
            total_len = ntohl(*(uint32_t*)(p_data+offset));
            total_len = total_len >> 8;
            offset+=3;
            if(data_len<offset+1||(p_data+offset==NULL))
            {
                return false;
            }
          //  memcpy(&(msg_body.DH_c_pubkey_len),p_data+offset,1);
            msg_body.DH_c_pubkey_len = *(uint8_t *)(p_data+offset);
               /* memcpy(&(msg_body.DH_c_pubkey_len),p_data+offset,2);
                if(DH_c_pubkey_total_len != (msg_body.DH_c_pubkey_len + 2))
                */
            if(total_len!=(msg_body.DH_c_pubkey_len+1))
            {
             if(total_len == (ntohs(*(uint16_t *)(p_data+offset))+2))
             {
                msg_body.DH_c_pubkey_len=ntohs(*(uint16_t *)(p_data+offset));
              if(data_len<offset +2+ msg_body.DH_c_pubkey_len || (p_data+NULL==NULL))
             {
             return false;
             }
              msg_body.DH_c_pubkey=new char[msg_body.DH_c_pubkey_len];
              memcpy((char *)msg_body.DH_c_pubkey,p_data+offset+2,msg_body.DH_c_pubkey_len);
             }
             else
             {
                 msg_body.DH_c_pubkey_len=total_len;
              if(data_len<offset + msg_body.DH_c_pubkey_len || (p_data+NULL==NULL))
             {
             return false;
             }
              msg_body.DH_c_pubkey=new char[msg_body.DH_c_pubkey_len];
              memcpy((char *)msg_body.DH_c_pubkey,p_data+offset,msg_body.DH_c_pubkey_len);
             }
             return true;
            }


            offset+=1;
            if(data_len<offset+msg_body.DH_c_pubkey_len||(p_data+offset==NULL))
            {
                return false;
            }
            if(msg_body.DH_c_pubkey!=NULL)
                delete []msg_body.DH_c_pubkey;
            /*if(total_len != (msg_body.DH_c_pubkey_len + 1))
            {
            msg_body.DH_c_pubkey=NULL;
            return true;
            }*/
            msg_body.DH_c_pubkey=new char[msg_body.DH_c_pubkey_len];
            memcpy((char *)msg_body.DH_c_pubkey,p_data+offset,msg_body.DH_c_pubkey_len);
            return true;
        };
        virtual void  msg_body_display()
        {

            //fprintf(stderr,"\tDH_c_pubkey_len:%d\n\tDH_c_pubkey:%d\n\t",msg_body.DH_c_pubkey_len,msg_body.DH_c_pubkey[msg_body.DH_c_pubkey_len]);



        };
    public:
        struct ClientKeyExchange_body
        {
            uint32_t DH_c_pubkey_len;
            char *DH_c_pubkey;
        };
        struct ClientKeyExchange_body msg_body;
};

class ssl_output_interface
{
    public:
        ssl_output_interface(){};
        ~ssl_output_interface(){};
        void init()
        {  
            direction=0;
            client_version_major=0;
            client_version_minor=0;
            server_version_major=0;
            server_version_minor=0;
            c_gmt_unix_time="";
            s_gmt_unix_time="";
            c_random_bytes="";
            //memset(c_random_bytes,0x00,28);
            c_session_id_length=0;
            s_session_id_length=0;
            s_session_id=NULL;
            c_session_id=NULL;
            cipher_suites_length=0;
            c_cipher_suites= NULL;
            challenge_length=0;
            challenge = NULL;
            Server_Name_length = 0;
            c_Server_Name = NULL;
            //memset(s_random_bytes,0x00,28);
            s_random_bytes="";
            s_cipher_suites=0;
            DH_s_pubkey_len=0;
            DH_s_pubkey=NULL;
            DH_s_Algorithm_hash=NULL;
            DH_s_Algorithm_signature=NULL;
            DH_s_signature=NULL;
            DH_s_signature_len=0;
            DH_c_pubkey_len=0;
            DH_c_pubkey=NULL;
            certificate_list.clear();
            mac_line_number = "";
            device_num = "";
            dev_no = "";
            layer_type = 0;
            is_ipv4 = 0;
            is_ipv6 = 0;
            is_mpls = 0;
            n_label = 0;
            in_nerlabel = 0;
            other_label = 0;
            proto = 0;
            duration = 0;
            total_payloadbytes = 0;
            total_payloadpackets = 0;
        };

        uint64_t time;
        c_ip server_ip;
        c_ip client_ip;
        string mac_line_number;
        string device_num;
        string dev_no;
        uint32_t layer_type;
        uint32_t is_ipv4;
        uint32_t is_ipv6;
        uint32_t is_mpls;
        uint32_t n_label;
        uint32_t in_nerlabel;
        uint32_t other_label;
        uint32_t proto;
        double  duration;
        //double ip_ju;
        //double ip_wd;
        uint32_t total_payloadbytes;
        uint32_t total_payloadpackets;

        uint16_t server_port;
        uint16_t client_port;
        uint8_t  direction;
        double communication_rate;
        uint8_t   client_version_major;
        uint8_t  client_version_minor;
        string c_gmt_unix_time;
        //char  c_random_bytes[28];
        string  c_random_bytes;
        uint16_t c_session_id_length;
        char *c_session_id;
        uint16_t  cipher_suites_length;
        //uint16_t *c_cipher_suites;
        char *c_cipher_suites;
        uint16_t challenge_length;
        char * challenge;
        uint16_t Server_Name_length;
        char *c_Server_Name;
        uint8_t server_version_major;
        uint8_t server_version_minor;
        string s_gmt_unix_time;
        //char s_random_bytes[28];
        string s_random_bytes;
        uint8_t s_session_id_length;
        char *s_session_id;
        uint16_t s_cipher_suites ;
        uint16_t DH_s_pubkey_len;
        char *DH_s_pubkey;
        uint8_t DH_s_Algorithm_hash;
        uint8_t DH_s_Algorithm_signature;
        char *DH_s_signature;
        uint16_t DH_s_signature_len;
        uint32_t DH_c_pubkey_len;
        char *DH_c_pubkey;
        list<Certificate_body*> certificate_list;
};


class ssl_session
{
    public:
        uint64_t requst_time;
        uint64_t response_time;
        list<ssl_message *> *sl_msg;   //一个ssl消息链表，存储所有接收到的ssl消息
        uint16_t msg_len;
        uint32_t len;
        int16_t data_len;
        char * p_data;
        uint64_t packet_time;
        bool b_c2s;
        int state;
    public:
        ssl_message *ssl_pkt_parse(const char* p_data,int16_t data_len,ssl_session * p_ssl_session);//ssl数据包解析函数
        void display_ssl_msg_list();   //打印函数，仅供测试使用


};

#endif /*SSL_STR_H*/




































