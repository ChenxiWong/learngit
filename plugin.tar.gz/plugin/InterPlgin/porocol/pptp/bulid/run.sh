#!/bin/bash
make clean
make
cp -rf  $NPR_SDK/../plugin/InterPlgin/porocol/pptp/lib/libpptp.so  $NPR_ROOT/plugin/InterPlugin/

