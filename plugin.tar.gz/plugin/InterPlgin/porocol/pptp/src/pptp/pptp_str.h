// Last Update:2016-05-12 14:58:09
/**
 * @file pptp_str.h
 * @brief pptp Session 定义
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-04-21
 */

#ifndef PPTP_STR_H
#define PPTP_STR_H

#include <session.h>
#include <stdint.h>
#include <string>
#include <list>
using namespace std;

//消息类型宏定义  RFC2637 P8
#define CONTROL_MESSAGE         1
#define MANAGEMENT_MESSAGE      2


//控制消息类型宏定义  RFC2637 P9
#define START_CONTROL_CONNECTION_REQUEST        1
#define START_CONTROL_CONNECTION_REPLY          2
#define STOP_CONTROL_CONNECTION_REQUEST         3
#define STOP_CONTROL_CONNECTION_REPLY           4
#define ECHO_REQUEST                            5
#define ECHO_REPLY                              6
#define OUTGOING_CALL_REQUEST                   7
#define OUTGOING_CALL_REPLY                     8
#define INCOMING_CALL_REQUEST                   9
#define INCOMING_CALL_REPLY                     10
#define INCOMING_CALL_CONNECTED                 11
#define CALL_CLEAR_REQUEST                      12
#define CALL_DISCONNECT_NOTIFY                  13
#define WAN_ERROR_NOTIFY                        14
#define SET_LINK_INFO                           15

static char NO_NULL[1]={0};

//#pragma pack(push, 1)

//PPTP消息头
struct pptp_message_header
{
    uint16_t msg_length;
    uint16_t message_type;
    uint32_t magic_cookie;
};


//PPTP控制消息头
struct pptp_ctrl_msg_header
{
    uint16_t control_message_type;
    uint16_t reserved0;
};
//#pragma pack(pop)



//PPTP消息类
class pptp_message
{
    public:
        pptp_message(uint16_t len, uint64_t time, bool b_packet_c2s, uint16_t pptp_message_type, uint16_t pptp_message_sub_type)
            :message_length(len), packet_time(time), b_c2s(b_packet_c2s), message_type(pptp_message_type), message_sub_type(pptp_message_sub_type){};
        virtual ~pptp_message(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len) = 0;          //消息体解析函数，纯虚函数
        virtual void msg_body_display(){};                                              //消息体打印函数，仅供调试使用
        void msg_header_display()                                                       //消息头打印函数，仅供调试使用
        {
            printf("    Message type: %d\n    Message subtype: %d \n",message_type, message_sub_type);
        };
    public:
        uint16_t message_length;
        uint64_t packet_time;                                                           //消息时间
        bool b_c2s;                                                                     //方向判断，true:方向为c2s，false:方向为s2c
        uint16_t message_type;                                                          //消息类型：控制消息or管理消息
        uint16_t message_sub_type;                                                      //消息子类类型
        //void *p_msg_body;
        //pritvate:
        //bool pptp_message_header_parse();
};


//Start-Control-Connection-Request消息类 RFC2637 P11
class start_control_connection_request:public pptp_message
{
    public:
        start_control_connection_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, START_CONTROL_CONNECTION_REQUEST){};
        virtual ~start_control_connection_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(start_control_connection_request_body))
            {
                return false;
            }
            msg_body = *(start_control_connection_request_body*)p_data;
            return true;
        };
        virtual void msg_body_display()
        {
            printf("\tprotocol_version: %d.%d\n\tframing_capabilities: %d\n\tbearer_capabilities:%d\n\tmaximum_channels: %d\n\tfirmware_revision: %d\n\thost_name: %s\n\tvendor_string: %s\n",\
                    (uint8_t)msg_body.protocol_version, msg_body.protocol_version >> 8,ntohl(msg_body.framing_capabilities), ntohl(msg_body.bearer_capabilities), \
                    ntohs(msg_body.maximum_channels), ntohs(msg_body.firmware_revision), msg_body.host_name, msg_body.vendor_string);
        }
    public:
        struct start_control_connection_request_body
        {
            uint16_t protocol_version;
            uint16_t reserved1;
            uint32_t framing_capabilities;
            uint32_t bearer_capabilities;
            uint16_t maximum_channels;
            uint16_t firmware_revision;
            char host_name[64];
            char vendor_string[64];
        };
        struct start_control_connection_request_body msg_body;
};



//Start-Control-Connection-Reply消息类 RFC2637 P13
class start_control_connection_reply:public pptp_message
{
    public:
        start_control_connection_reply(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, START_CONTROL_CONNECTION_REPLY){};
        virtual ~start_control_connection_reply(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(start_control_connection_reply_body))
            {
                return false;
            }
            msg_body = *(start_control_connection_reply_body*)p_data;
            return true;
        };
        virtual void msg_body_display()
        {
            printf("\tprotocol_version: %d.%d\n\tresult_code: %d\n\terror_code: %d\n\tframing_capabilities: %d\n\tbearer_capabilities: %d\n\tmaximum_channels: %d\n\tfirmware_revision: %d\
                    \n\thost_name: %s\n\tvendor_string: %s\n",\
                    (uint8_t)msg_body.protocol_version, msg_body.protocol_version >> 8, msg_body.result_code, msg_body.error_code, ntohl(msg_body.framing_capabilities), ntohl(msg_body.bearer_capabilities), \
                    ntohs(msg_body.maximum_channels), ntohs(msg_body.firmware_revision), msg_body.host_name, msg_body.vendor_string);
        };

    public:
        struct start_control_connection_reply_body
        {
            uint16_t protocol_version;
            uint8_t result_code;
            uint8_t error_code;
            uint32_t framing_capabilities;
            uint32_t bearer_capabilities;
            uint16_t maximum_channels;
            uint16_t firmware_revision;
            char host_name[64];
            char vendor_string[64];
        };
        struct start_control_connection_reply_body msg_body;
};


//Stop-Control-Connection-Request消息类 RFC2637 P15
class stop_control_connection_request:public pptp_message
{
    public:
        stop_control_connection_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, STOP_CONTROL_CONNECTION_REQUEST){};
        virtual ~stop_control_connection_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(stop_control_connection_request_body))
            {
                return false;
            }
            msg_body = *(stop_control_connection_request_body*)p_data;
            return true;
        };

    public:
        struct stop_control_connection_request_body
        {
            uint8_t reason;
            uint8_t reserved1;
            uint16_t reserved2;
        };
        struct stop_control_connection_request_body msg_body;
};


//Stop-Control-Connection-Reply消息类 RFC2637 P16
class stop_control_connection_reply:public pptp_message
{
    public:
        stop_control_connection_reply(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, STOP_CONTROL_CONNECTION_REPLY){};
        virtual ~stop_control_connection_reply(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(stop_control_connection_reply_body))
            {
                return false;
            }
            msg_body = *(stop_control_connection_reply_body*)p_data;
            return true;
        };

    public:
        struct stop_control_connection_reply_body
        {
            uint8_t result_code;
            uint8_t error_code;
            uint16_t reserved1;
        };
        struct stop_control_connection_reply_body msg_body;
};


//Echo-Request消息类 RFC2637 P17
class echo_request:public pptp_message
{
    public:
        echo_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, ECHO_REQUEST){};
        virtual ~echo_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(uint32_t))
            {
                return false;
            }
            identifier = *(uint32_t*)p_data;
            return true;
        };

    public:
        uint32_t identifier;
};

//Echo-Reply消息类 RFC2637 P18
class echo_reply:public pptp_message
{
    public:
        echo_reply(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, ECHO_REPLY){};
        virtual ~echo_reply(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(echo_reply_body))
            {
                return false;
            }
            msg_body = *(echo_reply_body*)p_data;
            return true;
        };

    public:
        struct echo_reply_body
        {
            uint32_t identifier;
            uint8_t result_code;
            uint8_t error_code;
            uint16_t reserved1;
        };
        struct echo_reply_body msg_body;
};



//Outgoing-Call-Request消息类 RFC2637 P20
class outgoing_call_request:public pptp_message
{
    public:
        outgoing_call_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, OUTGOING_CALL_REQUEST){};
        virtual ~outgoing_call_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(outgoing_call_request_body))
            {
                return false;
            }
            msg_body = *(outgoing_call_request_body*)p_data;
            return true;
        };
        virtual void msg_body_display()
        {
            printf("\tcall_id: %d\n\tcall_serial_number: %d\n\tminimum_bps: %d\n\tmaximum_bps: %d\n\tbearer_type: %d\n\tframing_type: %d\n\tpacket_recv_window_size: %d\
                    \n\tpacket_processing_delay: %d\n\tphone_number_length: %d\n",\
                    ntohs(msg_body.call_id), ntohs(msg_body.call_serial_number), ntohl(msg_body.minimum_bps), ntohl(msg_body.maximum_bps), ntohl(msg_body.bearer_type), ntohl(msg_body.framing_type),\
                    ntohs(msg_body.packet_recv_window_size), ntohs(msg_body.packet_processing_delay), ntohs(msg_body.phone_number_length));
            printf("\tphone_number: ");
            for(int i=0; i<64; i++)
            {
                printf("%02X ",(unsigned char)msg_body.phone_number[i]);
            }
            printf("\n\tsubaddress: ");
            for(int j=0; j<64; j++)
            {
                printf("%02X ",(unsigned char)msg_body.subaddress[j]);
            }
            printf("\n");
        };

    public:
        struct outgoing_call_request_body
        {
            uint16_t call_id;
            uint16_t call_serial_number;
            uint32_t minimum_bps;
            uint32_t maximum_bps;
            uint32_t bearer_type;
            uint32_t framing_type;
            uint16_t packet_recv_window_size;
            uint16_t packet_processing_delay;
            uint16_t phone_number_length;
            uint16_t reserved1;
            char phone_number[64];
            char subaddress[64];
        };
        struct outgoing_call_request_body msg_body;
};


//Outgoing-Call-Reply消息类 RFC2637 P23
class outgoing_call_reply:public pptp_message
{
    public:
        outgoing_call_reply(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, OUTGOING_CALL_REPLY){};
        virtual ~outgoing_call_reply(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(outgoing_call_reply_body))
            {
                return false;
            }
            msg_body = *(outgoing_call_reply_body*)p_data;
            return true;
        };
        virtual void msg_body_display()
        {
            printf("\tcall_id: %d\n\tpeers_call_id: %d\n\tresult_code: %d\n\terror_code: %d\n\tcause_code: %d\n\tconnect_speed: %d\n\tpacket_recv_window_size: %d\n\tpacket_processing_delay: %d\
                    \n\tphysical_channel_id: %d\n",\
                    ntohs(msg_body.call_id), ntohs(msg_body.peers_call_id), msg_body.result_code, msg_body.error_code, msg_body.cause_code, ntohl(msg_body.connect_speed), ntohs(msg_body.packet_recv_window_size),\
                    ntohs(msg_body.packet_processing_delay), ntohl(msg_body.physical_channel_id));
        };

    public:
        struct outgoing_call_reply_body
        {
            uint16_t call_id;
            uint16_t peers_call_id;
            uint8_t result_code;
            uint8_t error_code;
            uint16_t cause_code;
            uint32_t connect_speed;
            uint16_t packet_recv_window_size;
            uint16_t packet_processing_delay;
            uint32_t physical_channel_id;
        };
        struct outgoing_call_reply_body msg_body;
};



//Incoming-Call-Request RFC2637 P26
class incoming_call_request:public pptp_message
{
    public:
        incoming_call_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, INCOMING_CALL_REQUEST){};
        virtual ~incoming_call_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(incoming_call_request_body))
            {
                return false;
            }
            msg_body = *(incoming_call_request_body*)p_data;
            return true;
        };

    public:
        struct incoming_call_request_body
        {
            uint16_t call_id;
            uint16_t call_serial_number;
            uint32_t call_bearer_type;
            uint32_t physical_channel_id;
            uint16_t dialed_number_length;
            uint16_t dialing_number_length;
            char dialed_number[64];
            char dialing_number[64];
            char subaddress[64];
        };
        struct incoming_call_request_body msg_body;
};



//Incoming-Call-Reply消息类 RFC2637 P28
class incoming_call_reply:public pptp_message
{
    public:
        incoming_call_reply(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, INCOMING_CALL_REPLY){};
        virtual ~incoming_call_reply(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(incoming_call_reply_body))
            {
                return false;
            }
            msg_body = *(incoming_call_reply_body*)p_data;
            return true;
        };

    public:
        struct incoming_call_reply_body
        {
            uint16_t call_id;
            uint16_t peers_call_id;
            uint8_t result_code;
            uint8_t error_code;
            uint16_t packet_recv_window_size;
            uint16_t packet_processing_delay;
            uint16_t reserved1;
        };
        struct incoming_call_reply_body msg_body;
};



//Incoming-Call-Connected消息类 RFC2637 P30
class incoming_call_connected:public pptp_message
{
    public:
        incoming_call_connected(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, INCOMING_CALL_CONNECTED){};
        virtual ~incoming_call_connected(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(incoming_call_connected_body))
            {
                return false;
            }
            msg_body = *(incoming_call_connected_body*)p_data;
            return true;
        };

    public:
        struct incoming_call_connected_body
        {
            uint16_t peers_call_id;
            uint16_t reserved1;
            uint32_t connect_speed;
            uint16_t packet_recv_window_size;
            uint16_t packet_processing_delay;
            uint32_t framing_type;
        };
        struct incoming_call_connected_body msg_body;
};



//Call-Clear-Request消息类 P31
class call_clear_request:public pptp_message
{
    public:
        call_clear_request(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, CALL_CLEAR_REQUEST){};
        virtual ~call_clear_request(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(call_clear_request_body))
            {
                return false;
            }
            msg_body = *(call_clear_request_body*)p_data;
            return true;
        };

    public:
        struct call_clear_request_body
        {
            uint16_t call_id;
            uint16_t reserved1;
        };
        struct call_clear_request_body msg_body;
};



//Call-Disconnect-Notify消息类 RFC2637 P32
class call_disconnect_notify:public pptp_message
{
    public:
        call_disconnect_notify(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, CALL_DISCONNECT_NOTIFY){};
        virtual ~call_disconnect_notify(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(call_disconnect_notify_body))
            {
                return false;
            }
            msg_body = *(call_disconnect_notify_body*)p_data;
            return true;
        };

    public:
        struct call_disconnect_notify_body
        {
            uint16_t call_id;
            uint8_t result_code;
            uint8_t error_code;
            uint16_t cause_code;
            uint16_t reserved1;
            char call_statistics[128];
        };
        struct call_disconnect_notify_body msg_body;
};

//WAN-Error-Notify消息类 RFC2637 P34
class wan_error_notify:public pptp_message
{
    public:
        wan_error_notify(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, WAN_ERROR_NOTIFY){};
        virtual ~wan_error_notify(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(wan_error_notify_body))
            {
                return false;
            }
            msg_body = *(wan_error_notify_body*)p_data;
            return true;
        };

    public:
        struct wan_error_notify_body
        {
            uint16_t peers_call_id;
            uint16_t reserved1;
            uint32_t crc_errors;
            uint32_t framing_errors;
            uint32_t hardware_overruns;
            uint32_t buffer_overruns;
            uint32_t timeout_errors;
            uint32_t alignment_errors;
        };
        struct wan_error_notify_body msg_body;
};


//Set-Link-Info消息类 RFC2637 P35
class set_link_info:public pptp_message
{
    public:
        set_link_info(uint16_t len, uint64_t time, bool b_packet_c2s):pptp_message(len, time, b_packet_c2s, CONTROL_MESSAGE, SET_LINK_INFO){};
        virtual ~set_link_info(){};
        virtual bool msg_body_parse(const char* p_data, int16_t data_len)
        {
            if(data_len < 0 || (size_t)data_len < sizeof(set_link_info_body))
            {
                return false;
            }
            msg_body = *(set_link_info_body*)p_data;
            return true;
        };
        virtual void msg_body_display()
        {
            printf("\tpeers_call_id: %d\n\tsend_accm: %#X\n\treceive_accm: %#X\n",ntohs(msg_body.peers_call_id), ntohl(msg_body.send_accm), ntohl(msg_body.receive_accm));
        };

    public:
        struct set_link_info_body
        {
            uint16_t peers_call_id;
            uint16_t reserved1;
            uint32_t send_accm;
            uint32_t receive_accm;
        };
        struct set_link_info_body msg_body;
};


class pptp_output_interface
{
    public:
        pptp_output_interface(){};
        ~pptp_output_interface(){};
        void init()
        {
            direction = 0;
            protocol_version = 0;
            communication_rate = 0;
            message_type = 0;
            framing_capabilities = 0;
            bearer_capabilities = 0;
            server_firmware_revision = 0;
            client_firmware_revision = 0;
            memset(server_hostname, 0x00, 64);
            memset(client_hostname, 0x00, 64);

            // 王晨曦 添加用户需求之增加解析Vendor Name 字段
            memset(vendor_name, 0x00, 64);
            server_call_id = 0;
            client_call_id = 0;
            call_serial_number = 0;
            server_send_accm = 0;
            server_receive_accm = 0;
            client_send_accm = 0;
            client_receive_accm = 0;
            mac_line_number = "";
            device_num = "";
            layer_type = 0;
            is_ipv4 = 0;
            is_ipv6 = 0;
            is_mpls = 0;
            n_label = 0;
            in_nerlabel = 0;
            other_label = 0;
            proto = 0;
            duration = 0;
            total_payloadbytes = 0;
            total_payloadpackets = 0;
        };
        //void message_handling(isakmp_message *p_msg, session* p_session);
    public:
        uint64_t time;
        c_ip server_ip;
        c_ip client_ip;
        string mac_line_number;
        string device_num;
        uint32_t layer_type;
        uint32_t is_ipv4;
        uint32_t is_ipv6;
        uint32_t is_mpls;
        uint32_t n_label;
        uint32_t in_nerlabel;
        uint32_t other_label;
        uint32_t proto;
        double  duration;
        //double ip_ju;
        //double ip_wd;
        uint32_t total_payloadbytes;
        uint32_t total_payloadpackets;

        uint16_t server_port;
        uint16_t client_port;
        uint8_t  direction;
        double communication_rate;
        uint16_t protocol_version;
        uint16_t message_type;

        uint32_t framing_capabilities;
        uint32_t bearer_capabilities;
        uint32_t server_firmware_revision;
        uint32_t client_firmware_revision;
        char server_hostname[64];
        char client_hostname[64];

        // 王晨曦 添加用户需求之增加解析Vendor Name 字段
        char vendor_name[64];
        uint32_t server_call_id;
        uint32_t client_call_id;
        uint32_t call_serial_number;
        uint32_t server_send_accm;
        uint32_t server_receive_accm;
        uint32_t client_send_accm;
        uint32_t client_receive_accm;
};




class pptp_session
{
    public:
        uint64_t requst_time;
        uint64_t response_time;
        list<pptp_message*> *pl_msg;                                            //一个pptp消息链表，存储所有接收到的pptp消息

        int16_t data_len;
        char *p_data;
        uint64_t packet_time;
        bool b_c2s; // 方向判断，true:方向为c2s，false:方向为s2c
    public:
        pptp_message *pptp_pkt_parse(const char* p_data, int16_t data_len);     //PPTP数据包解析函数
        void display_pptp_message_list();                                       //打印函数，仅供测试使用
};

#endif  /*PPTP_STR_H*/
