// Last Update:2016-09-12 16:52:54
/**
 * @file pptp_plugin.cpp
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-04-21
 */

#include "pptp_plugin.h"
#include <commit_tools.h>
#include <sys/stat.h>

#define PPTPDEFINEPORT 1723

static bool b_check_config  = true;

extern "C"
{
    int get_plugin_id()
    {
        return 10002;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p;
        return new  pptp_plugin();
    }
}


pptp_plugin::pptp_plugin()
{
    data_interface_type = FILESEND;
    pptp_time_out = 1;
    reload();
}

pptp_plugin::~pptp_plugin()
{
}

void pptp_plugin::reload()
{
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/pptp_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" )
        {
            data_interface_type = NETSEND;
        }
    }
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        pptp_time_out = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_row");
    if(p_value != NULL)
    {
        max_row = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/max_time");
    if(p_value != NULL)
    {
        max_time_scr = atoi(p_value);
    }

    if(b_check_config)
    {
        b_check_config = false;
        //协议识别
        string path = "/config/DFI";
        int num  = xml.get_value_count(path.c_str());
        for(int i = 0 ; i < num ; i++)
        {
            string xpath = path;
            xml.assemble_path(xpath, i);
            string type_path = xpath;
            type_path +="/type";
            char * value  = (char *)xml.get_value(type_path.c_str());
            int  type = 0 ;
            if(value  != NULL)
            {
                type  = atoi(value);
            }
            type_path = xpath;
            type_path +="/config_path";
            value  = (char *)xml.get_value(type_path.c_str());
            if(value  == NULL)
            {

                continue;
            }

            list<rule_node_offist * > node_list;

            int rule_num = 400 ;
            protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), rule_num);
            list<rule_node_offist * > ::iterator iter = node_list.begin();
            for(;iter != node_list.end(); iter ++)
            {
                rule_node_offist * p = *iter ;
                public_pptp_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
            }
        }
    }
    feature_rule_map = & public_pptp_feature_rule_map;
}

void pptp_plugin::init_pptp_session(pptp_session * p_pptp_session)
{
    p_pptp_session->requst_time = 0;
    p_pptp_session->response_time = 0;
    p_pptp_session->pl_msg = new list<pptp_message*>();
    p_pptp_session->pl_msg->clear();
    p_pptp_session->p_data = NULL;
    p_pptp_session->data_len = 0;
    //p_pptp_session->p_pptp_message = NULL;
}

void pptp_plugin::multimode_pptp_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }
    p_session->is_pptp = false;
    p_session->is_c2s = false;
    p_session->is_c2s = false;
    short num_short =ntohs(*((short*) (p_packet->p_app_data)));
    if(num_short == p_packet->app_data_len)
    {
        p_session->is_pptp = true;
    }

    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet -> rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 1723)
            {
                p_session->is_pptp = true;
                if(p_session->is_c2s || p_session->is_s2c) break;
                continue;
            }
            else if(iter->second == 1724)
            {
                p_session->is_c2s = true;
                if(p_session->is_pptp)break;
                continue;
            }
            else if(iter->second == 1725)
            {
                p_session->is_s2c = true;
                if(p_session->is_pptp)break;
                continue;
            }
        }
    }
    return ;
}


bool pptp_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(!p_packet->b_is_tcp)
    {
        return false;
    }
    /*
    // 用端口判断是否是pptp协议
    if(ntohs(p_session->srcport) == PPTPDEFINEPORT)
    {
    p_session->b_src_is_ser  = true;
    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    init_pptp_session(p_pptp_session);
    return true;
    }
    else if(ntohs(p_session->dstport) == PPTPDEFINEPORT)
    {
    p_session->b_src_is_ser = false;
    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    init_pptp_session(p_pptp_session);
    return true;
    }
    */
    multimode_pptp_identity(p_session, p_packet);
    if(!p_session->is_pptp)return false;
    if((p_session->is_c2s) || (p_session->client_ip == p_session->srcip) ||(ntohs(p_session->dstport) == PPTPDEFINEPORT))
    {
        p_session->b_src_is_ser = false;
        pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
        init_pptp_session(p_pptp_session);
        return true;
    }else if((p_session->is_s2c) || (p_session->client_ip == p_session->dstip) ||(ntohs(p_session->srcport) == PPTPDEFINEPORT))
    {
        p_session->b_src_is_ser  = true;
        pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
        init_pptp_session(p_pptp_session);
        return true;
    }
    else if(!p_session->direction_clarity) // 为了增强代码的可读性，故此使用该表述方式，虽然显得很累赘。
    {
        return false;
    }
    return false;
}

void pptp_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session == NULL || p_packet == NULL )
    {
        return;
    }
    /*p_session->packet_len += p_packet->buff_len;
      p_session->packet_num++;

      if(p_session->packet_begin_time == 0)
      {
      p_session->packet_begin_time = p_packet->m_timeval;
      p_session->packet_end_time = p_packet->m_timeval;
      }
      if (p_packet->m_timeval > p_session->packet_end_time )
      {
      p_session->packet_end_time = p_packet->m_timeval;
      }*/
    if(!p_packet->b_is_tcp || p_packet->p_tcphdr==NULL)
    {
        return;
    }
    if(p_packet->p_tcphdr->fin == 1)
    {
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
        return;
    }
    if(p_packet->p_app_data == NULL || p_packet->app_data_len == 0)
    {
        return;
    }
    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    p_pptp_session->p_data = (char *)p_packet->p_app_data;
    p_pptp_session->data_len = p_packet->app_data_len;
    p_pptp_session->packet_time = p_packet->m_timeval;
    //公共字段提取
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    //判断数据包的方向
    if((p_session->srcport==p_packet->get_src_port() && p_session->b_src_is_ser) ||
            (p_session->b_src_is_ser==false && p_session->dstport==p_packet->get_src_port()))
    {
        p_pptp_session->b_c2s = false;
    }
    else
    {
        p_pptp_session->b_c2s = true;
    }
    SET_EXPORT(p_session);
    return;
}

void pptp_plugin::pococol_parse_handle(session * p_session)
{
    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    if(p_pptp_session->p_data == NULL || p_pptp_session->data_len == 0)
    {
        return;
    }
    //解析数据包的内容
    pptp_message *p_pptp_message = p_pptp_session->pptp_pkt_parse(p_pptp_session->p_data, p_pptp_session->data_len);
    if(p_pptp_message != NULL)
    {
        if(p_pptp_session->pl_msg->empty() && p_pptp_message->message_sub_type != START_CONTROL_CONNECTION_REQUEST && p_pptp_message->message_sub_type != START_CONTROL_CONNECTION_REPLY)
        {
            //SET_SESSION_OVER(p_session);
            delete p_pptp_message;
        }
        else
        {
            p_pptp_session->pl_msg->push_back(p_pptp_message);
        }
        if(p_pptp_message->message_sub_type == STOP_CONTROL_CONNECTION_REQUEST || p_pptp_message->message_sub_type == STOP_CONTROL_CONNECTION_REPLY)
        {
            SET_SESSION_OVER(p_session);
        }
    }

    if(IS_SESSION_OVER(p_session))              //session结束时统一输出
    {
        p_session->send_len = 1;
        p_session->p_send_buf = NO_NULL;
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
    }
    p_pptp_session->packet_time = 0;
    p_pptp_session->b_c2s = false;
    p_pptp_session->p_data = NULL;
    p_pptp_session->data_len = 0;
}

void pptp_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    int is_ipv6 ;
    int is_ipv4 ;
    uint32_t busy_time = 0;

    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    if(p_pptp_session->pl_msg->empty())
    {
        return;
    }
    output_interface.init();
    output_interface.message_type = 1;
    //数据流方向判断
    list<pptp_message*>::iterator iter = p_pptp_session->pl_msg->begin();
    bool b_msg_c2s = (*iter)->b_c2s;
    if(p_pptp_session->pl_msg->size() > 1)
    {
        //output_interface.direction = 0;
        for(;iter != p_pptp_session->pl_msg->end(); ++iter)
        {
            if((*iter)->b_c2s != b_msg_c2s)
            {
                output_interface.direction = 3;    //双向
                break;
            }
        }
    }
    if(output_interface.direction != 3)
    {
        if(b_msg_c2s)
        {
            output_interface.direction = 1;         //c2s
        }
        else
        {
            output_interface.direction = 2;         //s2c
        }

    }
    //计算通信速率
    double session_duration = (double)(p_session->packet_end_time - p_session->packet_begin_time);
    if (session_duration != 0)
    {
        //output_interface.communication_rate = ((double)total_throughput / session_duration)*1000000;
        output_interface.communication_rate = ((double)p_session->packet_len / session_duration)*1000000;
    }
    else
    {
        output_interface.communication_rate = 1;
    }

    //解析消息(最简单的处理方式，以后根据需求变化需要进行重构)
    for(iter = p_pptp_session->pl_msg->begin(); iter != p_pptp_session->pl_msg->end(); ++iter)
    {
        switch((*iter)->message_sub_type)
        {
            case START_CONTROL_CONNECTION_REQUEST:
                {
                    start_control_connection_request *p_message = (start_control_connection_request*)(*iter);
                    output_interface.protocol_version = ntohs(p_message->msg_body.protocol_version);
                    output_interface.framing_capabilities = ntohl(p_message->msg_body.framing_capabilities);
                    output_interface.bearer_capabilities = ntohl(p_message->msg_body.bearer_capabilities);
                    output_interface.client_firmware_revision = ntohs(p_message->msg_body.firmware_revision);
                    if(p_message->msg_body.host_name[0] != 0 && output_interface.client_hostname[0] == 0 )
                    {
                        memcpy(output_interface.client_hostname, p_message->msg_body.host_name, 64);
                    }
                    // 王晨曦 添加用户需求之增加解析Vendor Name 字段
                    if(p_message->msg_body.vendor_string[0] != 0 && output_interface.vendor_name[0] == 0 )
                    {
                        memcpy(output_interface.vendor_name, p_message->msg_body.vendor_string, 64);
                    }
                    break;
                }
            case START_CONTROL_CONNECTION_REPLY:
                {
                    start_control_connection_reply *p_message = (start_control_connection_reply*)(*iter);
                    output_interface.protocol_version = ntohs(p_message->msg_body.protocol_version);
                    output_interface.framing_capabilities = ntohl(p_message->msg_body.framing_capabilities);
                    output_interface.bearer_capabilities = ntohl(p_message->msg_body.bearer_capabilities);
                    output_interface.server_firmware_revision = ntohs(p_message->msg_body.firmware_revision);
                    if(p_message->msg_body.host_name[0] != 0 && output_interface.server_hostname[0] == 0)
                    {
                        memcpy(output_interface.server_hostname, p_message->msg_body.host_name, 64);
                    }
                    break;
                }
            case STOP_CONTROL_CONNECTION_REQUEST:
            case STOP_CONTROL_CONNECTION_REPLY:
            case ECHO_REQUEST:
            case ECHO_REPLY:
                break;
            case OUTGOING_CALL_REQUEST:
                {
                    outgoing_call_request *p_message = (outgoing_call_request*)(*iter);
                    output_interface.client_call_id = ntohs(p_message->msg_body.call_id);
                    output_interface.call_serial_number = ntohs(p_message->msg_body.call_serial_number);
                    break;
                }
            case OUTGOING_CALL_REPLY:
                {
                    outgoing_call_reply *p_message = (outgoing_call_reply*)(*iter);
                    output_interface.server_call_id = ntohs(p_message->msg_body.call_id);
                    output_interface.client_call_id = ntohs(p_message->msg_body.peers_call_id);
                    break;
                }
            case INCOMING_CALL_REQUEST:
                {
                    incoming_call_request *p_message = (incoming_call_request*)(*iter);
                    output_interface.server_call_id = ntohs(p_message->msg_body.call_id);
                    output_interface.call_serial_number = ntohs(p_message->msg_body.call_serial_number);
                    break;
                }
            case INCOMING_CALL_REPLY:
                {
                    incoming_call_reply *p_message = (incoming_call_reply*)(*iter);
                    output_interface.client_call_id = ntohs(p_message->msg_body.call_id);
                    output_interface.server_call_id = ntohs(p_message->msg_body.peers_call_id);
                    break;
                }
            case INCOMING_CALL_CONNECTED:
            case CALL_CLEAR_REQUEST:
            case CALL_DISCONNECT_NOTIFY:
            case WAN_ERROR_NOTIFY:
                break;
            case SET_LINK_INFO:
                {
                    set_link_info *p_message = (set_link_info*)(*iter);
                    if(p_message->b_c2s)
                    {
                        output_interface.server_call_id = ntohs(p_message->msg_body.peers_call_id);
                        output_interface.client_send_accm = ntohl(p_message->msg_body.send_accm);
                        output_interface.client_receive_accm = ntohl(p_message->msg_body.receive_accm);
                    }
                    else
                    {
                        output_interface.client_call_id = ntohs(p_message->msg_body.peers_call_id);
                        output_interface.server_send_accm = ntohl(p_message->msg_body.send_accm);
                        output_interface.server_receive_accm = ntohl(p_message->msg_body.receive_accm);
                    }
                    break;
                }
            default:
                break;
        }
    }
    //取基本信息
    if(p_session -> b_src_is_ser)
    {
        output_interface.client_port = p_session->dstport;
        output_interface.client_ip = p_session->dstip;
        output_interface.server_port = p_session->srcport;
        output_interface.server_ip = p_session->srcip;
    }
    else
    {
        output_interface.client_port = p_session->srcport;
        output_interface.client_ip = p_session->srcip;
        output_interface.server_port = p_session->dstport;
        output_interface.server_ip = p_session->dstip;
    }
    output_interface.mac_line_number = p_session->mac_line_num;
    output_interface.device_num = p_session-> device_num;
    classify_ip_kind_info(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
    output_interface.is_ipv4 = is_ipv4;
    output_interface.is_ipv6 = is_ipv6;
    output_interface.is_mpls = p_session->m_is_mpls;
    output_interface.n_label = p_session->m_label;
    output_interface.in_nerlabel = p_session->m_inner_label;
    output_interface.other_label = p_session->m_other_lable;
    output_interface.proto = p_session->proto_type;
    output_interface.total_payloadbytes = p_session->packet_len;
    output_interface.total_payloadpackets = p_session->packet_num;
    if(p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    output_interface.duration = busy_time;

    iter = p_pptp_session->pl_msg->begin();
    output_interface.time = (*iter)->packet_time;
    //将数据加入接口
    pptp_interface_handling(p_list);
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    return;

}

void pptp_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > pptp_time_out *1000000)
    {
        //开始超时处理
        //  printf("PPTP session time out!\n");
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
}

void pptp_plugin::resources_recovery(session * p_session)
{
    pptp_session * p_pptp_session = (pptp_session *)p_session->expansion_data;
    //p_pptp_session->display_pptp_message_list();
    list<pptp_message*>::iterator iter = p_pptp_session->pl_msg->begin();
    for(;iter != p_pptp_session->pl_msg->end(); ++iter)
    {
        //(*iter)->display();
        delete *iter;
    }
    p_pptp_session->pl_msg->clear();
    delete p_pptp_session->pl_msg;
}



//Summary:  PPTP插件接口数据处理函数
//Parameters:
//       p_list: 数据接口链表指针
//Return : 无
void pptp_plugin::pptp_interface_handling(list<data_interface> *p_list)
{
    data_interface m_data;
    if(data_interface_type == NETSEND)
    {
        net_str * p_net = new net_str;
        p_net->msg = new CAmsg;
        p_net->msg->Clear();
        p_net->msg->set_type(25); // PPTP

        pptp_msg* p_pptp = p_net->msg->mutable_pptp();
        Comm_msg* p_comm = p_pptp->mutable_comm_msg();
        //公共消息
        p_comm ->set_src_ip(output_interface.client_ip.ip_str());
        p_comm ->set_src_port(ntohs(output_interface.client_port));
        p_comm ->set_dst_ip(output_interface.server_ip.ip_str());
        p_comm ->set_dst_port(ntohs(output_interface.server_port));
        p_comm ->set_line_num(output_interface.mac_line_number);
        p_comm ->set_dev_num(output_interface.device_num);
        p_comm ->set_time(output_interface.time);
        //add new common header
        p_comm->set_is_ipv4(output_interface.is_ipv4);
        p_comm->set_is_ipv6(output_interface.is_ipv6);
        p_comm->set_proto(output_interface.proto);
        p_comm->set_link_layer_type(0);
        p_comm ->set_is_mpls(output_interface.is_mpls);
        p_comm ->set_n_label(output_interface.n_label);
        p_comm ->set_inner_label(output_interface.in_nerlabel);
        p_comm ->set_other_label(output_interface.other_label);
        p_comm ->set_total_pay_load_bytes(output_interface.total_payloadbytes);
        p_comm ->set_tatal_pay_load_packets(output_interface.total_payloadpackets);
        p_comm ->set_duration(output_interface.duration);
        //PPTP消息
        p_pptp->set_protocol_family(1210001);
        p_pptp->set_communication_rate(output_interface.communication_rate);
        p_pptp->set_direction(output_interface.direction);
        p_pptp->set_protocol_version(output_interface.protocol_version);
        p_pptp->set_message_type(output_interface.message_type);
        p_pptp->set_framing_capabilities(output_interface.framing_capabilities);
        p_pptp->set_bearer_capabilities(output_interface.bearer_capabilities);
        p_pptp->set_server_firmware_revision(output_interface.server_firmware_revision);
        p_pptp->set_client_firmware_revision(output_interface.client_firmware_revision);
        p_pptp->set_server_call_id(output_interface.server_call_id);
        p_pptp->set_client_call_id(output_interface.client_call_id);
        p_pptp->set_call_serial_number(output_interface.call_serial_number);
        p_pptp->set_server_send_accm(output_interface.server_send_accm);
        p_pptp->set_client_send_accm(output_interface.client_send_accm);
        p_pptp->set_server_receive_accm(output_interface.server_receive_accm);
        p_pptp->set_client_receive_accm(output_interface.client_receive_accm);
        if(output_interface.server_hostname[0] != 0)
        {
            p_pptp->set_server_hostname(output_interface.server_hostname, 64);
        }
        if(output_interface.client_hostname[0] != 0)
        {
            p_pptp->set_client_hostname(output_interface.client_hostname, 64);
        }
        // 王晨曦 添加用户需求之增加解析Vendor Name 字段
        if(output_interface.vendor_name[0] != 0)
        {
            p_pptp->set_vendor_name(output_interface.vendor_name, 64);
        }
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }
    return;
}




//Summary:  PPTP消息解析函数
//Parameters:
//       p_data: PPTP数据包数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，则返回一个指向pptp_message的指针，若解析失败则返回NULL
pptp_message* pptp_session::pptp_pkt_parse(const char* p_data, int16_t data_len)
{
    if(p_data == NULL || data_len < 0 || (size_t)data_len < sizeof(pptp_message_header))
    {
        return NULL;
    }
    //解析消息头
    struct pptp_message_header msg_header = *(pptp_message_header*)p_data;//const uint32_t magic_cookie = 0x1A2B3C4D;
    const uint32_t magic_cookie = 0x1A2B3C4D;              //固定的cookie,以检验消息的正确性，这里为方便对比，将其转为网络序
    uint16_t message_length = ntohs(msg_header.msg_length);
    if(data_len < message_length || ntohl(msg_header.magic_cookie) != magic_cookie)
    {
        return NULL;
    }
    p_data += sizeof(pptp_message_header);
    data_len -= sizeof(pptp_message_header);
    switch(ntohs(msg_header.message_type))
    {
        case CONTROL_MESSAGE:
            {
                //解析控制消息头
                if(data_len < 0 || (size_t)data_len < sizeof(pptp_ctrl_msg_header))
                {
                    return NULL;
                }
                struct pptp_ctrl_msg_header ctrl_msg_header= *(pptp_ctrl_msg_header*)p_data;
                p_data += sizeof(pptp_ctrl_msg_header);
                data_len -= sizeof(pptp_ctrl_msg_header);
                //解析控制消息体
                pptp_message *p_pptp_message = NULL;
                switch(ntohs(ctrl_msg_header.control_message_type))
                {
                    case START_CONTROL_CONNECTION_REQUEST:
                        p_pptp_message = new start_control_connection_request(message_length, packet_time, b_c2s);
                        break;
                    case START_CONTROL_CONNECTION_REPLY:
                        p_pptp_message = new start_control_connection_reply(message_length, packet_time, b_c2s);
                        break;
                    case STOP_CONTROL_CONNECTION_REQUEST:
                        p_pptp_message = new stop_control_connection_request(message_length, packet_time, b_c2s);
                        break;
                    case STOP_CONTROL_CONNECTION_REPLY:
                        p_pptp_message = new stop_control_connection_reply(message_length, packet_time, b_c2s);
                        break;
                    case ECHO_REQUEST:
                        p_pptp_message = new echo_request(message_length, packet_time, b_c2s);
                        break;
                    case ECHO_REPLY:
                        p_pptp_message = new echo_reply(message_length, packet_time, b_c2s);
                        break;
                    case OUTGOING_CALL_REQUEST:
                        p_pptp_message = new outgoing_call_request(message_length, packet_time, b_c2s);
                        break;
                    case OUTGOING_CALL_REPLY:
                        p_pptp_message = new outgoing_call_reply(message_length, packet_time, b_c2s);
                        break;
                    case INCOMING_CALL_REQUEST:
                        p_pptp_message = new incoming_call_request(message_length, packet_time, b_c2s);
                        break;
                    case INCOMING_CALL_REPLY:
                        p_pptp_message = new incoming_call_reply(message_length, packet_time, b_c2s);
                        break;
                    case INCOMING_CALL_CONNECTED:
                        p_pptp_message = new incoming_call_connected(message_length, packet_time, b_c2s);
                        break;
                    case CALL_CLEAR_REQUEST:
                        p_pptp_message = new call_clear_request(message_length, packet_time, b_c2s);
                        break;
                    case CALL_DISCONNECT_NOTIFY:
                        p_pptp_message = new call_disconnect_notify(message_length, packet_time, b_c2s);
                        break;
                    case WAN_ERROR_NOTIFY:
                        p_pptp_message = new wan_error_notify(message_length, packet_time, b_c2s);
                        break;
                    case SET_LINK_INFO:
                        p_pptp_message = new set_link_info(message_length, packet_time, b_c2s);
                        break;
                    default:
                        printf("Unidentified PPTP Control Message Type!\n");
                        return NULL;
                }
                if(!p_pptp_message->msg_body_parse(p_data, data_len))
                {
                    delete p_pptp_message;
                    return NULL;
                }
                return p_pptp_message;
            }
        case MANAGEMENT_MESSAGE:                     //目前不处理管理消息
            return NULL;
        default:
            printf("Unidentified PPTP Message Type!\n");
            return NULL;
    }
}



//打印函数，仅供调试使用
void pptp_session::display_pptp_message_list()
{
    list<pptp_message*>::iterator iter = pl_msg->begin();
    for(int i=1;iter != pl_msg->end(); ++iter,++i)
    {
        printf("########## Message %d ##########\n",i);
        (*iter)->msg_header_display();
        (*iter)->msg_body_display();
    }
    return;
}
