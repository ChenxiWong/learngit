// Last Update:2016-05-12 09:22:14
/**
 * @file pptp_plugin.h
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-04-21
 */

#ifndef PPTP_PLUGIN_H
#define PPTP_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "pptp_str.h"
#include <tcp_recombine.h>
#include <map>

#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;


extern "C"
{
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info * p );
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class pptp_plugin :public protocol_parse_base_handle
{
    public:
        pptp_plugin();
        ~pptp_plugin();
        virtual void reload();
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);

        map <rule_node_offist * , int  >*  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;
        void multimode_pptp_identity(session* p_session, c_packet* p_packet);

    private:

        void init_pptp_session(pptp_session * p_pptp_session);
        void pptp_interface_handling(list<data_interface> * p_list);
        uint32_t  pptp_time_out;    //单位s
        int       data_interface_type;
        pptp_output_interface output_interface;

        //uint32_t begin_len;
        //char  * begin_data;

        xml_parse  xml;
        //uint64_t begin_time;
        //uint32_t row;
        uint32_t max_row;
        uint32_t max_time_scr;

};
static attach_info *  p_attach_info ;
map <rule_node_offist * , int  >  public_pptp_feature_rule_map ;
#endif  /*PPTP_PLUGIN_H*/
