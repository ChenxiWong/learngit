#!/bin/bash 
plugin_name=$1
make clean
make
cp -rf  $NPR_SDK/../plugin/InterPlgin/porocol/${plugin_name}/lib/lib${plugin_name}.so  $NPR_ROOT/plugin/InterPlugin/

