// Last Update:2015-12-16 11:37:46
/**
 * @file unic_to_utf8_str.h
 * @brief 
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-12-15
 */
//将一个字符串中所有unicode字面值转为utf-8存入string中
#ifndef UNIC_TO_UTF8_STR_H
#define UNIC_TO_UTF8_STR_H
#include "unic_to_utf8.h"
#include <iostream>
#include <string>
#include <cstring>
#include <stdint.h>
#include <math.h>
class unic_to_utf8_str_cls
{
public:
    unic_to_utf8_str_cls(const char * p_tmp, const int& len):m_p_buf(p_tmp), m_len(len){}
    std :: string operator()()
    {
        unic_to_utf8_str();
        return m_str_out;
    }
    static bool str_to_hex(char *, uint32_t&);
private:
    std :: string m_str_out;
    const char *m_p_buf;
    const int m_len;
    bool unic_to_utf8_str();
};

#endif  /*UNIC_TO_UTF8_STR_H*/
