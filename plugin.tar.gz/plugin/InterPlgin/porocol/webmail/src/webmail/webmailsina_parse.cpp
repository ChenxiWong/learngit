// Last Update:2015-12-28 15:35:31
/**
 * @file webmailsina_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-11
 */

#include "webmailsina_parse.h"
// resonse   gzip xml 
//#define DEFMAXBUF 1024*1024
#define DEFMAXBUF 6553500
//
#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ; \
    ss.clear(); }

bool webmailsina_parse::response_handle_sohu_body_length(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    if( p_webmail_session ->response_length  > 0) 
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value->len < 5) return false;
    char * pend = strstr(p_parse_value -> buf ,"\r\n");
    if(pend != NULL)
    {
        string tmp(p_parse_value->buf,0,pend - p_parse_value->buf);
        p_parse_value->len  -= pend-p_parse_value->buf +2 ;
        p_parse_value->buf = pend+2 ;
        p_webmail_session ->response_length =  strtol(tmp.c_str(),NULL,16); 
        return true;
    }
    return true;
}
bool webmailsina_parse::response_handle_sohu_att_id(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->Uri.buf_begin == NULL)
        return true;

    string url = string(p_requst -> Uri.buf_begin,0,p_requst->Uri.space_use_len);
    string name = "requset_url_";
    int size =  url.rfind("/");
    if(size != string::npos && url.length()>size+1)
    {
        string svalue(url,size+1,url.length()-size-1);

        node_value_list ::iterator iter = v_list.begin();
        for(;iter != v_list.end(); iter ++)
        {
            name +=*iter;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    return true;

}

void json_array_parse(Json::Value value ,string & svalue)
{
    if(value.type() == Json::arrayValue)
    {
        int size = value.size();
        for ( int index =0; index < size; ++index )
        {
            json_array_parse(value[index],svalue);
        }
    }
    else
    {
        string tmp;
        if(value.isString())
        {
            tmp = value.asString();
            //if(tmp.find("@")!= tmp.npos)
            if(tmp.find("@")!= string::npos)
            {
                if(svalue.length() > 0)
                    svalue += "|";
                svalue += tmp;
            }
        }
    }
}

void json_array_parse_attach(Json::Value value ,string & svalue)
{
    if(value.type() == Json::arrayValue)
    {
        int size = value.size();
        for ( int index =0; index < size; ++index )
        {
            json_array_parse_attach(value[index],svalue);
        }
    }
    else
    {
        string tmp;
        if(value.isString())
        {
            tmp = value.asString();
            if(svalue.length() > 0)
                svalue += "]";
            svalue += tmp;
        }
        else if(value.isInt())
        {
            int t = value.asInt();
            DNUMTOSTR(t, tmp);
            if(svalue.length() > 0)
                svalue += "]";
            svalue += tmp;
        }
    }
}

bool webmailsina_parse:: response_handle_sina_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  sina 查看邮件 处理 
{

    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> b_end_send  == false ) 
    {
        if(p_webmail_session -> b_c2s  ) 
        {
            return true;
        }
    }
    if(p_webmail_session ->state == server_data) 
    {
        //  p_parse_value -> parse_type = MESS_BODY;
        // 获取
        if(p_webmail_session ->response_length  == 0) 
        {
            if(p_parse_value->len < DEFMAXBUF)
                p_parse_value->parse_tmp_buf   = new char[DEFMAXBUF];
            else 
                return  true;

        }
        else 
        {
            if(p_parse_value->len > p_webmail_session ->response_length +16)
            {
                p_parse_value->parse_tmp_buf   = new char[p_parse_value->len];
            }
            else 
            {
                p_parse_value->parse_tmp_buf   = new char[p_webmail_session ->response_length +16];
            }

        }
        p_webmail_session ->b_add_end = true;
        //if(p_parse_value->len > 0)
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len += p_parse_value->len;
        //p_parse_value->file_data = string(p_parse_value->buf, 0,p_parse_value->len);
        if(p_webmail_session ->response_length == 0||p_webmail_session ->response_length >  p_parse_value ->len) 
        {
            // 
            if(p_parse_value ->len > 0) 
            {
                p_webmail_session->state = server_data_continue;
                p_session -> send_len = 0;
                p_session->p_send_buf= NO_NULL; 
            }

            return true;
        }
    }
    else if(p_webmail_session ->state == server_data_continue) 
    {
        if(p_webmail_session ->response_length >  0)
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > p_webmail_session ->response_length) 
            {
                if(p_webmail_session ->response_length > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = p_webmail_session ->response_length - p_parse_value->parse_tmp_len;
                }
            }
        }
        else
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > DEFMAXBUF) 
            {
                if(DEFMAXBUF > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = DEFMAXBUF - p_parse_value->parse_tmp_len;
                }
            }
        }

        //if(p_parse_value->len > 0)
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf + p_parse_value->parse_tmp_len ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len += p_parse_value->len;
        p_session -> send_len = 0;
        p_session->p_send_buf= NO_NULL; 

    }
    char * ungzip_buffer = NULL;
    uint32_t len = 0 ;
    if((p_webmail_session ->response_length  != 0 &&p_parse_value->parse_tmp_len >= p_webmail_session ->response_length) || IS_SESSION_OVER(p_session))
    {
        if(p_webmail_session ->response_length < p_parse_value->parse_tmp_len )
            p_webmail_session ->response_length = p_parse_value->parse_tmp_len;


        if(p_parse_value->parse_tmp_buf == NULL)
            return true;

        ungzip_buffer = new char[ p_webmail_session ->response_length * 10];
        if(ungzip_buffer == NULL)
            return true;

        len = p_webmail_session ->response_length * 10;

        int ret  = httpgzdecompress((Bytef *)p_parse_value->parse_tmp_buf ,(uLong)p_parse_value->parse_tmp_len,
                (Bytef *) ungzip_buffer , (uLong*)&len);
        if(ret != 0 && p_parse_value->parse_tmp_len>7) 
        {
            //  尝试第二次 解析   sohu 正文 ，  
            ret  = httpgzdecompress((Bytef *)p_parse_value->parse_tmp_buf ,(uLong)p_parse_value->parse_tmp_len -7,
                    (Bytef *) ungzip_buffer , (uLong*)&len);

        }
        //  ungzip  
        if(ret == 0 )
        {
            // 
            ungzip_buffer[len] = 0x0;
            /*
               FILE * fp = fopen("/root/ttt.json","a+");
               fwrite(ungzip_buffer,len,1,fp);
               fclose(fp);
               */
            // json  解析
            Json::Reader reader; 
            Json::Value value; 
            reader.parse(ungzip_buffer,value); 
            node_value_list::iterator iter =  v_list.begin();
            string svalue = "";
            string name = "";
            char *src_path  = NULL;
            char node[128]={0x0};
            Json::Value arrayObj ;
            for(;iter != v_list.end(); iter ++)
            {
                char * src_path = (char *)iter->c_str();
                arrayObj = value;
                while(char_path_parse(src_path,node)) 
                {
                    arrayObj = arrayObj[node];
                    //svalue = value[iter ->c_str()].asString();
                    //svalue = arrayObj[iter ->c_str()].asString();
                }
                name = "response_json_";
                name  += *iter;
                if(arrayObj.type() == Json::arrayValue)
                {
                    //数组 
                    if(name == "response_json_attach")
                    {
                        json_array_parse_attach(arrayObj ,svalue);
                        svalue += "]";
                        p_parse_value->value_map[name] = svalue;
                        svalue = "";
                        continue;
                    }
                    else
                    {
                        json_array_parse(arrayObj ,svalue);
                    }
                }
                else if(arrayObj.type() == Json::stringValue)
                {
                    svalue = arrayObj.asString();
                }
                if(name == "response_json_content")
                {
                    string key = "response_json_display";
                    if(!p_parse_value->value_map[key].empty())
                    {
                        svalue += p_parse_value->value_map[key];
                    }
                }
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                svalue = "";
                // 设置 发送 
            }

            //结束 
            p_webmail_session->b_end_send = true;
            p_session -> send_len = 1;
            p_session->p_send_buf= NO_NULL; 

        }

        if(p_parse_value->parse_tmp_buf != NULL)
        {
            delete [] p_parse_value->parse_tmp_buf;
        }
        p_parse_value->parse_tmp_buf = NULL;
        if(ungzip_buffer != NULL)
        {
            delete [] ungzip_buffer ;
        }
        ungzip_buffer = NULL;
        return true;
    }
    return true;
}

bool webmailsina_parse::get_redis_map(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if (p_requst == NULL || p_response == NULL) 
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // 组成KEY  
    string s_key = p_session -> srcip.ip_str() ;
 //   s_key +=  p_session -> dstip.ip_str() ;
    s_key +=  p_parse_value->value_map["requset_cookie_JSESSIONID"];
    string s_value = "";
    get_redis_data(s_key ,s_value );
    map_to_decode(s_value, p_webmail_session ) ;
    return true;
}
bool webmailsina_parse::response_handle_163_getbody(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    // 判断长度
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> b_end_send  == false ) 
    {
        if(p_webmail_session -> b_c2s  ) 
        {
            return true;
        }
    }
    if(p_webmail_session ->state == server_data) 
    {
        //  p_parse_value -> parse_type = MESS_BODY;
        // 获取
        if(p_webmail_session ->response_length  == 0) 
        {

            if(p_parse_value->len < DEFMAXBUF)
            {
                p_parse_value->parse_tmp_buf   = new char[DEFMAXBUF];
                p_parse_value->parse_tmp_len = 0;
            }
            else 
                return true;
        }
        else 
        {
            if(p_parse_value->len > p_webmail_session ->response_length +16) 
            {
                p_parse_value->parse_tmp_buf   = new char[p_parse_value->len];
            }
            else {
                p_parse_value->parse_tmp_buf   = new char[p_webmail_session ->response_length +16];
            }

            p_parse_value->parse_tmp_len = 0;
        }
        p_webmail_session ->b_add_end = true;

        //if(p_parse_value->len > 0)
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len = p_parse_value->len;
        //p_parse_value->file_data = string(p_parse_value->buf, 0,p_parse_value->len);
        if(p_webmail_session ->response_length != 0 && p_webmail_session ->response_length >  p_parse_value ->len) 
        {
            p_webmail_session->state = server_data_continue;
            p_session -> send_len = 0;
            p_session->p_send_buf= NO_NULL; 

            return true;
        }
    }
    else if(p_webmail_session ->state == server_data_continue) 
    {
        if(p_webmail_session ->response_length >  0)
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > p_webmail_session ->response_length) 
            {
                if(p_webmail_session ->response_length > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = p_webmail_session ->response_length - p_parse_value->parse_tmp_len;
                }
            }
        }
        else 
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > DEFMAXBUF) 
            {
                if(DEFMAXBUF > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = DEFMAXBUF - p_parse_value->parse_tmp_len;
                }
            }
        }
        if(p_parse_value->parse_tmp_buf == NULL)
        {
            if(p_webmail_session ->response_length  == 0) 
            {
                if(p_parse_value->len < DEFMAXBUF)
                {
                    p_parse_value->parse_tmp_buf   = new char[DEFMAXBUF];
                }
                else
                { 
                    return true;
                }
            }
            else 
            {
                if(p_parse_value->len > p_webmail_session ->response_length +16) 
                {
                    p_parse_value->parse_tmp_buf   = new char[p_parse_value->len];
                }
                else
                {
                    p_parse_value->parse_tmp_buf   = new char[p_webmail_session ->response_length +16];
                }
            }
            p_parse_value->parse_tmp_len = 0;
        }
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf + p_parse_value->parse_tmp_len ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len += p_parse_value->len;
        p_session -> send_len = 0;
        p_session->p_send_buf= NO_NULL;
    }

    char * ungzip_buffer = NULL;
    uint32_t len = 0 ;
    //if((p_webmail_session ->response_length  != 0 &&p_parse_value->parse_tmp_len >= p_webmail_session ->response_length) || IS_SESSION_OVER(p_session))
    if((p_parse_value->parse_tmp_len >= p_webmail_session ->response_length) || IS_SESSION_OVER(p_session))
    {
        p_webmail_session ->b_add_end = true;
        int buflen = 0;
        if(p_webmail_session ->response_length  < p_parse_value->parse_tmp_len )
        {
            buflen  = p_parse_value->parse_tmp_len;
        }
        else {
            buflen = p_webmail_session ->response_length ;
        }
        if(buflen  == 0) 
        {
            p_session -> send_len = 0;
            p_session->p_send_buf= NO_NULL; 

            return true;
        }
        ungzip_buffer = new char[ buflen * 10];
        if(ungzip_buffer == NULL)
            return true;

        //printf ("ungzip buffer len is %d\n", buflen * 10);
        len   = buflen * 10;

        string zip_key = "response_head_key_Content-Encoding";
        int ret = 2;
        p_parse_value->parse_tmp_buf[p_parse_value->parse_tmp_len] = 0x0;
        if(p_parse_value->parse_tmp_buf==NULL)
            return true;

        if(p_parse_value->value_map[zip_key] == "gzip")
        {
            p_parse_value->value_map.erase(zip_key);
            ret  = httpgzdecompress((Bytef *)p_parse_value->parse_tmp_buf ,(uLong)p_parse_value->parse_tmp_len,
                    (Bytef *) ungzip_buffer , (uLong*)&len);
        }
        else
        {
            //if(p_parse_value->parse_tmp_len > 0)
            if((ungzip_buffer!=NULL) && (p_parse_value->parse_tmp_len>0))
                memcpy(ungzip_buffer, p_parse_value->parse_tmp_buf, p_parse_value->parse_tmp_len);
            len = p_parse_value->parse_tmp_len;
        }
        if(ret != -1) 
        {
            parse_value * p_parse_value = p_webmail_session ->p_parse_value;
            string name_ = "response_head_key_Content-Type";
            parse_value_map::iterator iter = p_parse_value->value_map.find(name_);
            if(iter!=p_parse_value->value_map.end())
            {
                string tmp_ = iter->second;
                p_parse_value->value_map.erase (iter);
                if(tmp_.find("text/javascript") != string::npos)
                {
                    // 变种的json 格式 ，
                    node_value_list ::iterator it = v_list.begin();
                    for(;it != v_list.end();it ++)
                    {
                        string str = *it;
                        char * p_start = strstr(ungzip_buffer,str.c_str());
                        if(p_start != NULL) 
                            p_start += str.length();
                        else  
                            continue;
                        char * p_end = NULL;
                        if(str.length() <= 0)
                            break;
                        char course=str[str.length()-1]; 
                        //判断查询的是不是 数组 
                        if(course =='[')
                        {
                            p_end = strstr(p_start,"]");
                            if(p_end == NULL)  continue;
                        }
                        else
                        {
                            p_end = strstr(p_start,"\n");
                            if(p_end == NULL)  continue;
                        }
                        string name = "163_json_";
                        name += str;

                        if(p_start > p_end)
                            break;
                        string svalue(p_start, 0, p_end-p_start);
                        // 替换 所有 的 ， 成 | 
                        svalue = replace_all(svalue,",\n","|");
                        p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                    }

                    string str_pattern = "requset_urlparam_mid";
                    parse_value_map::iterator iter = p_parse_value->value_map.find(str_pattern);
                    if(p_parse_value->value_map.find(str_pattern) == p_parse_value->value_map.end() || p_parse_value->value_map.find("163_json_'from':[") == p_parse_value->value_map.end())
                    {
                        if( p_parse_value -> continue_state  ==  0 &&  p_parse_value->value_map.find(str_pattern) == p_parse_value->value_map.end() )
                        {
                            p_session->p_send_buf = NULL;
                            p_session->send_len = 0;
                            p_session->client.clear_buf();
                            p_session->server.clear_buf();
                            p_parse_value -> continue_state = 1;
                            // *************************************
                            string s_key = p_session -> srcip.ip_str() ;
                            //s_key +=  p_session -> dstip.ip_str() ;
                            s_key +=  p_parse_value->value_map["requset_cookie_JSESSIONID"];
                            string s_value = "";
                            map_to_encode(s_value , p_webmail_session ) ; 
                            set_redis_data(s_key , s_value, c_thread_static::num_webmail_redis_time_out );
                            SET_SESSION_OVER(p_session);
                            return true;
                        }
                        else 
                        {
                            //p_webmail_session->b_end_send = true;
                            p_session -> send_len = 1;
                            p_session->p_send_buf  = NO_NULL;
                            // 把 数据发送出去，组织起来  
                            // string key = ip + ip  + nssid ;
                            string s_key = p_session -> srcip.ip_str() ;
                           // s_key +=  p_session -> dstip.ip_str() ;
                            s_key +=  p_parse_value->value_map["requset_cookie_JSESSIONID"];
                            string s_value = "";
                            map_to_encode(s_value , p_webmail_session ) ; 

                            set_redis_data(s_key , s_value, c_thread_static::num_webmail_redis_time_out );
                            SET_SESSION_OVER(p_session);
                            // 清理数据  
                            return true;
                            // 保存现场  

                        }
                    }
                    else
                    {
                        p_session->p_send_buf  = NO_NULL;
                        p_webmail_session->b_end_send = true;
                    }

                    p_webmail_session ->state = client_data;
                    //p_session->p_send_buf  = NO_NULL;
                    p_webmail_session ->response_length  = 0;
                }
                else if(tmp_.find("text/html") != string::npos)
                {
                    //  ungzip  
                    if(ret != -1)
                    {
                        //ungzip_buffer[len] = 0x0;
                        char * p_start = strstr(ungzip_buffer,"\r\n\r\n\r\n");
                        if(p_start == NULL) 
                        {
                            p_session->p_send_buf = NO_NULL;
                            p_session->send_len = 0;
                            if(p_parse_value->parse_tmp_buf != NULL && p_parse_value->parse_tmp_len>0)
                            {
                                delete [] p_parse_value->parse_tmp_buf;
                            }
                            p_parse_value->parse_tmp_buf = NULL;
                            p_parse_value->parse_tmp_len = 0;
                            if(ungzip_buffer != NULL)
                            {
                                delete [] ungzip_buffer;
                            }
                            ungzip_buffer = NULL;
                            return true;
                        }

                        p_start += 6;
                        while((p_start-ungzip_buffer+2<len) && (*p_start)=='\r' && *(p_start+1)=='\n')
                        {
                            p_start += 2;
                        }

                        char * p_end = strstr(p_start,"\r\n\r\n");
                        if(p_end == NULL)
                        {
                            p_session->p_send_buf = NO_NULL;
                            p_session->send_len = 0;
                            if(p_parse_value->parse_tmp_buf != NULL)
                            {
                                delete [] p_parse_value->parse_tmp_buf;
                            }
                            p_parse_value->parse_tmp_buf = NULL;
                            p_parse_value->parse_tmp_len = 0;
                            if(ungzip_buffer != NULL)
                            {
                                delete [] ungzip_buffer;
                            }
                            ungzip_buffer = NULL;
                            return true;
                        }
                        string name = "resonse_163_html_content";
                        if(p_start < p_end)
                        {
                            string svalue(p_start, 0, p_end-p_start);
                            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                            p_session -> send_len = 1;
                            p_session->p_send_buf= NO_NULL; 
                        }
                    }
                }
                //return true;
            }
        } 

        if(p_parse_value->parse_tmp_buf != NULL && p_parse_value->parse_tmp_len>0)
        {
            delete [] p_parse_value->parse_tmp_buf;
        }
        p_parse_value->parse_tmp_buf = NULL;
        p_parse_value->parse_tmp_len = 0;

        if(ungzip_buffer != NULL)
        {
            delete [] ungzip_buffer;
        }
        //p_webmail_session->b_end_send = true;
        //p_session -> send_len = 1;
        //p_session->p_send_buf= NO_NULL; 
        ungzip_buffer = NULL;
        string str_pattern = "requset_urlparam_mid";
        parse_value_map::iterator iter = p_parse_value->value_map.find(str_pattern);
        if(p_parse_value->value_map.find(str_pattern) == p_parse_value->value_map.end() || p_parse_value->value_map.find("163_json_'from':[") == p_parse_value->value_map.end())
        {
            if( p_parse_value -> continue_state  ==  0 &&  p_parse_value->value_map.find(str_pattern) == p_parse_value->value_map.end() )
            {
                p_session->p_send_buf = NULL;
                p_session->send_len = 0;
                p_session->client.clear_buf();
                p_session->server.clear_buf();
                p_parse_value -> continue_state = 1;
                p_session->p_send_buf  = NO_NULL;
                // 把 数据发送出去，组织起来  
                // string key = ip + ip  + nssid ;
                string s_key = p_session -> srcip.ip_str() ;
              //  s_key +=  p_session -> dstip.ip_str() ;
                s_key +=  p_parse_value->value_map["requset_cookie_JSESSIONID"];
                string s_value = "";
                map_to_encode(s_value , p_webmail_session ) ; 
                set_redis_data(s_key , s_value, c_thread_static::num_webmail_redis_time_out );
                SET_SESSION_OVER(p_session);
                return true;

            }
            else 
            {
                //p_webmail_session->b_end_send = true;
                p_session -> send_len = 1;
                p_session->p_send_buf  = NO_NULL;
                // 把 数据发送出去，组织起来  
                // string key = ip + ip  + nssid ;
                string s_key = p_session -> srcip.ip_str() ;
              //  s_key +=  p_session -> dstip.ip_str() ;
                s_key +=  p_parse_value->value_map["requset_cookie_JSESSIONID"];
                string s_value = "";
                map_to_encode(s_value , p_webmail_session ) ; 

                set_redis_data(s_key , s_value, c_thread_static::num_webmail_redis_time_out );
                SET_SESSION_OVER(p_session);
                // 清理数据  
                return true;
                // 保存现场  

            }
        }
        else
        {
            p_webmail_session->b_end_send = true;
            p_session -> send_len = 1;
            p_session->p_send_buf  = NO_NULL;
            //SET_SESSION_OVER(p_session);
        }
        return true;
    }

    return false;
}

