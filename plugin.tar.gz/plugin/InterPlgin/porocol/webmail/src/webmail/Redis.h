// Last Update:2015-10-29 13:37:53
/**
 * @file Redis.h
 * @brief  Redis 操作类封装
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-19
 */

#ifndef REDIS_OPR_H
#define REDIS_OPR_H

#include <hiredis/hiredis.h>
#include <string.h>
#include <string>
#include <stdio.h>
#include <stdint.h>


#define TEXT_DATABASE           0
#define FILE_DATABASE           1
#define MAIL_DATABASE           2
#define ATTACHMENT_DATABASE     3
#define PARAMETER_DATABASE      4

using namespace std;
class Redis {
    public:
        Redis(string redis_host, int redis_port);
        ~Redis();
        bool connect();
        bool add_data(int database_id, string key,string value,int expire_time);
        bool add_data(int database_id, string key,uint64_t value,int expire_time);
        bool get_data(int database_id, string key, string & value);
        bool delete_data(int database_id, string key);
        bool find_keys_num(int database_id, string key,int &num);
        void display_database(int database_id);
        void flushall();
        void flush(int database_id);
    private:
        bool check_connection();
        bool select(int database_id);
        bool set(string key, string value);
        bool set(string key, uint64_t value);
        bool set(string key, string value, int expire_time);
        bool set(string key, uint64_t value, int expire_time);
        bool get(string key, string& value) ;
    private :
        redisContext *      connect_;
        redisReply *        reply_;
        string              host;
        int                 port;
//        int                 mail_expire_time;
};

#endif  /*REDIS_OPR_H*/
