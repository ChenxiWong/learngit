// Last Update:2015-05-13 14:13:58
/**
 * @file qq_file_http_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-05-27
 */

#ifndef QQ_FILE_HTTP_PARSE_H
#define QQ_FILE_HTTP_PARSE_H

#include "webmail_str.h"
#include "http_urlparam_analyzer.h"
#include <tinyxml_parse.h>
#include "http_post_analyzer.h" 
#include <string>
using namespace std;
class qq_file_http_parse {
    public:
        static bool request_handle_att_id(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list);
        static bool response_handle_getbody(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list);
        static bool request_handle_att(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list); //  163 ����������  ���������Ƴ�����
    private:
};

#endif  /*QQ_FILE_HTTP_PARSE_H*/
