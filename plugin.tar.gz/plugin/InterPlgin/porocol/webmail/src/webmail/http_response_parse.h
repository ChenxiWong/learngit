// Last Update:2015-11-02 16:04:08
/**
 * @file http_response_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-02
 */

#ifndef HTTP_RESPONSE_PARSE_H
#define HTTP_RESPONSE_PARSE_H
#include "webmail_str.h"
#include "http_urlparam_analyzer.h"
#include <tinyxml_parse.h>
#include "http_post_analyzer.h"
#include "ungzip.h"
#include  <jsoncpp/json.h>
#include <string>
#include "html2txt.h"

class http_response_parse
{
    public:
        static bool response_body_html2txt(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
};



#endif  /*HTTP_RESPONACE_PARSE_H*/
