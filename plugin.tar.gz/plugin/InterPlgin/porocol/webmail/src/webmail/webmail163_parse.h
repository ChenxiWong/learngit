// Last Update:2016-05-23 19:11:38
/**
 * @file webmail163_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-06
 */

#ifndef WEBMAIL163_PARSE_H
#define WEBMAIL163_PARSE_H
#include "webmail_str.h"
#include "http_urlparam_analyzer.h"
#include <tinyxml_parse.h>
#include "http_post_analyzer.h"
#include "identity.h"
bool http_r_context_length_parse(session *,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list); // http 通用 ，解析 context_length 
bool http_s_context_length_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);


// http  urlparam 解析 
bool http_r_urlparam_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list);
class webmail163_parse  
{
    public:
        static bool burs_163_acc(session * p_session, c_packet * p_packet); //  163 附件类的组包  靠返回来推出数据
        static bool identity_burs_request(session * p_session, c_packet * p_packet);
        static bool requst_handle_163_acc(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list);//  163 附件类的组包  靠返回来推出数据
        static bool requst_handle_163_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list); //  163 类的组包  靠返回来推出数据
        static  bool requst_handle_163_xml(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool burs_163_get_acc(session * p_session, c_packet * p_packet);
        static bool burs_163_get_identity(session * p_session, c_packet * p_packet);
        static bool response_handle_163_acc(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;//  下载 163 附件类的组包
        static bool burs_accumulate_head_body(session * p_session, c_packet * p_packet); //  王晨曦添加 的组包函数
        static bool finish_right_now(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        // add by zq,增加对c2s方向注册数据的输出判定函数
        static bool c2s_finish_or_continue(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_sina_cookie_info_request(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_request_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool gbk_to_utf(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool urldecode_config(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_request_body_form2(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_request_body_form3(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_request_body_common(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool from_sign_to_real_mean(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_url(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_request_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_request_body1(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool replace_table(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_time(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_cookie_info_request(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_map_option(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool divide_str_option(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool set_action_type(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
        static bool get_info_from_map_value(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;
};


bool no_burs(session * p_session, c_packet * p_packet); // 该端数据不需要处理  直接返回 

bool no_requst_burs(session * p_session, c_packet * p_packet); // 该端数据不需要处理  直接返回 

void init_webmail163();

bool http_xml_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list);
bool http_s_http_handle_key(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);
bool http_r_http_handle_key(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);


bool http_r_post_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);

bool get_option_and_push_to_map(session* p_session, webmail_session* p_webmail_session, string& svalue, const char* start_sign, string& add_name, const char* start, const char* end_sign,int  to_start,int to_end,const char* start_sign_1 = NULL, const char* end_sign_1 = NULL, int to_s_1 = 0,int to_e_1 = 0);
bool deal_info_trunk(session* p_session, webmail_session* p_webmail_session,string& svalue,string& add_name,const char* search_start,const char* search_start_1 = NULL );

#endif  /*WEBMAIL163_PARSE_H*/
