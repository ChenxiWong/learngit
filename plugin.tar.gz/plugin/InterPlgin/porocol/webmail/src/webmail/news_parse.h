/*
 * new_parse.h
 *
 *  Created on: 2016年4月20日
 *      Author: Tianfeng-PC
 */

#ifndef PLUGIN_INTERPLGIN_POROCOL_WEBMAIL_SRC_WEBMAIL_NEWS_PARSE_H_
#define PLUGIN_INTERPLGIN_POROCOL_WEBMAIL_SRC_WEBMAIL_NEWS_PARSE_H_

#include <tinyxml_parse.h>
#include "webmail_str.h"
#include "ungzip.h"

class news_parse
{
public:
    static bool http_news_requst_parse(session *p_session,
                    webmail_session* p_webmail_session,
                    s_http_request * p_requst,
                    s_http_response * p_response,
                    node_value_list& v_list);
    static bool http_news_preview_response_parse(session *p_session,
                    webmail_session* p_webmail_session,
                    s_http_request * p_requst,
                    s_http_response * p_response,
                    node_value_list& v_list);
    static bool new_mail_request_att_parse(session *p_session,
                    webmail_session* p_webmail_session,
                    s_http_request * p_requst,
                    s_http_response * p_response,
                    node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
};

void init_news(void);

#endif /* PLUGIN_INTERPLGIN_POROCOL_WEBMAIL_SRC_WEBMAIL_NEWS_PARSE_H_ */
