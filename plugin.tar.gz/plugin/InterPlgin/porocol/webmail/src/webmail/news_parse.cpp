/*
 * news_parse.cpp
 *
 *  Created on: 2016年4月20日
 *      Author: Tianfeng-PC
 */
#include "news_parse.h"
#include "identity.h"
#include "commit_tools.h"
extern "C"{
#include <string.h>
}

void init_news()
{
    map_marge :: get_instance() -> add_node_map("news_response_handle_att", news_parse::http_news_preview_response_parse);//处理云盘的响应体
    map_marge :: get_instance() -> add_node_map("new_mail_request_parse", news_parse::new_mail_request_att_parse);
}

bool fiter_info(char * buff,char *p_content_info_fliter)
{
    char *p_fliter_begin = NULL;
    p_fliter_begin = strstr(buff,">");
    if(p_fliter_begin != NULL)
    {
        memcpy(p_content_info_fliter,buff,p_fliter_begin - buff - 1);
        return true;
    }
    return false;

}


bool ungzip_news_get_info(char * buff,char *find_h_key,char * find_t_key,char *p_con_info,uint32_t len)
{
    char *p_info_begin = NULL;
    char *p_info_end = NULL;
    char *p_info_title =  NULL;
    //char arr_info[200] = { 0 };
    //p_con_info = arr_info;
    p_info_begin = strstr(buff,find_h_key);
    if(p_info_begin == NULL)
    {
        return false;
    }
    p_info_end = strstr(p_info_begin,find_t_key);

    if(memcmp(find_h_key,"keywords=",len)==0)
    {
        memcpy(p_con_info,p_info_begin+len,p_info_end - p_info_begin - len - 1 );
        //   printf("info = %s\n",p_con_info);
        return true;
    }

    if((p_info_end - p_info_begin - len - 2) > 0)
    {
        memcpy(p_con_info,p_info_begin+len,p_info_end - p_info_begin - len -2);
        p_info_title = strstr(p_con_info,"\r\n");
        if(p_info_title != NULL)
        {
            char *p_title_b = NULL;
            char *p_title_e = NULL;
            char array_info[100] = { 0 };
            //p_con_info = array_info;
            p_title_b = strstr(p_con_info,">");
            if(p_title_b != NULL)
            {
                memcpy(array_info,p_con_info,p_title_b - p_con_info - 1);
                memcpy(p_con_info,array_info,strlen(array_info));
                //printf("arrar_info =%s\n",array_info);
            }
            else
            {
                return false;
            }
        }
        //printf("info = %s\n",p_con_info);
    }
    else
    {
        return false;
    }
    return true;

}

bool news_parse::http_news_preview_response_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value *p_parse_value = p_webmail_session->p_parse_value;

    if((p_parse_value == NULL) || (p_parse_value->len == 0))
        return false;

    //  p_parse_value->parse_type = CLOUD;
    if(p_webmail_session->state == server_data)
    {
        p_webmail_session ->b_add_end = true;
        p_webmail_session -> state = server_data_continue;
        //     string str_key = "response_head_key_Content-Disposition";
        string str_key = "response_head_key_Content-Encoding";

        //    p_parse_value->value_map.insert(pair<string,string>("app_type_360","2"));
        //    (p_parse_value -> value_map)["app_type_handle"] = "0";

        string str_tmp = "";

        parse_value_map::iterator iter1 = p_parse_value->value_map.find(str_key);
        if (iter1 != p_parse_value->value_map.end())
        {
            str_tmp = iter1->second;
            uint32_t size = str_tmp.find("gzip");
            if(size != string::npos)
            {
                p_parse_value -> bgzip = true;
            }
        }
        if(p_webmail_session -> requst_time == 0)
        {
            p_webmail_session -> requst_time = p_session -> packet_time;
        }
        if(p_webmail_session ->response_length > 0 &&  (uint32_t)(p_webmail_session->response_length) <= p_parse_value->len )
        {
            p_webmail_session ->b_end_send = true;
        }
    }

    if(p_parse_value->buf != NULL && p_parse_value->len > 0)
    {
        if(p_parse_value -> value_map["response_head_key_Transfer-Encoding"] == "chunked")
        {
            if(p_parse_value -> bgzip)
            {
                int ioffise = 0;
                uint32_t ibuf_offist = 0;

                ioffise = p_webmail_session->had_send_len;//rem_len;

                while(p_parse_value -> len > ibuf_offist)
                {
                    if(p_webmail_session -> tmp_len == 0)
                    {
                        char *mid = strstr(p_parse_value -> buf + ibuf_offist,"\r\n");
                        if(mid == NULL)
                        {
                            // p_session->server.clear_buf();
                            return true;
                        }
                        uint32_t len = strtol(p_parse_value -> buf +  ibuf_offist,&mid,16);
                        if(len == 0)
                        {
                            p_webmail_session -> b_end_send = true;
                            if(p_session -> send_len == 0 && ioffise == 0)
                            {
                                p_session -> p_send_buf = NO_NULL;
                                p_session -> send_len = 1;
                            }
                            else
                            {
                                try
                                {
                                    p_parse_value->parse_tmp_len =ioffise * 400;
                                    p_parse_value->parse_tmp_buf = new  char [ioffise * 400] ;
                                }
                                catch( const bad_alloc & e)
                                {
                                    try
                                    {
                                        p_parse_value->parse_tmp_len =ioffise * 10;
                                        p_parse_value->parse_tmp_buf = new  char [ioffise * 10] ;
                                    }
                                    catch( const bad_alloc & e)
                                    {
                                        return true;
                                    }

                                }
                                p_parse_value -> gzip_len = ioffise;
                                // int ret  = httpgzdecompress((Bytef *)p_parse_value -> gzip_buffer ,(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  ,(uLong*)& p_parse_value->parse_tmp_len);
                                int ret  = httpgzdecompress((Bytef *)(*(p_webmail_session->file_content)).c_str(),(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  ,(uLong*)& p_parse_value->parse_tmp_len);
                                *(p_webmail_session->file_content) = "";
                                p_parse_value->gzip_len = 0;
                                p_webmail_session->had_send_len = 0;
                                char p_content_info[200] = { 0 };
                                char p_fliter_info[200] = { 0 };

                                if(ret == 0)
                                {
                                    bool ret_flag;
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"meta charset=\"","/>",p_content_info,strlen("meta charset=\""));
                                    if(ret_flag == true)
                                    {
                                        int ret_fliter = fiter_info(p_content_info,p_fliter_info);
                                        if(ret_fliter == true)
                                        {
                                            p_parse_value->value_map.insert(pair<string,string>("title_charset",p_fliter_info));
                                        }
                                        else
                                        {
                                            p_parse_value->value_map.insert(pair<string,string>("title_charset",p_content_info));
                                        }
                                    }

                                    memset(p_content_info,'\0',sizeof(p_content_info));
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"<title>","</title>",p_content_info,strlen("<title>"));
                                    if(ret_flag == true)
                                    {
                                        p_parse_value->value_map.insert(pair<string,string>("title",p_content_info));
                                    }
                                    memset(p_content_info,0,sizeof(p_content_info));
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"itemprop=\"keywords\" content=\"","/>",p_content_info,strlen("itemprop=\"keywords\" content=\""));
                                    if(ret_flag == true)
                                    {
                                        p_parse_value->value_map.insert(pair<string,string>("title_keywords",p_content_info));
                                    }
                                    memset(p_content_info,0,sizeof(p_content_info));
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"keywords=","/>",p_content_info,strlen("keywords="));
                                    if(ret_flag == true)
                                    {
                                        p_parse_value->value_map.insert(pair<string,string>("keywords",p_content_info));
                                    }
                                    memset(p_content_info,0,sizeof(p_content_info));
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"meta http-equiv=\"Content-Type\" content=\"","/>",p_content_info,strlen("meta http-equiv=\"Content-Type\" content=\""));
                                    if(ret_flag == true)
                                    {
                                        p_parse_value->value_map.insert(pair<string,string>("formmat",p_content_info));
                                    }
                                    memset(p_content_info,0,sizeof(p_content_info));
                                    ret_flag = ungzip_news_get_info(p_parse_value->parse_tmp_buf,"meta name=\"keywords\" content=\"","/>",p_content_info,strlen("meta name=\"keywords\" content=\""));
                                    if(ret_flag == true)
                                    {
                                        p_parse_value->value_map.insert(pair<string,string>("search_title_keywords",p_content_info));
                                    }		


                                    /* bool ret_info;
                                       ret_info = pc_app_download_info(p_webmail_session,p_parse_value->parse_tmp_buf,p_parse_value->parse_tmp_len);
                                       if(ret_info == false)
                                       {
                                       p_session -> p_send_buf = NO_NULL;
                                       p_session -> send_len = 1;
                                       }
                                       else
                                       {*/
                                    p_session -> p_send_buf = p_parse_value->parse_tmp_buf;
                                    p_session -> send_len = p_parse_value->parse_tmp_len;
                                    //}
                                }

                            }
                            return true;
                        }
                        mid += 2;
                        ibuf_offist = mid - p_parse_value -> buf;

                        if(p_parse_value -> len - ibuf_offist > len)//已经缓存到数据大于要处理到数据
                        {
                            //memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, len);
                            //memcpy(buffer , p_parse_value -> buf + ibuf_offist, len);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + ibuf_offist + len);
                            *(p_webmail_session->file_content) += tmp;
                            ibuf_offist += 2;
                            ioffise += len;
                            ibuf_offist += len;
                            p_webmail_session -> tmp_len = 0;
                            p_webmail_session->had_send_len = ioffise;
                            p_webmail_session -> response_length = 0;
                        }
                        else //已经缓存的数据小于要处理到数据
                        {
                            //memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            // memcpy(buffer , p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + p_parse_value -> len);
                            *(p_webmail_session->file_content) += tmp;
                            ioffise += p_parse_value -> len - ibuf_offist;//缓存数据到长度
                            p_webmail_session -> tmp_len = len - (p_parse_value -> len - ibuf_offist);//剩余数据的长度
                            p_webmail_session -> response_length = len - p_parse_value -> len +ibuf_offist;
                            // p_parse_value->parse_tmp_len = ioffise;
                            p_webmail_session->had_send_len = ioffise;
                            // rem_packet = len - p_parse_value -> len;
                            // p_webmail_session ->response_length = p_parse_value->len;
                            p_session->server.clear_buf();
                            return true;
                        }
                    }
                    else
                    {
                        if(p_webmail_session -> tmp_len < p_parse_value -> len)//剩余数据的长度小于缓冲区到长度
                        {
                            int len = p_webmail_session -> tmp_len;
                            p_webmail_session -> tmp_len = 0;
                            // memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, len);
                            //  memcpy(buffer , p_parse_value -> buf + ibuf_offist, len);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + ibuf_offist + len);
                            *(p_webmail_session->file_content) += tmp;
                            ibuf_offist += len;
                            ibuf_offist +=2 ;
                            ioffise += len  ;
                            p_webmail_session->had_send_len = ioffise;
                            p_webmail_session -> response_length = 0;
                        }
                        else//剩余数据到长度大于缓冲区的长度
                        {
                            int len = p_webmail_session ->tmp_len ;
                            // memcpy(buffer + ioffise, p_parse_value->buf + ibuf_offist ,p_parse_value -> len - ibuf_offist );
                            // memcpy(buffer , p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + p_parse_value -> len);
                            *(p_webmail_session->file_content) += tmp;
                            ioffise += p_parse_value -> len - ibuf_offist  ;
                            p_webmail_session ->tmp_len = len - (p_parse_value->len   - ibuf_offist);
                            //   p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                            //   p_session -> send_len = ioffise;
                            p_webmail_session -> response_length = len - p_parse_value -> len +ibuf_offist;
                            p_webmail_session->had_send_len = ioffise;

                            p_session->server.clear_buf();
                            return true;
                        }
                    }
                }
                if(ioffise == 0)
                {
                    if(p_webmail_session ->b_end_send == true)
                    {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 1;
                    }
                    else {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 0;
                    }
                }
                else
                {
                    p_webmail_session->had_send_len = ioffise;
                    p_webmail_session -> response_length = 0;
                }
                p_session->server.clear_buf();
                return true;
            }
        }
        /*//非压缩文件
          else
          {
          if( p_parse_value -> parse_tmp_len < (uint32_t)(p_webmail_session->response_length))
          {
          p_session -> p_send_buf = p_parse_value -> buf;
          if ((uint32_t)(p_parse_value->parse_tmp_len) + p_parse_value ->len >= (uint32_t)(p_webmail_session->response_length))
          {
          p_session -> send_len += p_webmail_session->response_length;// - p_parse_value->parse_tmp_len;
          p_parse_value ->  parse_tmp_len = 0;
          p_webmail_session -> b_end_send = true;
          }
          else
          {
          p_session -> send_len = p_parse_value -> len;
          p_parse_value -> parse_tmp_len += p_parse_value -> len;
          }
          }
          }*/
        if(p_webmail_session ->b_end_send )
        {
            if(p_session->send_len == 0 || p_session->p_send_buf == NULL)
            {
                p_session->send_len = 1;
                p_session->p_send_buf = NO_NULL;
            }
            p_session->server.clear_buf();
            return true;
        }
    }
    p_session->server.clear_buf();
    return true;
}

bool news_parse::new_mail_request_att_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_parse_value -> parse_type  = MESS_BODY;
    if(p_parse_value == NULL)
        return false;
    if(p_parse_value->len == 0)
        return false;

    //  包长度
    // 文件 长度
    if(p_webmail_session -> state == client_data)
    {
        /*if(p_requst == NULL || p_response == NULL)
          {
          return true;
          }*/

        // 文件长度计算
        p_parse_value->buf[p_parse_value->len] = 0x0;
        char * b = p_parse_value->buf;
        char * mid = strstr(b, "\r\n");
        if(mid == NULL)
            return true;
        int boundary_len = mid-b;

        string key = "filename=\"";
        char * end = strstr(mid, key.c_str());
        if(end == NULL)
            return true;

        end += key.length();
        mid = strstr(end, "\"");
        if(mid == NULL)
            return true;

        string svalue(end, mid);
        node_value_list::iterator iter = v_list.begin();
        string name = "sohu_att_";
        name += *(v_list.begin());
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        end = strstr(mid, "\r\n\r\n");
        if(end == NULL)
            return true;
        end += 4;

        //int remaind = end-b + 2*(boundary_len+2) + 65;
        int remaind = end - p_parse_value->buf  + boundary_len  + 4; //end-b + 2*(boundary_len+2) + 65;
        int content_len = p_webmail_session->requset_length - remaind ;

        p_parse_value->acc_file_length = content_len;
        // 首先处理包属性字段的提取，包内容是在后面的包单独发送传输过来, 没有发现包内容和属性字段组在一起发送
        // 设置清理之前的数据包信号，p_session->send_len == 0 && p_session->p_send_buf  != NULL, 在webmail_plugin.cpp里面清理
        if(end - b  == p_parse_value->len)
        {
            p_session->p_send_buf = end;
            p_session->send_len = 0;
            p_webmail_session->had_send_len =  remaind ;

        }
        else
        {
            uint32_t len = p_parse_value->len - (end - p_parse_value->buf ) ;
            if (len > content_len )
            {
                len = content_len ;
            }
            p_session->p_send_buf = end;
            p_session->send_len = len;
            p_webmail_session->had_send_len = len + remaind ;
        }
        //p_webmail_session->requset_length -= p_parse_value->len;
        // 设置收包处理属性
        // p_webmail_session->state = client_data_continue;
    }

    return true;
}
