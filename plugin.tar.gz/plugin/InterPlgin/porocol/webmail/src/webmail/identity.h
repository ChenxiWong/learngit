// Last Update:2016-06-21 16:36:12
/**
 * @file identity.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-10-07
 */

#ifndef IDENTITY_H
#define IDENTITY_H
#include "webmail_str.h"
#include "unic_to_utf8_str.h"
#include "http_urlparam_analyzer.h"
#include "shttp_common.h"
#include <tinyxml_parse.h>
#include <string>
// 门户网站提取用户名和密码
class identity_parse
{
    public:
        static bool identity_url_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_request_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_request_parse1(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_request_parse2(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_gzip_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool validity_distinguish(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_request_parse_zhenai(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse_yingshi(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse_yiche(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse_yicheregiste(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_request_parse_qq(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse_dongfang(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_parse_anjuke(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        
        static bool identity_bxw_user_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_lashou_reg_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_dzdp_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_zhenai_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_anjuke_reg(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_qq_reg(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool identity_response_gzip_parse_zhenai(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);


        /*********************以下为位置信息*********************************/
        static bool http_requst_urlparam_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_url_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_post_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_post2_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_post3_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_urlparam_decode_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_urlparam3_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_strcat_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_strcat2_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_strcat3_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_distinguish_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_lashou_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool http_requst_url_second_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);
        static bool http_retaken_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list);
            /************************************The following was added by wangchenxi*************************/
            static bool get_position_info_request(session* p_session, webmail_session* p_webmail_session, s_http_request* p_requst, s_http_response* p_response, node_value_list& v_list);
        static bool aiguanggongjiao_request_to_response(session* p_session, webmail_session* p_webmail_session, s_http_request* p_requst, s_http_response* p_response, node_value_list& v_list);
        static bool aiguanggongjiao_position_info_response(session* p_session, webmail_session* p_webmail_session, s_http_request* p_requst, s_http_response* p_response, node_value_list& v_list);
        static bool turn_client_state_to_server_state(session* p_session, webmail_session* p_webmail_session, s_http_request* p_requst, s_http_response* p_response, node_value_list& v_list);
        /**********************************************stop here******************************************/
        static bool unic_to_utf(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
};
void init_identity();
void init_location();
int filewrite(string path,string content);
string urldecode(string &str_source);


#endif  /*IDENTITY_H*/
