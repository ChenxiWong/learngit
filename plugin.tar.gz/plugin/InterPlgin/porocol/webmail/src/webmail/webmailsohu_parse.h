// Last Update:2015-07-01 22:29:34
/**
 * @file webmailsohu_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-05-09
 */

#ifndef WEBMAILSOHU_PARSE_H
#define WEBMAILSOHU_PARSE_H
#include "webmail_str.h"
#include "http_urlparam_analyzer.h"
#include <tinyxml_parse.h>

class webmailsohu_parse
{
    public:
        static bool response_att_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requset, s_http_response * p_response, node_value_list& v_list);//  sohu 附件类的组包  靠返回来推出数据
        static bool request_body_atts_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool request_body_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool request_att_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool request_att_parse2(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool request_cookie_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool request_cookie2_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool request_cookie_parse1(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool get_cookie_message(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
        static bool get_message_map(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list);
		static bool sina_request_body_atts_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sina 提取请求体的attid
        static bool sina_request_att_image_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool sina_response_att_image_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requset, s_http_response * p_response, node_value_list& v_list);//  sohu 附件类的组包  靠返回来推出数据
        static bool sina_request_body_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sina提取请求体的from，to等
        static bool sina_urlparam_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sina提取请求体的from，to等
        static bool sina_get_att_image_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
        static bool response_sohu_get_mids(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list); //  sohu 类的组包  靠返回来推出数据
};

void init_webmailsohu();

bool smiple_burs(session * p_session, c_packet * p_packet); // 该端数据需要处理

#endif  /*WEBMAILSOHU_PARSE_H*/
