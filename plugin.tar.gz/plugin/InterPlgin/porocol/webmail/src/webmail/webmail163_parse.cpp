// Last Update:2016-08-19 09:23:13
/**
 * @file webmail163_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-06
 */

// 163 附件类的组包  靠返回来推出数据 
//
#include "webmail163_parse.h"
#include "webmailsina_parse.h"
#include "http_urlparam_analyzer.h"
#include  "http_response_parse.h"
#include "commit_tools.h"
#include  <iomanip>
#include  "shttp_common.h"

void init_webmail163()
{
    // 163 附件 组包 
    map_marge::get_instance()->add_burs_map("web163_requse_att", webmail163_parse::burs_163_acc); // 判断是否结束 
    map_marge::get_instance()->add_burs_map("identity_burs_request", webmail163_parse::identity_burs_request);
    map_marge::get_instance()->add_burs_map("no_burs", no_burs); //不处理 
    map_marge::get_instance()->add_burs_map("no_requst_burs", no_requst_burs); //收到包后不验证长度，直接进入
    map_marge::get_instance()->add_burs_map("web163_get_att", webmail163_parse::burs_163_get_acc); // 处理 response 端的数据 
    map_marge::get_instance()->add_burs_map("web163_get_identity", webmail163_parse::burs_163_get_identity); // 处理 response 端的数据
    //
    map_marge::get_instance()->add_node_map("web163_requse_att_handle", webmail163_parse::requst_handle_163_acc); // 163 邮箱处理 
    map_marge::get_instance()->add_node_map("r_context_length", http_r_context_length_parse); //  取长度 
    map_marge::get_instance()->add_node_map("s_context_length", http_s_context_length_parse); //response 长度 
    map_marge::get_instance()->add_node_map("urlparam", http_r_urlparam_parse); // 解析 url param 
    map_marge::get_instance()->add_node_map("requst_handle_163_body", webmail163_parse::requst_handle_163_body); //163 邮件正文处理 
    map_marge::get_instance()->add_node_map("requst_head_pasre", http_r_http_handle_key); // 请求头解析 
    map_marge::get_instance()->add_node_map("response_head_pasre", http_s_http_handle_key); // 返回 头解析 

    map_marge::get_instance()->add_node_map("response_handle_163_att", webmail163_parse::response_handle_163_acc); //163 邮件返回处理 

    map_marge::get_instance()->add_node_map("httppost", http_r_post_parse); //163 邮件返回处理 

    map_marge::get_instance()->add_node_map("response_gzip_json_parse", webmailsina_parse::response_handle_sina_body); // 返回是gzip  json 格式 
    map_marge::get_instance()->add_node_map("response_sohu_length", webmailsina_parse::response_handle_sohu_body_length); // 返回是gzip  加密文件的长队
    map_marge::get_instance()->add_node_map("request_url_sohu_att_id", webmailsina_parse::response_handle_sohu_att_id); // 返回是gzip  json 格式 
    map_marge::get_instance()->add_node_map("response_163_body_parse", webmailsina_parse::response_handle_163_getbody); // 163 收取邮件正文处理
    map_marge::get_instance()->add_node_map("get_redis_map", webmailsina_parse::get_redis_map); // 163 收取邮件正文处理
    map_marge::get_instance()->add_burs_map("web_accumulate_head_body", webmail163_parse::burs_accumulate_head_body); // 王晨曦添加的组包函数

    map_marge::get_instance()->add_node_map("http_response_parse", http_response_parse::response_body_html2txt); // 163 收取邮件正文处理
    map_marge::get_instance()->add_node_map("finish_right_now", webmail163_parse::finish_right_now); // 163 收取邮件正文处理
    // // add by zq,增加对c2s方向注册数据的输出判定函数
    map_marge::get_instance()->add_node_map("c2s_finish_or_continue", webmail163_parse::c2s_finish_or_continue); //处理c2s方向数据判定是否输出
    map_marge::get_instance()->add_node_map("get_sina_cookie_info_request", webmail163_parse::get_sina_cookie_info_request);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_request_body", webmail163_parse::get_info_from_request_body);// added by wangchenxi
    map_marge::get_instance()->add_node_map("gbk_to_utf", webmail163_parse::gbk_to_utf);// added by wangchenxi
    map_marge::get_instance()->add_node_map("urldecode_config", webmail163_parse::urldecode_config);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_request_body_form2", webmail163_parse::get_info_from_request_body_form2);// added by wangchenxi
    map_marge::get_instance()->add_node_map("from_sign_to_real_mean", webmail163_parse::from_sign_to_real_mean);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_request_body_form3", webmail163_parse::get_info_from_request_body_form3);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_request_body_common", webmail163_parse::get_info_from_request_body_common);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_url", webmail163_parse::get_info_url);// added by xiaojun
    map_marge::get_instance()->add_node_map("get_info_request_body", webmail163_parse::get_info_request_body);// added by xiaojun
    map_marge::get_instance()->add_node_map("get_info_request_body1", webmail163_parse::get_info_request_body1);// added by xiaojun
    map_marge::get_instance()->add_node_map("replace_table", webmail163_parse::replace_table);// added by xiaojun
    map_marge::get_instance()->add_node_map("get_time", webmail163_parse::get_time);// added by xiaojun
    map_marge::get_instance()->add_node_map("get_cookie_info_request", webmail163_parse::get_cookie_info_request);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_map_option", webmail163_parse::get_info_from_map_option);// added by wangchenxi
    map_marge::get_instance()->add_node_map("divide_str_option", webmail163_parse::divide_str_option);// added by wangchenxi
    map_marge::get_instance()->add_node_map("set_action_type", webmail163_parse::set_action_type);// added by wangchenxi
    map_marge::get_instance()->add_node_map("get_info_from_map_value", webmail163_parse::get_info_from_map_value);// added by zhoujuanjuan
}

bool webmail163_parse::burs_163_get_identity(session* p_session,c_packet* p_packet)
{
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    p_session->packet_len += p_packet->app_data_len ;//p_packet->buff_len;
    // p_session->packet_num++;

    if(p_session->packet_begin_time == 0)
    {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
    }
    if(p_session->packet_end_time != 0)
    {
        p_session->packet_end_time = p_packet->m_timeval;
    }

    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s )
    {
        if( p_webmail_session ->b_add_end)
        {
            p_webmail_session ->b_end_send = true;
            p_webmail_session -> state = client_data;
        }
        p_session->packet_num++;
        return true;
    }
    // 判断是否不是第一次收取数据 //包括头  判断头是否结束
    if(p_webmail_session -> state == server_data)
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;
        }
        else
        {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据clouddisk360_parse.cpp
        {
            p_session->packet_num++;
            return true;
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            return true;
        }
    }
    else if  (p_webmail_session -> state == server_data_continue)
    {
        //p_session->server.add_tcp_packet(len,p_data,seq);
        //p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session ->response_length == 0) // 添加chunked 判定
        {
            char *mid = strstr((char *)p_data,"\r\n");
            if(mid == NULL)
            {
                p_session->packet_num++;
                return true;
            }
            int other_len = strtol((char *)p_data,&mid,16);
            p_data = mid+2;
            p_webmail_session ->response_length = other_len;//- rem_packet;
            len -= mid+2-p_data;
        }
        p_session->server.add_tcp_packet(len, p_data, seq);
        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session ->response_length > 0)
        {
            parse_value * p_parse_value = p_webmail_session ->p_parse_value;
            if(p_webmail_session->len + p_parse_value->parse_tmp_len  >=p_webmail_session ->response_length)
            {
                p_session->packet_num++;
                return true;
            }
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            //正文超长
            return true;
        }
    }
    return false;
}

bool webmail163_parse::burs_163_get_acc(session * p_session, c_packet * p_packet)
{
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    p_session->packet_len += p_packet->app_data_len ;//p_packet->buff_len;
    //p_session->packet_num++;
    if(p_session->packet_begin_time == 0)
    {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
    }
    if(p_session->packet_end_time != 0)
    {
        p_session->packet_end_time = p_packet->m_timeval;
    }
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s  )
    {
        if(len > 0 ) 
        {
            if (len ==1 && *p_data == 0x0) 
            {
                return false;
            }

            if( p_webmail_session ->b_add_end) 
            {
                p_webmail_session ->b_end_send = true;
                // --- 
                p_webmail_session -> state = client_data;
                SET_SESSION_OVER(p_session);
            } 
            return true;
        }
        return false ;
    }
    // 判断是否不是第一次收取数据 //包括头  判断头是否结束 
    if(p_webmail_session -> state == server_data) 
    {
        p_session->server.add_tcp_packet(len,p_data,seq);

        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;
        }
        else {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据 
        {
            p_session->packet_num++;
            return true; 
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            return true;
        }
    }
    else if  (p_webmail_session -> state == server_data_continue)
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);

        parse_value * p_parse_value = p_webmail_session ->p_parse_value;
        if(p_webmail_session ->response_length == 0  &&   p_parse_value->parse_tmp_len  == 0 &&  p_webmail_session->len  > 0) 
        {
            p_session->packet_num++;
            return true;
        }
        if(p_webmail_session ->response_length >  0  ) 
        {
            if(p_webmail_session->len + p_parse_value->parse_tmp_len  >=p_webmail_session ->response_length)
            {
                p_session->packet_num++;
                return true;
            }
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            //正文超长
            return true;
        }
    }
    return false;
}
bool webmail163_parse::burs_163_acc(session * p_session, c_packet * p_packet)
{
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    p_session->packet_len += p_packet->app_data_len ;//p_packet->buff_len;
    // p_session->packet_num++;
    if(p_session->packet_begin_time == 0)
    {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
    }
    if(p_session->packet_end_time != 0)
    {
        p_session->packet_end_time = p_packet->m_timeval;
    }
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s == false)
    {
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len); 
        if(p_webmail_session->len  + p_webmail_session->had_send_len >=p_webmail_session ->requset_length) 
        {
            p_session->packet_num++;
            return true;
        }
        if(p_webmail_session->p_data != NULL && strncmp((char *)p_webmail_session->p_data ,"HTTP/1.1 200 OK",15 ) == 0) 
        {
            SET_SESSION_OVER(p_session);
            p_session->packet_num++;
            return true;
        }
        return false;
    }
    // 判断是否不是第一次收取数据 //包括头  判断头是否结束 
    if(p_webmail_session -> state == client_data) 
    {
        p_session->client.add_tcp_packet(len,p_data,seq);

        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;
        }
        else {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据 
        {
            //p_webmail_session->http_head_length = p_end - (char *)p_webmail_session->p_data + 4;
            p_session->packet_num++;
            return true; 
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            return true;
        }
    }
    else if  (p_webmail_session -> state == client_data_continue)
    {
        p_session->client.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);
        parse_value * p_parse_value = p_webmail_session ->p_parse_value;
        if((p_webmail_session->len  + p_webmail_session->had_send_len >=p_webmail_session ->requset_length)
                ||(p_parse_value -> courze_len > 0 &&  p_webmail_session->len  + p_webmail_session->had_send_len >= p_parse_value ->  courze_len))
        {
            // 文件结束 
            //p_webmail_session ->requset_length = 0;
            p_session->packet_num++;
            return true;
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            //正文超长
            //p_webmail_session ->requset_length -= p_webmail_session->len;
            p_session->packet_num++;
            return true;
        }
    }
    return false;
}
// 163 xml 1.0 使用关键字解析 
bool webmail163_parse::requst_handle_163_xml(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 类的组包  靠返回来推出数据
{
    // return true;
    // xml  1.0 解析头函数
    if(p_webmail_session==NULL || p_webmail_session ->p_parse_value==NULL)
        return true;

    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 
    char * buffer = p_parse_value->buf;
    if(buffer == NULL)
        return true;
    //buffer[p_parse_value->len ] = 0x0;
    //buffer[p_webmail_session ->requset_length  -4 ] = 0x0;
    int request_len = p_webmail_session ->tmp_requset_length>4? p_webmail_session->tmp_requset_length : p_webmail_session->requset_length;
    if(request_len < 4)
        return true;

    buffer[request_len-4] = 0x0;
    char buff[6553510];
    int len  = 6553600;
    char * p_str = NULL;
    char * p_end = NULL;
    string name = "";
    string svalue ="";
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        //char * p_str = strstr(buffer ,iter->c_str());
        p_str = strstr(buffer ,iter->c_str());
        if(p_str != NULL)
        {
            //if(iter->compare(0,"array%20")== 0)  // 数组 
            if(iter->length()>strlen("array%20") && strncmp(iter->c_str(),"array%20",strlen("array%20"))==0 )
            {
                // 找到下一结束标记
                p_str += iter->length();
                p_end = strstr(p_str,"%3C%2Farray%3E");
                if(p_end != NULL)
                {
                    svalue = "";
                    while(p_str < p_end)
                    {
                        if(p_str+strlen("%3Cstring%3E")<p_end && strncmp(p_str,"%3Cstring%3E",strlen("%3Cstring%3E")) == 0)
                        {
                            if(p_str >= p_end) 
                            {
                                break ;
                            }
                            p_str += strlen("%3Cstring%3E");
                            if(p_str >= p_end) 
                            {
                                break ;
                            }
                            char *pp_end = strstr(p_str,"%3C%2Fstring%3E%");
                            if(pp_end != NULL && pp_end < p_end)
                            {
                                if(p_str >= p_end) 
                                {
                                    break ;
                                }
                                len  = 6553600;
                                char s = *pp_end;
                                UrlDecode(p_str , pp_end - p_str  ,buff,len);    
                                *pp_end = s;
                                if(svalue.length() > 0) 
                                {
                                    svalue +="|";
                                }
                                svalue += buff;

                                //p_str = pp_end + strlen("%3C%2Fstring%3E%") +1;
                                p_str = pp_end + strlen("%3C%2Fstring%3E");
                            }
                            else {
                                return true;
                            }
                        }
                        else {
                            return true;
                        }
                    }
                    name = "xml_";
                    name += *iter;

                    char * buffer = new char[svalue.length()];
                    if(buffer == NULL)
                        return true;

                    int len = 0;
                    html_to_txt(buffer, len, svalue.c_str(), svalue.length());
                    if(len > 0)
                    {
                        svalue.clear();
                        //svalue.assign(buffer, buffer+len);
                        svalue = string(buffer, 0, len);
                    }
                    delete [] buffer;
                    buffer = NULL;
                    p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                }
            }
            // 找到关键字 判断是否需要循环取出数据 
            else 
            {
                p_str += iter->length();

                p_end = strstr(p_str,"%3C%2Fstring%3E%");
                if(p_end != NULL)
                {
                    name = "xml_";
                    name += *iter;
                    svalue = "";
                    if(p_end > p_str ) 
                    {
                        len  = 6553600;
                        char s = *p_end;
                        UrlDecode(p_str , p_end - p_str  ,buff,len);    
                        *p_end = s;
                        svalue= buff;
                    }
                    char * buffer = new char[svalue.length()];
                    if(buffer == NULL)
                        return true;

                    int len = 0;
                    html_to_txt(buffer, len, svalue.c_str(), svalue.length());
                    if(len > 0)
                    {
                        svalue.clear();
                        //svalue.assign(buffer, buffer+len);
                        svalue = string(buffer, 0, len);
                    }
                    if(buffer != NULL)
                    {
                        delete[] buffer;
                    }
                    buffer = NULL;
                    p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                }

            }

        } 
    }
    return true;
}
bool webmail163_parse::requst_handle_163_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 类的组包  靠返回来推出数据
{
    // 正文 65536
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_parse_value -> parse_type  = MESS_BODY;
    if(p_webmail_session -> state == client_data)
    {
        if(p_parse_value->len   + p_webmail_session ->tmp_requset_length   >= p_webmail_session ->requset_length)
        {

            if(p_requst == NULL || p_response == NULL)
            {
                return false;
            }
            // 求出包的长度 

            p_webmail_session -> state = server_data;
            p_webmail_session-> b_end_send = true;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = 1;
            // 解析头函数
            return requst_handle_163_xml(p_session,p_webmail_session,p_requst,p_response,v_list);

        }
        else {
            // 
            p_parse_value->buf[p_parse_value->len ] =0x0;
            p_parse_value->file_data += p_parse_value->buf; 
            //清理buffer 
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = 0;
            p_webmail_session -> state = client_data_continue;
        }
    }
    else if (p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->len == 0)
            return true;
        if(p_webmail_session->tmp_requset_length == 0)
        {
            if(p_parse_value->len+MAXPACKETLEN > MAXTCPBUF)
            {
                p_webmail_session ->tmp_requset_length = p_webmail_session->requset_length;
                p_webmail_session ->tmp_requset_length += p_parse_value->len;
            }
            else
            {
                p_webmail_session ->tmp_requset_length = p_webmail_session->requset_length>0 ? p_webmail_session->requset_length : p_parse_value->len;
            }
        }

        //p_parse_value->buf[p_parse_value->len] =0x0;
        p_parse_value->file_data += p_parse_value->buf; 
        if(p_parse_value->file_data.length()>=p_webmail_session->tmp_requset_length)
        {
            p_parse_value->buf[p_parse_value->len] =0x0;
            if(p_parse_value->file_data.length() > 4)
            {
                //p_parse_value->buf = new  char[p_parse_value->file_data.length-4];
                p_parse_value->buf = (char *)p_parse_value->file_data.c_str()+4;
                //memcpy(p_parse_value->buf, p_parse_value->file_data.c_str()+4, p_parse_value->file_data.length-4);
            }
            //p_parse_value->len = p_webmail_session ->requset_length -4;

            if(p_webmail_session ->tmp_requset_length > 4)
            {
                p_parse_value->len = p_webmail_session ->tmp_requset_length -4;
            }
            else if(p_parse_value->len > 4)
            {
                p_parse_value->len -= 4;
            }

            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = 1;
            return requst_handle_163_xml(p_session,p_webmail_session,p_requst,p_response,v_list);
        }
        if(p_parse_value->buf != NULL)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = p_parse_value->buf;
        }
    }
    return  true;
    // --- 
}
// 163
bool webmail163_parse::response_handle_163_acc(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  下载 163 附件类的组包
{

    //修改key 中的值 ，
    // bool bgzip = false;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_webmail_session -> state == server_data) 
    {
        p_webmail_session -> state = server_data_continue;
        p_webmail_session ->b_add_end = true;
        string key ="response_head_key_Content-Disposition";
        string key2 ="response_head_key_Content-Encoding";
        if(p_webmail_session->requst_time == 0)
            p_webmail_session->requst_time = p_session->packet_time;
        parse_value_map ::iterator iter = p_parse_value->value_map.find(key);
        string name = "";
        string tmp = "";
        if(iter != p_parse_value->value_map.end())
        {
            tmp = iter->second;

            int size = tmp.find("filename=");
            if(size != string::npos && size+10<tmp.length())
            {
                name=string(tmp,size+10,tmp.length()-size-10-1);
                // if(name == "")
            }
            else
            {
                name = tmp;
            }
        }

        size_t pos = name.find("*=\"UTF-8''");//sina邮箱下载附件取文件名的特殊情况
        if(pos != string::npos)
        {
            name.assign(name,pos+10,name.length()-(pos + 11));
        }
        parse_value_map ::iterator iter2 = p_parse_value->value_map.find(key2);
        if(iter2!= p_parse_value->value_map.end())
        {
            tmp = iter2->second;
            int size = tmp.find("gzip");
            if(size != string::npos)
            {
                //name +=".tar.gz";
                p_parse_value -> bgzip = true;
            }
        }
        if(name.length()> 0)
            p_parse_value->value_map.insert(pair<string,string>("webmail163_filename",name));
    }
    if(p_parse_value->buf != NULL && p_parse_value->len > 0)
    {
        //p_session->p_send_buf = p_parse_value->buf;
        if(p_parse_value -> bgzip) 
        {
            if(p_webmail_session ->response_length > 0 &&  p_webmail_session ->response_length <= p_parse_value->len  +  p_parse_value->gzip_len  )
            {
                p_webmail_session ->b_end_send = true;
            }
            if(p_parse_value->gzip_buffer == NULL )
            {
                webmailsina_parse::response_handle_sohu_body_length(p_session ,p_webmail_session ,p_requst ,  p_response , v_list);
                p_parse_value->gzip_buffer = new  char[p_webmail_session ->response_length  + 20];
                p_parse_value->gzip_len  = 0 ;
                p_parse_value ->parse_tmp_len = 0;
                if(p_parse_value->gzip_buffer  == NULL) 
                    return false;
            }
            //if(p_webmail_session ->response_length > 0)
            if(p_webmail_session ->response_length <=   p_parse_value->gzip_len   +   p_parse_value->len  )
            {
                //   p_webmail_session ->response_length -= p_parse_value->len;
                //  p_session->send_len = p_parse_value->len ;
                if(p_webmail_session ->response_length  <=  p_parse_value->gzip_len  +  p_parse_value->len  )
                {
                    p_parse_value->parse_tmp_buf = NULL;
                    p_webmail_session ->b_end_send = true;
                    {
                        // 
                        // memcpy()
                        p_parse_value->len = p_webmail_session ->response_length -  p_parse_value->gzip_len  ;//p_webmail_session ->response_length;
                        memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len  , p_parse_value->buf,p_parse_value->len);
                        p_parse_value->gzip_len += p_parse_value->len;

                        p_parse_value->parse_tmp_len =p_parse_value->gzip_len * 10;
                        p_parse_value->parse_tmp_buf = new  char [p_parse_value->gzip_len * 10] ;
                    }
                    if(p_parse_value->parse_tmp_buf  == NULL) 
                    {
                        return true;
                    }
                    // --------------- 
                    //解压文件
                    int ret  = httpgzdecompress((Bytef *)p_parse_value->gzip_buffer ,(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  , (uLong*)& p_parse_value->parse_tmp_len);
                    delete [] p_parse_value->gzip_buffer ;
                    p_parse_value->gzip_buffer = NULL; 
                    p_parse_value->gzip_len = 0;

                    if(ret == 0 )
                    {
                        //发送解压文件
                        p_parse_value->parse_tmp_buf[p_parse_value->parse_tmp_len ] = 0x0;
                        p_session->p_send_buf = p_parse_value->parse_tmp_buf;
                        p_session->send_len = p_parse_value->parse_tmp_len ;
                        return true;
                    }
                    else
                    {
                        // 清理数据
                        p_parse_value->parse_tmp_len  = 0;
                        p_session->p_send_buf = NO_NULL;
                        return true;
                    }
                }
                else
                {
                    memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len  , p_parse_value->buf,p_parse_value->len);
                    p_parse_value->gzip_len += p_parse_value->len;
                    p_webmail_session -> state = server_data_continue;
                    p_session->send_len = 0;
                    p_session->p_send_buf = NO_NULL;
                    return true;
                }
            }
            else
            {
                memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len  , p_parse_value->buf,p_parse_value->len);
                p_parse_value->gzip_len += p_parse_value->len ;
                p_webmail_session -> had_send_len = p_parse_value->gzip_len;
                p_parse_value->parse_tmp_len  = p_parse_value->gzip_len;
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;

                //p_webmail_session -> state = client_data_continue;
                //p_session->send_len = p_parse_value->len ;
                return true;
            }
        }
        else
        { // 非压缩模式
            if(p_parse_value->value_map["response_head_key_Transfer-Encoding"] == "chunked")
            {
                //
                if(p_parse_value ->gzip_buffer == NULL) 
                {
                    p_parse_value ->gzip_buffer = new char[655350];
                    p_parse_value->gzip_len = 0;
                }
                char *buffer = p_parse_value ->gzip_buffer;
                int ioffise = 0 ;
                int ibuf_offist = 0 ;
                p_session->send_len = 0;
                while( p_parse_value->len > ibuf_offist) 
                {
                    if(p_parse_value->parse_tmp_len  == 0)
                    {
                        char * mid = strstr(p_parse_value->buf + ibuf_offist , "\r\n");
                        if(mid == NULL)
                            return true;
                        int len = strtol(p_parse_value->buf + ibuf_offist , &mid, 16);
                        //if(len > 1024*1024*100)
                        //   return true;
                        if(len == 0)
                        {
                            p_webmail_session ->b_end_send = true;
                            if(p_session -> send_len == 0 && ioffise == 0) 
                            {
                                p_session->p_send_buf = NO_NULL ;
                                p_session->send_len = 1;
                            }
                            else 
                            {
                                p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                                p_session -> send_len = ioffise;
                            }
                            return true;
                        }
                        p_parse_value->parse_tmp_len = 0;
                        //printf("len == %d\n",len);
                        mid += 2;
                        ibuf_offist = mid - p_parse_value->buf ;
                        if(p_parse_value->len  - ibuf_offist > len ) 
                        {
                            memcpy(buffer + ioffise, p_parse_value->buf + ibuf_offist ,len);
                            ibuf_offist +=2 ;
                            ioffise+= len ;
                            ibuf_offist += len ;
                            p_webmail_session ->tmp_len = 0;
                            p_parse_value->parse_tmp_len  = 0 ;
                        }
                        else { 
                            memcpy(buffer + ioffise, p_parse_value->buf + ibuf_offist ,p_parse_value -> len - ibuf_offist );
                            ioffise += p_parse_value -> len - ibuf_offist  ;
                            p_webmail_session ->response_length = len ; 

                            p_webmail_session -> state = server_data_continue;
                            p_webmail_session ->tmp_len =p_parse_value -> len - ibuf_offist ; //ioffise ; //len - (p_parse_value->len   - ibuf_offist);
                            p_parse_value->parse_tmp_len = p_webmail_session ->tmp_len  ;



                            p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                            p_session -> send_len = ioffise;
                            p_webmail_session ->b_end_send = false;
                            return true;
                        }
                    }
                    else
                    {
                        //if(p_parse_value ->offise <= p_parse_value->len)
                        if(p_webmail_session ->response_length - p_parse_value->parse_tmp_len  <  p_parse_value->len)
                        {
                            int len = p_webmail_session ->response_length - p_parse_value ->parse_tmp_len  ;
                            p_webmail_session ->tmp_len  = 0;
                            p_parse_value->parse_tmp_len = 0;
                            memcpy(buffer + ioffise , p_parse_value->buf + ibuf_offist , len );
                            ibuf_offist += len ;
                            ibuf_offist +=2 ;
                            ioffise += len  ;
                            p_webmail_session ->b_end_send = false;
                            p_webmail_session -> state = server_data_continue;
                            p_webmail_session ->response_length  = 0;
                        }
                        else
                        {
                            //int len = p_webmail_session ->response_length - p_parse_value->parse_tmp_len  ;
                            memcpy(buffer + ioffise, p_parse_value->buf + ibuf_offist ,p_parse_value -> len - ibuf_offist );
                            //ibuf_offist +=2 ;

                            ioffise += p_parse_value -> len - ibuf_offist  ;

                            p_webmail_session ->tmp_len = p_parse_value -> len - ibuf_offist ;//len - (p_parse_value->len   - ibuf_offist);
                            p_parse_value->parse_tmp_len += p_webmail_session ->tmp_len ; //p_webmail_session ->tmp_len ;// len - (p_parse_value->len   - ibuf_offist); 

                            p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                            p_session -> send_len = ioffise;
                            p_webmail_session ->b_end_send = false;
                            p_webmail_session -> state = server_data_continue;
                            return true;
                        }
                    }
                }
                if(ioffise == 0) 
                {
                    if(p_webmail_session ->b_end_send == true) 
                    {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 1;
                    }
                    else {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 0;
                    }
                }
                else 
                {
                    p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                    p_session -> send_len = ioffise;
                }

                return true;
            }

            else
            {
                p_session->p_send_buf = p_parse_value->buf;
                if(p_webmail_session ->response_length >0)
                {
                    p_session->send_len = p_parse_value->len ;
                    p_webmail_session ->response_length = p_parse_value->len;
                    if(p_webmail_session ->response_length  <= 0 )
                        p_webmail_session ->b_end_send = true;
                }
                else 
                {
                    p_session->send_len = p_parse_value->len ;
                    return true;
                }
            }
        }

        if(p_webmail_session ->b_end_send ) 
        {
            if(p_session->send_len == 0 || p_session->p_send_buf == NULL)
            {
                p_session->send_len = 1;
                p_session->p_send_buf = NO_NULL;
            }
            return true;
        }

    }
    /* 
       if(b_clearbuf ) ; 
       {
       p_session->send_len =  0;
       p_session->p_send_buf = NO_NULL;
       }*/
    return true;
}

bool webmail163_parse::requst_handle_163_acc(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 附件类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    //  包长度 
    // 文件 长度 
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_webmail_session -> state == client_data)
    {
        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);
        p_parse_value->len = p_parse_value->len - (p_requst->parsepos - p_parse_value->buf);
        p_parse_value->buf = p_requst->parsepos ;
        p_parse_value->acc_file_length = 0;
        c_http_str * p = find_key_value(p_requst ->HttpHeaderKeyNameValue,"Mail-Upload-size");
        if(p != NULL)
        {
            string tmp(p->buf_begin,0,p->space_use_len);
            p_parse_value->acc_file_length = atoi(tmp.c_str());
        }
        else 
        {
            //return false;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            return false;
        }
        //文件偏移
        p_parse_value->offise = 0;
        p = find_key_value(p_requst ->HttpHeaderKeyNameValue,"Mail-Upload-offset");
        if(p != NULL)
        {
            string tmp(p->buf_begin,0,p->space_use_len);
            p_parse_value->offise=atoi(tmp.c_str());
        }
        else 
        {
            //return false;
            p_parse_value->offise = 0;
        }
        int context_length  =  0; 
        p = find_key_value(p_requst ->HttpHeaderKeyNameValue,"Content-Length");
        if(p != NULL)
        {
            string tmp(p->buf_begin,0,p->space_use_len);
            context_length=atoi(tmp.c_str());
        }

        //文件名
        p_parse_value->file_name = "";
        p = find_key_value(p_requst ->HttpHeaderKeyNameValue,"Mail-Upload-name");
        if(p != NULL)
        {
            char * buffer = new char[p->space_use_len+16];
            if(buffer == NULL)
                return true;
            int len = p->space_use_len +16;
            len = UrlDecode(p->buf_begin, p->space_use_len, buffer, len);
            string tmp(buffer, 0, len-1);
            p_parse_value->file_name = tmp;

            p_parse_value->value_map.insert(pair<string,string>("requset_head_Mail-Upload-name", tmp));
            delete []buffer;
            buffer = NULL;
        }
        else 
        {
            return false;
        }
        if(  p_webmail_session ->requset_length <  p_parse_value->acc_file_length ) 
        {
            p_parse_value -> courze_len  = p_webmail_session ->requset_length  ;
            p_parse_value -> had_courze_len = 0 ;
            p_webmail_session ->requset_length = p_parse_value->acc_file_length ;
        }
        //  本次包发送完毕     
        if(p_parse_value->len  >= p_webmail_session ->requset_length)
        {
            // 文件结束
            if((p_parse_value->offise  + p_webmail_session->had_send_len  >=  p_webmail_session ->requset_length  ) ||
                    (p_parse_value->offise  +context_length >= p_webmail_session ->requset_length  ) )
            {
                p_webmail_session -> state = server_data;
                p_webmail_session-> b_end_send = true;
            }
            else 
            {
                // 还有新的数据过来 a
                p_webmail_session ->b_add_end = true;
                p_webmail_session->had_send_len = 0;
                p_webmail_session -> state = client_data; 
                p_webmail_session-> b_end_send = false;
            }
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
            p_webmail_session->had_send_len += p_parse_value->len;
            p_parse_value -> had_courze_len += p_parse_value -> len ;
            // 写文件，
        }
        else {
            //开始新的
            p_webmail_session -> state = client_data_continue;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
            p_webmail_session-> b_end_send = false;
            p_webmail_session ->b_add_end = true;
            p_webmail_session->had_send_len += p_session->send_len;
            p_parse_value -> had_courze_len += p_parse_value -> len ;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->len == 0)
        {
            if(p_webmail_session -> b_end_send)
            {
                p_session->p_send_buf = NO_NULL;
                p_session->send_len = 1;
            }
            return true;
        }
        //if(p_webmail_session->had_send_len + p_parse_value->len >= p_webmail_session ->requset_length)
        if(p_parse_value->len +  p_webmail_session->had_send_len  >= p_webmail_session ->requset_length)
        {
            if(p_webmail_session->len  + MAXPACKETLEN < MAXTCPBUF)
            {
                //if(p_parse_value->offise  +p_webmail_session ->requset_length == p_parse_value->acc_file_length )
                if(p_parse_value->offise+p_webmail_session->had_send_len+p_parse_value->len >= p_webmail_session ->requset_length )
                {
                    p_webmail_session -> state = server_data;
                    p_webmail_session-> b_end_send = true;
                }
                else
                {
                    // 还有新的数据过来 a
                    p_webmail_session -> state = client_data; 
                    p_webmail_session-> b_end_send = false;
                }
            }
            p_webmail_session->had_send_len += p_parse_value->len;
            p_parse_value -> had_courze_len += p_parse_value -> len ;
            p_session->p_send_buf = p_parse_value->buf ;
            p_session->send_len = p_parse_value->len;
            if(p_webmail_session->had_send_len >= p_webmail_session ->requset_length  ) 
            {
                p_webmail_session -> state = server_data;
                p_webmail_session-> b_end_send = true;
            }
        }
        else
        {
            p_webmail_session->had_send_len += p_parse_value->len;
            p_parse_value -> had_courze_len += p_parse_value -> len ;
            if( p_parse_value -> had_courze_len ==  p_parse_value -> courze_len )
            {
                // 头还有 ,继续
                p_webmail_session -> state = client_data ;
                p_parse_value -> had_courze_len = 0;
            }
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
            if(p_webmail_session->had_send_len >= p_webmail_session ->requset_length ) 
            {
                p_webmail_session -> state = server_data;
                p_webmail_session-> b_end_send = true;
            }
        }
    }

    return true;
    // CCID 

}


//取包的长度
bool http_r_context_length_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    //查找http 头中的 context_length 字段 
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    c_http_str * p = find_key_value(p_requst ->HttpHeaderKeyNameValue,"Content-Length");
    if(p != NULL)
    {
        string tmp(p->buf_begin,0,p->space_use_len);
        p_webmail_session ->requset_length = atoi(tmp.c_str());
        return true;
    }
    else 
    {
        p_webmail_session ->requset_length = 0;
        return false;
    }

}
bool http_s_http_handle_key(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    //查找http 头中的 context_length 字段 
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";
    node_value_list::iterator iter = v_list.begin();
    c_http_str * p = NULL;
    for(;iter != v_list.end();iter ++)
    {
        p = find_key_value(p_response ->HttpHeaderKeyNameValue,iter->c_str());
        if(p!= NULL)
        {
            name = "response_head_key_";
            name += *iter;
            string svalue(p->buf_begin,0,p->space_use_len);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        }
    }
    return true;
}

static void request_method_uri_insert_into_map(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string name ("requset_head_key_Method");
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string svalue("");
    switch( p_requst->HttpMothed)
    {
        case GET:
            {
                svalue ="GET ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case POST:
            {
                svalue = "POST ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case OPTIONS:
            {
                svalue = "OPTIONS ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case  HEAD_M:
            {
                svalue = "HEAD ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case PUT:
            {
                svalue = "PUT ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case DELETE:
            {
                svalue = "DELETE ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case TRACE:
            {
                svalue = "TRACE ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case CONNECT:
            {
                svalue = "CONNECT ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        case METHODERROR:
            {
                svalue = "METHODERROR ";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                break;
            }
        default:
            {
                svalue = "";
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            }
    }
    //在webmail_plugin.cpp的url_wait状态下提取了urlparam这一完整的url填入到valu_map中，且key为requset_head_key_Url,————————by任泽众
    //name ="requset_head_key_Uri";
    //string uri(p_requst->Uri.buf_begin, 0, p_requst->Uri.space_use_len );
    //p_parse_value->value_map.insert(pair<string,string>(name,uri));
    //string url = svalue + uri;
    //name ="requset_head_key_Url";
    //p_parse_value->value_map.insert(pair<string,string>(name,url));
    name = "public_info";
    string info ="1";
    p_parse_value->value_map.insert(pair<string,string>(name,info));
}



bool http_r_http_handle_key(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    //查找http 头中的 context_length 字段 
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    request_method_uri_insert_into_map(p_session, p_webmail_session, p_requst, p_response, v_list);
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";
    node_value_list::iterator iter = v_list.begin();
    c_http_str * p = NULL;
    for(;iter != v_list.end();iter ++)
    {
        p = find_key_value(p_requst ->HttpHeaderKeyNameValue,iter->c_str());
        if(p!= NULL)
        {
            name = "requset_head_key_";
            name += *iter;
            string svalue(p->buf_begin,0,p->space_use_len);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        }
    }
    return true;
}
//取包的长度
bool http_s_context_length_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    //查找http 头中的 context_length 字段 
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    c_http_str * p = find_key_value(p_response ->HttpHeaderKeyNameValue,"Content-Length");
    if(p != NULL)
    {
        string tmp(p->buf_begin,0,p->space_use_len);
        p_webmail_session ->response_length= atoi(tmp.c_str());
        return true;
    }
    else 
    {
        p_webmail_session ->response_length = 0;
        return true;
    }
}
bool http_r_urlparam_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    http_urlparam_analyzer url_param;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";
    c_http_str * p = &(p_requst->UriParam);
    //char * p_end = p->buf_begin +p->space_use_len;
    s_key_value * phead =NULL;
    url_param.ParamAnakyses(p,phead);
    node_value_list::iterator iter = v_list.begin();
    // 把所有的需要记录的数据放入 map中
    for(;iter!=v_list.end();iter ++)
    {

        c_http_str * p_value = find_key_value(phead,iter->c_str());
        if(p_value != NULL )
        {
            name = "requset_urlparam_";
            name += *iter;
            string svalue ("");
            if(p_value->buf_begin != NULL)
            {
                if(p_value->space_use_len < 0 || p_value->space_use_len > 10240000)
                {
                    continue;
                }

                if(p_value->space_use_len > (p_parse_value -> value_map["requset_head_key_Url"]).length() )
                {
                    continue;
                }

                string str_tmp(p_value->buf_begin,p_value->space_use_len);
                svalue = str_tmp;
            }
            string goods("") ;
            goods = urldecode(svalue);
            p_parse_value->value_map.insert(pair<string,string>(name,goods));
        }

    }
    //
    s_key_value_free(phead);
    return true;
}


bool http_r_post_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->HttpMothed != POST) return true;
    if( p_parse_value -> len <  p_webmail_session ->requset_length) {
        p_webmail_session -> state = client_data;
        return false;
    }
    http_post_analyzer url_post;
    string name = "";
    c_http_str  m_str ;
    m_str.buf_begin = p_parse_value -> buf;
    m_str.space_use_len = p_parse_value -> len;
    char * p_end = m_str.buf_begin +m_str.space_use_len;
    s_key_value * phead =NULL;
    url_post.post_text_analyzer(&m_str,p_end,phead);
    node_value_list::iterator iter = v_list.begin();
    // 把所有的需要记录的数据放入 map中
    for(;iter!=v_list.end();iter ++)
    {

        c_http_str * p_value = find_key_value(phead,iter->c_str());
        if(p_value != NULL)
        {
            name = "requset_post_";
            name += *iter;
            string svalue(p_value->buf_begin,0,p_value->space_use_len);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }

    }
    s_key_value_free(phead);
    p_webmail_session -> state = server_data;
    return true;
}

bool no_requst_burs(session * p_session, c_packet * p_packet) // 请求端数据不需要处理  直接返回 
{
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    if(len == 0) return false;
    if(p_webmail_session ->b_c2s )
    {
        if(p_webmail_session -> state == client_data)
        {
            p_webmail_session -> state = server_data_continue_last ;
        }
        p_session->client.add_tcp_packet(len,p_data,seq);
    }
    else {
        if(p_webmail_session -> state  == client_data || p_webmail_session -> state  == client_data_continue )
            p_webmail_session -> state = server_data ;
        p_session->server.add_tcp_packet(len,p_data,seq);
    }
    return true;
}
bool no_burs(session * p_session, c_packet * p_packet) // 服务端数据不需要处理  直接返回 
{
    return false;
}

// 
// 适用 xml 1.2 版本以上的
bool http_xml_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 
    char * buffer = new char[p_parse_value->len+16];
    if(buffer == NULL)
        return true;

    int len = p_parse_value->len +16;
    len = UrlDecode(p_parse_value->buf , p_parse_value->len  ,buffer,len);
    //uint32_t i = 0;
    char * p  = strchr(buffer +1 ,'<');
    if(p != NULL &&  p - buffer  > p_parse_value->len )
    {
        delete [] buffer;
        buffer = NULL;
        return true;
    }

    TiXmlDocument *p_xmldoc = new TiXmlDocument();
    TiXmlNode * p_node = NULL;
    if(p_xmldoc == NULL) 
    {
        delete [] buffer;
        buffer = NULL;
        return false;
    }
    if(p_xmldoc->Parse(p,0,TIXML_DEFAULT_ENCODING))
    {
        delete [] buffer;
        buffer = NULL;
        delete p_xmldoc;
        p_xmldoc = NULL;
        return false;
    }
    TiXmlElement *root = p_xmldoc->RootElement();
    string tmp = "";
    string xpath = "";

    //char * p_value;
    string s_value = "";
    string name = "";
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        tmp = *iter;
        p_node = get_path_node(root,(char *)iter->c_str());
        if(p_node != NULL)
        {
            dumpTextNode(p_node , 0,s_value); 
            // printf("%s\n",s_value.c_str());
        }
        //  
    }
    delete p_xmldoc;
    p_xmldoc = NULL;
    delete [] buffer ;
    buffer = NULL;
    return false;
    //解析mem xml 数据 
    //p_parse_value->buf
    //p_parse_value->len
}

bool webmail163_parse::identity_burs_request(session * p_session, c_packet * p_packet)
{
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    p_session->packet_len += p_packet->app_data_len ;//p_packet->buff_len;
    //p_session->packet_num++;

    if(p_session->packet_begin_time == 0)
    {
        p_session->packet_begin_time = p_packet->m_timeval;
        p_session->packet_end_time = p_packet->m_timeval;
    }
    if(p_session->packet_end_time != 0)
    {
        p_session->packet_end_time = p_packet->m_timeval;
    }

    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s == false)
    {
        p_session->packet_num++;
        return true;
    }

    if(p_webmail_session -> state == client_data) //是第一个包
    {
        p_session->client.add_tcp_packet(len,p_data,seq);//将包存放到缓存中
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);//从缓存中取出数据
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;//将数据最后一位置为空
        }
        else {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据 ，这里认为找到回车换行就是头接收完毕 
        {
            p_session->packet_num++;
            return true; 
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )//超出最大接收量
        {
            p_session->packet_num++;
            return true;
        }
    }
    else if  (p_webmail_session -> state == client_data_continue)
    {
        p_session->client.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len >=p_webmail_session ->requset_length)
        {
            p_session->packet_num++;
            return true;
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            p_session->packet_num++;
            //正文超长
            p_webmail_session ->requset_length -= p_webmail_session->len;
            return true;
        }
    }
    return false;
}
// wangchenxi 添加的组包函数  有待进一步调整
bool webmail163_parse::burs_accumulate_head_body(session * p_session, c_packet * p_packet)
{

    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s == false)
    {
        return true;
    }

    if(p_webmail_session -> state == client_data) //是第一个包
    {
        p_session->client.add_tcp_packet(len,p_data,seq);//将包存放到缓存中
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);//从缓存中取出数据
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;//将数据最后一位置为空
        }
        else {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据 ，这里认为找到回车换行就是头接收完毕 
        {
            char* p_Content_Length = strstr((char*)p_webmail_session->p_data, "Content-Length:");
            if( p_Content_Length == NULL)
            {
                return false;
            }
            p_Content_Length +=15;
            char* p_tmp = strstr(p_Content_Length, "\r\n");
            if( p_tmp == NULL)
            {
                return false;
            }
            string str_length(p_Content_Length, p_tmp - p_Content_Length);
            uint32_t int_length = atoi(str_length.c_str());
            p_webmail_session->requset_length = int_length;
            char* p_body_start = p_end + 4;
            int already_body_len = p_webmail_session->len - (p_body_start - ((char*)p_webmail_session->p_data));
            if(already_body_len < int_length)
            {
                return false;
            }
            //p_webmail_session->http_head_length = p_end - (char *)p_webmail_session->p_data + 4;
            return true; 
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )//超出最大接收量
        {
            return true;
        }
    }
    else if  (p_webmail_session -> state == client_data_continue)
    {
        p_session->client.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->client.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len >=p_webmail_session ->requset_length)
        {
            // 文件结束 
            p_webmail_session ->requset_length = 0;

            return true;
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            //正文超长
            p_webmail_session ->requset_length -= p_webmail_session->len;
            return true;
        }
    }
    return false;
}

bool webmail163_parse::finish_right_now(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string name ("action_statistics");
    string value("1");
    p_parse_value->value_map.insert(pair<string,string>(name, value));
    node_value_list::iterator iter_key = v_list.begin();
    name = "direction_type";
    value = iter_key->c_str();
    p_parse_value->value_map.insert(pair<string,string>(name, value));
    p_webmail_session -> b_end_send = true;
    p_session -> p_send_buf = NO_NULL;
    p_session -> send_len = 1; 
    return true;
}

//add by zq
bool webmail163_parse::c2s_finish_or_continue(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    if(p_parse_value->value_map.find(v_list.begin()->c_str()) == p_parse_value->value_map.end())
        return true;

    string name ("action_statistics");
    string value("1");
    p_parse_value->value_map.insert(pair<string,string>(name, value));
    name = "direction_type";
    value = "1";
    p_parse_value->value_map.insert(pair<string,string>(name, value));
    p_webmail_session -> b_end_send = true;
    p_session -> p_send_buf = NO_NULL;
    p_session -> send_len = 1;
    return true;
}

/* what added by wangchenxi 
   data 2015-12-28
   */
// 提取一项内容，并将给内容压入表中
bool get_option_and_push_to_map(session* p_session,
        webmail_session* p_webmail_session,
        string& svalue,
        const char* start_sign,
        string& add_name,
        const char* start,
        const char* end_sign,
        int  to_start,
        int to_end,
        const char* start_sign_1 ,
        const char* end_sign_1 ,
        int to_s_1 ,
        int to_e_1 )
{
    string name = start_sign;
    if(!get_string_from_http_buffer(svalue, start, start_sign, end_sign, to_start, to_end))
    {
        if(start_sign_1 == NULL)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        if(!get_string_from_http_buffer(svalue, start, start_sign_1, end_sign_1, to_s_1,to_e_1))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
    }
    name += add_name ;
    p_webmail_session->p_parse_value->value_map.insert(pair<string,string>(name, svalue));
    return true;
}

// 找到r_requst链表的最后一个节点，进而确定请求体开始地址
s_key_value* get_body_start(s_http_request* p_requst)
{
    if( p_requst == NULL)
    {
        return NULL;
    }
    s_key_value* p_tmp = p_requst->HttpHeaderKeyNameValue;
    while( p_tmp->link != NULL)
    {
        p_tmp = p_tmp->link;
    }
    return p_tmp;
}
// 从请求体中提取内容  第三种形式
// 王晨曦添加
bool webmail163_parse::get_info_from_request_body_form3(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0,max_size = p_webmail_session -> requset_length;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";

    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(p_body_start == NULL)
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    int already_body_len = buf_len - (p_body_start - p_buf);
    if(max_size > 65535)
    {
        max_size = 65535;
    }
    if (already_body_len >=  max_size)
    {
        node_value_list::iterator iter_key = v_list.begin();
        for(;iter_key != v_list.end(); iter_key++)
        {
            string name = iter_key->c_str();
            get_string_from_http_buffer(svalue, p_body_start, name.c_str(), "\"", 3 + name.size(), 0);
            if(svalue.size() == 0)
                continue;
            name = "get_info_from_request_body_form3_" + name;
            svalue = urldecode(svalue);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            svalue = "";
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}

// 从请求体中提取内容  第二种形式
// 王晨曦添加
bool webmail163_parse::get_info_from_request_body_form2(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0,max_size = p_webmail_session -> requset_length;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";
    int  have_deal_len = 0;
    int  no_useful_len = 0;
    string key_words("");

    string str_sign_tmp("; name=");
    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(NULL == p_body_start ||0 == *p_body_start )
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    char* p_deal_start = p_body_start;
    int already_body_len = buf_len - (p_body_start - p_buf);
    if(max_size > 65535)
    {
        max_size = 65535;
    }
    if (already_body_len >=  max_size)
    {
        node_value_list::iterator iter_key = v_list.begin();
        while(1)
        {
            if(!get_string_from_http_buffer(key_words, p_deal_start, str_sign_tmp.c_str(), "\r\n\r\n", str_sign_tmp.size(), 0, &have_deal_len, &no_useful_len))break;
            p_deal_start += no_useful_len;
            if((p_deal_start  - p_body_start) >= already_body_len)break;
            get_string_from_http_buffer(svalue, p_deal_start, key_words.c_str(), "\r\n------", 4 + key_words.size(), 0, &have_deal_len, NULL);
            p_deal_start += have_deal_len;
            if((p_deal_start  - p_body_start) >= already_body_len)break;
            if(svalue.size() == 0)
                continue;
            key_words = "get_info_from_request_body_form2_" + key_words;
            if(svalue[0] == '\n' && svalue.size() > 1)//任泽众修改，考虑首字节是\n的情况。
            {
                string str_tmp(svalue, 1, svalue.size() - 1);
                svalue.assign(urldecode(str_tmp));
                p_parse_value->value_map.insert(pair<string,string>(key_words,svalue));
            }
            else
            {
                svalue = urldecode(svalue);
                p_parse_value->value_map.insert(pair<string,string>(key_words,svalue));
                svalue = "";
            }
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}


// 从请求体中提取内容
// 王晨曦添加
bool webmail163_parse::get_info_from_request_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";

    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(p_body_start == NULL)
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    int already_body_len = buf_len - (p_body_start - p_buf);
    if (already_body_len >=  p_webmail_session ->requset_length)
    {
        node_value_list::iterator iter_key = v_list.begin();
        for(;iter_key != v_list.end(); iter_key++)
        {
            string name = iter_key->c_str();
            get_string_from_http_buffer(svalue, p_body_start, name.c_str(), "&", name.size(), 0);
            name = "get_info_from_request_body_" + name;
            svalue = urldecode(svalue);
            if(svalue.size() == 0)
                continue;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            svalue = "";
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}


// 从cookie中提取二次urldecode数据
// 王晨曦添加
bool webmail163_parse::get_sina_cookie_info_request(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    string svalue = "";
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("requset_head_key_Cookie");
    if(iter == p_webmail_session->p_parse_value->value_map.end())
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NO_NULL;
        return false;
    }
    string src_str = iter->second;
    for(;iter_key != v_list.end(); iter_key++)
    {
        string name = iter_key->c_str();
        get_string_from_http_buffer(svalue, src_str.c_str(), name.c_str(), "%26", name.size(), 0);
        name = "urldecode_cookie_" + name;
        svalue = urldecode(svalue);
        svalue = urldecode(svalue);
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

    }
    return true;
}

//转码函数
bool webmail163_parse::gbk_to_utf(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    for(;iter_key != v_list.end();iter_key++)
    {
        parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
        if(iter != p_parse_value->value_map.end())
        {
            string map_value (iter->second);
            int dst_size = 4 * map_value.size();
            char* c_dst = new char[dst_size +1];
            if(c_dst == NULL)
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
            memset(c_dst, 0, dst_size + 1);
            char* c_src = const_cast<char*>(map_value.c_str());
            g2u(c_src, map_value.size(), c_dst, dst_size);
            if( dst_size < 0)
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                delete [] c_dst;
                c_dst = NULL;
                return false;
            }
            string svalue (c_dst);
            delete [] c_dst;
            c_dst = NULL;
            string name (iter_key->c_str());
            name = "utf_8_" + name;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    return true;
}

//url解码
bool webmail163_parse::urldecode_config(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    for(;iter_key != v_list.end();iter_key++)
    {
        parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
        if(iter != p_parse_value->value_map.end())
        {
            string map_value (iter->second);
            string svalue = urldecode(map_value);
            string name (iter_key->c_str());
            name = "urldecode_config_" + name;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    return true;
}


//从标志到标签转换
bool webmail163_parse::from_sign_to_real_mean(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
    if(iter != p_parse_value->value_map.end())
    {
        string map_value (iter->second);
        string str_tmp_str(iter->second);
        iter_key++;
        string str_buff (iter_key->c_str());
        map_value = ";" + map_value + "=";
        string aim_str("");
        if(!get_string_from_http_buffer(aim_str, str_buff.c_str(), map_value.c_str(), ";", map_value.size(), 0))
        {
            aim_str ="未覆盖板块，关联关键词为："+ str_tmp_str;
        }
        iter_key--;
        string name (iter_key->c_str());
        name = "from_sign_to_real_mean_" + name;
        p_parse_value->value_map.insert(pair<string,string>(name,aim_str));
    }
    return true;
}


//从URL中提取数据,可以从完整URL中获取数据,只需要配置的时候给其开始标志位以及结束标志位其以+分割
bool webmail163_parse::get_info_url(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if (p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    if (p_parse_value == NULL)
    {
        return true;
    }
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("requset_head_key_Url");
    if (iter != p_webmail_session->p_parse_value->value_map.end())
    {
        uint32_t len = iter->second.size();
        node_value_list::iterator iter_key = v_list.begin();
        for (; iter_key!=v_list.end(); ++iter_key)
        {
            string str_end = "&";
            string str_begin = "";
            string::size_type cur = (*iter_key).find("+");
            if (cur != string::npos)
            {
                str_begin = (*iter_key).substr(0, cur);
                str_end = (*iter_key).substr(cur+1);
            }
            else
            {
                str_begin = *iter_key;
            }
            int leng = str_begin.size();
            cur = iter->second.find(str_begin);
            if (cur != string::npos && cur < len && cur>0)
            {
                string::size_type now = iter->second.find(str_end, cur+leng);
                if (now != string::npos && now<len && now > 0)
                {
                    string name = "url_second_";
                    name += str_begin;
                    string svalue = iter->second.substr(cur+leng, now-cur-leng);
                    string goods = urldecode(svalue);
                    p_parse_value->value_map.insert(pair<string,string>(name, goods));
                }
                else
                {
                    string name = "url_second_";
                    name += str_begin;
                    string svalue = iter->second.substr(cur+leng);
                    string goods = urldecode(svalue);
                    p_parse_value->value_map.insert(pair<string,string>(name, goods));
                }
            }
            else
            {
                continue;
            }
        }
    }
    return true;
}


// 从请求体中提取内容
//add xiaojun
//自动设置请求体开始位置和结束位置，获取其中的数据，循环获取从请求体一直向后提取不是每次从头开始
bool webmail163_parse::get_info_request_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";

    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(p_body_start == NULL)
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    int already_body_len = buf_len - (p_body_start - p_buf);
    if (already_body_len >=  p_webmail_session ->requset_length)
    {
        int flag = 1;
        const char* p_begin = NULL;
        const char* p_end = NULL;
        p_end = p_body_start;
        node_value_list::iterator iter_key = v_list.begin();
        for(;iter_key != v_list.end(); iter_key++)
        {
            string str_begin = "";
            string str_end = "";
            string::size_type cur;
            cur = (*iter_key).find("-");
            if (cur == string::npos)
            {
                return true;
            }
            str_begin = (*iter_key).substr(0, cur);
            str_end = (*iter_key).substr(cur+1);
            int len = str_begin.size();
            p_begin = strstr(p_end, str_begin.c_str());
            if (p_begin == NULL)
            {
                return true;
            }
            get_string_from_http_buffer(svalue, p_begin, str_begin.c_str(), str_end.c_str(), str_begin.size(), 0);
            p_end = strstr(p_begin+len, str_end.c_str());
            if (p_end == NULL)
            {
                return true;
            }
            std::stringstream ss;
            ss << flag;
            string str_flag = std::string(ss.str());
            ss.clear();
            string name = "get_info_request_body_";
            name += str_begin;
            name += str_flag;
            svalue = urldecode(svalue);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            svalue = "";
            ++flag;
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}

//add by maxiaojun
//该函数主要用于处理形式和XML格式一样的请求体数据其关键字为你要搜索的关键字-开始标志位-结束标志位 放入映射表中的名字位get_info_request_body_搜索关键字，如果只写了搜索关键字其会默认开始标志位位>结束标志位为<,其数据为><之间的数据
bool webmail163_parse::get_info_request_body1(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";

    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(p_body_start == NULL)
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    int already_body_len = buf_len - (p_body_start - p_buf);
    if (already_body_len >=  p_webmail_session ->requset_length)
    {
        const char* p_begin = NULL;
        const char* p_flag = NULL;
        node_value_list::iterator iter_key = v_list.begin();
        for(;iter_key != v_list.end(); iter_key++)
        {
            string str_flag = "";
            string str_name = "<";
            string str_begin = ">";
            string str_end = "<";
            string::size_type cur, now;
            cur = (*iter_key).find("-");
            if (cur != string::npos)
            {
                str_flag = (*iter_key).substr(0, cur);
                now = (*iter_key).find("-", cur+1);
                if (cur == string::npos)
                {
                    continue;
                }
                str_begin = (*iter_key).substr(cur+1, now-cur-1);
                str_end = (*iter_key).substr(now+1);
            }
            else
            {
                str_flag = *iter_key;
            }
            str_name += str_flag;
            p_flag = strstr(p_body_start, str_name.c_str());
            if (p_flag == NULL)
            {
                continue;
            }
            int len = str_name.size();
            p_begin = strstr(p_flag+len, str_begin.c_str());
            if (p_begin == NULL)
            {
                continue;
            }
            get_string_from_http_buffer(svalue, p_begin, str_begin.c_str(), str_end.c_str(), str_begin.size(), 0);
            if (svalue.size() != 0)
            {
                string name = "get_info_request_body_";
                name += str_flag;
                svalue = urldecode(svalue);
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            }
            svalue = "";
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}

// 从请求体中提取内容 通用解析有待进一步完善 
// 王晨曦添加
bool webmail163_parse::get_info_from_request_body_common(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0,max_size = p_webmail_session -> requset_length;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    string svalue = "";

    string name = "";

    s_key_value* p_s_key_value = get_body_start(p_requst);
    char* p_body_start = p_s_key_value->value.buf_begin + p_s_key_value->value.space_use_len + 4;
    if(p_body_start == NULL)
    {
        p_webmail_session -> state == client_data_continue;
        return false;
    }
    int already_body_len = buf_len - (p_body_start - p_buf);
    if(max_size > 65535)
    {
        max_size = 65535;
    }
    if (already_body_len >=  max_size)
    {
        node_value_list::iterator iter_key = v_list.begin();
        int end_sign_to_name = atoi(iter_key->c_str());
        iter_key++;
        int start_sign_to_name = atoi(iter_key->c_str());
        iter_key++;
        string start_sign = iter_key->c_str();
        iter_key++;
        int start_sign_to_value = atoi(iter_key->c_str());
        iter_key++;
        string end_sign = iter_key->c_str();
        iter_key++;
        int end_sign_to_value = atoi(iter_key->c_str());
        char c_arr[2];
        c_arr[1] =  0;
        c_arr[0] =  *p_body_start;
        string name = "";
        string add_sign = "common_get_info_from_body_";
        get_string_from_http_buffer(svalue, p_body_start, c_arr, start_sign.c_str(),  0, start_sign_to_name);
        name = add_sign + svalue;
        int deal_length = name.size() + start_sign_to_name;
        char* deal_start = p_body_start + deal_length;
        int i =  100;
        while(i != 0)
        {
            --i;
            get_string_from_http_buffer(svalue, deal_start, start_sign.c_str(), end_sign.c_str(), start_sign_to_value + start_sign.size(), end_sign_to_value);
            deal_length = deal_length + + start_sign.size() + start_sign_to_value + svalue.size() + end_sign_to_value;
            deal_start = p_body_start + deal_length;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            if(deal_length >= max_size)break;
            svalue = "";
            name = "";
            get_string_from_http_buffer(svalue, p_body_start, end_sign.c_str(), start_sign.c_str(),  end_sign.size() + end_sign_to_name, start_sign_to_name);
            name = add_sign + svalue;
            deal_length = deal_length +  end_sign.size() + end_sign_to_name + name.size() + start_sign_to_name;
            if(deal_length >= max_size)break;
            deal_start = p_body_start + deal_length;
        }
        return true;
    }
    p_webmail_session -> state == client_data_continue;
    return false;
}


//该函数用于处理传进来的时间将其组合成一个新的时间字符串
bool webmail163_parse::get_time(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    if (p_parse_value == NULL)
    {
        return true;
    }
    node_value_list::iterator iter;
    parse_value_map::iterator iter_flag;
    std::stringstream ss;
    if (v_list.size() >= 2)
    {
        iter = v_list.begin();
        string str_time = "";
        string name = *iter;
        for (; iter!=v_list.end(); ++iter)
        {
            iter_flag = p_parse_value->value_map.find(*iter);
            if (iter_flag == p_parse_value->value_map.end())
            {
                return true;
            }
            const char* p_end = NULL;
            const char* p_begin = iter_flag->second.c_str();
            string str;
            if ((p_end = strstr(p_begin, "年")) || (p_end =strstr(p_begin, "月")) || (p_end =strstr(p_begin, "日")))
            {
                str = iter_flag->second.substr(0, p_end-p_begin);
                if (str.size() <= 2)
                {
                    ss<<setfill('0')<<setw(2)<<str;
                    str_time += ss.str();
                    ss.clear();
                    ss.str("");
                }
                else
                {
                    str_time += str;
                }
            }
            else
            {
                str = iter_flag->second;
                if (str.size() <= 2)
                {
                    ss<<setfill('0')<<setw(2)<<str;
                    str_time += ss.str();
                    ss.clear();
                    ss.str("");
                }
                else
                {
                    str_time += str;
                }
            }
        }

        name += "_time";
        p_parse_value->value_map.insert(pair<string, string>(name, str_time));
    }
    else
    {

        iter = v_list.begin();
        iter_flag = p_parse_value->value_map.find(*iter);
        if (iter_flag == p_parse_value->value_map.end())
        {
            return true;
        }
        string str_time = "";
        string name = *iter;
        string::size_type cur, now;
        cur = (iter_flag->second).find("-");
        if (cur == string::npos)
        {
            return true;
        }
        now = (iter_flag->second).find("-", cur+1);
        if (now == string::npos)
        {
            return true;
        }
        ss<<setfill('0')<<setw(4)<<((iter_flag->second).substr(0, cur));
        str_time += ss.str();
        ss.clear();
        ss.str("");
        ss<<setfill('0')<<setw(2)<<((iter_flag->second).substr(cur+1, now-cur-1));
        str_time += ss.str();
        ss.clear();
        ss.str("");
        ss<<setfill('0')<<setw(2)<<((iter_flag->second).substr(now+1));
        str_time += ss.str();
        ss.clear();
        ss.str("");
        name += "_time";
        p_parse_value->value_map.insert(pair<string, string>(name, str_time));
    }

    return true;
}

//该函数用于处理提取出来内容中的\t以及\r\n字符
bool webmail163_parse::replace_table(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    if (p_parse_value == NULL)
    {
        return true;
    }
    node_value_list::iterator iter = v_list.begin();
    for (; iter!= v_list.end(); ++iter)
    {
        parse_value_map::iterator iter_flag = p_parse_value->value_map.find(*iter);
        if (iter_flag == p_parse_value->value_map.end())
        {
            continue;
        }
        string svalue = iter_flag->second;
        replace_all(svalue, "\t", "");
        replace_all(svalue, "\r\n", "");
        string name = "replace_";
        name += *iter;
        p_parse_value->value_map.insert(pair<string, string>(name, svalue));
    }
    return true;
}


// 从cookie中提取数据
// 王晨曦添加
bool webmail163_parse::get_cookie_info_request(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    string svalue = "";
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("requset_head_key_Cookie");
    if(iter == p_webmail_session->p_parse_value->value_map.end())
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NO_NULL;
        return false;
    }
    string src_str = iter->second;
    for(;iter_key != v_list.end(); iter_key++)
    {
        string name = iter_key->c_str();
        get_string_from_http_buffer(svalue, src_str.c_str(), name.c_str(), "&", name.size(), 0);
        name = "from_cookie_" + name;
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));
    }
    return true;
}

// 王晨曦添加
bool webmail163_parse::get_info_from_map_option(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    // 获取获得数据的value_map项
    string svalue = "";
    string map_value ("");
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
    if(iter != p_parse_value->value_map.end())
    {
        map_value = iter->second ;
        // 获取完成搜索所需条件
        iter_key++;//开始关键字
        string keyword_str = iter_key->c_str();
        iter_key++;//结束标志
        string end_sign_str = iter_key->c_str();
        iter_key++;
        int to_start = atoi(iter_key->c_str());
        to_start += keyword_str.size();
        iter_key++;
        int to_end = atoi(iter_key->c_str());
        if(!get_string_from_http_buffer(svalue, map_value.c_str(), keyword_str.c_str(), end_sign_str.c_str(), to_start, to_end))
        {
            svalue = "";
            return true;
        }
        string name = "get_info_from_map_option_" + keyword_str;
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));
    }
    return true;
}
bool webmail163_parse::get_info_from_map_value(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    // 获取获得数据的value_map项
    string svalue = "";
    string map_value ("");
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
    if(iter != p_parse_value->value_map.end())
    {
        map_value = iter->second ;
        // 获取完成搜索所需条件

        iter_key++;//开始关键字
        int i=0;
        string::size_type cur=0;
        string::size_type ssize=0;
        string chr=iter_key->c_str();
        string s;
        while((ssize=map_value.find(chr,cur))!=string::npos)
        {

            ssize=map_value.find(chr,cur);
            string svalue="";
            svalue = map_value.substr(cur,(ssize-cur));
            i++;
            string name = "";
            s = "";
            DNUMTOSTR(i, s);
            name = "get_info_from_map_value_" + s;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));

            s = "" ;
            cur += (ssize-cur+1);
            ssize=0;
        }
        i++;
        if(map_value.size() >= cur )
        {

            string svalue="";
            svalue = map_value.substr(cur,(map_value.size()-cur + 1 ));
            string name = "";
            string s = "";
            DNUMTOSTR(i, s);
            name = "get_info_from_map_value_" + s;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            s = "";
        }



        iter_key ++ ;
        string name1 = "get_info_from_map_value_" + *iter_key ;
        iter = p_parse_value->value_map.find(name1);
        if(iter != p_parse_value->value_map.end())
        { 
            cur = 0;
            int j = 0;
            iter_key ++ ;

            for(;iter_key != v_list.end(); iter_key ++)
            {
                j++;
                s = "" ;
                DNUMTOSTR (j,s);
                string ssvalue="";
                string name = "";
                svalue =  iter->second ;
                if(0 <= cur <= svalue.size())
                { 
                    ssvalue = svalue.substr(cur,atoi(iter_key->c_str()));

                    name = "get_info_from_map_value_sub_" + s;
                    p_parse_value->value_map.insert(pair<string,string>(name,ssvalue));
                    cur += atoi(iter_key->c_str());
                }
            } 
        }

    }
    return true;
}
// 王晨曦添加
bool webmail163_parse::divide_str_option(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    string svalue = "";
    string map_value ("");
    string back_name("");
    string name("");
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // 获取获得数据的value_map项
    node_value_list::iterator iter_key = v_list.begin();
    back_name = iter_key->c_str();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
    if(iter != p_parse_value->value_map.end())
    {
        map_value = iter->second ;
        int flag_num = 0;
        char flag_arry[100];
        memset(flag_arry, 0, 100);
        // 获取完成搜索所需条件
        iter_key++;//开始关键字
        string keyword_str = iter_key->c_str();
        string::size_type begin;
        begin = map_value.find(keyword_str.c_str());
        while(begin != string::npos)
        {
            sprintf(flag_arry, "divide_str_option_%d_", flag_num);
            ++flag_num;
            name = flag_arry + back_name;
            memset(flag_arry, 0, 100);
            svalue = map_value.substr(0, begin);
            map_value = map_value.substr(begin+1);
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            begin = map_value.find(keyword_str.c_str());
        }
        sprintf(flag_arry, "divide_str_option_%d_", flag_num);
        name = flag_arry + back_name;
        p_parse_value->value_map.insert(pair<string,string>(name,map_value));
        memset(flag_arry, 0, 100);
        return true;
    }
    return true;
}
//从根据提取内容，自由设置动作类型换
bool webmail163_parse::set_action_type(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    node_value_list::iterator iter_key = v_list.begin();
    parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find(iter_key->c_str());
    if(iter != p_parse_value->value_map.end())
    {
        string map_value (iter->second);
        string str_tmp_str(iter->second);
        iter_key++;
        string str_buff (iter_key->c_str());
        map_value = ";" + map_value + "=";
        string aim_str("");
        if(!get_string_from_http_buffer(aim_str, str_buff.c_str(), map_value.c_str(), ";", map_value.size(), 0))
        {
            aim_str ="未覆盖新协议，待进一步更新开发，关联关键词为："+ str_tmp_str;
        }
        p_mail_handle->str_action = aim_str;
        /*iter_key--;
          string name (iter_key->c_str());
          name = "from_sign_to_real_mean_" + name;
          p_parse_value->value_map.insert(pair<string,string>(name,aim_str));*/
    }
    return true;
}
