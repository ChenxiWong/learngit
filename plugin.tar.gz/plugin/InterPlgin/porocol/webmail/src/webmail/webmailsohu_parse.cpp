// Last Update:2016-05-27 15:37:12
/**
 * @file webmailsohu_parse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-05-09
 */

// sohu 附件类的组包  靠返回来推出数据 
//
#include "webmailsohu_parse.h"
#include "webmail163_parse.h"
#include "qq_file_http_parse.h"
#include "http_cookie_analyzer.h"
#include "identity.h"
#include <stdio.h>
#include <string.h>
using namespace std;

void init_webmailsohu()
{
    // sohu 附件 组包 sohu 组包和163的一样
    map_marge::get_instance()->add_burs_map("websohu_res_burs", smiple_burs);

    map_marge::get_instance()->add_node_map("cookie", webmailsohu_parse::request_cookie_parse);
    map_marge::get_instance()->add_node_map("cookie2", webmailsohu_parse::request_cookie2_parse);//xiaojun add
    map_marge::get_instance()->add_node_map("sohu_res_att", webmailsohu_parse::response_att_parse);
    map_marge::get_instance()->add_node_map("sohu_req_att", webmailsohu_parse::request_att_parse);
    map_marge::get_instance()->add_node_map("sohu_req_att2", webmailsohu_parse::request_att_parse2);
    map_marge::get_instance()->add_node_map("sohu_req_body", webmailsohu_parse::request_body_parse);
    map_marge::get_instance()->add_node_map("sohu_req_body_atts", webmailsohu_parse::request_body_atts_parse);
    map_marge::get_instance()->add_node_map("response_sohu_get_mids", webmailsohu_parse::response_sohu_get_mids);
    map_marge::get_instance()->add_node_map("message_cookie", webmailsohu_parse::get_cookie_message);//xiaojun add
    map_marge::get_instance()->add_node_map("message_map", webmailsohu_parse::get_message_map);//xiaojun add
    map_marge::get_instance()->add_node_map("cookie1", webmailsohu_parse::request_cookie_parse1);//xiaojun add
    // sina 附件 组包 sohu 组包和sina的一样
    map_marge::get_instance()->add_node_map("sina_res_att_image", webmailsohu_parse::sina_response_att_image_parse);
    map_marge::get_instance()->add_node_map("sina_req_att_image", webmailsohu_parse::sina_request_att_image_parse);
    map_marge::get_instance()->add_node_map("sina_req_body", webmailsohu_parse::sina_request_body_parse);
    map_marge::get_instance()->add_node_map("sina_req_body_atts", webmailsohu_parse::sina_request_body_atts_parse);
    map_marge::get_instance()->add_node_map("sina_get_image_urlparam", webmailsohu_parse::sina_urlparam_parse);
    map_marge::get_instance()->add_node_map("sina_get_att_image", webmailsohu_parse::sina_get_att_image_parse);

    // qq 离线文件下载
    map_marge::get_instance()->add_node_map("qq_file_http_id", qq_file_http_parse::request_handle_att_id);
    map_marge::get_instance()->add_node_map("qq_file_response_body", qq_file_http_parse::response_handle_getbody);
    map_marge::get_instance()->add_node_map("qq_file_resquest_body", qq_file_http_parse::request_handle_att);
}

bool smiple_burs(session * p_session, c_packet * p_packet)
{
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;

    if(p_webmail_session -> state == server_data) 
    {
        p_session->server.add_tcp_packet(len,p_data,seq);

        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;
        }

        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            return true;
        }
    }
    return false;
}

// 接卸请求体里面的附件属性，提取附件的ids
bool webmailsohu_parse::sina_request_body_atts_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 需要对attid单独提取
    if(p_parse_value->len == 0)
    {
        p_webmail_session->state = client_data_continue;
        p_session->client.clear_buf();
        return false;
    }

    p_parse_value->buf[p_parse_value->len] = 0x0;
    //if(p_parse_value->len < p_webmail_session->requset_length)
    //    return false;

    if(p_webmail_session->state==client_data || p_webmail_session->state==client_data_continue)
    {
        char * buffer = p_parse_value->buf;
        char * p_str = NULL;
        char * p_end = NULL;
        node_value_list::iterator iter = v_list.begin();
        p_str = strstr(buffer, iter->c_str());
        if(p_str == NULL)
        {
            return true;
        }

        p_str += (*iter).length();
        string value = "";
        string pattern = "\"id\":\"";
        char * b = strstr(p_str, pattern.c_str());
        if(b == NULL)
            return true;

        b += pattern.length();
        p_end = strstr(b, "\r\n");
        if(p_end == NULL)
            return true;

        p_str = strstr(b, "\"");
        if(p_str == NULL)
            return true;

        for(; ; )
        {
            char * mid = strstr(b, "|");
            if(mid==NULL || mid>p_end)
                break;

            ++mid;
            if(mid >= p_str)
                break;

            string v(mid, 0, p_str-mid);
            if(!value.empty())
            {
                value += "|";
            }
            value += v;

            b = strstr(p_str, pattern.c_str());
            if(b == NULL)
                break;

            b += pattern.length();
            p_str = strstr(b, "\"");
            if(p_str == NULL)
                break;
        }

        string name = "sina_send_";
        name += *iter;
        p_parse_value->value_map.insert(pair<string,string>(name, value));
    }
    return true;
}

// 提取请求体里面的from，to等属性值
bool webmailsohu_parse::sina_request_body_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 需要对attid单独提取
    if(p_parse_value->len == 0)
    {
        p_webmail_session->state = client_data_continue;
        p_session->client.clear_buf();
        return false;
    }

    p_parse_value->buf[p_parse_value->len] = 0x0;
    //if(p_parse_value->len < p_webmail_session->requset_length)
    //    return false;

    if(p_webmail_session->state==client_data || p_webmail_session->state==client_data_continue)
    {
        p_webmail_session->state = client_data_continue;
        char * buffer = p_parse_value->buf;
        char * p_str = NULL;
        char * p_end = NULL;
        string name = "";
        string &boundary = p_parse_value->value_map["boundary"];
        string &msg_txt_str = p_parse_value->value_map["sina_send_msgtxt"];
        if(msg_txt_str.empty())
        {
            node_value_list::iterator iter = v_list.begin();
            for(; iter!=v_list.end(); ++iter)
            {
                string pattern = "\"";
                pattern += *iter;
                pattern += "\"";
                p_str = strstr(buffer, pattern.c_str());

                if(p_str != NULL)
                {
                    // 找到关键字 判断是否需要循环取出数据 
                    p_str += pattern.length();
                    //if(*p_str=='\r' && *(p_str+1)=='\n' && *(p_str+2)=='\r'&& *(p_str+3)=='\n')
                    if(p_str-buffer+4<p_parse_value->len && *p_str=='\r' && *(p_str+1)=='\n' && *(p_str+2)=='\r'&& *(p_str+3)=='\n')
                    {
                        p_str += 4;
                        string pattern2 = "";
                        if(boundary.empty())
                            pattern2 = "\r\n";
                        else
                            pattern2 = boundary;

                        p_end = strstr(p_str, pattern2.c_str());
                        if(p_end != NULL)
                        {
                            name = "sina_send_";
                            name += *iter;
                            string svalue = "";
                            if(p_end!=p_str+1 && p_str!=NULL)
                            {
                                if(boundary.empty())
                                {
                                    svalue = string(p_str, 0, p_end-p_str);
                                    p_end += pattern2.length();
                                    char *mid = strstr(p_end, "\r\n");
                                    if(mid != NULL)
                                    {
                                        //boundary.assign(p_end, mid);
                                        boundary = string(p_end, 0, mid-p_end);
                                    }
                                }
                                else if(p_str!=NULL && p_end>p_str+2)
                                {
                                    //svalue.assign(p_str, p_end-2);
                                    if(p_str+2 < p_end)
                                    {
                                        svalue = string(p_str, 0, p_end-2-p_str);
                                    }
                                }
                            }
                            if(pattern == "\"msgtxt\"")
                            {
                                msg_txt_str += svalue;
                                // 真对正文图片的处理
                                /*      if((p_parse_value->value_map["sina_send_att_swf"]).empty() && p_str+45<p_end)
                                        {
                                        string tmp(p_str, p_str+45);
                                        if(tmp == " <img src=\"/classic/showattachimage.php?name=")
                                        {
                                        p_str += 45;
                                        char *mid = strstr(p_str, "|");
                                        if(mid != NULL && mid-p_str<2)
                                        {
                                        p_str = strstr(++mid, "\"");
                                        if(p_str!=NULL && *(p_str+1)=='>')
                                        {
                                        tmp.assign(mid, p_str);
                                        p_parse_value->value_map["sina_send_att_swf"] = tmp;
                                        }
                                        }
                                        }
                                        }*/

                                string tmp1 = "";
                                while(p_str!=NULL && (p_str+44<p_end))
                                {
                                    p_str = strstr(p_str, "<img src=\"/classic/showattachimage.php?name=");
                                    if(p_str != NULL)
                                    {
                                        p_str += 44;
                                        char *mid = strstr(p_str, "|");
                                        if(mid != NULL && mid-p_str<2)
                                        {
                                            if(mid < p_end)
                                                ++mid;

                                            p_str = strstr(mid, "\"");
                                            if(p_str!=NULL&& p_str+1<p_end && *(p_str+1)=='>')
                                            {
                                                if( !tmp1.empty())
                                                { 
                                                    //tmp1.append("|");     
                                                    tmp1 += "|";
                                                }
                                                //tmp1.append(mid, p_str);
                                                tmp1 += string(mid, 0, p_str-mid);
                                            }
                                        }
                                    }                                    
                                }
                                if(tmp1.length() > 0)
                                    p_parse_value->value_map["sina_send_att_swf"] = tmp1;
                            }
                            else
                            {
                                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                            }
                        }
                        else if(pattern == "\"msgtxt\"")
                        {
                            //msg_txt_str.assign(p_str, p_str+(p_parse_value->len-(p_str-p_parse_value->buf)));
                            if(p_str-p_parse_value->buf < p_parse_value->len)
                            {
                                msg_txt_str = string(p_str, 0, p_parse_value->len-(p_str-p_parse_value->buf));
                            }
                            //name = "sina_send_msgtxt";
                            //msg_txt_str.assign(p_str, p_str+(p_parse_value->len-(p_str-p_parse_value->buf)));
                            //p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                        }
                    }
                }
            }
        }
        else
        {
            char *p_str = strstr(buffer, boundary.c_str());
            if(p_str == NULL)
            {
                //string svalue(p_parse_value->buf,p_parse_value->buf+p_parse_value->len);
                string svalue(p_parse_value->buf, 0 ,p_parse_value->len);
                msg_txt_str += svalue;
            }
            else
            {
                //string svalue(p_parse_value->buf,0, p_parse_value->buf+(p_parse_value->len-(p_str-p_parse_value->buf)));
                string svalue(p_parse_value->buf,0,p_parse_value->len-(p_str-p_parse_value->buf));
                msg_txt_str += svalue;
            }
        }

        // 发空包，写取得的属性参数
        if(p_webmail_session->requset_length<=p_parse_value->len + p_webmail_session->had_send_len )
        {
            p_webmail_session->state = server_data;
            p_webmail_session->b_end_send = true;
            p_session->p_send_buf = p_parse_value->buf;
            p_parse_value -> parse_type  = MESS_BODY;
            p_session->send_len = 1;
        }
        else
        {
           // p_webmail_session->requset_length -= p_parse_value->len;
              p_webmail_session->had_send_len += p_parse_value->len ;
              p_session->send_len = 0 ;
              p_session->p_send_buf = NO_NULL;
            //p_session->client.clear_buf();
        }
    }
    return true;
}

// 接卸请求体里面的附件属性，提取附件的ids
bool webmailsohu_parse::request_body_atts_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 需要对attid单独提取
    if(p_parse_value->len == 0)
    {
        //p_webmail_session->state = client_data_continue;
        //     p_session->client.clear_buf();
        //p_session->p_send_buf = NO_NULL ;
        //p_session->send_len = 0;
        return false;
    }
    // 数据缓存  --- 
    if(p_webmail_session->state == client_data ) 
    {
        if(p_webmail_session->requset_length > p_parse_value->len )
        {
            p_parse_value->gzip_buffer = new char[p_webmail_session->requset_length +  p_parse_value->len  + 100];

            p_webmail_session->state = client_data_continue;
            memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len ,p_parse_value->buf,p_parse_value->len);
            p_parse_value->gzip_len+= p_parse_value->len;
            p_webmail_session->had_send_len = p_parse_value->len; 
            //p_webmail_session->requset_length -= p_parse_value->len;
            // 清理数据
            p_session->p_send_buf = NO_NULL ;
            p_session->send_len = 0;
            return false;
        }
    }
    else if(p_webmail_session->state == client_data_continue)
    {
        if(p_parse_value->gzip_buffer  == NULL) 
        {
            p_parse_value->gzip_buffer = new char[p_webmail_session->requset_length +  p_parse_value->len + 100];
        }
        if(p_webmail_session->requset_length > p_webmail_session->had_send_len + p_parse_value->len  ) 
        {

            memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len ,p_parse_value->buf,p_parse_value->len);
            p_parse_value->gzip_len+= p_parse_value->len;
            p_webmail_session->had_send_len += p_parse_value->len; 
            // 清理数据
            p_session->p_send_buf = NO_NULL ;
            p_session->send_len = 0;
            return false;
        }
        else {

            memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len ,p_parse_value->buf,p_parse_value->len  );
            p_parse_value->gzip_len+= p_webmail_session->len ;
        }

        p_parse_value->buf = p_parse_value->gzip_buffer;
        p_parse_value->len = p_parse_value->gzip_len;

    }

    //return true;
    if(p_webmail_session->state == client_data || p_webmail_session->state == client_data_continue)
    {
        int len = p_parse_value->len*2;
        char * buffer = NULL;
        buffer = new char[len];
        if(buffer == NULL) 
        {
            return false;
        }

        p_parse_value->buf[p_parse_value->len] = 0x0;
        //printf("enc len is %d , buf is  %d \n", p_parse_value->len , len );
        len = UrlDecode(p_parse_value->buf, p_parse_value->len, buffer, len);
        //printf("DES LEN IS %d \n\n",len);
        char * p_str = NULL;
        char * p_end = NULL;
        node_value_list::iterator iter = v_list.begin();
        p_str = strstr(buffer, iter->c_str());
        if(p_str == NULL)
        {
            if(buffer!= NULL)
                delete [] buffer;
            buffer = NULL;
            return true;
        }

        string name = "";
        p_str += iter->length();
        char * b = strchr(p_str, '[');
        if(b == NULL)
        {
            if(buffer!= NULL)
                delete [] buffer;
            buffer = NULL;
            return true;
        }

        ++b;
        p_end = strchr(b, ']');
        if(p_end == NULL)
        {
            if(buffer!= NULL)
                delete [] buffer;
            buffer = NULL;
            return true;
        }

        string value = "";
        p_str = strstr(b, ",");
        if(p_str == NULL)
        {
            if(p_str>p_end && b<p_end)
            {
                value = string(b, 0, p_end-b);
            }
        }
        else
        {
            for(; b<p_end && p_str<=p_end; )
            {
                if(p_str <= b)
                    break;

                string v(b, 0, p_str-b);
                if(!value.empty())
                    value += "|";

                value += v;
                ++p_str;
                while((p_str<p_end) && (*p_str++ == '0x20')){}
                b = p_str;
                p_str = strstr(b, ",");
                if(p_str == NULL)
                    break;
            }

            if(p_str < p_end)
            {
                string v(p_str, 0, p_end-p_str);
                value += "|";
                value += v;
            }
            else
            {
                if(p_end > b)
                {
                    string v(b, 0, p_end-b);
                    if(!value.empty())
                    {
                        value += "|";
                    }
                    value += v;
                }
            }
        }

        name = "sohu_send_";
        name += *iter;
        p_parse_value->value_map.insert(pair<string,string>(name, value));

        if(buffer!= NULL)
            delete [] buffer;
        buffer = NULL;
    }
    return true;
}

// 提取请求体里面的from，to等属性值
bool webmailsohu_parse::request_body_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 需要对attid单独提取
    if(p_parse_value->len == 0)
        return false;

    if(p_parse_value->len < p_webmail_session->requset_length)
        return false;
    /*if(p_parse_value->buf != p_parse_value->gzip_buffer ) 
      {
      return  true;
      }*/

    if(p_webmail_session->state == client_data || p_webmail_session->state == client_data_continue)
    {
        p_parse_value->buf[p_parse_value->len] = 0x0;
        char * buffer = new char[p_parse_value->len * 2];
        if(buffer == NULL) 
        {
            return false;
        }
        int len = p_parse_value->len * 2;
        len = UrlDecode(p_parse_value->buf, p_parse_value->len, buffer, len);
        char * p_str = NULL;
        char * p_end = NULL;
        string name = "";
        buffer[len] = 0x0;
        node_value_list::iterator iter = v_list.begin();
        for(; iter!=v_list.end(); ++iter)
        {
            string pattern = *iter;
            pattern += "=";
            p_str = strstr(buffer, pattern.c_str());
            if(p_str != NULL)
            {
                // 找到关键字 判断是否需要循环取出数据 
                p_str += pattern.length();
                {
                    p_end = strchr(p_str, '&');
                    // 去掉 &nbsp;
                    if(p_end != NULL)
                    {
                        if(pattern == "text=")
                        {
                            int i = 0;
                            for(;p_end!=NULL && i<10;)
                            {
                                if(*(p_end+i) == ';')
                                {
                                    i = 0;
                                    p_end = strchr(p_end+i+1, '&');
                                }
                                else
                                {
                                    ++i;
                                }
                            }
                        }
                        name = "sohu_send_";
                        name += *iter;
                        string svalue = "";
                        if(p_end != p_str+1 && p_end>p_str)
                        {
                            //svalue.assign(p_str, p_end);
                            svalue = string(p_str, 0, p_end-p_str);
                        }
                        p_parse_value->value_map.insert(pair<string,string>(name,svalue));
                    }
                }
            }
        }

        delete [] buffer;
        buffer = NULL;

        // 发空包，写取得的属性参数
        p_webmail_session->state = server_data;
        p_webmail_session->b_end_send = true;
        //p_session->p_send_buf = p_parse_value->buf;
        p_session->p_send_buf = NO_NULL;
        p_parse_value -> parse_type  = MESS_BODY;
        p_session->send_len = 1;
    }
    return true;
}
bool webmailsohu_parse::request_att_parse2(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_parse_value == NULL)
        return false;
    if(p_parse_value->len == 0)
        return false;

    //  包长度 
    // 文件 长度 
    if(p_webmail_session -> state == client_data)
    {
        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }

        
        p_parse_value->buf[p_parse_value->len] = 0x0;
        char * b = p_parse_value->buf;
        char * mid = strstr(b, "\r\n");
        if(mid == NULL)
            return true;
        int boundary_len = mid-b;

        string key = "filename=\"";
        char * end = strstr(mid, key.c_str());
        if(end == NULL)
            return true;

        end += key.length();
        mid = strstr(end, "\"");
        if(mid == NULL)
            return true;

        string svalue(end, mid);
        node_value_list::iterator iter = v_list.begin();
        string name = "sohu_att_";
        name += *(v_list.begin());
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        end = strstr(mid, "\r\n\r\n");
        if(end == NULL)
            return true;
        end += 4;

        //int remaind = end-b + 2*(boundary_len+2) + 65;
        int remaind = end - p_parse_value->buf  + boundary_len * 2 + 68; //end-b + 2*(boundary_len+2) + 65;
        int content_len = p_webmail_session->requset_length - remaind ;

        p_parse_value->acc_file_length = content_len;
        // 首先处理包属性字段的提取，包内容是在后面的包单独发送传输过来, 没有发现包内容和属性字段组在一起发送
        // 设置清理之前的数据包信号，p_session->send_len == 0 && p_session->p_send_buf  != NULL, 在webmail_plugin.cpp里面清理
        if(end - b  == p_parse_value->len)
        {
            p_session->p_send_buf = end;
            p_session->send_len = 0;
            p_webmail_session->had_send_len =  remaind ;

        }
        else
        {
            uint32_t len = p_parse_value->len - (end - p_parse_value->buf ) ;
            if (len > content_len ) 
            {
                len = content_len ;
            }
            p_session->p_send_buf = end;
            p_session->send_len = len;
            p_webmail_session->had_send_len = len + remaind ;
        }
        //p_webmail_session->requset_length -= p_parse_value->len;
        // 设置收包处理属性
        p_webmail_session->state = client_data_continue;
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_webmail_session ->had_send_len + p_parse_value->len >= p_webmail_session-> requset_length)
        {
            // 设置文件结束标志，网络接口的话还要传输, 还要写入attid,attid做关联
            // 并且把状态设置成服务器返回数据的状态，组服务器端数据包，从里面提取attid, 用yyid和at
            //p_webmail_session-> b_end_send = true;
            p_webmail_session -> state = server_data;
            p_session->p_send_buf = p_parse_value->buf ;
            p_session->send_len = p_webmail_session->requset_length  - p_webmail_session ->had_send_len ;
              // p_parse_value->acc_file_length-p_webmail_session->had_send_len;
            p_webmail_session->had_send_len += p_parse_value->acc_file_length;
        }
        else
        {
            p_webmail_session->had_send_len += p_parse_value->len;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
        }
    }
    if(p_webmail_session ->had_send_len  >= p_webmail_session-> requset_length)
    {
        p_webmail_session -> state = server_data ;
    }

    return true;
}

bool webmailsohu_parse::request_att_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) //  sohu 类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_parse_value == NULL)
        return false;
    if(p_parse_value->len == 0)
        return false;

    //  包长度 
    // 文件 长度 
    if(p_webmail_session -> state == client_data)
    {
        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }

        // 文件长度计算
        p_parse_value->buf[p_parse_value->len] = 0x0;
        char * b = p_parse_value->buf;
        char * mid = strstr(b, "\r\n");
        if(mid == NULL)
            return true;
        int boundary_len = mid-b;

        string key = "filename=\"";
        char * end = strstr(mid, key.c_str());
        if(end == NULL)
            return true;

        end += key.length();
        mid = strstr(end, "\"");
        if(mid == NULL)
            return true;

        string svalue(end, mid);
        node_value_list::iterator iter = v_list.begin();
        string name = "sohu_att_";
        name += *(v_list.begin());
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        end = strstr(mid, "\r\n\r\n");
        if(end == NULL)
            return true;
        end += 4;

        //int remaind = end-b + 2*(boundary_len+2) + 65;
        int remaind = end - p_parse_value->buf  + boundary_len  + 4; //end-b + 2*(boundary_len+2) + 65;
        int content_len = p_webmail_session->requset_length - remaind ;

        p_parse_value->acc_file_length = content_len;
        // 首先处理包属性字段的提取，包内容是在后面的包单独发送传输过来, 没有发现包内容和属性字段组在一起发送
        // 设置清理之前的数据包信号，p_session->send_len == 0 && p_session->p_send_buf  != NULL, 在webmail_plugin.cpp里面清理
        if(end - b  == p_parse_value->len)
        {
            p_session->p_send_buf = end;
            p_session->send_len = 0;
            p_webmail_session->had_send_len =  remaind ;

        }
        else
        {
            uint32_t len = p_parse_value->len - (end - p_parse_value->buf ) ;
            if (len > content_len ) 
            {
                len = content_len ;
            }
            p_session->p_send_buf = end;
            p_session->send_len = len;
            p_webmail_session->had_send_len = len + remaind ;
        }
        //p_webmail_session->requset_length -= p_parse_value->len;
        // 设置收包处理属性
        p_webmail_session->state = client_data_continue;
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_webmail_session ->had_send_len + p_parse_value->len >= p_webmail_session-> requset_length)
        {
            // 设置文件结束标志，网络接口的话还要传输, 还要写入attid,attid做关联
            // 并且把状态设置成服务器返回数据的状态，组服务器端数据包，从里面提取attid, 用yyid和at
            //p_webmail_session-> b_end_send = true;
            p_webmail_session -> state = server_data;
            p_session->p_send_buf = p_parse_value->buf ;
            p_session->send_len = p_webmail_session->requset_length  - p_webmail_session ->had_send_len ;
              // p_parse_value->acc_file_length-p_webmail_session->had_send_len;
            p_webmail_session->had_send_len = p_parse_value->acc_file_length;
        }
        else
        {
            p_webmail_session->had_send_len += p_parse_value->len;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
        }
    }
    if(p_webmail_session ->had_send_len  >= p_webmail_session-> requset_length)
    {
        p_webmail_session -> state = server_data ;
    }

    return true;
}

bool webmailsohu_parse::sina_request_att_image_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) // sina 上传图片文件
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value->len == 0)
        return false;
    p_parse_value->buf[p_parse_value->len] = 0x0;

    //  包长度 
    // 文件 长度 
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_webmail_session -> state == client_data)
    {
        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }

        // 文件长度计算
        char * b = p_parse_value->buf;
        char * mid = strstr(b, "\r\n");
        if(mid == NULL)
            return true;
        int boundary_len = mid-b;

        string key = "filename=\"";
        char * end = strstr(mid, key.c_str());
        if(end == NULL)
            return true;

        end += key.length();
        mid = strstr(end, "\"");
        if(mid == NULL)
            return true;

        string svalue(end, 0, mid-end);
        node_value_list::iterator iter = v_list.begin();
        string name = "sina_att_";
        name += *(v_list.begin());
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        end = strstr(mid, "\r\n\r\n");
        if(end == NULL)
            return true;
        end += 4;

        int remaind = end-b + (boundary_len+2)+4;
        int content_len = p_webmail_session->requset_length - remaind;

        p_parse_value->acc_file_length = content_len;
        // 首先处理包属性字段的提取，包内容是在后面的包单独发送传输过来, 没有发现包内容和属性字段组在一起发送
        // 设置清理之前的数据包信号，p_session->send_len == 0 && p_session->p_send_buf  != NULL, 在webmail_plugin.cpp里面清理
        if(end-b == p_parse_value->len)
        {
            p_session->p_send_buf = end;
            p_session->send_len = 0;
            p_webmail_session->had_send_len = 0;
        }
        else
        {
            uint32_t len = p_parse_value->len-(end-p_parse_value->buf);
            p_session->p_send_buf = end;
            p_session->send_len = len;
            p_webmail_session->had_send_len = len;
        }
        //p_webmail_session->requset_length -= p_parse_value->len;
        // 设置收包处理属性
        p_webmail_session->state = client_data_continue;
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_webmail_session->had_send_len + p_parse_value->len >= p_parse_value->acc_file_length)
        {
            // 设置文件结束标志，网络接口的话还要传输, 还要写入attid,attid做关联
            // 并且把状态设置成服务器返回数据的状态，组服务器端数据包，从里面提取attid, 用yyid和at
            //p_webmail_session ->b_add_end = true;
            p_webmail_session -> state = server_data;
            p_session->p_send_buf = p_parse_value->buf ;
            p_session->send_len = p_parse_value->acc_file_length-p_webmail_session->had_send_len;
            p_webmail_session->had_send_len = p_parse_value->acc_file_length;
        }
        else
        {
            p_webmail_session ->b_add_end = true;
            p_webmail_session->had_send_len += p_parse_value->len;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
        }
    }

    return true;
}

bool webmailsohu_parse::sina_get_att_image_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list) // sina 上传图片文件
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value->len == 0)
        return false;

    //  包长度 
    // 文件 长度 
    p_parse_value->buf[p_parse_value->len] = 0x0;
    p_parse_value -> parse_type  = ATTACHMENT;
    if(p_webmail_session -> state == server_data)
    {
        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }

        // 文件长度计算
        char * b = p_parse_value->buf;
        char * mid = strstr(b, "\r\n");
        if(mid == NULL)
            return true;

        string svalue(mid,0, b - mid);
        int att_len = atoi(svalue.c_str());
        mid += 2;

        p_parse_value->acc_file_length = att_len;
        // 首先处理包属性字段的提取，包内容是在后面的包单独发送传输过来, 没有发现包内容和属性字段组在一起发送
        // 设置清理之前的数据包信号，p_session->send_len == 0 && p_session->p_send_buf  != NULL, 在webmail_plugin.cpp里面清理
        if(mid-b == p_parse_value->len)
        {
            p_session->p_send_buf = mid;
            p_session->send_len = 0;
            p_webmail_session->had_send_len = 0;
        }
        else
        {
            uint32_t len = p_parse_value->len-(mid-p_parse_value->buf);
            p_session->p_send_buf = mid;
            p_session->send_len = len;
            p_webmail_session->had_send_len = len;
        }
        //p_webmail_session->requset_length -= p_parse_value->len;
        // 设置收包处理属性
        p_webmail_session->state = server_data_continue;
    }
    else if(p_webmail_session -> state == server_data_continue)
    {
        if(p_webmail_session->had_send_len + p_parse_value->len >= p_parse_value->acc_file_length)
        {
            // 设置文件结束标志，网络接口的话还要传输, 还要写入attid,attid做关联
            // 并且把状态设置成服务器返回数据的状态，组服务器端数据包，从里面提取attid, 用yyid和at
            //p_webmail_session ->b_add_end = true;
            p_webmail_session -> state = server_data;
            p_session->p_send_buf = p_parse_value->buf ;
            p_session->send_len = p_parse_value->acc_file_length-p_webmail_session->had_send_len;
            p_webmail_session->had_send_len = p_parse_value->acc_file_length;
        }
        else
        {
            p_webmail_session ->b_add_end = true;
            p_webmail_session->had_send_len += p_parse_value->len;
            p_session->p_send_buf = p_parse_value->buf;
            p_session->send_len = p_parse_value->len;
        }
    }

    return true;
}

bool webmailsohu_parse::sina_response_att_image_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 附件类的组包  靠返回来推出数据
{
    // 提取应答体里面的附件 id
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 
    p_parse_value->buf[p_parse_value->len] = 0x0;
    if(p_webmail_session->state == server_data)
    {
        string key ="response_json_data/remotename";
        parse_value_map ::iterator iter = p_parse_value->value_map.find(key);
        if(iter != p_parse_value->value_map.end())
        {
            string tmp = iter->second;
            // 提取att_id
            string svalue="";
            int size = tmp.find("|");
            if(size != 0)
            {
                svalue = string(tmp, size+1, tmp.length()-size-1);
            }
            else
            {
                svalue.swap(tmp);
            }
            node_value_list::iterator iter = v_list.begin();
            string name = "sina_att_";
            name += *(v_list.begin());
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));

            // 发送空包，写attid, 设置文件结束标志
            p_webmail_session-> b_end_send = true;
            p_session->p_send_buf = NO_NULL;
            p_session->send_len =1;
        }
    }

    return true;
}

bool webmailsohu_parse::response_att_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 附件类的组包  靠返回来推出数据
{
    // 提取应答体里面的附件 id
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    // url 解码 
    if(p_webmail_session->state == server_data)
    {
        if(p_parse_value->len == 0)
            return true;
        char * b = p_parse_value->buf;

        string key = "\"id\":";
        char * end = strstr(b, key.c_str());
        if(end == NULL)
            return false;

        end += key.length();
        while(*end++ == '0x20'){}

        char * mid = strstr(end, ",");
        if(mid == NULL)
            return false;

        string svalue = "";
        if(*(mid-1) != '"')
        {
            //svalue.assign(end, mid);
            svalue = string(end, 0, mid-end);
        }
        else
        {
            --mid;
            char *pos = strstr(end, "|");
            if(pos==NULL || pos>mid)
            {
                //svalue.assign(end, mid);
                svalue = string(end, 0, mid-end);
            }
            else
            {
                //svalue.assign(++pos, mid);
                ++pos;
                svalue = string(pos, 0, mid-pos);
            }
        }

        node_value_list::iterator iter = v_list.begin();
        string name = "sohu_att_";
        name += *(v_list.begin());
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));

        // 发送空包，写attid, 设置文件结束标志
        p_webmail_session-> b_end_send = true;
        p_session->p_send_buf = p_parse_value->buf ;
        p_session->send_len =1;
    }

    return true;
}

// 解析cookie 提取YYID
bool webmailsohu_parse::request_cookie_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }

    http_cookie_analyzer url_cookie;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";

    c_http_str * p = find_key_value(p_requst->HttpHeaderKeyNameValue, "Cookie");
    if(p != NULL)
    {
        //char * p_end = p->buf_begin+p->space_use_len;
        s_key_value * phead =NULL;
        url_cookie.CookieParse(p, phead);
        node_value_list::iterator iter = v_list.begin();
        // 把所有的需要记录的数据放入 map中
        for(;iter!=v_list.end();iter ++)
        {
            string str = iter->c_str();
            c_http_str * p_value = find_key_value(phead,iter->c_str());
            if(p_value != NULL)
            {
                name = "requset_cookie_";
                name += *iter;
                string svalue(p_value->buf_begin,0,p_value->space_use_len);
                if (svalue[svalue.size()-1] == ';' || svalue[svalue.size()-1] == '\r')
                {
                    svalue = svalue.substr(0,svalue.size()-1);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                }
                p_parse_value->value_map.insert(pair<string,string>(name,svalue));

            }
        }
        s_key_value_free(phead);
    }
    return true;
}

//该函数用于解决从cookie中提取关键字是不确定的字符，使用该函数的时候需要给其关键字，然后在给你要提取字符串的开始位置以及结束位置
bool webmailsohu_parse::request_cookie2_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }

    http_cookie_analyzer url_cookie;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";

    c_http_str * p = find_key_value(p_requst->HttpHeaderKeyNameValue, "Cookie");
    if(p != NULL)
    {
        node_value_list::iterator iter = v_list.begin();
        char* p_buf = p->buf_begin;
        if (p_buf == NULL) 
        {
            return true;
        }
        const char* p_flag = strstr(p_buf, iter->c_str());
        if (p_flag == NULL)
        {
            return true;
        }
        int len = iter->size();
        ++iter;
        const char* p_begin = strstr(p_flag+len, iter->c_str());
        if (p_begin == NULL)
        {
            return true;
        }
        int len1 = iter->size();
        ++iter;
        const char* p_end = strstr(p_begin+len1, iter->c_str());
        if (p_end == NULL)
        {
            return true;
        }
        if (p_begin+len1 > p_end)
        {
            return true;
        }
        string svalue(p_begin+len1, p_end-p_begin-len1);
        string goods = urldecode(svalue);
        string name = "requset_cookie_";
        name += *iter;
        p_parse_value->value_map.insert(pair<string,string>(name,goods));
    }
    return true;
}
// 解析cookie 提取YYID 并且对其进行url解码
bool webmailsohu_parse::request_cookie_parse1(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }

    http_cookie_analyzer url_cookie;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";

    c_http_str * p = find_key_value(p_requst->HttpHeaderKeyNameValue, "Cookie");
    if(p != NULL)
    {
        //char * p_end = p->buf_begin+p->space_use_len;
        s_key_value * phead =NULL;
        url_cookie.CookieParse(p, phead);
        node_value_list::iterator iter = v_list.begin();
        // 把所有的需要记录的数据放入 map中
        for(;iter!=v_list.end();iter ++)
        {
            string str = iter->c_str();
            c_http_str * p_value = find_key_value(phead,iter->c_str());
            if(p_value != NULL)
            {
                name = "requset_cookie_";
                name += *iter;
                string svalue(p_value->buf_begin,0,p_value->space_use_len);
                if (svalue[svalue.size()-1] == ';' || svalue[svalue.size()-1] == '\r')
                {
                    svalue = svalue.substr(0,svalue.size()-1);
                }
                //xiaojun add
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;

                p_parse_value->value_map.insert(pair<string,string>(name,svalue));
            }
        }
        s_key_value_free(phead);
    }
    return true;
}
//该函数是用来从cookie中某个关键词后边的数据中获取信息，比如:SUP=...user=jjk&id=jj&...;如果我们要获取user以及id后边的值。需要先在cookie在其下配置关键词SUP将其后的数据放入映射中，接着在调用get_cookie_message其第一个key值为SUP-=-&amp;其会从映射中将request_cookie_SUP数据取出来，然后开始标志位为=结束标志位为&，接下来配置的key值即为你要从SUP后那个词后边的数据，如配置user其会将其后数据放入映射中
bool webmailsohu_parse::get_cookie_message(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (p_parse_value == NULL)
    {
        return true;
    }
    node_value_list::iterator iter = v_list.begin();
    string::size_type begin, end;
    string begin_flag, end_flag, map_flag;
    begin = (*iter).find_first_of("-");
    if (begin == string::npos)
    {
        return true;
    }
    end = (*iter).find_first_of("-", begin+1);
    if (end == string::npos)
    {
        return true;
    }
    map_flag = (*iter).substr(0, begin);
    begin_flag = (*iter).substr(begin+1, end-begin-1); 
    end_flag = (*iter).substr(end+1);
    string str_flag = "requset_cookie_";
    str_flag += map_flag;
    parse_value_map::iterator it= p_parse_value->value_map.find(str_flag);
    if (it == p_parse_value->value_map.end())
    {
        return true;
    }
    ++iter;
    for ( ; iter != v_list.end(); ++iter)
    {
        const char* p = strstr(it->second.c_str(), iter->c_str());
        if (!p)
        {
            continue;
        }
        const char* p_begin = strstr(p, begin_flag.c_str());
        if (!p_begin)
        {
            continue;
        } 
        const char* p_end = strstr(p_begin, end_flag.c_str());
        if (!p_end)
        {
            continue;
        }
        string name = "requset_cookie_";
        name += *iter;
        int len = begin_flag.size();
        if (p_end-p_begin-len >= 0)
        {
            string svalue(p_begin+len, p_end-p_begin-len);
            string goods = urldecode(svalue);//url 解码  
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
        else
        {
            continue;
        }
    }
    return true;
}

//从map中的svalue中提取数据，第一个key值设置在map中的name以及开始标志位和结束标志位以-连接
//后边的key位要进行提取的数据
bool webmailsohu_parse::get_message_map(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (p_parse_value == NULL)
    {
        return true;
    }
    node_value_list::iterator iter = v_list.begin();
    string::size_type begin, end;
    string begin_flag, end_flag, map_flag;
    begin = (*iter).find_first_of("-");
    if (begin == string::npos)
    {
        return true;
    }
    end = (*iter).find_first_of("-", begin+1);
    if (end == string::npos)
    {
        return true;
    }
    map_flag = (*iter).substr(0, begin);
    begin_flag = (*iter).substr(begin+1, end-begin-1); 
    end_flag = (*iter).substr(end+1);
    parse_value_map::iterator it= p_parse_value->value_map.find(map_flag);
    if (it == p_parse_value->value_map.end())
    {
        return true;
    }
    ++iter;
    const char* p_flag = it->second.c_str();
    for ( ; iter != v_list.end(); ++iter)
    {
        const char* p = strstr(p_flag, iter->c_str());
        if (!p)
        {
            continue;
        }
        const char* p_begin = strstr(p, begin_flag.c_str());
        if (!p_begin)
        {
            continue;
        } 
        const char* p_end = strstr(p_begin, end_flag.c_str());
        if (!p_end)
        {
            continue;
        }
        string name = "map_message_";
        name += *iter;
        int len = begin_flag.size();
        if (p_end-p_begin-len >= 0)
        {
            string svalue(p_begin+len, p_end-p_begin-len);
            string goods = urldecode(svalue);//url 解码  
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
        else
        {
            continue;
        }
        p_flag = p_end;
    }
    return true;
}

bool webmailsohu_parse::sina_urlparam_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    http_urlparam_analyzer url_param;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";
    c_http_str * p = &(p_requst->UriParam);
    //char * p_end = p->buf_begin +p->space_use_len;
    s_key_value * phead =NULL;
    url_param.ParamAnakyses(p,phead);
    node_value_list::iterator iter = v_list.begin();
    // 把所有的需要记录的数据放入 map中
    for(;iter!=v_list.end();iter ++)
    {

        c_http_str * p_value = find_key_value(phead,iter->c_str());
        if(p_value != NULL)
        {
            name = "requset_urlparam_";
            name += *iter;
            string svalue;
            char *mid = strstr(p_value->buf_begin, "|");
            if(mid == NULL)
            {
                //svalue.assign(mid, p_value->buf_begin+p_value->space_use_len);
                svalue = string(mid, 0, p_value->buf_begin+p_value->space_use_len-mid);
            }
            else
            {
                //svalue.assign(p_value->buf_begin,p_value->buf_begin+p_value->space_use_len);
                svalue = string(p_value->buf_begin, 0, p_value->space_use_len);
            }
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    s_key_value_free(phead);
    return true;
}

bool webmailsohu_parse::response_sohu_get_mids(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string key = "response_json_attach";
    string value = p_parse_value->value_map[key];
    if(value.length() < 2)
        return true;

    // 解析提取mid的字符串
    string svalue = "";
    size_t pos = value.find("]");
    if(pos != string::npos)
        pos--;

    while(pos != string::npos)
    {
        pos = value.find("]",pos+1);
        if(pos == string::npos)
            break;

        pos = value.find("]", pos+1);
        if(pos == string::npos)
            break;

        pos = value.find("]", pos+1);
        if(pos == string::npos)
            break;

        size_t pos2 = value.find("]", pos+1);
        if(pos2 == string::npos)
            break;

        pos = value.find("]", pos2+1);
        if(pos == string::npos)
            break;

        string str(value,pos2+1,pos-pos2-1);

        if(!svalue.empty())
        {
            svalue += "|";
        }

        svalue += str;
        svalue += ".";
    }

    if(!svalue.empty())
    {
        string name = "response_json_mid";
        p_parse_value->value_map.insert(pair<string,string>(name,svalue));
    }

    return true;
}
