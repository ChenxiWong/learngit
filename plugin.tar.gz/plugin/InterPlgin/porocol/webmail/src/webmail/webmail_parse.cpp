// Last Update:2016-04-22 14:04:58
/**
 * @file webmail_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-27
 */

#include "webmail_parse.h"

webmail_parse::webmail_parse()
{
    m_request.HttpHeaderKeyNameValue = NULL;
    m_response.HttpHeaderKeyNameValue = NULL;
}

webmail_parse::~webmail_parse()
{
    init_s_http_requset(&m_request);
    init_s_http_response(&m_response);
}

bool webmail_parse::host_get(char * httpbuf , uint32_t len ,string & host)
{
    host ="";
    if(len < 17) 
        return false;

    //httpbuf[len] = 0x0;
    char * p = strstr(httpbuf , "\r\nHost:");
    if(p == NULL || p - httpbuf > len )
        return false;
    char *p_end = strstr(p + 7,"\r\n");
    if(p_end == NULL)
        return false;
    if(p_end - p < 8 || p_end - httpbuf > len )
    {
        return false;
    }
    host =string(p+8,0,p_end - p - 8) ;
 //   trim(host);
 //   printf("%s\n",host.c_str());
    return true;

}


bool webmail_parse::url_get(char * httpbuf , uint32_t len,string & url,string & urlparam)
{
    // 判断是否结束  // 取值到/r/n 结束 
    // 第一步判断是否是 GET POST 
    if(len < 17) 
        return false;
    if(strncmp(httpbuf ,"GET ",4)== 0 || strncmp(httpbuf,"POST ",5)== 0)
    {
        // ----   
        char * p = strstr(httpbuf,"\r\n");
        if(p!=NULL && p -httpbuf <= len && p-httpbuf > 10)
        {
           urlparam = string(httpbuf,0,p-httpbuf-9);
           // 去掉URL PARAM 部分
           int size = urlparam.find('?') ;
           if(size > 0) 
           {
                url= urlparam.substr(0,size);
           }
           else {
               url = urlparam;
           }
           // 取值到 是否有 
           return true; 
        }
    }
    
    return false;
}

method_type webmail_parse::http_method_type(char * buffer ,int len )
{
    char * p = strchr(buffer,0x20);
    if(p - buffer > 10) 
    {
        return METHODERROR;
    }
    c_http_str tmp;
    tmp.buf_begin = buffer;
    tmp.space_use_len = p -buffer -1;

    return uriparse.find_http_mothed(tmp );

}

response_type webmail_parse::http_response_type(char * buffer ,int len)
{

        return HTTP_CONTINUE;
}

bool webmail_parse::http_request_head_parse(webmail_session * p_webmail_session ,char * pbuffer,int len )
{
    // 
    init_s_http_requset(&m_request);
    m_request.parsestate = dRStateMethodBegin;
    m_request.parsepos = pbuffer;
    char * p_end = pbuffer +len;
    int state = uriparse.http_url_analyer(&m_request,p_end);
    switch(state)
    {
        case BUF_END:
              return false;
        case PASER_CONTINUE:
              //继续出来
              break;
        case ERROR:
              return false;
        default:
              return false;

    }
    m_request.HttpHeaderKeyNameValue = NULL; 
    // 处理 http 头
    state = http_head.key_header_parse(m_request.parsepos,p_end,&m_request.parsestate,m_request.HttpHeaderKeyNameValue);
    if(state != PASER_CONTINUE)
    {
        return false;
    }
    // 取包的长度
    c_http_str * p_value = find_key_value(m_request.HttpHeaderKeyNameValue,"Content-Length");
    if(p_value != NULL) 
    {
        char tmp[16];
        memset(tmp,0x0,16);
        memcpy(tmp,p_value->buf_begin,p_value->space_use_len);
        p_webmail_session ->requset_length = atoi(tmp);

    }
    // 取http 字符集类型
    p_value = find_key_value(m_request.HttpHeaderKeyNameValue,"Content-Type");
    if(p_value != NULL) 
    {

    }
    // 取http 字符集类型
    return true;

}

bool webmail_parse::http_response_head_parse(webmail_session * p_webmail_session ,char * pbuffer,int len )
{
    init_s_http_response(&m_response);
    m_response.parsestate = dSStateVersion;
    m_response.parsepos  = pbuffer;
    char * p_end = pbuffer +len;
    int state = http_resp_parse.http_s_version_analysis(&m_response,p_end);
    if(state == BUF_END || state == ERROR)
    {
        return false;
    }
    state  = http_resp_parse.http_s_code_analysis(&m_response,p_end);
    if(state == BUF_END || state == ERROR)
    {
        return false;
    }
    if(!( m_response.http_code == 200|| m_response.http_code == 100 || m_response.http_code == 302 || m_response.http_code == 206))
    {
        return true;
    }
    state = http_resp_parse.http_s_codename_analysis(&m_response,p_end);
    if(state == BUF_END || state == ERROR)
    {
        return false;
    }
    
    state = http_head.key_header_parse(m_response.parsepos,p_end,&m_response.parsestate,m_response.HttpHeaderKeyNameValue);
    if(state != PASER_CONTINUE)
    {
        return false;
    }
    // 取包的长度 判断包是否结束 
    c_http_str * p_value = find_key_value(m_response.HttpHeaderKeyNameValue,"Content-Length");
    if(p_value != NULL) 
    {
        char tmp[16];
        memset(tmp,0x0,16);
        if(p_value->space_use_len >15)
            p_value->space_use_len = 15;
        memcpy(tmp,p_value->buf_begin,p_value->space_use_len);
        p_webmail_session ->response_length = atoi(tmp);

    }
    // 取http 字符集类型
    p_value = find_key_value(m_response.HttpHeaderKeyNameValue,"Content-Type");
    if(p_value != NULL)
    {
        // 字符集类型
        m_response.CentextLangth. buf_begin  = p_value-> buf_begin ;
        m_response.CentextLangth. space_use_len  = p_value-> space_use_len ;
        m_response.CentextLangth. Nextbuf  = NULL;
    }
    return true;
}


