// Last Update:2015-12-27 10:04:57
/**
 * @file unic_to_utf8_str.cpp
 * @brief 
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-12-16
 */
//将一个字符串中所有unicode字面值转为utf-8存入string中
#include "unic_to_utf8_str.h"
bool unic_to_utf8_str_cls :: unic_to_utf8_str()
{
    char *p_pos = const_cast<char*>(m_p_buf);
    char *p_type = NULL;
    while(1)
    {
        p_type = p_pos;
        p_pos = strstr(p_pos, "\\u");
        if(NULL != p_pos && p_pos < m_p_buf + m_len)
        {
            if(p_type == p_pos)
            {
                char *p_tmp = p_pos + 2;
                uint32_t i = 0;
                /*
                for(;; ++i)
                {
                    if((*(p_tmp + i) < '0') || (*(p_tmp + i) > '9' && *(p_tmp + i) < 'A') || 
                    (*(p_tmp + i) > 'Z' && *(p_tmp + i) < 'a') || (*(p_tmp + i) > 'z'))
                        {
                            break;
                        }
                }
                */
                p_pos = p_tmp + 4;
                i = 4;
                if(unic_to_utf8_str_cls :: str_to_hex(p_tmp, i))
                {
                    char tmp_array[6] = {'\0','\0','\0','\0','\0','\0'};
                    int byte_number = unicode_to_utf8(i,(unsigned char *)tmp_array, 6);
                    m_str_out.insert(m_str_out.end(), tmp_array, tmp_array + byte_number);
                }
            }
            else
            {
                m_str_out.insert(m_str_out.end(), p_type, p_pos);
            }
        }
        else
        {
            m_str_out.insert(m_str_out.end(), p_type, const_cast<char *>(m_p_buf) + m_len);
            break;
        }
    }
    return true;
}
bool unic_to_utf8_str_cls:: str_to_hex(char * p_char, uint32_t& len)
{
    uint32_t result = 0;
    for(uint32_t i =0; i!= len; ++i)
    {
        if(*(p_char + i) >= '0' && *(p_char + i) <= '9')
        {
            result += (*(p_char + i) - '0') * pow(16, len - 1 - i);
        }
        else if(*(p_char + i) >= 'A' && *(p_char + i) <= 'Z')
        {
            result += (*(p_char + i) - 55) * pow(16, len - 1 - i);
        }
        else if(*(p_char + i) >= 'a' && *(p_char + i) <= 'z')
        {
            result += (*(p_char + i) - 87) * pow(16, len - 1 - i);
        }
    }
    len = result;
    return true;
}

