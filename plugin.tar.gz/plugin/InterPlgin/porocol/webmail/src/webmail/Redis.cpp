// Last Update:2015-11-16 08:34:53
/**
 * @file Redis.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-08-19
 */
#include <sstream>
#include <stdlib.h>
#include "Redis.h"

void itoa(uint64_t n, string& str)
{
    std ::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}



Redis::Redis(string redis_host, int redis_port)
{
    connect_ = NULL;
    reply_  = NULL;
    host = redis_host;
    port = redis_port;
//    mail_expire_time = expire_time;
}

Redis::~Redis()
{
    if(connect_!=NULL)
        redisFree(connect_);
    connect_ = NULL;
    reply_  = NULL;
    host = "";
}




bool Redis::connect ()
{
    if(connect_!=NULL)
    {
        redisFree(connect_);
        connect_ = NULL;
    }
    connect_ = redisConnect(host.c_str(), port);
//    if(this->connect_ != NULL && connect_->err)
    if(connect_->err)
    {
        redisFree(connect_);
        connect_ = NULL;
        return false;
    }
    return true;
}


bool Redis::check_connection()
{
    if(connect_ == NULL)
        return false;
    reply_ = (redisReply *)redisCommand(connect_,"PING");
    if(reply_ == NULL)
    {
        redisFree(connect_);
        connect_ = NULL;
      //  printf("Redis connetion loss!\n");
        return false;
    }
    if(!(reply_->type == REDIS_REPLY_STATUS && strcmp(reply_->str,"PONG")==0))
    {
        redisFree(connect_);
        connect_ = NULL;
       // printf("Redis connetion loss!\n");
//        printf("%s\n",reply_->str);
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
    else
    {
        //printf("Redis connection is OK!\n");
        freeReplyObject(reply_);
        reply_ = NULL;
        return true;
    }
}



bool Redis::select(int database_id)
{
    reply_ = (redisReply *)redisCommand(connect_,"SELECT %d",database_id);
    if(reply_ == NULL)
    {
        //printf("Redis connetion loss!\n");
        return false;
    }
    else if(!(reply_->type == REDIS_REPLY_STATUS && strcmp(reply_->str,"OK")==0))
    {
        //printf("Redis select reply error!\n");
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
    freeReplyObject(reply_);
    reply_ = NULL;
    //printf("Databse:%d \n",database_id);
    return true;
}




bool Redis::set(std::string key , std::string value)
{
    reply_ = (redisReply *)redisCommand(connect_ , "SET %s %s",key.c_str(),value.c_str());
    if(reply_ == NULL)
    {
        //printf("Redis connetion loss!\n");
        return false;
    }
    else if(!(reply_->type == REDIS_REPLY_STATUS && strcmp(reply_->str,"OK")==0))
    {
        //printf("Redis set reply error!\n");
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
    freeReplyObject(reply_);
    reply_ = NULL;
    return true;
}




bool Redis ::set(std::string key, std::string value, int expire_time)
{
//    redisCommand(connect_ , "SET %s %s",key.c_str(),value.c_str());
//    redisCommand(connect_ , "EXPIRE %s %d", key.c_str(), expire_time);
    reply_ = (redisReply *)redisCommand(connect_ , "SETEX %s %d %s",key.c_str(),expire_time,value.c_str());
    if(reply_ == NULL)
    {
        //printf("Redis connetion loss!\n");
        return false;
    }
    else if(!(reply_->type == REDIS_REPLY_STATUS && strcmp(reply_->str,"OK")==0))
    {
        //printf("Redis set reply error!\n");
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
    freeReplyObject(reply_);
    reply_ = NULL;
    return true;

}


bool Redis::set(std::string key, uint64_t value, int expire_time)
{
    string str;
    itoa(value,str);
    return(set(key,str,expire_time));
}

bool Redis::set(std::string key, uint64_t value)
{
    string str;
    itoa(value,str);
    return(set(key,str));
}


bool Redis::get(std::string key ,std::string & value)
{
    reply_ = (redisReply *) redisCommand(connect_ , "GET %s",key.c_str());
    if(reply_ == NULL)
    {
   //     printf("Redis connetion loss!\n");
        return false;
    }
    else if(!(reply_->type == REDIS_REPLY_STRING && reply_->str!=NULL))
    {
    //    printf("Redis get reply error!\n");
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
    value = reply_ -> str;
    freeReplyObject(reply_);
    reply_ = NULL;
    return true;
}


bool Redis::add_data(int database_id, std::string key,std::string value,int expire_time)
{
    if(!check_connection())
    {
        if(!connect())
        {
     //       printf("Redis connect error!\n");
            return false;
        }
    }
    if(!select(database_id))
    {
      //  printf("Select error!\n");
        return false;
    }
    if(expire_time == 0)
        return (set(key,value));
    else
        return (set(key,value,expire_time));

}


bool Redis::add_data(int database_id, std::string key,uint64_t value,int expire_time)
{
    if(!check_connection())
    {
        if(!connect())
        {
       //     printf("Redis connect error!\n");
            return false;
        }
    }
    if(!select(database_id))
    {
        //printf("Select error!\n");
        return false;
    }
    if(expire_time == 0)
        return (set(key,value));
    else
        return (set(key,value,expire_time));
}

bool Redis::get_data(int database_id, std::string key, std::string & value)
{
    if(!check_connection())
    {
        if(!connect())
        {
         //   printf("Redis connect error!\n");
            return false;
        }
    }
    if(!select(database_id))
    {
       // printf("Select error!\n");
        return false;
    }
    return (get(key,value));
}

void Redis::display_database(int database_id)
{
    select(database_id);
    reply_ = (redisReply *)redisCommand(connect_ , "KEYS *");
    for(int i=0;i<reply_->elements;i++)
    {
        redisReply* childReply = reply_->element[i];
        if (childReply->type == REDIS_REPLY_STRING)
        {
      //      printf("*Key* %s.\n",childReply->str);
        }
    }
    freeReplyObject(reply_);
    reply_ = NULL;
    return;
}


bool Redis::delete_data(int database_id ,string key)
{
    if(!check_connection())
    {
        if(!connect())
        {
       //     printf("Redis connect error!\n");
            return false;
        }
    }
    if(!select(database_id))
    {
        //printf("Select error!\n");
        return false;
    }
    reply_ = (redisReply *) redisCommand(connect_ , "DEL %s",key.c_str());
    if(reply_ == NULL)
    {
        //printf("Redis connetion loss!\n");
        return false;
    }
    else if(reply_->type == REDIS_REPLY_INTEGER && reply_->integer==1)
    {
//        printf("Redis get reply error!\n");
       // printf("Delete %s successfully!\n",key.c_str());
        freeReplyObject(reply_);
        reply_ = NULL;
        return true;
    }
    else
    {
        freeReplyObject(reply_);
        reply_ = NULL;
        return false;
    }
}


void Redis::flushall()
{
    reply_ = (redisReply *)redisCommand(connect_ , "FLUSHALL");
    freeReplyObject(reply_);
    reply_ = NULL;
    printf("Flush all database!\n");
    return;
}





void Redis::flush(int database_id)
{
    select(database_id);
    reply_ = (redisReply *)redisCommand(connect_ , "FLUSHDB");
    freeReplyObject(reply_);
    reply_ = NULL;
    printf("Database %d flush!\n");
    return;
}



bool Redis::find_keys_num(int database_id, std::string key,int &num)
{
    if(!check_connection())
    {
        if(!connect())
        {
        //    printf("Redis connect error!\n");
            return false;
        }
    }
    if(!select(database_id))
    {
        //printf("Select error!\n");
        return false;
    }
    reply_ = (redisReply *) redisCommand(connect_ , "KEYS %s*",key.c_str());
    if(reply_ == NULL)
    {
        //printf("Redis connetion loss!\n");
        return false;
    }
    num = reply_ ->elements;
    freeReplyObject(reply_);
    reply_ = NULL;
    return true;
}
