// Last Update:2016-03-30 10:37:51
/**
 * @file function.h
 * @brief this is a class which contains a plenty of functions
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-11-13
 */

#ifndef FUNCTION_H
#define FUNCTION_H
#include <iostream>
#include <string>
#include <cstring>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
using namespace std;
class cl_function
{
public:
    static char * abstract(const char *p_source, const uint32_t source_length, uint32_t& desti_length, const char *p_start_flag, char * *pp_end_flag = NULL);//在源缓冲区中查询标志字符串p_flag后p_end_flag之前的内容,
                                                                                                                                                   //并由desti_length通过引用将内容长度带出函数(在client_data状态下使用,
                                                                                                                                                   //针对要提取的内容有开始标志，结束标志可以有也可以没有)。
    static char * abstract(const char *p_source, const uint32_t source_length, uint32_t& desti_length, char ** pp_end_flag );//在缓冲区中查找以p_end_flag为结尾的内容，该标志为如果没有则将整个缓冲区视为需要传输的内容
                                                                                                                   //(在client_data_continue状态下使用)。
    static uint32_t to_int(const char* p_char);//将一个char型的变量转换为对应字面值的整数。
    static string to_string(const size_t & input);//将一个整型数变为相应的字符串(string型)。
    static char * mystrchar(const char * p_const_source, const uint32_t source_length, const char *p_const_desti);//在源缓冲去中查找给定字符串的内容，并且返回其位置,可以单独在响应报文中使用,前提是明确知道内容的长度。
};
#endif  /*FUNCTION_H*/
