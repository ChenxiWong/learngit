// Last Update:2015-05-08 09:55:24
/**
 * @file http_header_parse.h
 * @brief  解析http 头成 key -value 模式 ，直到遇到 /r/n/r/n 为止 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-29
 */

#ifndef HTTP_HEADER_PARSE_H
#define HTTP_HEADER_PARSE_H
#include "shttp_common.h"
class  http_head_parse {
public:
    int key_header_parse(char * & parsepos ,char * p_end, int * pint ,s_key_value* & p_head);
};


#endif  /*HTTP_HEADER_PARSE_H*/
