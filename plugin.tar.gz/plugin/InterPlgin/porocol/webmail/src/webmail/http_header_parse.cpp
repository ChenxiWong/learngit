// Last Update:2015-05-15 15:45:09
/**
 * @file http_header_parse.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-29
 */
#include "http_header_parse.h"
#include <string.h>
int http_head_parse::key_header_parse(char * & parsepos ,char * p_end, int * pint,s_key_value* & p_head ) {
    s_key_value *pkey = NULL;
    s_key_value *pT= NULL;
    *pint = dRStateKeyBegin; 
    for(;parsepos<p_end; parsepos ++)
    {
        switch(*pint)
        {
            case dRStateKeyBegin:

                if(*parsepos==0x20  )
                {
                    if((parsepos +1)!= p_end) parsepos ++;
                }
                pkey = new s_key_value; 
                memset (pkey,0x0,sizeof(s_key_value));
                pkey->name.buf_begin = parsepos;
                pkey->name.space_use_len= 1;
                pkey->link = NULL;
                if(p_head == NULL || pT == NULL)
                {
                    p_head = pkey;
                    pT = p_head;
                }
                else {
                    pT->link = pkey;
                    pT = pT -> link;
                }
                *pint = dRStateKeyName;
                break;
            case dRStateKeyName:
                for(;parsepos!=p_end; parsepos ++)
                {
                    if(*parsepos == ':')
                    {
                        *pint = dRStateKeyNameONValue;
                        break;
                    }
                    else
                    {
                        pkey->name.space_use_len++;
                    }
                }
                break;
            case dRStateKeyNameONValue:
                if(*parsepos==0x20  )
                {
                    if((parsepos +1)!= p_end) parsepos ++;
                }
                pkey->value.buf_begin = parsepos;
                pkey->value.space_use_len= 1;
                *pint = dRStateKeyValue;
                break;
            case dRStateKeyValue:
                for(;parsepos!=p_end; parsepos ++)
                {
                    if(*parsepos == '\r')
                    {
                        *pint = dRStateKeyValueEnd1;
                        break;
                    }
                    else
                    {
                        pkey->value.space_use_len++;
                    }
                }
                break;
           case dRStateKeyValueEnd1:
                if(*parsepos != '\n')
                {
                    *pint = dRStateError;
                    break;
                }
            case dRStateKeyValueEnd2:
                if(*(parsepos+1) == '\r') {
                    parsepos++;
                    *pint = dStateHeaderEnd1;
                }
                else *pint = dRStateKeyBegin;
                break;
            case dStateHeaderEnd1:
                if(*parsepos == '\n')
                {
                    parsepos ++;
                    // 文本数据 
               //     TextVesionPos(pSess , parsepos );|   
                    *pint = dStateText;
                    return PASER_CONTINUE;
                }
                else *pint = dRStateError;
                break;
            default :
                return PASER_CONTINUE;
        }
    }
    return BUF_END;
}

