//
//
//  @ Project : Untitled
//  @ File Name : http_cookie_analyzer.h
//  @ Date : 2015/5/21
//  @ Author :wangxiang
//
//

#if !defined(_HTTP_COOKIE_ANALYSIS_H)
#define _HTTP_COOKIE_ANALYSIS_H

#include "shttp_common.h" 
//using namespace std;

class http_cookie_analyzer {
    public:
        http_cookie_analyzer();
        ~http_cookie_analyzer();
        static int CookieParse(c_http_str * buf,s_key_value * &pHead);
        static int SetCookieParse(c_http_str * buf,s_key_value * &pHead);
};

#endif  //_http_cookie_analyzer_H
