// Last Update:2016-04-05 14:28:47
/**
 * @file cloud_parse.cpp
 * @brief 
 * @author renzehong
 * @version 0.1.00
 * @date 2015-11-11
 */
#include "cloud_parse.h"
/* operation : 1、add "identity.h" to this file;
 *             2、add "commit_tools.h" to this file.
 * purpose:1、 The reason for 1st operation is to use the function
 *         baptized urldecode involved  in  identity.h file.
 *         2、The reason for 2nd operation is to use the function
 *         baptized base64_decode involved in commit_tools.h file.
 * data 2015-12-08
 * operator wangchenxi
 */
#include "identity.h"
#include "commit_tools.h"
extern "C"{
#include <string.h>
}

#define DEBUG1
void init_cloud()
{
    map_marge :: get_instance() -> add_node_map("response_handle_cloud_att", cloud_parse :: response_handle_cloud_att);//处理云盘的响应体
    map_marge :: get_instance() -> add_node_map("request_handle_cloud_att",  cloud_parse :: request_handle_cloud_att);//处理云盘的请求体
    map_marge :: get_instance() -> add_node_map("response_donothing_cloud_att",  cloud_parse :: response_donothing_cloud_att);//处理云盘的请求体
    map_marge :: get_instance() -> add_node_map("request_second_cloud_att",  cloud_parse :: request_second_cloud_att);//处理云盘的请求体
    map_marge :: get_instance() -> add_node_map("cookie_send_nothing",  cloud_parse :: request_nosend_cloud_att);//限制cookie函数向后发送
    /******************************** the following added by wangchenxi *********************************
     *date 2015-12-07
     * brief 金山快盘解析处理函数（网页版）
     * author wangchenxi
     */
    map_marge::get_instance()->add_node_map("request_kuaipan_property", cloud_parse::request_kuaipan_property); // 提取用户ID标识和文件名
    map_marge::get_instance()->add_node_map("response_kuaipan_property", cloud_parse::response_kuaipan_property);//提取上传文件ID（fileid）
    map_marge::get_instance()->add_node_map("response_kuaipan_property_download",cloud_parse::response_kuaipan_property_download); //提取下载文件的文件名
    map_marge::get_instance()->add_node_map("turn_session_state",cloud_parse::turn_client_state_to_server_state);
    // added by wangchenxi
    /**************************** What added by wangchenxi temporarily stop here. ************************/
    /******************************** the following added by cuixiaobo begin*********************************
     *date 2015-12-21
     * brief 360快盘解析处理函数（网页版）
     * author cuixiaobo
     */
    // 360组包函数
    map_marge::get_instance()->add_burs_map("clouddisk360_response_att", cloud_parse::burs_360_get_acc); // 应答包

    //360数据处理函数
    map_marge::get_instance()->add_node_map("url_get_info", cloud_parse::http_requst_urlparam_parse);//提取MD5
    map_marge::get_instance()->add_node_map("request_info_handle", cloud_parse::requset_info_handle); // 请求包处理函数

    map_marge::get_instance()->add_node_map("client_get_info", cloud_parse::client_get_info); // 请求包处理函数
    map_marge::get_instance()->add_node_map("response_parse_handle", cloud_parse::clouddisk360_response_parse_handle); // 应到包处理函数
    // added by cuixiaobo
    /**************************** What added by cuixiaobo temporarily end. ************************/
}

bool cloud_parse::response_handle_cloud_att(session *p_session, webmail_session *p_webmail_session, 
        s_http_request *p_request, s_http_response *p_response, 
        node_value_list& v_list)//下载baidu云的附件
{
    parse_value *p_parse_value = p_webmail_session -> p_parse_value;
    p_parse_value -> parse_type = CLOUD; //处理云盘的流
    if(p_webmail_session -> state == server_data)//响应体第一个数据包中(状态为server_data)，在该状态下从map表中提取Content-Disposition，
        //并从中提取filename放入value_map中。
    {
        
        /*
        string str_key_super  = "response_head_key_superfile";
        parse_value_map ::iterator iter_super = p_parse_value -> value_map.find(str_key_super);//查看表中是否存在superfile标签，如果存在则判断其值是否为0是框架现在无法处理的情况
        if(iter_super != p_parse_value -> value_map.end())
        {
            string str_tmp_super = iter_super -> second;
            if(str_tmp_super != "0")
            {
            p_parse_value -> value_map.insert(pair<string, string>("baidu_resource_filename", str_name));
            }

        }

*/

        (p_parse_value -> value_map)["baidu_is_upload"] = "0";
        (p_parse_value -> value_map)["app_type_baidu"] = "1";
        (p_parse_value -> value_map)["baidu_resource_range"] = "4294967295";//0xFFFFFFFF表示不是分端口发送的情况。
        if(p_webmail_session -> requst_time == 0)//request_time
        {
            p_webmail_session -> requst_time = p_session -> packet_time;
        }
        string str_key  = "response_head_key_Content-Disposition";
        //string str_key1 = "response_head_key_Content-Encoding";//这个字段是指明是否经过了编码处理。目前并未发现，所以是保留项
        string str_key1 = "response_head_key_Content-Length";
        parse_value_map ::iterator iter = p_parse_value -> value_map.find(str_key);//查找表中的Content-Dispositon后的内容，并从中提取filename
        string str_name ;
        string str_name_1;
        string str_tmp;
        if(iter != p_parse_value -> value_map.end())
        {
            str_tmp = iter -> second;
            string ::size_type  size = str_tmp.find("filename=");
            if(size != string :: npos && (size + 10) < str_tmp.length())
            {
                char *p_content = new char [256];
                int content_length = 0;
                if(str_tmp.length() < (size + 11))
                {
                    delete [] p_content;
                    p_content = NULL;
                    SET_SESSION_OVER(p_session );
                    return true;
                }
                str_name = string(str_tmp, size + 10, str_tmp.length() - size - 11);
                content_length = UrlDecode(const_cast<char*>(str_name.c_str()), str_name.size(), p_content, 256);
                if(content_length > 256)
                {
                    delete [] p_content;
                    p_content = NULL;
                    SET_SESSION_OVER(p_session);
                    return true;
                }
                str_name.assign(p_content, content_length - 1);
                delete [] p_content;
                p_content = NULL;
            }
            else
            {
                str_name = str_tmp;
            }
        }
        if(str_name.length() > 0)
        {
            p_parse_value -> value_map.insert(pair<string, string>("baidu_resource_filename", str_name));
        }
        p_webmail_session -> state = server_data_continue;//将状态设置为数据中继状态
        
        //查看这个数据包是不是多端口传输的一部分数据包
        string str_key_super  = "response_head_key_superfile";
        parse_value_map ::iterator iter_super = p_parse_value -> value_map.find(str_key_super);//查看表中是否存在superfile标签，如果存在则判断其值是否为0是框架现在无法处理的情况
        if(iter_super != p_parse_value -> value_map.end())
        {
            string str_tmp_super = iter_super -> second;
            if("0" != str_tmp_super )
            {
                string str_key1 = "response_head_key_Content-Range";
                parse_value_map ::iterator iter = p_parse_value -> value_map.find(str_key1);//查找表中的Content-Dispositon后的内容，并从中提取filename
                if(iter == p_parse_value -> value_map.end())
                {
                   SET_SESSION_OVER(p_session);
                   return true;
                }
                if (iter == p_parse_value -> value_map.end())
                {
                    SET_SESSION_OVER(p_session);
                    return true;
                }
                string str_range = iter -> second;
                uint32_t range_length = 0;
                char * p_tmp_range = NULL;
                char * p_end_flag = const_cast<char*> ("-");
                p_tmp_range = cl_function :: abstract(str_range.c_str(), str_range.size(), range_length, "bytes ", & p_end_flag);
                if(range_length != 0 && p_tmp_range != NULL && p_end_flag != NULL)
                {
                    str_range.assign(p_tmp_range, range_length);
                    (p_parse_value -> value_map)["baidu_resource_range"] = str_range;//修改偏移量的值，是分端口发送的情况。
                }
            }
        }
    }
    if ((uint32_t)(p_parse_value->parse_tmp_len) < (uint32_t)(p_webmail_session->response_length))
    {
        p_session -> p_send_buf = p_parse_value -> buf;
        if ((uint32_t)(p_parse_value->parse_tmp_len) + p_parse_value ->len >= (uint32_t)(p_webmail_session->response_length))
        {
            p_session -> send_len = p_webmail_session->response_length - p_parse_value->parse_tmp_len;
            p_parse_value ->  parse_tmp_len = 0;
            p_webmail_session -> b_end_send = true;
        }
        else 
        {
            p_session -> send_len = p_parse_value -> len;
            p_parse_value -> parse_tmp_len += p_parse_value -> len;
        }
        
        //string str_length = (p_parse_value -> value_map)["baidu_resource_range"];
        /*
        //是并行多端口传输，偏移量加上发送的长度。
        if(str_length != "4294967295")
        {
            size_t tmp_length = cl_function :: to_int(str_length.c_str());
            tmp_length += p_session -> send_len;
            string str_range_reset = cl_function :: to_string(tmp_length);
            (p_parse_value -> value_map)["baidu_resource_range"] = str_range_reset;//修改偏移量的值。
        }
        */
    }
    else
    {
        p_session -> p_send_buf = NO_NULL;
        p_session -> send_len = 1;
        p_parse_value -> parse_tmp_len = 0;
        p_webmail_session -> b_end_send = true;
    }
    return true;
}
//处理baidu云上传附件的过程。
bool cloud_parse::request_handle_cloud_att(session *p_session, webmail_session *p_webmail_session, 
        s_http_request *p_request, s_http_response *p_response, 
        node_value_list& v_list)//下载baidu云的附件
{
    parse_value *p_parse_value = p_webmail_session -> p_parse_value;
    p_parse_value -> parse_type = CLOUD; //处理云盘的流
    //if(client_data)如果状态是client_data,执行下几步(注意处理查找失败的情况。)
    if(p_webmail_session -> state == client_data)
    {
        (p_parse_value -> value_map)["app_type_baidu"] = "1";
        (p_parse_value -> value_map)["baidu_is_upload"] = "1";
        (p_parse_value -> value_map)["baidu_resource_range"] = "4294967295";//0xFFFFFFFF表示不是分端口发送的情况。
        (p_parse_value -> value_map)["response_head_key_x-bs-file-size"] = "0";//多端口传输其后送的完整内容长度为0，真实的完整内容长度将在一个秒传url的流中传递。
        //检查url中的uploadid,以确认是否是分端口发送的情况。
        if(0 != p_parse_value -> value_map .count("requset_urlparam_uploadid"))
        {
            string str_range = p_parse_value -> value_map["requset_urlparam_uploadid"];
            //是分多端口传输。
            if(0 == str_range.find('P'))
            {
                if(0 !=p_parse_value -> value_map.count("requset_urlparam_partseq"))
                {
                    //将提取到的多端口传输的数据块的序列号，扩大100000倍，在webmail_plugin.cpp中加上发送的内容长度作为相对偏移量使用。
                    p_parse_value -> value_map["requset_urlparam_partseq"] += "000000";
                    p_parse_value -> value_map["baidu_resource_range"] =
                    p_parse_value -> value_map["requset_urlparam_partseq"];
                }
                else
                {
                   SET_SESSION_OVER(p_session);
                   return true;
                }
            }
        }
        //  1.提取Content-Type中的boundary并压入value_map中
        if(p_webmail_session -> requst_time == 0)//request_time
        {
            p_webmail_session -> requst_time = p_session -> packet_time;
        }
        if(p_parse_value -> value_map.find("baidu_request_boundary") == p_parse_value -> value_map.end())
        {
            string str_key("requset_head_key_Content-Type");
            string str_tmp;
            string str_boundary;
            string str_name;
            parse_value_map ::iterator iter = p_parse_value -> value_map.find(str_key);//查找表中的Content-Type后的内容，并从中提取boundary
            if(iter != p_parse_value -> value_map.end())
            {
                str_tmp = iter -> second;
                string ::size_type  size = str_tmp.find("boundary=");
                if(size != string ::npos && size + 9 < str_tmp.size())
                {
                    //2.以"baidu_request_boundary"为key(默认构造为str)，以其后的标志字符串前接/r/n为value压入value_map
                    str_boundary.assign(str_tmp, size + 9, str_tmp.size() - size - 9);
                    p_parse_value -> value_map.insert(pair<string, string>("baidu_request_boundary", str_boundary));
                }
                else
                {
                    return (false);
                }
            }
            else
            {
                return (false);
            }
        }
        p_webmail_session -> state = client_data_continue;
        return true;
    }
    //if(client_data_continue) 如果状态是client_data_continue，执行以下几步
    if(client_data_continue == p_webmail_session -> state)
    {
        //3.在内容中查找文件名以"filename=\""为开始标志，以"\""为结尾，提取出文件名并进行编码转换。
        if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("baidu_download_filename"))
        {
            uint32_t content_length = 0;
            char * p_content = NULL;
            char * p_end_flag = const_cast<char*> ("\"");
            p_content = cl_function :: abstract((const char*)p_webmail_session -> p_data, p_webmail_session -> len, content_length, "filename=\"", & p_end_flag);
            //if (p_content != NULL)如果存在将结果压入到value_map中
            if(p_content != NULL)
            {
                //处理文件名为bolb的情况
                if((4 == content_length && (!strncmp(p_content, "blob", 4) || !strncmp(p_content,"name", 4))) && p_parse_value -> value_map.count("requset_urlparam_path"))
                {
                    string str_filename_tmp (p_parse_value -> value_map["requset_urlparam_path"]);
                    string :: size_type pos = str_filename_tmp.rfind('/', 0);
                    if(pos != string :: npos)
                    {
                        string str_filename_tmp_1(str_filename_tmp.begin() + pos +1, str_filename_tmp.end());//path=%2F   表示目录分割符/
                        p_parse_value -> value_map.insert(pair<string, string>("baidu_download_filename", str_filename_tmp_1));
                    }
                }
                else
                {
                    char *p_content_ = new char[256];
                    int content_length_ = 0;
                    content_length_ = UrlDecode(p_content, content_length, p_content_, 256);
                    if(content_length_ > 256)
                    {
                        delete [] p_content_;
                        p_content_ = NULL;
                        SET_SESSION_OVER(p_session);
                        return true;
                    }
                    string str_tmp_filename(p_content_, content_length_ -  1);
                    delete [] p_content_;
                    p_content_ = NULL;
                    p_parse_value -> value_map.insert(pair<string, string>("baidu_download_filename", str_tmp_filename));
                }
            }
            else
            {
                p_session -> p_send_buf = NO_NULL;
                p_session -> send_len   = 0;
                return false;
            }
        }
        //应对cookie没有的情况
        if(!p_parse_value -> value_map.count("requset_cookie_BAIDUID") && 
                p_parse_value -> value_map.count("requset_urlparam_uploadid"))
        {
            p_parse_value -> value_map["requset_cookie_BAIDUID"] =
                p_parse_value -> value_map["requset_urlparam_uploadid"];
        }
        //4.使用开始标志"octet-stream\r\n\r\n"和boundary的value作为限定标志位查找内容.
        if(1 != p_webmail_session -> had_send_len)//还没有查过开始标志
        {
            parse_value_map ::iterator iter_boundary = p_parse_value -> value_map.find("baidu_request_boundary");
            if(p_parse_value -> value_map.end() != iter_boundary)
            {
                const char *p_start_flag = "octet-stream\r\n\r\n";
                char *p_end_flag = const_cast<char *>((iter_boundary -> second).c_str());
                p_session -> p_send_buf = cl_function :: abstract((const char *)p_webmail_session -> p_data, p_webmail_session -> len, p_session -> send_len, p_start_flag, & p_end_flag);
                //(if p_send_buf != NULL) 查找到了内容
                if (p_session -> p_send_buf != NULL)
                {
                    p_webmail_session -> had_send_len = 1;//用作标志位，为1时表明开始标志位已经被查过了。
                    //if(p_end_flag != NULL)如果判断结束标志的指针不为空，结束标记找到了，
                    //内容提取完整了( p_session -> p_send_buf, p_session -> send_len已经被赋值了)
                    if(p_end_flag != NULL)
                    {
                        //p_webmail_session -> state = server_data;到应答体中提取MD5。
                        int i = 1;
                        for(;; ++i)
                        {
                            char * p_tmp = p_session -> p_send_buf + p_session -> send_len - i;
                            if(*p_tmp != '-' &&
                                    *p_tmp != '\r'&&
                                    *p_tmp != '\n')
                            {
                                break;
                            }
                        }
                        p_session -> send_len -= (i-1);
                        p_webmail_session -> state = server_data;
                        //p_webmail_session -> b_end_send = true;
                    }
                    else
                    {
                        if (0 == p_session -> send_len)
                        {
                            p_session -> p_send_buf = NO_NULL;
                            return false;
                        }
                    }
                    return true;
                }
                else
                {
                    p_session -> p_send_buf = NO_NULL;
                    p_session -> send_len   = 0;
                    return false;
                }
            }
            else
            {
                p_session -> p_send_buf = NO_NULL;
                p_session -> send_len   = 0;
                return false;
            }
        }
        parse_value_map ::iterator iter_boundary = p_parse_value -> value_map.find("baidu_request_boundary");
        if(p_parse_value -> value_map.end() != iter_boundary)
        {
            char *p_end_flag = const_cast<char *>((iter_boundary -> second).c_str());
            //1.使用只含有结束标志位的查询版本提取内容
            //（给p_session -> p_send_buf,和p_session -> send_len 赋值，如果结束标志的指针不为空，
            //就表示已经读完了，将state设置为server_data。）
            p_session -> p_send_buf = cl_function :: abstract((const char *)p_webmail_session -> p_data, p_webmail_session -> len, p_session -> send_len, & p_end_flag);
            if (NULL != p_session -> p_send_buf)
            {
                if (NULL != p_end_flag )
                {
                    int i = 1;
                    for(;; ++i)
                    {
                        char * p_tmp = p_session -> p_send_buf + p_session -> send_len - i;
                        if (*p_tmp != '-' && 
                                *p_tmp != '\r' && 
                                *p_tmp != '\n')
                        {
                            break;
                        }
                    }
                    p_session -> send_len -= (i-1);
                    p_webmail_session -> state = server_data;
                    //p_webmail_session -> b_end_send = true;
                }
            }
            return true;
            //如果value_map查找不到filename就执行查找
        }
        else
        {
            p_session -> p_send_buf = NO_NULL;
            p_session -> send_len   = 0;
            return false;
        }
    }
    return true;
}
bool cloud_parse::response_donothing_cloud_att(session *p_session, webmail_session *p_webmail_session, 
        s_http_request *p_request, s_http_response *p_response, 
        node_value_list& v_list)//下载baidu云的附件
{
    p_webmail_session -> b_end_send = true;
    p_session -> p_send_buf = NO_NULL;
    p_session -> send_len   = 1;
    return true;
}
//处理多端口上传单独提取文件总长度的情况
bool cloud_parse :: request_second_cloud_att(session *p_session, webmail_session *p_webmail_session,
        s_http_request *p_request, s_http_response *p_response,
        node_value_list& v_list)
{
    parse_value *p_parse_value = p_webmail_session -> p_parse_value;
    p_parse_value -> parse_type = CLOUD; //处理云盘的流
    //先将流状态设置为client_data_continue
    p_webmail_session -> state = client_data_continue;//将状态设置为数据中继状态
    (p_parse_value -> value_map)["app_type_baidu"] = "1";
    (p_parse_value -> value_map)["baidu_is_upload"] = "1";
    (p_parse_value -> value_map)["baidu_resource_range"] = "0";//非多端口传输，只传输文件长度。
    int flag = 0;
    if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("baidu_upload_mode_choise"))
    {
        uint32_t content_length = 0;
        char * p_content = NULL;
        char * p_end_flag = const_cast<char*> ("&");
        p_content = cl_function :: abstract((const char*)p_parse_value -> buf, p_parse_value -> len, content_length, "uploadid=", & p_end_flag);
        if(p_content != NULL)
        {
            //如果不是多端口传输，那么结束这个流，没必要分析。
            if(*p_content != 'P' && *p_content != 'p')
            {
                SET_SESSION_OVER(p_session);
                return true;
            }
            string str_upload_mode_choise(p_content, content_length);
            p_parse_value -> value_map.insert(pair<string, string>("baidu_upload_mode_choise", str_upload_mode_choise));
        }
    }
    if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("baidu_upload_filename"))
    {
        uint32_t content_length = 0;
        char * p_content = NULL;
        char * p_end_flag = const_cast<char*> ("&");
        p_content = cl_function :: abstract((const char*)p_parse_value -> buf, p_parse_value -> len, content_length, "path=", & p_end_flag);
        //(if p_content != NULL)如果存在将结果压入到value_map中
        if(p_content != NULL)
        {
            flag += 1;
            string str_file_name(p_content, content_length);
            str_file_name .assign(urldecode(str_file_name));
            string :: size_type pos = str_file_name.rfind('/', 0);
            if(pos != string :: npos)
            {
                string str_filename_tmp(str_file_name.begin() + pos +1, str_file_name.end());//path=%2F   表示目录分割符/
                p_parse_value -> value_map.insert(pair<string, string>("baidu_upload_filename", str_filename_tmp));
            }
        }
    }
    else
    {
        flag += 1;
    }
    if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("baidu_file_totle_size"))
    {
        uint32_t content_length = 0;
        char * p_size = NULL;
        char * p_end_flag = const_cast<char*> ("&");
        p_size = cl_function :: abstract((const char*)p_parse_value -> buf, p_parse_value -> len, content_length, "size=", & p_end_flag);
        //(if p_md5 != NULL)如果存在将结果压入到value_map中
        if(p_size != NULL)
        {
            flag += 1;
            string str_size(p_size, content_length);
            p_parse_value -> value_map.insert(pair<string, string>("baidu_file_totle_size", str_size));
        }
    }
    else
    {
        flag += 1;
    }
    //文件名和size都找齐了
    if(2 == flag)
    {
        p_webmail_session -> b_end_send = true;
        p_session -> p_send_buf = NO_NULL;
        p_session -> send_len   = 1;
        return true;
    }
	return true;
}
bool cloud_parse :: request_nosend_cloud_att(session *p_session, webmail_session *p_webmail_session,
        s_http_request *p_request, s_http_response *p_respnse,
        node_value_list& v_list)//限制cookie函数向后发送
{
    p_session -> p_send_buf = NULL;
    return true;
}


/************** the following added by wangchenxi *****************/
bool get_string_from_http_context(string& aim_str,
        const char* p_buffer,
        const char* start_sign,
        const char* end_sign,
        int aim_str_start,
        int aim_str_end_to_end_sign)
{
    if(!p_buffer)
    {
        return false;
    }
    char* p_start = NULL;
    char* p_end = NULL;
    if(1 == strlen(start_sign))
    {
        char tmp = *start_sign;
        p_start = const_cast<char*>(strchr(p_buffer, tmp));
    }
    else
    {
        p_start = const_cast<char*>(strstr(p_buffer, start_sign));
    }
    if(!p_start)
    {
        return false;
    }
    if(1 == strlen(end_sign))
    {
        char tmp = *end_sign;
        p_end = strchr(p_start + aim_str_start, tmp);
    }
    else
    {
        p_end = strstr(p_start + aim_str_start, end_sign);
    }
    if(!p_end)
    {
        return false;
    }
    int aim_len = p_end - p_start - aim_str_start - aim_str_end_to_end_sign;
    if(aim_len <= 0)
    {
        return false;
    }
    string tmp_aim(p_start, aim_str_start, aim_len);
    aim_str = tmp_aim;
    return true;
}
/*
 *function: 就是将 字符串aim_str改造成你想要的字符串
 *第一个参数,你传入的字符串引用（目的是带出目的字符串）；
 *第二个参数,你想从哪里得到你要的字符串？对，就是那个最大的字符串；
 *第三个参数,开始标志字符串（一般情况为文本关键字);
 *第四个参数,结束标志字符串（同上);
 *第五个参数,目的字符串起始于开始标志字符串后面的第 aim_str_start 位;
 *第六个参数,目的字符串起始于结束标志字符串前面的第 aim_str_end_to_end_sign 位。
 *********************************************
 *date 2015-12-07
 * brief 金山快盘解析处理函数（网页版）
 * author wangchenxi
 */


// 金山快盘解析处理函数 （上传解析用户ID和文件名)
bool cloud_parse::request_kuaipan_property(session *p_session,
        webmail_session *p_webmail_session,
        s_http_request *p_request,
        s_http_response *p_respnse,
        node_value_list& v_list)
{
    parse_value *p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char *p_buf = (char*)p_session->client.get_tcp_data(buf_len);
    if(p_buf == NULL)
    {
        return true;
    }
    p_parse_value->parse_type = CLOUD;
    string content_length_name = "request_kuaipan_body_Content-Length";
    if (p_webmail_session->state == client_data)
    {
        string str_content_length ="";
        if(!get_string_from_http_context(str_content_length, p_buf, "Content-Length:", "\r\n", 15, 0))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        int int_content_length = atoi(str_content_length.c_str());
        char* p_body_start = strstr(p_buf, "\r\n\r\n") + 4;
        int body_len = buf_len - (p_body_start - p_buf);
        if(body_len < int_content_length)
        {
            p_parse_value->value_map.insert(pair<string,string>(content_length_name, str_content_length));
            p_webmail_session->state = client_data_continue;
            return true;
        }
        string svalue = "";
        if(!get_string_from_http_context(svalue, p_body_start, "name=", "&", 5, 0))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        string name = "requset_kuaipan_file_name";
        string goods = urldecode(svalue);
        svalue = goods;
        p_parse_value->value_map.insert(pair<string,string>(name, svalue));
    }
    else if(p_webmail_session->state == client_data_continue)
    {
        parse_value_map::iterator iter_1 = p_parse_value->value_map.find(content_length_name);
        if(iter_1 != p_parse_value->value_map.end())
        {
            uint32_t content_length_tmp = atoi(iter_1->second.c_str());
            //char* p_body_start = strstr(p_buf, "\r\n\r\n") + 4;
            //int body_len = buf_len - (p_body_start - p_buf);
            if(buf_len < content_length_tmp)
            {
                return true;
            }
            string svalue = "";
            if(!get_string_from_http_context(svalue, p_buf, "name=", "&", 5, 0))
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
            string name = "requset_kuaipan_file_name";
            string goods = urldecode(svalue);
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name, svalue));
        }
        else
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
    }
    string user_id = "requset_cookie_token";
    parse_value_map::iterator iter = p_parse_value->value_map.find(user_id);
    if (iter != p_parse_value->value_map.end())
    {
        string svalue(iter->second, 0, 8); // 用 token 前8位代表用户ID标识，来区分
        string goods = urldecode(svalue);//url 解码
        svalue = goods;
        p_parse_value->value_map.insert(pair<string, string>("requset_cookie_token_end", svalue));
        p_webmail_session->state = server_data;
        p_parse_value->value_map.insert(pair<string,string>("Kingsoft_kuaipan_type", "3"));
        return true;
    }
    p_session->send_len = 0;
    p_session->p_send_buf = NO_NULL;
    return false;
}

// 金山快盘解析处理函数  （“上传”解析文件fn  对应file_name）
bool cloud_parse::response_kuaipan_property(session *p_session,webmail_session *p_webmail_session,
        s_http_request *p_request,
        s_http_response *p_respnse,
        node_value_list& v_list )
{
    parse_value *p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char *p_buf = (char*)p_session->server.get_tcp_data(buf_len);
    if(p_buf == NULL)
    {
        return true;
    }
    p_parse_value->parse_type = CLOUD;
    string content_length_name = "response_kuaipan_body_Content-Length";
    if(p_webmail_session->state == server_data)
    {
        string str_content_length ="";
        if(!get_string_from_http_context(str_content_length, p_buf, "Content-Length:", "\r\n", 15, 0))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        int int_content_length = atoi(str_content_length.c_str());
        p_webmail_session ->response_length = int_content_length;
        char* p_body_start = strstr(p_buf, "\r\n\r\n") + 4;
        int body_len = buf_len - (p_body_start - p_buf);
        if(body_len < int_content_length)
        {
            p_parse_value->value_map.insert(pair<string,string>(content_length_name, str_content_length));
            p_webmail_session->state = server_data_continue;
            return true;
        }
        string svalue = "";
        if(!get_string_from_http_context(svalue, p_buf, "fileId", "\"", 9, 0))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        string name = "response_kuaipan_fileId";
        string goods = urldecode(svalue);
        svalue = goods;
        p_parse_value->value_map.insert(pair<string,string>(name, svalue));
    }
    else if(p_webmail_session->state == server_data_continue)
    {
        parse_value_map::iterator iter_1 = p_parse_value->value_map.find(content_length_name);
        if(iter_1 != p_parse_value->value_map.end())
        {
            char* p_body_start = strstr(p_buf, "\r\n\r\n") + 4;
            int body_len = buf_len - (p_body_start - p_buf);
            int content_length_tmp = atoi(iter_1->second.c_str());
            if(body_len< content_length_tmp)
            {
                return true;
            }
            string svalue = "";
            if(!get_string_from_http_context(svalue, p_buf, "fileId", "\"", 9, 0))
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
            string name = "response_kuaipan_fileId";
            string goods = urldecode(svalue);
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name, svalue));
        }
    }
    p_parse_value->value_map.insert(pair<string,string>("Kingsoft_kuaipan_up_type", "1"));
    p_webmail_session -> b_end_send = true;
    p_session -> p_send_buf = NO_NULL;
    p_session -> send_len = 1;
    return true;
}

// 金山快盘解析处理函数  （下载提取文件名）
bool cloud_parse::response_kuaipan_property_download(session* p_session ,
        webmail_session* p_webmail_session,
        s_http_request* p_request,
        s_http_response* p_response,
        node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->server.get_tcp_data(buf_len);
    if(p_buf == NULL)
    {
        return true;
    }
    string content_length_name = "response_kuaipan_body_download_Content-Length";
    p_parse_value->parse_type = CLOUD;
    if(p_webmail_session->state == server_data)
    {
        string str_content_length = "";
        if(!get_string_from_http_context(str_content_length, p_buf, "Content-Length:", "\r\n", 15, 0))
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        int int_content_length = atoi(str_content_length.c_str());
        p_webmail_session ->response_length = int_content_length;
        char* p_body_start = strstr(p_buf, "\r\n\r\n");
        int body_len = buf_len - (p_body_start - p_buf);
        if(body_len < int_content_length )
        {
            p_parse_value->value_map.insert(pair<string, string>(content_length_name, str_content_length));
            p_webmail_session->state = server_data_continue;
            return true;
        }
        string svalue = "";
        if(!get_string_from_http_context(svalue, p_body_start, "fn","&", 3, 0))
        {
            p_parse_value->value_map.insert(pair<string, string>(content_length_name, str_content_length));
            p_webmail_session->state = server_data_continue;
            return false;
        }
        string name = "response_kuaipan_download_fn";
        int i = 0;
        svalue = base64_decode(svalue.c_str(),svalue.length(), i);
        p_parse_value->value_map.insert(pair<string, string>(name, svalue));
    }
    else if( p_webmail_session->state == server_data_continue)
    {
        parse_value_map::iterator iter_1 = p_parse_value->value_map.find(content_length_name);
        if(iter_1 != p_parse_value->value_map.end())
        {
            int content_length_tmp = atoi(iter_1->second.c_str());
            char* p_body_start = strstr(p_buf, "\r\n\r\n");
            int body_len = buf_len - (p_body_start - p_buf);
            if(body_len < content_length_tmp)
            {
                return true;
            }
            string svalue = "";
            if(!get_string_from_http_context(svalue, p_buf, "fn","&", 3, 0))
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
            string name = "response_kuaipan_download_fn";
            int i = 0;
            svalue = base64_decode(svalue.c_str(),svalue.length(), i);
            p_parse_value->value_map.insert(pair<string, string>(name, svalue));
        }
        else
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
    }
    string user_id = "requset_cookie_token";
    parse_value_map::iterator iter = p_parse_value->value_map.find(user_id);
    if (iter != p_parse_value->value_map.end())
    {
        string svalue(iter->second, 0, 8); // 用 token 前8位代表用户ID标识，来区分
        string goods = urldecode(svalue);//url 解码
        svalue = goods;
        p_parse_value->value_map.insert(pair<string, string>("requset_cookie_token_end", svalue));
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NO_NULL;
        return false;
    }
    string file_id = "requset_urlparam_id";
    parse_value_map::iterator iter_1 = p_parse_value->value_map.find(file_id);
    if (iter_1 != p_parse_value->value_map.end())
    {
        string svalue(iter_1->second, 0, 21);
        string goods = urldecode(svalue);//url 解码
        svalue = goods;
        p_parse_value->value_map.insert(pair<string, string>("requset_urlparam_id_end", svalue));
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NO_NULL;
        return false;
    }
    p_parse_value->value_map.insert(pair<string,string>("Kingsoft_kuaipan_type", "3"));
    p_parse_value->value_map.insert(pair<string,string>("Kingsoft_kuaipan_up_type", "0"));
    p_webmail_session -> b_end_send = true;
    p_session -> p_send_buf = NO_NULL;
    p_session -> send_len = 1;
    return true;
}

bool cloud_parse::turn_client_state_to_server_state(session *p_session,
        webmail_session *p_webmail_session,
        s_http_request *p_request,
        s_http_response *p_respnse,
        node_value_list& v_list)
{
    p_webmail_session->state = server_data;
    return true;
}
/**************************** What added by wangchenxi stop here. ******************************/

/************** the following added by cuixiaobo *****************/
//在源缓冲去中查找给定字符串的内容，并且返回其位置,可以单独在响应报文中使用,前提是明确知道内容的长度。
char * mysubstr(const char * p_source, const uint32_t  source_length, const char *p_desti)
{
    if(p_source == NULL || source_length < 0 || p_desti == NULL)
    {
        return NULL;
    }
    int desti_length = strlen(p_desti);
    char *p_cur = const_cast<char*>(p_source);
    int last_position = source_length - desti_length + 1;
    for(int i = 0; i < last_position; ++i, ++p_cur)
    {
        if(*p_cur == *p_desti)
        {
            if(memcmp(p_cur, p_desti, desti_length) == 0)
            {
                return p_cur;
            }
        }
    }
    return NULL;
}


/** @brief  下载组包函数
 *
 * bool cloud_parse::burs_360_get_acc(session* p_session,c_packet* p_packet)
 *
 *
 *  @param session* p_session 数据组包类
 *         c_packet* p_packet 得到到数据包
 *
 *  @return
 *  @note
 */
bool cloud_parse::burs_360_get_acc(session* p_session,c_packet* p_packet)
{
    char * p_data = (char *)p_packet->p_app_data;
    uint32_t seq = p_packet->get_seqnumber();
    uint16_t len = p_packet->app_data_len ;

    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if( p_webmail_session ->b_c2s )
    {
        if( p_webmail_session ->b_add_end)
        {
            p_webmail_session ->b_end_send = true;
            // ---
            p_webmail_session -> state = client_data;
        }
        return true;
    }
    // 判断是否不是第一次收取数据 //包括头  判断头是否结束
    if(p_webmail_session -> state == server_data)
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);

        if(p_webmail_session->len > 0)
        {
            p_webmail_session->p_data[p_webmail_session->len] =0x0;
        }
        else
        {
            return false;
        }

        char * p_end = strstr((char *)p_webmail_session->p_data,"\r\n\r\n");
        if(p_end != NULL) // http 头接受完毕  ，到出数据clouddisk360_parse.cpp
        {
            return true;
        }
        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            return true;
        }
    }
    else if  (p_webmail_session -> state == server_data_continue)
    {
        p_session->server.add_tcp_packet(len,p_data,seq);
        p_webmail_session->p_data= (uint8_t *)p_session->server.get_tcp_data(p_webmail_session->len);
        if(p_webmail_session ->response_length == 0)
        {
            char *mid = strstr((char *)p_webmail_session->p_data,"\r\n");
            if(mid == NULL)
                return true;
            int other_len = strtol((char *)p_webmail_session->p_data,&mid,16);
            p_webmail_session ->response_length = other_len ;//- rem_packet;
            return true;
        }
        if(p_webmail_session ->response_length > 0)
        {
            parse_value * p_parse_value = p_webmail_session ->p_parse_value;
            //p_parse_value->parse_tmp_len 已经处理到长度
            //p_webmail_session->len 已经缓存到长度
            if(p_webmail_session->len + p_parse_value->parse_tmp_len  >=p_webmail_session ->response_length)
            {
                return true;
            }
        }

        if(p_webmail_session->len  + MAXPACKETLEN > MAXTCPBUF )
        {
            //正文超长
            return true;
        }
    }
    return false;
}


/** @brief  从下载包中得到MD5和USER_ID
 *
 *bool cloud_parse::http_requst_urlparam_parse(session *p_session,webmail_session* p_webmail_session,
 *                            s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
 *
 *
 *  @param session* p_session 数据组包类
 *         c_packet* p_packet 得到到数据包
 *
 *  @return
 *  @note
 */
bool cloud_parse::http_requst_urlparam_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session -> p_parse_value;
    p_parse_value -> parse_type = CLOUD;
    uint32_t packet_len;

    char *buffer = NULL;
    if(p_webmail_session -> state == client_data)
    {
        if(p_parse_value->len >= p_webmail_session -> requset_length)
        {
            if( p_requst == NULL || p_response == NULL)
            {
                return true;
            }
            buffer = (char *)p_session -> client.get_tcp_data(packet_len);
            if(buffer == NULL)
            {
                return true;
            }

            string str_uid = "qid";
            string str_md5 = "fhash";
            char str_uid_key[20] = { 0 };

            if(p_parse_value->value_map.find("USER_ID") == p_parse_value->value_map.end())
            {
                char *p_str = NULL;
                char *p_end = NULL;
                p_str = strstr(buffer,"qid");
                if(p_str == NULL)
                {
                    return true;
                }
                p_end = strstr(p_str,"&");
                if(p_end == NULL)
                {
                    return true;
                }
                memcpy(str_uid_key,&p_str[4],strlen(p_str) - strlen(p_end) - 4);

                if(strlen(str_uid_key) > 0)
                {
                    p_parse_value->value_map.insert(pair<string,string>("USER_ID",str_uid_key));
                }
            }
            if(p_parse_value->value_map.find("Content-MD5") == p_parse_value->value_map.end())
            {
                char *p_str_md5 = NULL;
                char *p_end_md5 = NULL;
                char name_md5[100] = { 0 };
                if(buffer == NULL )
                {
                    return true;
                }

                p_str_md5 = strstr(buffer,"fhash");
                if(p_str_md5 == NULL)
                {
                    return true;
                }

                p_end_md5 = strstr(p_str_md5,"&");
                if(p_end_md5 == NULL)
                {
                    return true;
                }
                memcpy(name_md5,&p_str_md5[6],strlen(p_str_md5) - strlen(p_end_md5)- 6);

                if(strlen(name_md5) > 0)
                {
                    p_parse_value->value_map.insert(pair<string,string>("Content-MD5",name_md5));
                }
            }
            return true;
        }
	    return true; 
    }
	return true;
}


/** @brief  上传数据包处理函数
 *
 * requset_info_handle(session *p_session,webmail_session* p_webmail_session,
 *                      s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
 *
 *
 *  @param
 *
 *  @return
 *  @note
 */
bool cloud_parse::requset_info_handle(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value *p_parse_value = p_webmail_session -> p_parse_value;

    p_parse_value -> parse_type = CLOUD;

    if(p_webmail_session -> state == client_data)
    {
        p_webmail_session -> state = client_data_continue;

        if(p_requst == NULL || p_response == NULL)
        {
            return true;
        }

        string boundary_flag = "";

        string key1 = "requset_head_key_Content-Type";
        string tmp = "";
        string name = "";
        string str_boundary = "";

        p_parse_value->value_map.insert(pair<string,string>("app_type_360","2"));
        p_parse_value->value_map.insert(pair<string,string>("app_type_handle","1"));
        parse_value_map ::iterator iter1 = p_parse_value ->value_map.find(key1);

        if(iter1 != p_parse_value ->value_map.end())
        {
            tmp = iter1 ->second;
            uint32_t size = tmp.find("boundary=");
            if(size != string::npos && size + 9 < tmp.length())
            {
                str_boundary = string(tmp,size + 9,tmp.length() - size - 9);
            }
            else
            {
                str_boundary = tmp;
            }
        }

        if(str_boundary.length() > 0)
        {
            p_parse_value ->value_map.insert(pair<string,string>("packet_boundary",str_boundary));
        }
        else
            return false;

        p_session->client.clear_buf();
        return true;
    }

    string ori_boundary = p_parse_value ->value_map["packet_boundary"];
    string boundary = "--" + ori_boundary ;//+ "--";
    char *key4 = const_cast<char*> (boundary.c_str());
    static uint32_t first_len = 0;

    if(p_webmail_session -> state == client_data_continue)
    {
        char *file_str;
        char *file_tmp;
        string file_name = "";

        if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("USER_ID"))
        {
            char *p_qid;
            char *p_tmp;
            char *p_end;
            char p_qid_name[20] = { 0 };
            p_qid = mysubstr(p_parse_value ->buf,p_parse_value ->len, "\"qid\"");
            if(p_qid == NULL)
            {
                return false;
            }
            p_tmp = strstr(p_qid,"\r\n\r\n");
            if(p_tmp == NULL)
            {
                return false;
            }
            p_end = strstr(&p_tmp[4],"\r\n");
            if(p_end == NULL)
            {
                return false;
            }
            memcpy(p_qid_name,&p_tmp[4],strlen(p_tmp) - strlen(p_end) - 4);
            p_parse_value ->value_map.insert(pair<string,string>("USER_ID",p_qid_name));
        }
        if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("post_filename"))
        {
            file_str = mysubstr(p_parse_value ->buf,p_parse_value ->len, "filename=\"");
            if(file_str == NULL)
            {
                return false;
            }
            file_tmp = strstr(&file_str[10],"\"");
            if(file_tmp == NULL)
            {
                return false;
            }
            file_name = string(file_str,10,strlen(file_str) - 10 - strlen(file_tmp));
            string file_name_post = urldecode(file_name);
            p_parse_value ->value_map.insert(pair<string,string>("post_filename",file_name_post));
        }

        char *key3 = const_cast<char*>("\r\n\r\n");
        char *p_str = NULL;
        char *p_content_end = NULL;
        if(p_parse_value -> value_map.end() == p_parse_value -> value_map.find("content_begin"))
        {
            p_str = strstr(file_tmp, key3);

            if (p_str == NULL)
            {
                return false;
            }
            char content_begin[4] = { 0 };
            memcpy(content_begin,p_str,4);
            p_parse_value ->value_map.insert(pair<string,string>("content_begin",content_begin));

            p_str += 4;
            uint32_t content_len = p_parse_value ->len - (p_str - p_parse_value->buf);
            first_len = p_str - p_parse_value->buf;

            p_content_end = mysubstr(p_str,content_len,key4);
            //uint32_t relt = memcmp(key4,&p_str[content_len - bou_len - 2],bou_len);
            if (p_content_end != NULL)
            {
                p_session->p_send_buf = p_str;
                p_parse_value->parse_tmp_len = p_content_end - p_str - 2;
                p_session->send_len = p_parse_value->parse_tmp_len;//content_len - bou_len - 4;
                p_webmail_session -> b_end_send = true;
                //p_session->client.clear_buf();
                return true;
            }
            else
            {
                p_session->p_send_buf = p_str;
                p_parse_value->parse_tmp_len = p_parse_value ->len - first_len;//content_len - bou_len - 4;
                p_session->send_len = p_parse_value->parse_tmp_len;//content_len - bou_len - 4;
                p_session->client.clear_buf();
                return true;
            }
        }
        char *p_end = mysubstr(p_parse_value->buf,p_parse_value->len,key4);
        //uint32_t ret = memcmp(key4,&p_parse_value->buf[p_parse_value->len - bou_len - 2],bou_len);
        if(p_end != NULL)
        {
            p_parse_value->parse_tmp_len = p_end - p_parse_value->buf - 2;//p_parse_value->len - strlen(p_end) - 2;//bou_len - 6;
            //memcpy(p_session->p_send_buf,p_parse_value->buf,p_parse_value->parse_tmp_len);
            p_session->p_send_buf =  p_parse_value->buf;
            p_session->send_len = p_parse_value->parse_tmp_len ;
            p_webmail_session -> b_end_send = true;
            //p_session->client.clear_buf();
            return true;
        }

        p_session->p_send_buf =  p_parse_value->buf;
        p_parse_value->parse_tmp_len = p_parse_value->len;
        p_session->send_len = p_parse_value->parse_tmp_len;//p_parse_value->len;
        p_session->client.clear_buf();
        return true;
    }
	return true;
}


/** @brief  client下载大附件
 *
 * client_get_info(session *p_session,webmail_session* p_webmail_session,
 *                      s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
 *
 *
 *  @param
 *
 *  @return
 *  @note
 */
bool cloud_parse::client_get_info(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session -> p_parse_value;
    p_parse_value -> parse_type = CLOUD;
    uint32_t packet_len;

    char *buffer = NULL;
    if(p_webmail_session -> state == client_data)
    {
        if(p_parse_value->len >= p_webmail_session -> requset_length)
        {
            if( p_requst == NULL || p_response == NULL)
            {
                return true;
            }
            buffer = (char *)p_session -> client.get_tcp_data(packet_len);
            if(buffer == NULL)
            {
                return true;
            }
            p_parse_value->value_map.insert(pair<string,string>("app_type_360","2"));
            (p_parse_value -> value_map)["app_type_handle"] = "1";
            if(p_parse_value->value_map.find("clouddisk360_filename") == p_parse_value->value_map.end())
            {
                // string str_cookie = "requset_head_key_Cookie";
                // parse_value_map ::iterator iter = p_parse_value ->value_map.find(str_cookie);
                char *p_cookie = strstr(buffer,"Cookie:");
                if(p_cookie != NULL)//iter != p_parse_value ->value_map.end())
                {
                    //    char *temp = const_cast<char *>(iter->second.c_str());
                    //      char p_name_arr[100] = { 0 };
                    string str_name_real;// = "";
                    char *p_name_begin = strstr(p_cookie,"fname=");
                    if(p_name_begin == NULL)
                    {
                        return true;
                    }
                    char *p_name_end = strstr(p_name_begin,";");
                    if(p_name_end == NULL)
                    {
                        return true;
                    }
                    string str_name_tmp ;//= "";// = p_name_arr;
                    //                    memcpy((char *)p_name_arr,&p_name_begin[6],p_name_end - p_name_begin - 6);
                    //                    p_name_arr[p_name_end - p_name_begin - 6] = '\0';
                    str_name_tmp.insert(str_name_tmp.end(),p_name_begin + 6,(p_name_begin + (p_name_end - p_name_begin)));
                    string str_name_string = urldecode(str_name_tmp);
                    uint32_t size = str_name_string.rfind("/",str_name_string.length());
                    if(size != string::npos && size + 1 < str_name_string.length())
                    {
                        str_name_real = string(str_name_string,size + 1,str_name_string.length() - size - 1);
                    }
                    else
                    {
                        str_name_real = str_name_string;
                    }
                    if(str_name_real.length() > 0)
                    {
                        p_parse_value ->value_map.insert(pair<string,string>("clouddisk360_filename",str_name_real));
                    }


                    char *p_fhash_begin = strstr(p_cookie,"fhash=");
                    if(p_fhash_begin == NULL)
                    {
                        return true;
                    }
                    char *p_fhash_end = strstr(p_fhash_begin,";");
                    if(p_fhash_end == NULL)
                    {
                        return true;
                    }
                    char p_fhash_arr[100] = { 0 };
                    memcpy((char *)p_fhash_arr,&p_fhash_begin[6],p_fhash_end - p_fhash_begin - 6);
                    if(strlen(p_fhash_arr) > 0)
                    {
                        p_parse_value->value_map.insert(pair<string,string>("Content-MD5",p_fhash_arr));
                    }
                }
            }
            return true;
        }
    }
    return true;
}

/** @brief  PC客户端上传、下载解析提取函数
 *              提取内容包括：文件名、用户ID、MD5
 *              文件内容加密提取不出来
 * bool pc_app_download_info(webmail_session* p_webmail_session,char * buffer,uint32_t len)
 *
 *
 *  @param
 *
 *  @return
 *  @note
 */
bool pc_app_download_info(webmail_session* p_webmail_session,char * buffer,uint32_t len)
{
    parse_value *p_parse_value = p_webmail_session->p_parse_value;

    if(p_parse_value == NULL)
    {
        return false;
    }

    p_parse_value->parse_type = CLOUD;
    if(buffer == NULL || len == 0)
    {
        return false;
    }

    char *response_p = strstr(buffer,"response");
    if(response_p == NULL)
    {
        return true;
    }
    else
    {
        char *download_judge = NULL;
        download_judge = strstr(buffer,"file_info");//下载包到文件标识file_info
        if(download_judge != NULL)
        {
            (p_parse_value -> value_map)["app_type_handle"] = "0";
            if(p_parse_value -> value_map.find("USER_ID") == p_parse_value -> value_map.end())
            {
                char *p_qid_tmp = NULL;
                char *p_qid_str = NULL;
                char str_qid_temp[100] = "";
                //   char *user_qid = str_qid_temp;
                p_qid_tmp = strstr(buffer,"qid=\"");
                if(p_qid_tmp == NULL)
                {
                    return true;
                }
                p_qid_str = strstr(&p_qid_tmp[5],"\"");
                if(p_qid_str == NULL)
                {
                    return false;
                }
                memcpy(str_qid_temp,&p_qid_tmp[5],strlen(p_qid_tmp) - strlen(p_qid_str) - 5);
                p_parse_value->value_map.insert(pair<string,string>("USER_ID",str_qid_temp));
            }
            if(p_parse_value -> value_map.find("clouddisk360_filename") == p_parse_value -> value_map.end())
            {
                char *p_tmp = NULL;
                char *p_name = NULL;
                char str_temp[100] = "";

                p_tmp = strstr(buffer,"fpath=\"");
                if(p_tmp == NULL)
                {
                    return true;
                }

                p_name = strstr(&p_tmp[7],"\"");
                if(p_name == NULL)
                {
                    return false;
                }
                /*   memcpy(file_name,&p_tmp[7],strlen(p_tmp) - strlen(p_name) - 7);
                     file_name[strlen(p_tmp) - strlen(p_name) - 7] = 0x0;*/

                uint32_t offiset = 0;
                string file_name_real = "";

                string file_name_change = "";//= file_name;
                file_name_change.insert(file_name_change.end(),p_tmp + 7,p_tmp + (p_name - p_tmp));

                offiset = file_name_change.rfind("/",file_name_change.length());
                if(offiset != string::npos)
                {
                    file_name_real = string(file_name_change,offiset + 1,file_name_change.length() - offiset - 1);
                }
                string file_name_insert = urldecode(file_name_real);
                p_parse_value->value_map.insert(pair<string,string>("clouddisk360_filename",file_name_insert));

                char *p_temp = NULL;
                char *p_size = NULL;
                memset(str_temp,0,100);
                char *file_size = str_temp;

                p_temp = strstr(buffer,"fsize=\"");
                if(p_temp == NULL)
                {
                    return false;
                }
                p_size = strstr(&p_temp[7],"\"");
                if(p_size == NULL)
                {
                    return false;
                }
                memcpy(file_size,&p_temp[7],strlen(p_temp) - strlen(p_size) - 7);

                char *p_temp_h = NULL;
                char *p_fhash = NULL;
                memset(str_temp,0,100);
                char *file_fhash = str_temp;

                p_temp_h = strstr(buffer,"fhash=\"");
                if(p_temp_h == NULL)
                {
                    return false;
                }
                p_fhash = strstr(&p_temp_h[7],"\"");
                if(p_fhash == NULL)
                {
                    return false;
                }
                memcpy(file_fhash,&p_temp_h[7],strlen(p_temp_h) - strlen(p_fhash) - 7);
                p_parse_value->value_map.insert(pair<string,string>("Content-MD5",file_fhash));
            }
            return false;
        }
        (p_parse_value -> value_map)["app_type_handle"] = "1";
        char *update_judge = NULL;
        update_judge = strstr(buffer,"node_info");//上传包到文件标识node_info
        if(update_judge != NULL)
        {
            (p_parse_value -> value_map)["app_type_handle"] = "1";
            if(p_parse_value -> value_map.find("USER_ID") == p_parse_value -> value_map.end())
            {
                char *p_qid_tmp = NULL;
                char *p_qid_str = NULL;
                char str_qid_temp[50] = "";
                char *user_qid = str_qid_temp;

                p_qid_tmp = strstr(buffer,"qid=\"");
                if(p_qid_tmp == NULL)
                {
                    return true;
                }
                p_qid_str = strstr(&p_qid_tmp[5],"\"");
                if(p_qid_str == NULL)
                {
                    return false;
                }
                memcpy(user_qid,&p_qid_tmp[5],strlen(p_qid_tmp) - strlen(p_qid_str) - 5);
                p_parse_value->value_map.insert(pair<string,string>("USER_ID",user_qid));
            }

            if(p_parse_value -> value_map.find("clouddisk360_filename") == p_parse_value -> value_map.end())
            {
                char *p_tmp = NULL;
                char *p_name = NULL;
                char str_temp[100] = "";

                p_tmp = strstr(buffer,"name=\"");
                if(p_tmp == NULL)
                {
                    return true;
                }
                p_name = strstr(&p_tmp[6],"\"");
                if(p_name == NULL)
                {
                    return false;
                }
                /* memcpy(file_name,&p_tmp[7],strlen(p_tmp) - strlen(p_name) - 7);
                   file_name[strlen(p_tmp) - strlen(p_name) - 7] = 0x0;*/
                string file_name_client_bf = "";// = file_name;
                file_name_client_bf.insert(file_name_client_bf.end(),p_tmp + 7,p_tmp + (p_name - p_tmp));
                string file_name_client = urldecode(file_name_client_bf);
                p_parse_value->value_map.insert(pair<string,string>("clouddisk360_filename",file_name_client));

                /*char *p_temp = NULL;
                  char *p_size = NULL;
                  memset(str_temp,0,50);
                  char *file_size = str_temp;

                  p_temp = strstr(buffer,"fsize=\"");
                  if(p_temp == NULL)
                  {
                  return false;
                  }
                  p_size = strstr(&p_temp[7],"\"");
                  if(p_size == NULL)
                  {
                  return false;
                  }
                  memcpy(file_size,&p_temp[7],strlen(p_temp) - strlen(p_size) - 7);*/

                char *p_temp_h = NULL;
                char *p_fhash = NULL;
                memset(str_temp,0,100);
                char *file_fhash = str_temp;

                p_temp_h = strstr(buffer,"file_hash=\"");
                if(p_temp_h == NULL)
                {
                    return false;
                }
                p_fhash = strstr(&p_temp_h[11],"\"");
                if(p_fhash == NULL)
                {
                    return false;
                }
                memcpy(file_fhash,&p_temp_h[11],strlen(p_temp_h) - strlen(p_fhash) - 11);
                p_parse_value->value_map.insert(pair<string,string>("Content-MD5",file_fhash));
            }
            return false;
        }
    }
    return false;
}


/** @brief  下载数据包处理函数，得到文件名，文件类型
 *
 *bool cloud_parse::clouddisk360_response_parse_handle(session *p_session,webmail_session* p_webmail_session,
 *                                           s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
 *
 *
 *  @param session* p_session 数据组包类
 *         c_packet* p_packet 得到到数据包
 *
 *  @return
 *  @note
 */
bool cloud_parse::clouddisk360_response_parse_handle(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    parse_value *p_parse_value = p_webmail_session->p_parse_value;

    if((p_parse_value == NULL) || (p_parse_value->len == 0))
        return false;

    p_parse_value->parse_type = CLOUD;
    if(p_webmail_session->state == server_data)
    {
        p_webmail_session ->b_add_end = true;
        p_webmail_session -> state = server_data_continue;
        string str_key = "response_head_key_Content-Disposition";
        string str_key1 = "response_head_key_Content-Encoding";

        p_parse_value->value_map.insert(pair<string,string>("app_type_360","2"));
        (p_parse_value -> value_map)["app_type_handle"] = "0";

        parse_value_map ::iterator iter = p_parse_value->value_map.find(str_key.c_str());
        string file_name = "";
        string str_tmp = "";

        if(iter != p_parse_value->value_map.end())
        {
            str_tmp = iter->second;
            uint32_t size = str_tmp.find("filename=");
            if(size != string::npos && size + 10 < str_tmp.length())
            {
                file_name = string(str_tmp,size + 10,str_tmp.length() - size - 11);
            }
            else
            {
                file_name = str_tmp;
            }
        }

        parse_value_map::iterator iter1 = p_parse_value->value_map.find(str_key1);
        if (iter1 != p_parse_value->value_map.end())
        {
            str_tmp = iter1->second;
            uint32_t size = str_tmp.find("gzip");
            if(size != string::npos)
            {
                p_parse_value -> bgzip = true;
            }
        }
        if(file_name.length() > 0)
        {
            string file_name_str = urldecode(file_name);
            p_parse_value->value_map.insert(pair<string,string>("clouddisk360_filename",file_name_str));
        }

        if(p_webmail_session -> requst_time == 0)
        {
            p_webmail_session -> requst_time = p_session -> packet_time;
        }
        if(p_webmail_session ->response_length > 0 &&  (uint32_t)(p_webmail_session->response_length) <= p_parse_value->len )
        {
            p_webmail_session ->b_end_send = true;
        }
    }

    if(p_parse_value->buf != NULL && p_parse_value->len > 0)
    {
        if(p_parse_value -> value_map["response_head_key_Transfer-Encoding"] == "chunked")
        {
            if(p_parse_value -> bgzip)
            {
                int ioffise = 0;
                uint32_t ibuf_offist = 0;

                ioffise = p_webmail_session->had_send_len;//rem_len;

                while(p_parse_value -> len > ibuf_offist)
                {
                    if(p_webmail_session -> tmp_len == 0)
                    {
                        char *mid = strstr(p_parse_value -> buf + ibuf_offist,"\r\n");
                        if(mid == NULL)
                        {
                            // p_session->server.clear_buf();
                            return true;
                        }
                        uint32_t len = strtol(p_parse_value -> buf +  ibuf_offist,&mid,16);
                        if(len == 0)
                        {
                            p_webmail_session -> b_end_send = true;
                            if(p_session -> send_len == 0 && ioffise == 0)
                            {
                                p_session -> p_send_buf = NO_NULL;
                                p_session -> send_len = 1;
                            }
                            else
                            {
                                try
                                {
                                    p_parse_value->parse_tmp_len =ioffise * 400;
                                    p_parse_value->parse_tmp_buf = new  char [ioffise * 400] ;
                                }
                                catch( const bad_alloc & e)
                                {
                                    try
                                    {
                                        p_parse_value->parse_tmp_len =ioffise * 10;
                                        p_parse_value->parse_tmp_buf = new  char [ioffise * 10] ;
                                    }
                                    catch( const bad_alloc & e)
                                    {
                                        return true;
                                    }

                                }
                                p_parse_value -> gzip_len = ioffise;
                                // int ret  = httpgzdecompress((Bytef *)p_parse_value -> gzip_buffer ,(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  ,(uLong*)& p_parse_value->parse_tmp_len);
                                int ret  = httpgzdecompress((Bytef *)(*(p_webmail_session->file_content)).c_str(),(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  ,(uLong*)& p_parse_value->parse_tmp_len);
                                *(p_webmail_session->file_content) = "";
                                p_parse_value->gzip_len = 0;
                                p_webmail_session->had_send_len = 0;

                                if(ret == 0)
                                {
                                    bool ret_info;
                                    ret_info = pc_app_download_info(p_webmail_session,p_parse_value->parse_tmp_buf,p_parse_value->parse_tmp_len);
                                    if(ret_info == false)
                                    {
                                        p_session -> p_send_buf = NO_NULL;
                                        p_session -> send_len = 1;
                                    }
                                    else
                                    {
                                        p_session -> p_send_buf = p_parse_value->parse_tmp_buf;
                                        p_session -> send_len = p_parse_value->parse_tmp_len;
                                    }
                                }

                            }
                            return true;
                        }
                        mid += 2;
                        ibuf_offist = mid - p_parse_value -> buf;

                        if(p_parse_value -> len - ibuf_offist > len)//已经缓存到数据大于要处理到数据
                        {
                            //memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, len);
                            //memcpy(buffer , p_parse_value -> buf + ibuf_offist, len);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + ibuf_offist + len);
                            *(p_webmail_session->file_content) += tmp;
                            ibuf_offist += 2;
                            ioffise += len;
                            ibuf_offist += len;
                            p_webmail_session -> tmp_len = 0;
                            p_webmail_session->had_send_len = ioffise;
                            p_webmail_session -> response_length = 0;
                        }
                        else //已经缓存的数据小于要处理到数据
                        {
                            //memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            // memcpy(buffer , p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + p_parse_value -> len);
                            *(p_webmail_session->file_content) += tmp;
                            ioffise += p_parse_value -> len - ibuf_offist;//缓存数据到长度
                            p_webmail_session -> tmp_len = len - (p_parse_value -> len - ibuf_offist);//剩余数据的长度
                            p_webmail_session -> response_length = len - p_parse_value -> len +ibuf_offist;
                            // p_parse_value->parse_tmp_len = ioffise;
                            p_webmail_session->had_send_len = ioffise;
                            // rem_packet = len - p_parse_value -> len;
                            // p_webmail_session ->response_length = p_parse_value->len;
                            p_session->server.clear_buf();
                            return true;
                        }
                    }
                    else
                    {
                        if(p_webmail_session -> tmp_len < p_parse_value -> len)//剩余数据的长度小于缓冲区到长度
                        {
                            int len = p_webmail_session -> tmp_len;
                            p_webmail_session -> tmp_len = 0;
                            // memcpy(buffer + ioffise, p_parse_value -> buf + ibuf_offist, len);
                            //  memcpy(buffer , p_parse_value -> buf + ibuf_offist, len);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + ibuf_offist + len);
                            *(p_webmail_session->file_content) += tmp;
                            ibuf_offist += len;
                            ibuf_offist +=2 ;
                            ioffise += len  ;
                            p_webmail_session->had_send_len = ioffise;
                            p_webmail_session -> response_length = 0;
                        }
                        else//剩余数据到长度大于缓冲区的长度
                        {
                            int len = p_webmail_session ->tmp_len ;
                            // memcpy(buffer + ioffise, p_parse_value->buf + ibuf_offist ,p_parse_value -> len - ibuf_offist );
                            // memcpy(buffer , p_parse_value -> buf + ibuf_offist, p_parse_value -> len - ibuf_offist);
                            string tmp;
                            tmp.insert(tmp.end(),p_parse_value -> buf + ibuf_offist,p_parse_value -> buf + p_parse_value -> len);
                            *(p_webmail_session->file_content) += tmp;
                            ioffise += p_parse_value -> len - ibuf_offist  ;
                            p_webmail_session ->tmp_len = len - (p_parse_value->len   - ibuf_offist);
                            //   p_session->p_send_buf = p_parse_value -> gzip_buffer ;
                            //   p_session -> send_len = ioffise;
                            p_webmail_session -> response_length = len - p_parse_value -> len +ibuf_offist;
                            p_webmail_session->had_send_len = ioffise;

                            p_session->server.clear_buf();
                            return true;
                        }
                    }
                }
                if(ioffise == 0)
                {
                    if(p_webmail_session ->b_end_send == true)
                    {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 1;
                    }
                    else {
                        p_session->p_send_buf = NO_NULL ;
                        p_session->send_len = 0;
                    }
                }
                else
                {
                    p_webmail_session->had_send_len = ioffise;
                    p_webmail_session -> response_length = 0;
                }
                p_session->server.clear_buf();
                return true;
            }
        }
        //非压缩文件
        else
        {
            if( p_parse_value -> parse_tmp_len < (uint32_t)(p_webmail_session->response_length))
            {
                p_session -> p_send_buf = p_parse_value -> buf;
                if ((uint32_t)(p_parse_value->parse_tmp_len) + p_parse_value ->len >= (uint32_t)(p_webmail_session->response_length))
                {
                    p_session -> send_len += p_webmail_session->response_length;// - p_parse_value->parse_tmp_len;
                    p_parse_value ->  parse_tmp_len = 0;
                    p_webmail_session -> b_end_send = true;
                }
                else
                {
                    p_session -> send_len = p_parse_value -> len;
                    p_parse_value -> parse_tmp_len += p_parse_value -> len;
                }
            }
        }
        if(p_webmail_session ->b_end_send )
        {
            if(p_session->send_len == 0 || p_session->p_send_buf == NULL)
            {
                p_session->send_len = 1;
                p_session->p_send_buf = NO_NULL;
            }
            p_session->server.clear_buf();
            return true;
        }
    }
    p_session->server.clear_buf();
    return true;
}
