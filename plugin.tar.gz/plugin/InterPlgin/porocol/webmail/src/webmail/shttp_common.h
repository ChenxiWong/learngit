// Last Update:2016-04-07 13:04:55
/**
 * @file shttp_common.h
 * @brief-
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-22
 */


#if !defined(_S_HTTP_COMMON_H)
#define _S_HTTP_COMMON_H
#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <ctype.h>
#include <commit_tools.h>

// request 
#define dRStateMethodBegin 0
#define dRStateMethod1 1
#define dRStateMethodEnd 2
#define dRStateURIBegin 3
#define dRStateURIFileBegin 4
#define dRStateURIFile1 5
#define dRStateURIFileTypeBegin 6
#define dRStateURIFileType1 7
#define dRStateURI1 8
#define dRStateURIFileEnd 9
#define dRStateVersion 10
#define dRStateH 11
#define dRStateHT 12
#define dRStateHTT 13
#define dRStateHTTP 14
#define dRStateHTTP5C 15
#define dRStateHTTP5C1 16
#define dRStateHTTP5C12E 17
#define dRStateVesionEnd 18
#define dRStateVesionEnd1 19
#define dRStateVesionEnd2  20
#define dRStateKeyBegin  21
#define dRStateKeyName 22
#define dRStateKeyNameEnd  23
#define dRStateKeyNameONValue  24
#define dRStateKeyValue 25
#define dRStateKeyValueEnd 26
#define dRStateURIParamBegine 27
#define dRStateURIParamName 28
#define dRStateURIParamNameONValue 29
#define dRStateURIParamVaklue 30
#define dRStateURIParamEnd 31
#define dRStateKeyValueEnd1 32
#define dRStateKeyValueEnd2 33
#define dStateHeaderEnd1 34
#define dRStateURIParamVaule  35
#define dStateText 36
#define dRStatURIParamVaule 37
#define dRStateError 38



#define dSStateVersion 0
#define dSStateH 1
#define dSStateHT 2-
#define dSStateHTT 3-
#define dSStateHTTP 4-
#define dSStateHTTP5C 5-
#define dSStateHTTP5C1 6-
#define dSStateHTTP5C12E 7-
#define dSStateVesionEnd 8

#define dSStateCode1 9
#define dSStateCode2 10
#define dSStateCode3 11
#define dSStateCodeend 12

#define dSStateCodeName  13
#define dStateCodeNameContinue 14
#define dSCodeNameEnd1    15
#define dSCodeNameEnd2    16




#define ERROR          1
#define  BUF_END       2
#define  PASER_CONTINUE 3


#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
        ss<<n; \
        s+=std::string(ss.str()) ;\
        ss.clear(); }


typedef struct c_http_str_ {
	char * buf_begin;
	int space_use_len;
    struct c_http_str_ *Nextbuf;

}c_http_str;
/*class c_http_str{
public:
	char * buf_pos;
	char * buf_next_pos;
	char * buf_begin;
	char * buf_end;
	int space_use_len;
	int space_free_len;
	c_http_str * Nextbuf ;

};*/
void c_http_strInit(c_http_str * p );
bool isUTF8Code(unsigned char *str, int len);
int c_http_strCmp(c_http_str * str1,c_http_str * str2);
int c_http_strCmpstr(c_http_str * str1 ,char * name);
int c_http_strnCmpstr(c_http_str * str1 ,char * name,int len);
int reStrCmp(char * str1 ,char * str2);
typedef struct  s_key_value_ {
	c_http_str name;
	c_http_str value;
	struct s_key_value_ * link;
}s_key_value;
//s_key_value  * s_key_valueGet();
typedef int         INT    ;
typedef int16_t     INT16  ;
typedef u_int16_t   UINT16  ;
typedef int32_t     INT32  ;
typedef u_int32_t   UINT32 ;
typedef int64_t     INT64  ;
typedef u_int64_t   UINT64  ;
//typedef bool        BOOL   ;
typedef char        byte   ;
typedef struct {
	int http_code;
	int http_vesion;
	//int ContentType;
	int ContentLength;
	c_http_str HttpCodeName;
	c_http_str CentextLangth;
	s_key_value * HttpHeaderKeyNameValue;
//	s_key_value *NoDefineHeaderkey;
    int  parsestate;
    char * parsepos;
}s_http_response;
enum method_type
{
	GET = 1,
	POST,
	OPTIONS ,
	HEAD_M ,
	PUT ,
	DELETE ,
	TRACE ,	
	CONNECT,
	METHODERROR =99,
};

enum response_type 
{
  HTTP_CONTINUE = 0, //100

};
#define HTTP1_1 1
#define HTTP1_0 0

#define HtmlZip 1 
#define HtmlText 0

#define KEEPALIVE 1
#define CLOSE     0
typedef struct  {
	method_type  HttpMothed;
	int http_vesion;
	//int iCentextLangth;
	//int iAcceptEncoding;
	//int iConnection;
	c_http_str CentextLangth;
	c_http_str Uri;
	c_http_str UriFile;
	c_http_str UriFileType;
	c_http_str UriProlate;
	c_http_str UriWithParam;
    c_http_str UriParam;
	s_key_value * HttpHeaderKeyNameValue;
//	char * MaDecBuf;
    int  parsestate;
    char * parsepos;
}s_http_request;
// HttpDataFrom
#define CtoS 0
#define StoC 1
/*struct timeval {
        long    tv_sec;         ///< seconds
        long    tv_usec;        ///< microseconds
};*/

// parsestate
#define HR 1 //http requset
#define HS 2 // http reseponse
void s_key_value_free(s_key_value * p_key_value);
c_http_str * find_key_value(s_key_value * phead ,const  char * name);
void init_s_http_requset(s_http_request * r);
int UrlDecode(char* szSrc,int szlen, char* pBuf, int cbBufLen);
int UrlEncode(char* szSrc, char* pBuf, int cbBufLen, bool bUpperCase);
int UrlDeCodeFormat(const char* szSrc,int szlen, char* pBuf, int cbBufLen);
void InitKey(unsigned long ipaddr , unsigned short prot ,std::string & IPPortkey);
void init_s_http_response(s_http_response *s);

int html_to_txt(char *poutbuf, int &olen, const char *pinbuf, int inlen);
const char * StrnLowStr(const char *buf, int len, const char *pattern, int length);

#endif  //_SHTTPSESSIONINFO_H
