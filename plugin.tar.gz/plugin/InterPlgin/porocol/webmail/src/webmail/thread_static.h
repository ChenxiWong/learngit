// Last Update:2015-12-25 14:31:09
/**
 * @file thread_static.h
 * @brief : 保存线程的使用一次性new的变量 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-11-17
 */

#ifndef THREAD_STATIC_H
#define THREAD_STATIC_H

#include "html2txt.h"
#include <pthread.h>
#include <set>
#include <string>
#define MAXBUFFERLEN 1024*1024*4 

#include "Redis.h"
typedef  std::set<std::string> t_urlname_set;

class c_thread_static 
{
public:
   static   __thread   CTransEntity * p_entity;
   static   __thread   char *  p_buffer ;     
   static   __thread   int     num_buffer_len  ;     
   static   __thread   t_urlname_set * p_urlname_set;

   static   __thread    Redis * p_redis ;
   static   __thread    string * p_redis_host;   
   static   __thread    int  num_redis_port;   
   static   __thread    int  num_redis_id;   
   static   __thread    int  num_webmail_redis_time_out;   
  

};
static CTransEntity * get_transentity()
{
    if(c_thread_static::p_entity == NULL)
    {
        c_thread_static::p_entity = new CTransEntity ;
    }
    return  c_thread_static::p_entity  ;
}
static char  * get_buffer()
{
    if(c_thread_static::p_buffer == NULL)
    {
        c_thread_static::p_buffer = new char [MAXBUFFERLEN];
    }
    return  c_thread_static::p_buffer ;
}


static  Redis * get_redis()
{
    if(c_thread_static::p_redis == NULL)
    {
            if (c_thread_static::p_redis_host == NULL) 
            {
                c_thread_static::p_redis_host = new string("127.0.0.1");
            }
           c_thread_static::p_redis = new Redis(*c_thread_static::p_redis_host , c_thread_static:: num_redis_port );
    }
    return c_thread_static::p_redis ;
}

#endif  /*THREAD_STATIC_H*/
