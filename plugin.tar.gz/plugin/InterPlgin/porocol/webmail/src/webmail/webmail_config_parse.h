// Last Update:2016-05-12 16:03:24
/**
 * @file webmail_config_parse.h
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-02
 */

#ifndef WEBMAIL_CONFIG_PARSE_H
#define WEBMAIL_CONFIG_PARSE_H

#include <xml_parse.h>
#include <string>
#include <stdint.h>
#include <stdlib.h>
#include <list>
#include <map>
#include <sstream>
#include <c_ip.h>
#include <session.h>
#include <packet.h>
#include "webmail_str.h"
#include "webmail_parse.h"
#include "identity.h"

using namespace std;

class webmail_config_parse {

    public:
        webmail_config_parse();
        ~webmail_config_parse();

        void parse(string xmlstr, xml_parse  & xml );
        void urlparse(string xmlstr);//丹丹加，urlidmap表
        void code_set_value_parse(string xmlstr);//添加numid和英文代码集map表
        string send_data_type;
        uint32_t   time_out;
        uint32_t   flag;
        bool        b_had_dan_response ; // 是否解析单项请求体
        map_mail *p_map_mail;
        map_mail *p_map_mail_uncertain;
        part_url_list * p_partlist;
        part_url_list * p_partlist_uncertain;
        //set<c_ip>
        map<c_ip,map_mail*>ip_mail_map; //  IP 分捡 
        map<c_ip,part_url_list*>ip_parturl_mail_map; // 解析所有的 
        // host 分捡 
        map<uint32_t,map_mail*>host_mail_map; //  host 分捡 
        map<uint32_t,part_url_list*>host_parturl_mail_map; // host 分捡

        url2id_map  p_url2id_map;
        map<string,string> num_word_code;
        map<string,string> url_flag_map;
        map<string,uint32_t> url_app_loc_map;

    private:
        void tissue_keyvalue(string  xpath, aissue_list* p_list,xml_parse  & xml );
        void mail_other_keyvalue(string  xpath, aissue_list* p_list,xml_parse  & xml );
        list<map_mail*>del_mail_list;
        list<mail_handle*>del_mailhandle_list;
        list<part_url_list*>del_urlparthandle_list;
};

bool s_prce_init(pcre* & re,char * pattern);
bool parturl_compare(part_url_mail * p_parturl,string & url,string & urlwithpath );

#endif  /*WEBMAIL_CONFIG_PARSE_H*/
