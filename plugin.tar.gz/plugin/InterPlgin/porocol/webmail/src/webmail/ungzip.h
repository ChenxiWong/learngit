// Last Update:2015-05-12 10:31:18
/**
 * @file unzip.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-09
 */

#ifndef UNGZIP_H
#define UNGZIP_H


#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <zlib.h>
#include <stdint.h>
#define Bytef unsigned char 

#define uLong  uint32_t 
int gzcompress(Bytef *data, uLong ndata, Bytef *zdata, uLong *nzdata); // 压缩
int zdecompress(Byte *zdata, uLong nzdata, Byte *data, uLong *ndata); //解压缩
int httpgzdecompress(Byte *zdata, uLong nzdata,  Byte *data, uLong *ndata);


#endif  /*UNGZIP_H*/
