#include "http_post_analyzer.h"
#include <string.h>

char sPostDivision[]={'&',0x0};
int http_post_analyzer::post_text_analyzer(c_http_str * pos,char * pEnd ,s_key_value* & p_head ) {
    enum PostState{
        StateNameBegin =1,
        StateName,
        StateNameOnValue,
        StateValue,
        StateValueEnd
    };
    PostState state  = StateNameBegin;
    char * p  = pos->buf_begin;
    s_key_value * pkey = NULL;
    s_key_value * pT = NULL;
    for(;p < pEnd; p++)
    {
        switch(state )
        {
            case StateNameBegin:
                pkey =new s_key_value();
                pkey ->name.buf_begin = p;
                pkey-> name.space_use_len = 1;
                pkey -> link = NULL;
                if(p_head == NULL || pT == NULL) 
                {
                    p_head = pkey;
                    pT = pkey;
                }
                else 
                {
                    pT->link = pkey;
                    pT=pkey;
                }
                state = StateName;
                break;
            case StateName:
                if(*p != '=')
                {
                    pkey->name.space_use_len ++;
                    break;
                }
                else 
                {
                    state = StateNameOnValue;	
                }
                break;
            case StateNameOnValue:
                pkey ->value.buf_begin = p;
                pkey-> value.space_use_len = 1;	
                state = StateValue;
                break;	
            case StateValue:
                if(strchr(sPostDivision , *p ) == NULL)	
                {
                    pkey->value.space_use_len ++;
                    break;
                }
                else   {
                    state = StateNameBegin;
                }
                break;
            default :
                return 0;
        }
    }
    return 1;
}
/*
int http_post_analyzer::PostXMLParse(SHttpSession * pSess, CParseState* pStateArray ) {
    enum {
        XMLNameBegin1=1,
        XMLNameBegin2,
        XMLName ,
        XMLNameOnValue,
        XMLValue,
        XMLValueEnd
    }PostXMLState ;

    int state = XMLNameBegin1;
    //	CHttpStr name ;
    //	CHttpStr Value;
    s_key_value * pkey = NULL;
    s_key_value * pT = NULL;	
    pSess->R.uripostparam = NULL;
    char * p  = pSess->R.DecBuf.buf_begin;	
    char * pEnd = pSess->R.DecBuf.buf_begin + pSess->R.DecBuf.space_use_len;
    for(;p!=pEnd;p++)
    {
        switch(state )
        {
            case XMLNameBegin1:
                pkey = s_key_valueGet();
                pkey->name.buf_begin = p;
                pkey->name.space_use_len = 1;			
                pkey->link = NULL;
                if(pSess->R.uripostparam == NULL) 
                {
                    pSess->R.uripostparam  = pkey;
                    pT = pkey;
                }
                else 
                {
                    pT->link = pkey;
                    pT=pkey;
                }
                break;
            case XMLNameBegin2:
                pkey->name.buf_begin = p;
                pkey->name.space_use_len = 1;	
                break;	
            case XMLName:
                if(*p != '>')
                    pkey->name.space_use_len ++;
                else *p = XMLNameOnValue;
                break;
            case XMLNameOnValue:
                if(*p == '<') 
                {
                    state = XMLNameBegin1;
                    while(*p == '>') p++;
                }
                else 
                {
                    pkey->value.buf_begin = p;
                    pkey->value.space_use_len = 1;
                    state =  XMLValue;
                }
                break;
            case XMLValue:
                if(*p == '<')	state = XMLValueEnd;
                else pkey->value.space_use_len ++;	
                break;
            case XMLValueEnd:
                if(pSess->R.uripostparam == NULL)
                {
                    pSess->R.uripostparam  = pkey;
                    pT = pkey;
                }
                else
                {
                    pT->link = pkey;
                    pT=pkey;
                }
                while(*p == '>') p++;
                state =  XMLNameBegin1;
                break;
        }
    }	
}
*/
