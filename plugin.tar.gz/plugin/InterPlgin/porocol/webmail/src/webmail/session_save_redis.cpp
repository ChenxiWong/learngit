// Last Update:2015-12-27 10:53:02
/**
 * @file session_save_redis.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-12-25
 */
#include "session_save_redis.h"
bool map_to_encode(string & s_value , webmail_session* p_webmail_session) 
{
    // map 值组成 
      parse_value * p_parse_value = p_webmail_session ->p_parse_value;
      parse_value_map::iterator iter = p_parse_value->value_map.begin();
      string tmp = "";
      for(iter = p_parse_value->value_map.begin() ; iter != p_parse_value->value_map.end();iter ++)
      {
          // key
           tmp = iter -> first;
           DNUMTOSTR(tmp.length(), s_value);
           s_value += " ";
           s_value += tmp ;
           s_value += "="; 
           // value
           tmp = iter -> second ;
           //s_value += itoa(tmp.length());
           DNUMTOSTR (tmp.length(), s_value);
           s_value += " ";
           s_value += tmp ;

           // 

      }
      return true;

}
int get_decode_value (string & src , int  num_pos , int end ,string & value )
{
     int n = src.find_first_of(' ',num_pos) ;  
       // ----------- 
      string   tmp(src , num_pos , n - num_pos );
      int len = atoi(tmp.c_str());
      if( num_pos + len > end ) 
      {
     //     string value = string(src , n , end - num_pos - n );
          return 0;
      }
      value.assign(src , n +1, len);
       
      return n +  len  +1;
}
bool map_to_decode(string & value , webmail_session* p_webmail_session) 
{
    // 
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
     
    //
    // 查找重后向前查找 ， 
    int str_len = value.length();
    int num_pos = 0; 
    string name  = "";
    string svalue  = "";
    
    while(num_pos < str_len ) 
    {
        // 查找   = 为分割符号 
       int mid = value.find_first_of('=',num_pos) ;
       
       int len = get_decode_value(value , num_pos , mid , name  ) ;  
       if(len == 0 )
       {
           return false;
       }
       num_pos = len ;
       num_pos ++; 
       len = get_decode_value(value , num_pos , str_len , svalue  ) ;  
       if(len == 0 )
       {
           return false ;
       }
       num_pos = len ;
       
      p_parse_value -> value_map.insert(pair<string,string>(name,svalue));
      //num_pos = n ;
    }
    return true;

}
bool set_redis_data(std::string & key, std::string  & value, int expire_time)
{
    printf ("*********************************\n");
    bool ret =  get_redis() -> add_data(c_thread_static::num_redis_id,key,value,expire_time);
    return ret;
}
bool get_redis_data(std::string & key ,std::string & value)
{

    if(get_redis() -> get_data (c_thread_static::num_redis_id,key,value) )
    {
        // 清理数据 
        get_redis() -> delete_data(c_thread_static::num_redis_id,key ) ;
        return true;

    }
    return false;
}
