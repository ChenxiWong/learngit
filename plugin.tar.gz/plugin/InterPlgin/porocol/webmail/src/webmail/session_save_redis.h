// Last Update:2015-12-25 13:41:03
/**
 * @file session_save_redis.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-12-25
 */

#ifndef SESSION_SAVE_REDIS_H
#define SESSION_SAVE_REDIS_H
#include "thread_static.h"
#include "webmail_str.h"
#include "shttp_common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>
using namespace std;

// map 转换成string  序列化 
bool map_to_encode(string & value , webmail_session* p_webmail_session) ;
//反序列化 
bool map_to_decode(string & value , webmail_session* p_webmail_session) ;

// 存储到 redis
bool set_redis_data(std::string  & key, std::string  & value, int expire_time);

bool get_redis_data(std::string  & key ,std::string & value);



#endif  /*SESSION_SAVE_REDIS_H*/
