// Last Update:2015-05-04 14:43:59
/**
 * @file http_urimethod_analyzer.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-28
 */

#ifndef HTTP_URIMETHOD_ANALYZER_H
#define HTTP_URIMETHOD_ANALYZER_H

#include "shttp_common.h"
#include <stdlib.h>

class http_urimethod_analyzer {
    public:
        http_urimethod_analyzer();
        ~http_urimethod_analyzer();
        int  http_url_analyer(s_http_request* p_request,char * p_end) ;
        int http_vesion_analyzer(s_http_request* pSess, char * p_end) ;
        method_type find_http_mothed(c_http_str Mothed_name );
};
class http_respcode_analyer {
    public:
        int http_s_version_analysis(s_http_response* pSess, char * p_end);
        int http_s_code_analysis(s_http_response* pSess, char * p_end);
        int http_s_codename_analysis(s_http_response* pSess, char * p_end);
};

#endif  /*HTTP_URIMETHOD_ANALYZER_H*/
