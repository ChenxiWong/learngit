// Last Update:2015-12-27 09:58:21
/**
 * @file thread_static.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-11-17
 */

#include "thread_static.h" 
__thread CTransEntity * c_thread_static::p_entity = NULL;
__thread char  * c_thread_static::p_buffer = NULL;
__thread int     c_thread_static::num_buffer_len  = MAXBUFFERLEN ;
__thread t_urlname_set * c_thread_static::p_urlname_set = NULL;
__thread Redis * c_thread_static::p_redis  = NULL;

__thread string * c_thread_static::p_redis_host = NULL;

__thread int     c_thread_static::num_redis_port = 6379;
__thread int     c_thread_static::num_redis_id = 5;
__thread int     c_thread_static::num_webmail_redis_time_out = 60;

static CTransEntity * get_transentity();
static char  * get_buffer();
static  Redis * get_redis();

