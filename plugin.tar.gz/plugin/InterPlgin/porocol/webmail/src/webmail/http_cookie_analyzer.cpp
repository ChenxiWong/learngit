//
//
//  @ Project : Untitled
//  @ File Name : CHttpUriMethodAnalysis.cpp
//
//
//
#include "http_cookie_analyzer.h"
#include <string.h>
const char sCookieDivien[]={'&',';','\r',0x00};
http_cookie_analyzer::http_cookie_analyzer() {

}
http_cookie_analyzer::~http_cookie_analyzer() {

}

int http_cookie_analyzer::CookieParse( c_http_str * buf,s_key_value * &pHead) {

    char * p = buf ->  buf_begin;
    int i = 0 ;

    int sige = 1 ;
   // s_key_value Key ;
    s_key_value * pKey = NULL;
    s_key_value * pT = NULL;
    for(;i < buf->space_use_len+1 && *p != '\n';  p++)
    {
        i++;
        switch(sige)
        {
            case 1 :
                pKey = new s_key_value;
                //s_key_value_free(pKey);
                if(*p == 0x20) {
                    *p++;
                    i++;
                }
                pKey->name.buf_begin =  p;
                pKey->name.space_use_len =1;
                pKey->link = NULL;
                if(pHead == NULL || pT == NULL) 
                {
                    pHead = pKey;
                    pT = pKey;
                }
                else {
                    pT->link = pKey;
                    pT = pKey;
                    //pT = pKey -> link;
                }
                sige = 2;
                break;
            case 2:
                while( *p != '='  )
                {
                    pKey->name.space_use_len ++;
                    p++;
                    if(p - buf->buf_begin > buf->space_use_len) 
                        return 1;
                }
                sige =3;
                p++;
            case 3:
                pKey->value.buf_begin =  p;
                if(strchr(sCookieDivien , *p )!= NULL)
                {
                    pKey->value.space_use_len = 0;
                    // 
                    sige =1;
                    break;
                }
                pKey->value.space_use_len = 1;
                sige = 4;
                //	break;
            case 4:
                while (strchr(sCookieDivien , *p )== NULL)
                {
                    pKey->value.space_use_len ++;
                    p++;
                    if(p - buf->buf_begin > buf->space_use_len) 
                        return 1;
                }
                // 
                if(*p == '\r') return 1;
                sige =1;
                break;
            default :
                return 0;
        }
    }
    return  BUF_END;
}
int http_cookie_analyzer::SetCookieParse( c_http_str * buf,s_key_value * &pHead) {
    {
        char * p = buf ->  buf_begin;
        int i = 0 ; 

        int sige = 1 ;
        s_key_value * pKey = NULL;
        s_key_value * pT = NULL;
        for(;i < buf->space_use_len+1 && *p != '\n';  p++)
        {
            i++;
            switch(sige)
            {
                case 1 :
                    pKey = new s_key_value;
                   // s_key_value_free(pKey);
                    pKey->name.buf_begin =  p;
                    pKey->name.space_use_len =1;
                    pKey->link = NULL;
                    if(pHead == NULL)
                    {
                        pHead = pKey;
                        pT = pKey;
                    }
                    else {
                        pT->link = pKey;
                        pT = pT ->link;
                    }
                    sige = 2;
                    break;
                case 2:
                    while(*p != '=')
                    {
                        pKey->name.space_use_len ++;	
                        p++;
                    }
                    sige =3;
                    p++;
                case 3:
                    pKey->value.buf_begin =  p;
                    pKey->value.space_use_len =1;
                    sige = 4;
                    break;
                case 4:
                    while (strchr(sCookieDivien , *p )== NULL)
                    {
                        pKey->value.space_use_len ++;
                        p++;
                    }
                    if(*p == '\r') return 1;
                    sige =1;
                    break;
                default :
                    return 0;
            }
        }
    }
    return  BUF_END;
}

