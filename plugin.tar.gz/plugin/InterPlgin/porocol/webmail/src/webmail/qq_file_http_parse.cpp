// Last Update:2015-07-15 12:36:04
/**
 * @file qq_file_http_parse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-05-27
 */

#include "qq_file_http_parse.h"
#include "webmail163_parse.h"
#include <commit_tools.h>
#define DEFMAXBUF 65535

bool qq_file_http_parse::request_handle_att_id(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->Uri.buf_begin == NULL)
        return true;

    string url = string(p_requst -> Uri.buf_begin,0,p_requst->Uri.space_use_len);
    string name = "requset_url_";
    int size =  url.rfind("/");
    if(size != string::npos && url.length()>size+1)
    {
        string svalue(url,size+1,url.length()-size-1);

        node_value_list ::iterator iter = v_list.begin();
        for(;iter != v_list.end(); iter ++)
        {
            name +=*iter;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    return true;
}

bool qq_file_http_parse::response_handle_getbody(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    // 判断长度
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> b_c2s) 
    {
        return true;
    }
    //修改key 中的值
    p_parse_value -> parse_type = QQ_FILE;
    if(p_webmail_session -> state == server_data) 
    {
        p_webmail_session -> state = server_data_continue;
        p_webmail_session ->b_add_end = true;
    }
    else if(p_webmail_session -> state == server_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            if(p_webmail_session -> b_end_send)
            {
                p_session->p_send_buf = NO_NULL;
                p_session->send_len = 1;
            }
            return true;
        }

        if(p_webmail_session->had_send_len == 0)
        {
            // 文件长度计算
            char * b = p_parse_value->buf;
            string pattern = "Content-Length:";
            char * mid = strstr(b, pattern.c_str());
            if(mid == NULL)
                return true;

            mid += pattern.length();
            pattern = "\r\n\r\n";
            mid = strstr(mid, pattern.c_str());
            if(mid == NULL)
                return true;

            mid += pattern.length();
            p_parse_value->acc_file_length = p_webmail_session ->response_length;
            if(mid-b < p_parse_value->len)
            {
                p_webmail_session->had_send_len = p_parse_value->len-(mid-b);
                p_session->p_send_buf = mid;
                p_session->send_len = p_webmail_session->had_send_len;
            }
        }
        else
        {
            if(p_webmail_session->had_send_len + p_parse_value->len >= p_parse_value->acc_file_length)
            {
                p_webmail_session ->b_end_send = true;
                p_session->p_send_buf = p_parse_value->buf;
                p_session->send_len = p_parse_value->acc_file_length-p_webmail_session->had_send_len;
                p_webmail_session->had_send_len = p_parse_value->acc_file_length;
            }
            else
            {
                p_webmail_session->had_send_len += p_parse_value->len;
                p_session->p_send_buf = p_parse_value->buf;
                p_session->send_len = p_parse_value->len;
            }
        }

        if(p_webmail_session ->b_end_send ) 
        {
            if(p_session->send_len == 0 || p_session->p_send_buf == NULL)
            {
                p_session->send_len = 1;
                p_session->p_send_buf = NO_NULL;
            }
        }
    }

    return true;
}

bool qq_file_http_parse::request_handle_att(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) //  163 附件类的组包  靠返回来推出数据
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    p_session->p_send_buf = p_parse_value->buf;
    p_session->send_len = p_parse_value->len;
    p_parse_value -> parse_type = QQ_FILE;
    if(p_webmail_session -> state == client_data)
    {
        p_webmail_session-> state = client_data_continue;
        if(p_parse_value->len == 0)
            return true;
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->offise == 0) // 开始写文件或者开始写文件的一段内容的开始
        {
            if(p_parse_value->len < 364)
            {
                return true;
            }
            char *b = p_parse_value->buf;
            //uint32_t offset = (uint32_t)ntohl(*(int *)(b+12)); //parse_buf2uint32H(b, 12);
            uint32_t offset = parse_buf2uint32N(b, 12);
            if(offset < 348)
                return true;

            offset -= 348;
            //uint32_t file_seq = (uint32_t)ntohl(*(int *)(b+348)); //parse_buf2uint32H(b, 348);
            uint32_t file_seq = parse_buf2uint32N(b, 348);
            if(file_seq != 0)
            {
                if(file_seq != p_parse_value->post_len)
                    return true;
            }

            uint32_t len = p_parse_value->len-364;
            p_parse_value->acc_file_length += offset;
            p_parse_value->offise = offset;
            p_parse_value->parse_tmp_len = len;
            p_parse_value->post_len += len;
            p_session->p_send_buf = b+364;
            p_session->send_len = len;
            p_webmail_session-> b_end_send = false;
            if(p_parse_value->parse_tmp_len == p_parse_value->offise)
            {
                p_webmail_session ->b_add_end = true;
                p_parse_value->offise = 0;
                p_webmail_session -> state = client_data;
            }
        }
        else // 写后续的文件片段包
        {
            if(p_parse_value->parse_tmp_len + p_parse_value->len >= p_parse_value->offise)
            {
                // 因为不知道文件什么时候结束，设置成 true等待fin包结束发送结束指令
                p_webmail_session ->b_add_end = true;
                // 假设还有新的数据过来,因为不知道文件什么时候结束
                p_webmail_session -> state = client_data; 

                p_parse_value->offise = 0;
                p_parse_value->parse_tmp_len = 0;
                p_parse_value->post_len += p_parse_value->len;
                p_session->p_send_buf = p_parse_value->buf;
                p_session->send_len = p_parse_value->len;
            }
            else
            {
                p_parse_value->post_len += p_parse_value->len;
                p_parse_value->parse_tmp_len += p_parse_value->len;
                p_session->p_send_buf = p_parse_value->buf;
                p_session->send_len = p_parse_value->len;
            }
        }
    }

    return true;
}
