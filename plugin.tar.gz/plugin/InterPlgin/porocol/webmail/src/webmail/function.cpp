// Last Update:2016-03-30 10:39:58
/**
 * @file function.cpp
 * @brief this is the .cpp file of function.h
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-11-13
 */
#include "function.h"
char * cl_function :: mystrchar(const char * p_source, const uint32_t  source_length, const char *p_desti)//在源缓冲去中查找给定字符串的内容，并且返回其位置,可以单独在响应报文中使用,前提是明确知道内容的长度。
{
    if(p_source == NULL || source_length < 0 || p_desti == NULL)
    {
        return NULL;
    }
    int desti_length = strlen(p_desti);
    char *p_cur = const_cast<char*>(p_source);
    int last_position = source_length - desti_length + 1;
    for(int i = 0; i < last_position; ++i, ++p_cur)
    {
        if(*p_cur == *p_desti)
        {
            if(memcmp(p_cur, p_desti, desti_length) == 0)
            {
                return p_cur;
            }
        }
    }
    return NULL;
}
char * cl_function :: abstract(const char *p_source, const uint32_t source_length, uint32_t& desti_length, const char *p_start_flag, char * *pp_end_flag)    //在源缓冲区中查询标志字符串p_flag后pp_end_flag之前的内容,并由desti_length通过引用将内容长度带出函数(在client_data状态下使用,针对要提取的内容有开始标志，结束标志可以有也可以没有)。
{
    if(p_source == NULL || source_length <= 0)
    {
        desti_length = 0;
        return NULL;
    }
    uint32_t flag_length = strlen(p_start_flag);
    if(flag_length > source_length)
    {
        desti_length = 0;
        return NULL;
    }
    char *p_desti_start = NULL;
    p_desti_start = cl_function :: mystrchar(p_source,source_length, p_start_flag);
    if(p_desti_start == NULL)
    {
        desti_length = 0;
        return NULL;
    }
    p_desti_start += flag_length;
    if(*pp_end_flag == NULL)
    {
        desti_length = source_length - (p_desti_start - p_source );
    }
    else 
    {
        char * p_desti_end = cl_function :: mystrchar(p_desti_start,source_length - (p_desti_start - p_source),  *pp_end_flag);
        if(p_desti_end != NULL)
        {
            desti_length = p_desti_end - p_desti_start;
        }
        else
        {
            desti_length = source_length - (p_desti_start - p_source);
            *pp_end_flag = NULL;
        }
    }
    return p_desti_start;
}
char * cl_function ::abstract(const char *p_source, const uint32_t source_length, uint32_t& desti_length, char * *pp_end_flag )//在缓冲区中查找以p_end_flag为结尾的内容，该标志为如果没有则将整个缓冲区视为需要传输的内容(在client_data_continue状态下使用)。注意参数4使用非const型是因为函数重载。
{
    if(p_source == NULL || source_length <= 0)
    {
        desti_length = 0;
        return NULL;
    }
    char *p_flag = cl_function :: mystrchar(p_source, source_length, *pp_end_flag);
    if(p_flag == NULL)
    {
        desti_length = source_length;
        *pp_end_flag = NULL;
    }
    else
    {
        desti_length = p_flag - p_source;
    }
    return const_cast<char*>(p_source);
}
uint32_t cl_function :: to_int(const char* p_char)
{
   int len = strlen(p_char);
   uint32_t result = 0;
   for(int i = 0; i != len; ++i)
   {
       result += (p_char[i]- '0' )* pow(10, len - i - 1);
   }
   return result ;
}
string cl_function :: to_string(const size_t & input)//将一个整型数变为相应的字符串(string型)。
{
    size_t tmp = input;
    string str_tmp =  "";
    while(tmp != 0)
    {
        str_tmp .insert (str_tmp.begin(), 1, ((tmp % 10) + 48));
        tmp /= 10;
    }
    return str_tmp;
}
