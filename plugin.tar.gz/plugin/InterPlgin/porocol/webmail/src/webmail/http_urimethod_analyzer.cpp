// Last Update:2015-06-02 11:05:07
/**
 * @file  http_urimethod_analyzer.h
 * @brief :
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-03-30
 */

#include "http_urimethod_analyzer.h"
#include <string.h>

http_urimethod_analyzer::http_urimethod_analyzer() {

}

http_urimethod_analyzer::~http_urimethod_analyzer() {

}
// method and uri file
int  http_urimethod_analyzer::http_url_analyer(s_http_request* p_request,char * p_end) {
    int * pint = &(p_request->parsestate);
    s_http_request *r =  p_request;
    c_http_str httpMothed;
    memset(&httpMothed,0x0,sizeof(c_http_str));
    for(;p_request->parsepos < p_end;p_request->parsepos ++)
    {
        switch(*pint)
        {
            case dRStateMethodBegin:
                httpMothed.buf_begin = p_request->parsepos;
                httpMothed.space_use_len=1;
                *pint = dRStateMethod1;	
                break;	
            case dRStateMethod1:
                for(;p_request->parsepos!=NULL && p_request->parsepos < p_end; p_request->parsepos ++)
                {
                    if(*p_request->parsepos != 0x20) httpMothed.space_use_len ++;
                    else
                    {
                        r->HttpMothed = find_http_mothed(httpMothed);
                        if(!(GET == r->HttpMothed||POST == r->HttpMothed ))
                        {
                            return ERROR; 
                        }
                        *pint=dRStateMethodEnd;	
                        break;
                    }
                }
                if(p_request->parsepos == NULL) return BUF_END;
            case dRStateMethodEnd:
                p_request->parsestate =dRStateURIBegin;
                break;
            case dRStateURIBegin:
                r-> Uri.buf_begin = p_request->parsepos;
                r-> Uri.space_use_len =1;
                r->UriWithParam.buf_begin = p_request->parsepos;
                // *pint =dRStateURIFileType1;
                *pint = dRStateURIFile1;
                break;	
            case dRStateURIFile1:
                {
                    switch(*p_request->parsepos)
                    {
                        case '?':
                            *pint= dRStateURIParamBegine;
                            r->UriParam.buf_begin = p_request->parsepos+1;
                            r->UriParam.space_use_len = 0;
                            r-> Uri.space_use_len++;
                            p_request->parsepos ++;
                            break;
                        case '.':
                            *pint = dRStateURIFileTypeBegin;
                            r-> Uri.space_use_len++;
                            break;
                        case 0x20:
                //            r->UriParam.space_use_len= p_request->parsepos - r->UriParam.buf_begin;
                            r->UriWithParam.space_use_len = p_request->parsepos - r->UriWithParam.buf_begin;
                            *pint= dRStateVersion;
                            break;
                        default : 
                            r-> Uri.space_use_len++;
                            break;
                    }
                } 
                break;
            case dRStateURIParamBegine:
                while(p_request->parsepos <  p_end) 
                {
                   if(*p_request->parsepos != 0x20)
                   { 
                     r->UriParam.space_use_len++;
                     p_request->parsepos++;
                   }
                   else {
                       break;
                   }
                }
                r->UriWithParam.space_use_len = p_request->parsepos - r->UriWithParam.buf_begin;
                *pint = dRStateVersion;	
                break;
            case dRStateURIFileTypeBegin:
                r ->UriFileType.buf_begin = p_request->parsepos;	
                r ->UriFileType.space_use_len = 1;	
                r-> Uri .space_use_len++;
                *pint = dRStateURIFileType1;
                break;
            case dRStateURIFileType1:
                switch(*p_request->parsepos)
                {
                    //文件扩展名取最后一个 .
                    case '.': 
                        *pint = dRStateURIFileTypeBegin;
                        break;
                    case '?':
                        *pint= dRStateURIParamBegine;
                        r->UriParam.buf_begin = p_request->parsepos+1;
                        r->UriParam.space_use_len = 0;
                        p_request->parsepos ++;
                        break;
                        //return PASER_CONTINUE;
                    case 0x20:
                        r->UriParam.space_use_len= p_request->parsepos - r->UriParam.buf_begin;
                        r->UriWithParam.space_use_len = p_request->parsepos - r->UriWithParam.buf_begin;
                        *pint = dRStateVersion;	
                        break;
                    default:
                        r-> Uri.space_use_len++;
                        r ->UriFileType.space_use_len ++;	
                }
                break;
            case dRStateVersion:
                http_vesion_analyzer(p_request,p_end);
            default :
                return PASER_CONTINUE;	
        }
    }
    return BUF_END;
}
int http_urimethod_analyzer::http_vesion_analyzer(s_http_request * p_request,char * p_end) {
    int *pint = &p_request->parsestate;
    //p_request->R.UriWithParam.space_use_len = p_request->parsepos - p_request->R.UriWithParam.buf_begin-1;
    for(;p_request->parsepos!=p_end; p_request->parsepos ++)
    {
        switch(*pint)
        {
            case  dRStateVersion:
                if(* p_request->parsepos == 'H')
                {
                    *pint = dRStateH;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                p_request->UriWithParam.space_use_len = p_request->parsepos - p_request->UriWithParam.buf_begin -1;
                break;
            case dRStateH:
                if(* p_request->parsepos == 'T')
                {
                    *pint = dRStateHT;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHT:	
                if(* p_request->parsepos == 'T')
                {
                    *pint = dRStateHTT;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHTT:	
                if(* p_request->parsepos == 'P')
                {
                    *pint = dRStateHTTP;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHTTP:	
                if(* p_request->parsepos == 0x2f)
                {
                    *pint = dRStateHTTP5C;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHTTP5C:	
                if(* p_request->parsepos == '1')
                {
                    *pint = dRStateHTTP5C1;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHTTP5C1:	
                if(* p_request->parsepos == '.')
                {
                    *pint = dRStateHTTP5C12E;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateHTTP5C12E:
                if(* p_request->parsepos == '0')
                {
                    p_request->http_vesion =HTTP1_0;
                    *pint = dRStateVesionEnd;
                }
                else if(*p_request->parsepos == '1')
                {
                    p_request->http_vesion =HTTP1_1;
                    *pint = dRStateVesionEnd;
                }
                else 
                {
                    *pint  = dRStateError;
                    return	ERROR; 
                }
                break;
            case dRStateVesionEnd:
                if(*p_request->parsepos =='\r')
                {
                    *pint = dRStateVesionEnd1;
                }
                else
                {
                    *pint  = dRStateError;	
                    return	ERROR; 
                }
                break;
            case dRStateVesionEnd1:
                if(*p_request->parsepos =='\n')
                {
                    *pint = dRStateKeyBegin;
                }
                else
                {
                    *pint  = dRStateError;	
                    return	ERROR; 
                }
                // 
                break;
            default :
                return PASER_CONTINUE;	

        }	
    }
    return PASER_CONTINUE;	
}

method_type http_urimethod_analyzer::find_http_mothed(c_http_str Mothed_name )
{
    char headname =  *Mothed_name.buf_begin;
    switch(headname)
    {
        case 'C':
            if(Mothed_name. space_use_len == 7 && strncmp("CONNECT",Mothed_name.buf_begin,7)==0)
            {
                return CONNECT;
            }
            else return METHODERROR;
        case 'D':
            if(Mothed_name. space_use_len == 6 && strncmp("DELETE",Mothed_name.buf_begin,6)==0)
            {
                return DELETE;
            }
            else return METHODERROR;
        case 'G':
            if(Mothed_name. space_use_len == 3 && strncmp("GET",Mothed_name.buf_begin,3)==0)
            {
                return GET;
            }
            else return METHODERROR;
        case 'H':
            if(Mothed_name. space_use_len == 4 && strncmp("HEAD",Mothed_name.buf_begin,4)==0)
            {
                return HEAD_M;
            }
            else return METHODERROR;
        case 'O':
            if(Mothed_name. space_use_len == 7 && strncmp("OPTIONS",Mothed_name.buf_begin,7)==0)
            {
                return OPTIONS;
            }
            else return METHODERROR;

        case 'P':
            if(Mothed_name. space_use_len == 3 && strncmp("PUT",Mothed_name.buf_begin,3)==0)
            {
                return PUT;
            }
            else if (Mothed_name. space_use_len == 4 && strncmp("POST",Mothed_name.buf_begin,4)==0)
            {
                return POST;
            }
            else return METHODERROR;

        case 'T':
            if(Mothed_name. space_use_len == 5 && strncmp("TRACE",Mothed_name.buf_begin,3)==0)
            {
                return TRACE;
            }
            else return METHODERROR;
        default : return METHODERROR; 	
    }
    return GET;	
}
int http_respcode_analyer::http_s_version_analysis(s_http_response* pSess, char * p_end)
{
    if(p_end - pSess->parsepos < 8)
    {
        return ERROR;
    }
    if(strncmp("HTTP/1.0", pSess->parsepos,7 ) == 0 || strncmp("TTP/1.0", pSess->parsepos,6 ) == 0)
    {   
        pSess->http_vesion =HTTP1_0;

    }   
    else if(strncmp("HTTP/1.1", pSess->parsepos,7 ) == 0 || strncmp("TTP/1.1", pSess->parsepos,6 ) == 0)
    {   
        pSess->http_vesion =HTTP1_1;
    }   
    else return ERROR;
    pSess->parsepos += 8;
    return PASER_CONTINUE;
}


int http_respcode_analyer::http_s_code_analysis(s_http_response* pSess, char * p_end)
{
   char tmp[4];
    if(*pSess->parsepos == 0x20 ) pSess->parsepos++;
    strncpy(tmp ,pSess->parsepos ,3) ;
    tmp[4] =0x0;
    //printf("%s\n", tmp );
    pSess->http_code =atoi(tmp);
    pSess->parsestate = dSStateCodeName ;
    pSess->parsepos += 4;
    http_s_codename_analysis(pSess, p_end);
    return PASER_CONTINUE;
}


int http_respcode_analyer::http_s_codename_analysis(s_http_response* pSess, char * p_end)
{
    int *pint = &pSess->parsestate;
    for(;pSess->parsepos!=p_end; pSess->parsepos ++)
    {
        switch(*pint)
        {
            case dSStateCodeName:
                pSess->HttpCodeName.buf_begin = pSess->parsepos;
                pSess->HttpCodeName.space_use_len = 1;

                *pint = dStateCodeNameContinue;
                    break;  
            case dStateCodeNameContinue:
                    for(;pSess->parsepos!=p_end; pSess->parsepos ++)
                    {
                        if(*pSess->parsepos!= '\r')
                        {
                            pSess->HttpCodeName.space_use_len++;
                        }
                        else
                        {
                            *pint = dSCodeNameEnd1 ;
                            break;
                        }
                    }
                    break;
            case dSCodeNameEnd1:
                    if(*pSess->parsepos== '\n')
                    {
                        *pint = dRStateKeyName ;
                        pSess->parsepos ++;
                        return PASER_CONTINUE;
                    }
                    else
                    {
                        *pint  = dRStateError;
                        return  ERROR;
                    }
                    break;
            case dSCodeNameEnd2:
                    break;
            default:
                    return PASER_CONTINUE;
        }
    }
}

