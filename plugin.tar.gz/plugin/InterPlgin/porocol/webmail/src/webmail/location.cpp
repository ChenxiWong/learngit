// Last pdate:2015-11-14 14:28:14
/**
 * @file identity.cpp
 * @briefdfasdfasdfas
 * @author lidandan
 * @version 0.1.00
 * @date 2015-10-07
 */

#include "identity.h"
#include "webmail163_parse.h"
#include "webmailsina_parse.h"
#include "webmailsohu_parse.h"
#include "http_cookie_analyzer.h"
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include "cloud_parse.h"   // 调用了这里面的一个函数。。。。。


//初始化函数，将配置文件的doname与函数对应起来
void init_location()
{
    map_marge::get_instance()->add_node_map("post_parse_location", identity_parse::http_requst_post_parse_location);
    map_marge::get_instance()->add_node_map("post2_parse_location", identity_parse::http_requst_post2_parse_location);
    map_marge::get_instance()->add_node_map("post3_parse_location", identity_parse::http_requst_post3_parse_location);
    map_marge::get_instance()->add_node_map("url_parse_location", identity_parse::http_requst_url_parse_location);
//    map_marge::get_instance()->add_node_map("unzip_parse_location", identity_parse::http_response_unzip_parse_location)
    map_marge::get_instance()->add_node_map("urlparam_parse_location", identity_parse::http_requst_urlparam_parse_location);
    map_marge::get_instance()->add_node_map("decode_parse_location", identity_parse::http_requst_urlparam_decode_parse_location);
    map_marge::get_instance()->add_node_map("urlparam3_parse_location", identity_parse::http_requst_urlparam3_parse_location);
    map_marge::get_instance()->add_node_map("lashou_parse_location", identity_parse::http_requst_lashou_parse_location);
    map_marge::get_instance()->add_node_map("strcat_parse_location", identity_parse::http_requst_strcat_parse_location);//截取函数
    map_marge::get_instance()->add_node_map("strcat2_parse_location", identity_parse::http_requst_strcat2_parse_location);//截取函数,先纬度后经度
    map_marge::get_instance()->add_node_map("strcat3_parse_location", identity_parse::http_requst_strcat3_parse_location);//截取函数,先纬度后经度
    map_marge::get_instance()->add_node_map("distinguish_parse_location", identity_parse::http_requst_distinguish_parse_location);//截取函数,先纬度后经度
    map_marge::get_instance()->add_node_map("get_position_info_request", identity_parse::get_position_info_request);// added by wangchenxi
    map_marge::get_instance()->add_node_map("aiguanggongjiao_request_to_response", identity_parse::aiguanggongjiao_request_to_response);// added by wangchenxi
    map_marge::get_instance()->add_node_map("aiguanggongjiao_position_info_response", identity_parse::aiguanggongjiao_position_info_response);// added by wangchenxi
    map_marge::get_instance()->add_node_map("location_turn_session_state",identity_parse::turn_client_state_to_server_state);
    map_marge::get_instance()->add_node_map("url_second_parse",identity_parse::http_requst_url_second_parse);
    map_marge::get_instance()->add_node_map("retaken_parse",identity_parse::http_retaken_parse);
}
//提取url
bool identity_parse::http_requst_url_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->Uri.buf_begin == NULL)
    {
        return true;
    }
    string url = string(p_requst -> Uri.buf_begin,0,p_requst->Uri.space_use_len);
    p_parse_value->value_map.insert(pair<string,string>(string("url_meituan_send_"), url));
    if ( url.size() > 21 )
    {
        url = url.substr(0,21);
    }
    p_parse_value->value_map.insert(pair<string,string>(string("url_send_"), url));
 //   string path="/root/url.txt";
  //  filewrite(path, url+"\n ");
    p_session->send_len = p_parse_value->len;
    p_session->p_send_buf = p_parse_value ->buf;
    return true;
}
/*提取url并从提取出的url中再次提取内容
 * 关键字包含提取内容前后字符，用+号连接*/
bool identity_parse::http_requst_url_second_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->Uri.buf_begin == NULL)
    {
        return true;
    }
    string url = string(p_requst -> Uri.buf_begin,0,p_requst->Uri.space_use_len);
    string value = "";
    size_t ibegin = 0;
    size_t iend = 0;
    string key_begin = "";//截取开始字符串
    string key_end = "";
    char* p_pos = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = iter->c_str();
        string name ="url_second_";
        name += tmp;
        ibegin = tmp.find("+");
        if(ibegin != string::npos )
        {
            key_begin =  tmp.substr(0,ibegin);
            key_end = string(tmp,ibegin+1);
        }
        else if (tmp != "") 
        {
            key_begin = tmp;
        }
        if (key_end == "")
        {
            key_end = "&";
        }
        ibegin = url.find(key_begin);
        if (ibegin!=string::npos && ibegin<url.size() && ibegin>0 )
        {
            ibegin +=key_begin.size();
            iend = 0;
            iend = url.find(key_end,ibegin);
            if (iend!=string::npos && iend<url.size() && iend>0 && iend>ibegin )
            {
                value=url.substr(ibegin,iend-ibegin);
                string goods = urldecode(value);//url 解码  
                value = goods;
                p_parse_value->value_map.insert(pair<string,string>(name,value));
            }
            else if (iend == string::npos)
            {
                value = string(url,ibegin);
                string goods = urldecode(value);//url 解码  
                value = goods;
                p_parse_value->value_map.insert(pair<string,string>(name,value));
            }
        }
    }
    p_session->send_len = p_parse_value->len;
    p_session->p_send_buf = p_parse_value ->buf;
    return true;
}



//url解析，跟163里面的解析完全相同，只是增加了测试代码，待确认后可以删掉用已有的函数替换
bool identity_parse::http_requst_urlparam_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    http_urlparam_analyzer url_param;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string name = "";
    c_http_str * p = &(p_requst->UriParam);
    s_key_value * phead =NULL;
    url_param.ParamAnakyses(p,phead);
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        c_http_str * p_value = find_key_value(phead,iter->c_str());
        if(p_value != NULL)
        {
            name = "requset_urlparam_";
            name += *iter;
            if(p_value->space_use_len <= 0 || p_value->buf_begin == NULL)
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
            string svalue(p_value->buf_begin,p_value->space_use_len);
            string goods = urldecode(svalue);//url 解码  
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name,svalue));
        }
    }
    s_key_value_free(phead);
    return true;
}

//判定是否提取成功函数
bool identity_parse::http_requst_distinguish_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            p_session->send_len = 1;
            p_session->p_send_buf = NO_NULL;
        }
    }
    return true;
}

bool identity_parse::http_retaken_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string whole_name = *iter;
        string name = "";
        string start_sign = "";
        string end_sign = "";
        size_t i = 0;
        size_t j = 0;
        i = whole_name.find("+");
        i++;
        if (i!=string::npos && i<whole_name.size() && i>0)
        {
            name = whole_name.substr(0,i-1);
            j = whole_name.find('+',i);
            j++;
            if (j!=string::npos && j<whole_name.size() && j>0 && j>(i+1) )
            {
                start_sign = whole_name.substr(i,j-i-1);
            }
            end_sign = whole_name.substr(j);
        }
        if(name != "")
        {
            parse_value_map ::iterator iterator = p_parse_value ->value_map.find(name);
            if (iterator != p_parse_value->value_map.end())
            {
                size_t ibegin=0;
                size_t iend=0;
                string tmp = iterator->second;
                string tockens = urldecode(tmp);
                if(start_sign == "")
                {
                    if (end_sign== "")
                    {
                        p_parse_value->value_map.insert(pair<string,string>(whole_name,tockens));
                    }
                    else if (end_sign != "")
                    {
                        iend = tockens.find(end_sign);
                        if (iend!=string::npos && iend<tockens.size() && iend>0 )
                        {
                            string svalue=tockens.substr(0,iend);
                            p_parse_value->value_map.insert(pair<string,string>(whole_name,svalue));
                        }
                    }
                }
                else if (start_sign != "")
                {
                    ibegin = tockens.find(start_sign);
                    ibegin += start_sign.length();
                    if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
                    {
                        if (end_sign== "")
                        {
                            string svalue  = tockens.substr(ibegin); 
                            p_parse_value->value_map.insert(pair<string,string>(whole_name,tockens));
                        }
                        else if (end_sign != "")
                        {
                            iend = tockens.find(end_sign,ibegin);
                            if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                            {
                                string svalue=tockens.substr(ibegin,iend-ibegin);
                                p_parse_value->value_map.insert(pair<string,string>(whole_name,svalue));
                            }
                        }
                    }
                }
            }
        }
    }
    return true;
}
//大众点评urlparam截取，截取方式是再次找关键字，与上面不同
bool identity_parse::http_requst_urlparam_decode_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    size_t ibegin=0;
    size_t iend=0;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = "requset_urlparam_";
        name += *iter;
        parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            string tmp = iterator->second;
            string tockens = urldecode(tmp);
            ibegin = tockens.find("lng=");
            ibegin +=4;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find('&',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lon=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lon));
                    //string path="/root/url.txt";
                    //filewrite(path, lon+"\n");
                }
            }
            ibegin = tockens.find("lat=");
            ibegin+=4;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find('&',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
            ibegin = tockens.find("device_id=");
            ibegin+=10;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find('&',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_device",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
            ibegin = tockens.find("guid_str=");
            ibegin+=10;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find('&',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_uid",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
        }
    }
    return true;
}
//lashou
bool identity_parse::http_requst_lashou_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    size_t ibegin=0;
    size_t iend=0;
    size_t imid=0;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            string tmp = iterator->second;
            string tockens = urldecode(tmp);
            ibegin = tockens.find("location=");
            ibegin +=9;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                imid = tockens.find(',',ibegin);
                if (imid!=string::npos && imid<tockens.size() && imid>0 && imid>ibegin )
                {
                    lon=tockens.substr(ibegin,imid-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lon));
                    iend = tockens.find(';',imid);
                    if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>imid )
                    {
                        lat=tockens.substr(imid+1,iend-imid-1);
                        p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lat));
                        //string path="/root/url.txt";
                        // filewrite(path, lon+"\n");
                        //filewrite(path, lat+"\n");
                    }
                }
            }
            ibegin = tockens.find("imei=");
            ibegin+=5;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find(',',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_imei",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
            ibegin = tockens.find("sim=");
            ibegin+=4;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find(',',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_sim",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
            ibegin = tockens.find("userid=");
            ibegin+=7;
            if (ibegin!=string::npos && ibegin<tockens.size() && ibegin>0)
            {
                iend = tockens.find(',',ibegin);
                if (iend!=string::npos && iend<tockens.size() && iend>0 && iend>ibegin )
                {
                    lat=tockens.substr(ibegin,iend-ibegin);
                    p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_uid",lat));
                    // string path="/root/url.txt";
                    // filewrite(path, lat+"\n");
                }
            }
        }
    }
    return true;
}

//拆分函数。用于先经度后纬度的情况
bool identity_parse::http_requst_strcat_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    unsigned int i=0;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            string tmp = iterator->second;
            i = tmp.find(',');
            if (i!=string::npos && i<tmp.size() && i>0)
            {
                lon=tmp.substr(0,i);
                lat = tmp.substr(i+1,tmp.size());
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lat));
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lon));
                //string path="/root/url.txt";
                //filewrite(path, lat+"\n");
                // filewrite(path, lon+"\n");
            }
        }

    }
    return true;
}
//拆分函数。用于先纬度后经度的情况
bool identity_parse::http_requst_strcat2_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    string tmp ="";
    unsigned int i=0;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    parse_value_map ::iterator iterator;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            tmp = iterator->second;
            i = tmp.find(',');
            if (i!=string::npos && i<tmp.size() && i>0)
            {
                lon=tmp.substr(0,i);
                lat = tmp.substr(i+1,tmp.size());
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lon));
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lat));
                /* string path="/root/url.txt";
                   filewrite(path, lat+"\n");
                   filewrite(path, lon+"\n");*/
            }
        }
    }
    return true;
}
//拆分函数，andr百度我的位置专用，因为内容被（）包裹起来了
bool identity_parse::http_requst_strcat3_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    string tmp ="";
    unsigned int i=0;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    parse_value_map ::iterator iterator;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            tmp = iterator->second;
            i = tmp.find(',');
            if (i!=string::npos && i<tmp.size() && i>0)
            {
                lon=tmp.substr(1,i-1);
                lat = tmp.substr(i+1,tmp.size()-i-2);
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lat));
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lon));
                /*string path="/root/url.txt";
                  filewrite(path, lat+"\n");
                  filewrite(path, lon+"\n");*/
            }
        }
    }
    return true;
}
//美团外卖专用，因为从url截取而不是urlparam
bool identity_parse::http_requst_urlparam3_parse_location(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string lon="";
    string lat="";
    string tmp ="";
    size_t ibegin=0;
    size_t imid=0;
    string name = "url_meituan_send_";
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
    if (iterator != p_parse_value->value_map.end())
    {
        tmp = iterator->second;
        ibegin = tmp.find("latlng");
        ibegin += 7;
        if (ibegin!=string::npos && ibegin<tmp.size() && ibegin>0)
        {
            imid = tmp.find(',',ibegin);
            if (imid!=string::npos && imid<tmp.size() && imid>0 && imid>ibegin)
            {
                lat = tmp.substr(ibegin,imid-ibegin);
                lon = tmp.substr(imid+1,tmp.size());
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_latitude",lat));
                p_parse_value->value_map.insert(pair<string,string>("requset_urlparam_longitude",lon));
                /* string path="/root/url.txt";
                   filewrite(path, lat+"\n");
                   filewrite(path, lon+"\n");*/
                p_session->send_len = 1;
                p_session->p_send_buf = NO_NULL;
            }
        }
    }
    return true;
}

//请求体解析关键字 =
bool identity_parse::http_requst_post_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    p_webmail_session -> state = client_data_continue;
    if(p_webmail_session ->p_parse_value->buf == NULL || p_webmail_session ->p_parse_value->len == 0)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if( p_parse_value -> len <  p_webmail_session ->requset_length) 
    {
        p_webmail_session -> state = client_data;
        return false;
    }
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += "=";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, '&');//&处结束
            if(p_end != NULL && p_end> p_pos)
            {
                name = "requset_post_";
                name += *iter;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) && (p_pos != NULL) )
            {
                p_end =p_parse_value -> buf + p_parse_value ->len;
                if(p_end != NULL && p_end>p_pos)
                {
                    name = "requset_post_";
                    name += *iter;
                    string svalue(p_pos, 0, p_end-p_pos);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                }
            }
            p_webmail_session -> state = server_data;
        }
    }
    return true;
}
//墨迹天气专用 :
bool identity_parse::http_requst_post3_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    p_webmail_session -> state = client_data_continue;
    if(p_webmail_session ->p_parse_value->buf == NULL || p_webmail_session ->p_parse_value->len == 0)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if( p_parse_value -> len <  p_webmail_session ->requset_length) 
    {
        p_webmail_session -> state = client_data;
        return false;
    }
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += " : ";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, ',');//&处结束
            p_end2 = strstr(p_pos, "\r\n");
            if( (p_end != NULL && p_end< p_end2) || p_end2==NULL)
            {
                if(p_end <= p_pos) return true;
                name = "requset_post_";
                name += *iter;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) || (p_end2 != NULL && p_end> p_end2) ) 
            {
                if(p_end2 <= p_pos) return true;
                name = "requset_post_";
                name += *iter;
                string svalue(p_pos, 0, p_end2-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            p_webmail_session -> state = server_data;
        }
    }
    return true;
}
//请求体解析，内容用“扩起来的”
bool identity_parse::http_requst_post2_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    p_webmail_session -> state = client_data_continue;
    if(p_webmail_session ->p_parse_value->buf == NULL || p_webmail_session ->p_parse_value->len == 0)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if( p_parse_value -> len <  p_webmail_session ->requset_length) 
    {
        p_webmail_session -> state = client_data;
        return false;
    }
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;//找关键字用
    char* p_pos1 = NULL;//找第一个”用
    char* p_pos2 = NULL;//找第二个“用
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到关键字之后
            p_pos1 = strchr(p_pos, '\"');//找到第一个“
            if(p_pos1 != NULL && p_pos1>p_pos)
            {
                p_pos1++;
                p_pos2 = strchr(p_pos1, '\"');//找到第二个“
                if(p_pos2 != NULL && p_pos2>p_pos1)
                {
                    name = "requset_post_";
                    name += *iter;
                    string svalue(p_pos1, 0, p_pos2-p_pos1);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                    /*string path="/root/url.txt";
                      filewrite(path, name+":");
                      filewrite(path, svalue+"\n");*/

                }
            }
            p_webmail_session -> state = server_data;
        }
    }
    return true;
}

// 干实事儿的苦力
static bool deal_info (session* p_session,
        webmail_session* p_webmail_session,
        string& svalue,
        string& add_name,
        const char* search_start,
        const char* search_start_1 = NULL)
{
    if( add_name == "_lashoutuangouweizhi_request_1")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "location=", add_name, search_start, ",", 9, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "location", add_name, search_start, "&", 9, 0))
        {
            return false;
        }
        else
        {
            parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("location_lashoutuangouweizhi_request_1");
            string::size_type cur = iter->second.find_first_of(',');
            p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("location_lashoutuangouweizhi_request_1_end", iter->second.substr(cur+1)));
        }
    }
    else if( add_name == "_lashoutuangouweizhi_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue,  "userid=", add_name, search_start_1, ";", 7, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "imei=", add_name, search_start_1, ";", 5, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "location=", add_name, search_start_1, ",", 9, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "location", add_name, search_start_1, ";", 9, 0))
        {
            return false;
        }
        else
        {
            parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("location_lashoutuangouweizhi_request");
            string::size_type cur = iter->second.find_first_of(',');
            p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("location_lashoutuangouweizhi_request_end", iter->second.substr(cur+1)));
        }
    }
    else if( add_name == "_8684shanghaiditu_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "lat=", add_name, search_start, ".", 4, -5))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "lng", add_name, search_start, "&", 4, 0))
        {
            return false;
        }
    }
    else if( add_name == "_xiechengzhoubianjiudian_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "pos", add_name, search_start, "|", 6, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "|", add_name, search_start, "\"",1 , 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "cid", add_name, search_start, "\"", 6, 0))
        {
            return false;
        }
    }
    else if( add_name == "_mojitianqi_ios_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "identifier", add_name, search_start, "\"", 15, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "uid", add_name, search_start, ",", 6, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "platform", add_name, search_start, "\"", 13, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "device", add_name, search_start, "\"", 11, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "latitude", add_name, search_start, ",", 11, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "net", add_name, search_start, "\"", 8, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "longitude", add_name, search_start, "\n", 12, 0))
        {
            return false;
        }
    }
    else if( add_name == "_daohangquan_ios_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "guid", add_name, search_start, "\"", 7, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "longitude", add_name, search_start, ",", 22, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "latitude", add_name, search_start, ")", 12, 0))
        {
            return false;
        }
        else
        {
            parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("latitude_daohangquan_ios_request");
            string::size_type cur = iter->second.find_first_of(',');
            p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("latitude_daohangquan_ios_request_end", iter->second.substr(cur+1)));
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "pcode", add_name, search_start, "\"", 8, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "sign", add_name, search_start, "\"", 7, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "city", add_name, search_start, "\"", 7, 0))
        {
            return false;
        }
    }
    else if( add_name == "_ganjishenghuo_request")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "coordinate", add_name, search_start, ",", 11, 0, "value", ",", 8, 0))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "coordinat", add_name, search_start, ",", 11, -9, "value", "\"", 8, 0))
        {
            return false;
        }
        else
        {
            parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("coordinat_ganjishenghuo_request");
            string::size_type cur = iter->second.find_first_of(',');
            string svalue = iter->second.substr(cur+1);
            string::size_type cur1 = svalue.find_first_of(',');
            if(string::npos == cur1)
            {
                p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("coordinat_ganjishenghuo_request_end", svalue));
            }
            else
            {
                string svalue1(iter->second.c_str(), cur+1, cur1);
                p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("coordinat_ganjishenghuo_request_end", svalue1));
            }
        }
    }
    else if( add_name == "_aiguanggongjiao_response")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "latlng\"", add_name, search_start, ",", 9, 0, "latlng", ",", 7, 0))
            return false;
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "\"latlng", add_name, search_start, "\"", 10, 0, "latlng", "<", 7, 0))
        {
            return false;
        }
        else
        {
            parse_value_map::iterator iter = p_webmail_session->p_parse_value->value_map.find("\"latlng_aiguanggongjiao_response");
            string::size_type cur = iter->second.find_first_of(',');
            p_webmail_session->p_parse_value->value_map.insert(pair<string,string>("\"latlng_aiguanggongjiao_response_end", iter->second.substr(cur+1)));
        }
    }
    else if( add_name == "_PCgaodedingwei_response")
    {
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "lat", add_name, search_start, ",", 6, 1))
        {
            return false;
        }
        if(!get_option_and_push_to_map(p_session, p_webmail_session, svalue, "lng", add_name, search_start, "\"", 6, 0))
        {
            return false;
        }
    }
    else
    {
        return false;
    }
    return true;
}

/*
 *    请求体解析
 */
bool identity_parse::get_position_info_request(session* p_session,
        webmail_session* p_webmail_session,
        s_http_request* p_requst,
        s_http_response* p_response,
        node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    p_parse_value->parse_type = LOCATION;
    string svalue = "";
    node_value_list::iterator iter = v_list.begin();
    string add_name = * iter;
    string content_length_name ("Content-Length");
    content_length_name += add_name;
    if(p_webmail_session->state == client_data)
    {
        string str_content_length ("");
        if(!get_string_from_http_context(str_content_length, p_buf, "Content-Length:", "\r\n", 15, 0))
        {
            return false;
        }
        int int_content_length = atoi(str_content_length.c_str());
        p_webmail_session->requset_length = int_content_length;
        char* p_body_start = strstr(p_buf, "\r\n\r\n") ;
        if(p_body_start == NULL)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        p_body_start += 4;
        uint32_t body_len = buf_len - ( p_body_start  - p_buf);
        if(body_len < p_webmail_session->requset_length)
        {
            p_parse_value->value_map.insert(pair<string,string>(content_length_name, str_content_length));
            p_webmail_session->state = client_data_continue;
            return true;
        }
        if(!deal_info(p_session, p_webmail_session, svalue, add_name, p_body_start, p_buf))
        {
            return false;
        }
    }
    else if(p_webmail_session->state == client_data_continue)
    {
        parse_value_map::iterator iter_1 = p_parse_value->value_map.find(content_length_name);
        int content_length_tmp = atoi(iter_1->second.c_str());
        char *c_str_tmp = strstr(p_buf, "\r\n\r\n");
        if( c_str_tmp == NULL)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
        char* p_body_start = c_str_tmp + 4;
        int body_len = buf_len - ( p_body_start  - p_buf);
        if(body_len < content_length_tmp)
        {
            return true;
        }
        if(!deal_info(p_session, p_webmail_session, svalue, add_name, p_body_start, p_buf))
        {
            return false;
        }
        p_webmail_session ->requset_length = 0;
    }
    p_webmail_session->b_end_send = true;
    p_session->p_send_buf = NO_NULL;
    p_session->send_len = 1;
    return true;
}

/*
 * 转换状态
 */
bool identity_parse::aiguanggongjiao_request_to_response(session* p_session,
        webmail_session* p_webmail_session,
        s_http_request* p_requst,
        s_http_response* p_response,
        node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->client.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    p_parse_value->parse_type = LOCATION;
    string content_length_name = "request_aibanggongjiao_body_Content-Length";
    if(p_webmail_session->state == client_data)
    {
        string str_content_length ("");
        if(!get_string_from_http_context(str_content_length, p_buf, "Content-Length:", "\r\n", 15, 0))
        {
            return false;
        }
        int int_content_length = atoi(str_content_length.c_str());
        p_webmail_session->requset_length = int_content_length;
        char* p_body_start = strstr(p_buf, "\r\n\r\n") ;
        if(p_body_start == NULL)
        {
            return true;
        }
        p_body_start += 4;
        uint32_t body_len = buf_len - ( p_body_start  - p_buf);
        if(body_len < p_webmail_session->requset_length)
        {
            p_parse_value->value_map.insert(pair<string,string>(content_length_name, str_content_length));
            p_webmail_session->state = client_data_continue;
            return true;
        }
    }
    else if (p_webmail_session->state == client_data_continue)
    {
        parse_value_map::iterator iter_1 = p_parse_value->value_map.find(content_length_name);
        uint32_t content_length_tmp = atoi(iter_1->second.c_str());
        char* p_body_start = strstr(p_buf, "\r\n\r\n") + 4;
        uint32_t body_len = buf_len - ( p_body_start  - p_buf);
        if(body_len < content_length_tmp)
        {
            return true;
        }
    }
    p_webmail_session->state = server_data;
    return true;
}

/*
 *将响应内容解压
 */
bool gzip_deal_info_response(session* p_session,
        webmail_session* p_webmail_session,
        string& svalue,
        string& add_name,
        char* p_body_start)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string key("response_head_key_Content-Encoding");
    parse_value_map::iterator iter = p_parse_value->value_map.find(key);
    if(iter != p_parse_value->value_map.end())
    {
        uint32_t size = iter->second.find("gzip");
        if(string::npos != size)
        {
            p_parse_value->bgzip = true;
        }
    }
    p_parse_value->gzip_len = p_webmail_session->response_length ;
    p_parse_value->gzip_buffer = new char[p_parse_value->gzip_len];
    if( NULL == p_parse_value->gzip_buffer)
    {
        return false;
    }
    memset(p_parse_value->gzip_buffer, 0, p_parse_value->gzip_len);
    memcpy(p_parse_value->gzip_buffer, p_body_start + 4, p_parse_value->gzip_len);
    p_parse_value->parse_tmp_len = p_parse_value->gzip_len * 10;
    p_parse_value->parse_tmp_buf = new char[p_parse_value->parse_tmp_len];
    memset(p_parse_value->parse_tmp_buf, 0, p_parse_value->parse_tmp_len);
    if( NULL ==p_parse_value->parse_tmp_buf)
    {
        delete[] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
        return false;
    }
    int ret = httpgzdecompress((Bytef *)p_parse_value->gzip_buffer ,(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  , (uLong*)& p_parse_value->parse_tmp_len);
    delete[] p_parse_value->gzip_buffer;
    p_parse_value->gzip_buffer = NULL;
    p_parse_value->gzip_len = 0;
    if( ret != 0)
    {
        p_parse_value->parse_tmp_len  = 0;
        p_session->p_send_buf = NO_NULL;
        if (p_parse_value->parse_tmp_buf != NULL) 
        {
            delete [] p_parse_value->parse_tmp_buf;
            p_parse_value->parse_tmp_buf = NULL; 
            p_parse_value->parse_tmp_len = 0;
        }
        return false;
    }
    if(!deal_info(p_session, p_webmail_session, svalue, add_name, p_parse_value->parse_tmp_buf ))
    {
        delete[] p_parse_value->parse_tmp_buf;
        p_parse_value->parse_tmp_buf = NULL;
        p_parse_value->parse_tmp_len = 0;
        return false;
    }
    delete[] p_parse_value->parse_tmp_buf;
    p_parse_value->parse_tmp_buf = NULL;
    p_parse_value->parse_tmp_len = 0;
    return true;
}

/*
 *从响应体中提取位置信息
 */
bool identity_parse::aiguanggongjiao_position_info_response(session* p_session,
        webmail_session* p_webmail_session,
        s_http_request* p_requst,
        s_http_response* p_response,
        node_value_list& v_list)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    uint32_t buf_len = 0;
    char* p_buf = (char*) p_session->server.get_tcp_data(buf_len);
    if(NULL == p_buf)
    {
        return true;
    }
    p_parse_value->parse_type = LOCATION;
    string svalue = "";
    node_value_list::iterator iter = v_list.begin();
    string add_name = * iter;
    if(p_webmail_session->state == server_data)
    {
        char* p_body_start = strstr(p_buf, "\r\n\r\n");
        if(p_body_start == NULL)
        {
            return true;
        }
        int body_len = buf_len - ( p_body_start + 4 - p_buf);
        if(body_len < p_webmail_session->response_length)
        {
            p_webmail_session->state = server_data_continue;
            return true;
        }
        if( add_name == "_aiguanggongjiao_response")
        {
            if(!gzip_deal_info_response(p_session, p_webmail_session, svalue, add_name, p_body_start))
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
        }
        else if ( add_name == "_PCgaodedingwei_response")
        {
            if(!deal_info(p_session, p_webmail_session, svalue, add_name, p_body_start, p_buf))
            {
                return false;
            }
        }
    }
    else if (p_webmail_session->state == client_data_continue)
    {
        char* p_body_start = strstr(p_buf, "\r\n\r\n");
        if(p_body_start == NULL)
        {
            return true;
        }
        uint32_t body_len = buf_len - ( p_body_start - p_buf);
        if(body_len < p_webmail_session->requset_length)
        {
            return true;
        }
        if( add_name == "_aiguanggongjiao_response")
        {
            if(!gzip_deal_info_response(p_session, p_webmail_session, svalue, add_name, p_body_start))
            {
                p_session->send_len = 0;
                p_session->p_send_buf = NO_NULL;
                return false;
            }
        }
        else if ( add_name == "_PCgaodedingwei_response")
        {
            if(!deal_info(p_session, p_webmail_session, svalue, add_name, p_body_start, p_buf))
            {
                return false;
            }
        }
    }
    p_webmail_session->b_end_send = true;
    p_session->p_send_buf = NO_NULL;
    p_session->send_len = 1;
    return true;
}
bool identity_parse::turn_client_state_to_server_state(session *p_session,
        webmail_session *p_webmail_session,
        s_http_request *p_request,
        s_http_response *p_respnse,
        node_value_list& v_list)
{
    p_webmail_session->state = server_data;
    return true;
}
/*
//解压缩应答体
bool identity_parse::http_response_unzip_parse_location(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
if (!p_webmail_session->anjuke_flag)//不是安居客
{
return true;
}
parse_value * p_parse_value = p_webmail_session ->p_parse_value;
if (p_parse_value->len < (uint32_t)(p_webmail_session->response_length))
{
p_webmail_session -> state = server_data;
return false;
}
if (p_webmail_session->state == server_data)//第一个包，先判是否压缩 
{
string key2 = "response_head_key_Content-Encoding";
parse_value_map::iterator iter2 = p_parse_value->value_map.find(key2);
if (iter2 != p_parse_value->value_map.end())
{
string tmp = iter2->second;
uint32_t size = tmp.find("gzip");
if (size != string::npos)
{
p_parse_value -> bgzip = true;
}
}
if ((uint32_t)(p_webmail_session->response_length) > 0 && (int32_t)(p_webmail_session->response_length) <= (uint32_t)(p_parse_value->len))
{
p_webmail_session ->b_end_send = true;
}
}
if (p_parse_value->buf == NULL || p_parse_value->len == 0)
{
p_webmail_session -> state = server_data_continue;
p_session->server.clear_buf();
return true;
}

if (p_parse_value -> bgzip)
{
if (p_parse_value->gzip_buffer == NULL)
{
webmailsina_parse::response_handle_sohu_body_length(p_session ,p_webmail_session ,p_requst ,  p_response , v_list);
p_parse_value->gzip_buffer = new  char[p_webmail_session ->response_length  + 20];
if(p_parse_value->gzip_buffer == NULL)
{
return false;
}
}
if (p_webmail_session ->response_length >0)
{
p_webmail_session ->response_length -= p_parse_value->len;
if (p_webmail_session ->response_length <= 0)
{
p_parse_value->parse_tmp_buf = NULL;
{
p_parse_value->len += p_webmail_session ->response_length;
memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len  , p_parse_value->buf,p_parse_value->len);
p_parse_value->gzip_len += p_parse_value->len;
p_parse_value->parse_tmp_len =p_parse_value->gzip_len * 10;
p_parse_value->parse_tmp_buf = new  char [p_parse_value->gzip_len * 10] ;
}
if (p_parse_value->parse_tmp_buf == NULL)
{
return true;
}
//解压文件
int ret  = httpgzdecompress((Bytef *)p_parse_value->gzip_buffer ,(uLong)p_parse_value->gzip_len ,(Bytef *) p_parse_value->parse_tmp_buf  , (uLong*)& p_parse_value->parse_tmp_len);
delete [] p_parse_value->gzip_buffer ;
p_parse_value->gzip_buffer = NULL; 
p_parse_value->gzip_len = 0;

if(ret == 0 )
{
    p_parse_value->parse_tmp_buf[p_parse_value->parse_tmp_len ] = 0x0;
    //解压成功，读取值
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->parse_tmp_buf;
    string key3 = "status\":";
    p_pos = strstr(p_begin,key3.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key3.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            p_webmail_session -> state = client_data;
        }
    }
    if (p_parse_value->parse_tmp_buf != NULL) 
    {
        delete [] p_parse_value->parse_tmp_buf;
        p_parse_value->parse_tmp_buf = NULL; 
        p_parse_value->parse_tmp_len = 0;
    }
    return true;
}
else//是压缩格式但解压失败
{
    // 清理数据
    p_parse_value->parse_tmp_len  = 0;
    p_session->p_send_buf = NO_NULL;
    if (p_parse_value->parse_tmp_buf != NULL) 
    {
        delete [] p_parse_value->parse_tmp_buf;
        p_parse_value->parse_tmp_buf = NULL; 
        p_parse_value->parse_tmp_len = 0;
    }
    return true;
}
}
else
{
    memcpy(p_parse_value->gzip_buffer + p_parse_value->gzip_len  , p_parse_value->buf,p_parse_value->len);
    p_parse_value->gzip_len += p_parse_value->len;
    p_webmail_session -> state = server_data_continue;
    return true;
}
}
else
{
    p_session->send_len = p_parse_value->len ;
    p_session->send_len = 1;
    p_session->p_send_buf = NO_NULL;
}
}
p_session->server.clear_buf();
return true;
}
*/
