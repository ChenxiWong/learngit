// Last pdate:2015-11-14 14:28:14
/**
 * @file identity.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-10-07
 */

#include "identity.h"
#include "webmail163_parse.h"
#include "webmailsina_parse.h"
#include "http_cookie_analyzer.h"
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include "commit_tools.h"

using namespace std;
static string webname = "";

void itoa_(int n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}
static int php_htoi(char *s)  
{  
    int value;  
    int c;  

    c = ((unsigned char *)s)[0];  
    if (isupper(c))  
        c = tolower(c);  
    value = (c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10) * 16;  

    c = ((unsigned char *)s)[1];  
    if (isupper(c))  
        c = tolower(c);  
    value += c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10;  

    return (value);
}
//url解码函数:utf-8类型
string urldecode(string &str_source)
{
    char const *in_str = str_source.c_str();  
    int in_str_len = strlen(in_str);  
    int out_str_len = 0;  
    string out_str;  
    char *str;  

    str = strdup(in_str);  
    char *dest = str;  
    char *data = str;  
    while (in_str_len--)
    {
        if (*data == '+') 
        {
            *dest = ' ';  
        }
        else if (*data == '%' && in_str_len >= 2 && isxdigit((int) *(data + 1))   
                && isxdigit((int) *(data + 2))) 
        {
            *dest = (char) php_htoi(data+1);  
            data += 2;  
            in_str_len -= 2;  
        }
        else 
        {
            *dest = *data;  
        }
        data++;
        dest++;
    }
    *dest = '\0';  
    out_str_len =  dest - str;  
    out_str = str;  
    free(str);  
    return out_str;  
}

//写文件函数，path是文件路径和文件名，content是要写入文件的内容
int filewrite(string path,string content)
{
    ofstream out;  
    //第二个参数控制写文件时不覆盖之前的内容
    out.open(path.c_str() ,ios_base::app);
    if (out.is_open())   
    {  
        out << content ;    
        out.flush();
        out.close();  
    } 
    return 0;  
}  


//初始化函数，将配置文件的doname与函数对应起来
void init_identity()
{
    map_marge::get_instance()->add_node_map("identity_url", identity_parse::identity_url_parse);
    map_marge::get_instance()->add_node_map("identity_response", identity_parse::identity_response_parse);
    map_marge::get_instance()->add_node_map("identity_response_anjuke", identity_parse::identity_response_parse_anjuke);
    map_marge::get_instance()->add_node_map("identity_response_dongfang", identity_parse::identity_response_parse_dongfang);
    map_marge::get_instance()->add_node_map("identity_response_yingshi", identity_parse::identity_response_parse_yingshi);
    map_marge::get_instance()->add_node_map("identity_response_yiche", identity_parse::identity_response_parse_yiche);
    map_marge::get_instance()->add_node_map("identity_response_yicheregiste", identity_parse::identity_response_parse_yicheregiste);
    map_marge::get_instance()->add_node_map("identity_response_gzip", identity_parse::identity_response_gzip_parse);
    map_marge::get_instance()->add_node_map("identity_response_gzip_zhenai", identity_parse::identity_response_gzip_parse_zhenai);
    map_marge::get_instance()->add_node_map("identity_request", identity_parse::identity_request_parse);
    
    map_marge::get_instance()->add_node_map("identity_request1", identity_parse::identity_request_parse1);//xiaojun add
    map_marge::get_instance()->add_node_map("identity_request_qq", identity_parse::identity_request_parse_qq);
    map_marge::get_instance()->add_node_map("identity_request2", identity_parse::identity_request_parse2);
    map_marge::get_instance()->add_node_map("validity_distinguish", identity_parse::validity_distinguish);
    map_marge::get_instance()->add_node_map("identity_request_parse_zhenai", identity_parse::identity_request_parse_zhenai);
    
    map_marge::get_instance()->add_node_map("identity_bxw_user", identity_parse::identity_bxw_user_parse);
    map_marge::get_instance()->add_node_map("identity_lashou_reg", identity_parse::identity_lashou_reg_parse);
    map_marge::get_instance()->add_node_map("identity_dzdp_user", identity_parse::identity_dzdp_parse);
    map_marge::get_instance()->add_node_map("identity_zhenai_user", identity_parse::identity_zhenai_parse);
    map_marge::get_instance()->add_node_map("identity_anjuke_reg", identity_parse::identity_anjuke_reg);
    map_marge::get_instance()->add_node_map("identity_qq", identity_parse::identity_qq_reg);
    map_marge::get_instance()->add_node_map("unic_to_utf", identity_parse::unic_to_utf);

    init_location();
}

//提取url
bool identity_parse::identity_url_parse(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list)
{
    if(p_requst == NULL || p_response == NULL)
    {
        return true;
    }
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_requst->Uri.buf_begin == NULL)
    {
        return true;
    }
    // ***************************
    if (strstr(p_requst -> Uri.buf_begin, "act=login"))
    {
        p_parse_value->parse_type = LOGIN;
    }
    else if (strstr(p_requst -> Uri.buf_begin, "act=reg") || strstr(p_requst -> Uri.buf_begin, "act=checkName"))
    {
        p_parse_value->parse_type = REGIST;
    }
    string url = string(p_requst -> Uri.buf_begin,0,p_requst->Uri.space_use_len);
    p_parse_value->value_map.insert(pair<string,string>(string("url_send_"), url));
    return true;
}
//请求体提取。
bool identity_parse::identity_request_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> state == client_data)
    {
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);//取请求体的长度
        if(p_webmail_session ->requset_length == 0)//没有请求体 
        {
            p_session->p_send_buf = NULL;
            p_session->send_len = 0;
            p_webmail_session -> state = server_data;
            return true;
        }
        p_webmail_session -> state = client_data_continue;
        if(p_parse_value->buf == NULL || p_parse_value->len == 0)
        {
            p_session->p_send_buf = NULL;
            p_session->send_len = 0;
            return true;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            return false;
        }
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        pfind +=4;
        if(pfind != NULL)
        {
            p_parse_value -> len = p_parse_value -> len -(pfind - p_parse_value->buf);
            p_parse_value->buf = pfind;
        }
    }
    if( p_parse_value -> len <  p_webmail_session ->requset_length)//在组包函数中，如果达到字数，请求要求长度就会被置为0
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
        p_webmail_session -> state = client_data_continue;
        return true;
    }
    p_parse_value -> len = p_webmail_session ->requset_length;
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += "=";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, '&');//&处结束
            p_end2 =p_parse_value -> buf + p_parse_value ->len;
            if(p_end != NULL && p_end <= p_end2)
            {
                name = "requset_post_";
                name += *iter;
                if(p_end <=  p_pos)
                    return true;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) || (p_end > p_end2) )
            {
                if(p_end2 != NULL)
                {
                    name = "requset_post_";
                    name += *iter;
                    if(p_end2 <=  p_pos)
                        return true;
                    string svalue(p_pos, 0, p_end2-p_pos);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                }
            }
        }
    }
    p_webmail_session -> state = server_data;
    return true;
}
//请求体提取。
bool identity_parse::identity_request_parse1(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> state == client_data)
    {
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);//取请求体的长度
        if(p_webmail_session ->requset_length == 0)//没有请求体 
        {
            p_session->p_send_buf = NULL;
            p_session->send_len = 0;
            p_webmail_session -> state = server_data;
            return true;
        }
        p_webmail_session -> state = client_data_continue;
        if(p_parse_value->buf == NULL || p_parse_value->len == 0)
        {
            p_session->p_send_buf = NULL;
            p_session->send_len = 0;
            return true;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            return false;
        }
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        pfind +=4;
        if(pfind != NULL)
        {
            p_parse_value -> len = p_parse_value -> len -(pfind - p_parse_value->buf);
            p_parse_value->buf = pfind;
        }
    }
    if( p_parse_value -> len <  p_webmail_session ->requset_length)//在组包函数中，如果达到字数，请求要求长度就会被置为0
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
        p_webmail_session -> state = client_data_continue;
        return true;
    }
    p_parse_value -> len = p_webmail_session ->requset_length;
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += "=";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, '&');//&处结束
            p_end2 =p_parse_value -> buf + p_parse_value ->len;
            if(p_end != NULL && p_end <= p_end2)
            {
                name = "requset_post_";
                name += *iter;
                if(p_end <=  p_pos)
                    return true;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                if (strstr(svalue.c_str(), "@"))
                {
                       name += "phone";
                }
                else
                {
                       name += *iter;
                }
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) || (p_end > p_end2) )
            {
                if(p_end2 != NULL)
                {
                    name = "requset_post_";
                    if(p_end2 <=  p_pos)
                        return true;
                    string svalue(p_pos, 0, p_end2-p_pos);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                }
            }
        }
    }
    p_webmail_session -> state = server_data;
    return true;
}

//该函数主要用于处理字符串中含有%u格式的unicon码转utf8
bool identity_parse::unic_to_utf(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (!p_parse_value)
    {
       return true;
    }
    node_value_list::iterator iter_key = v_list.begin();
    string name = *iter_key;
    parse_value_map::iterator iter = p_parse_value->value_map.find(name.c_str());
    if (iter != p_parse_value->value_map.end())
    {
        iter_key++;
        string flag = "";
        flag = *iter_key;
        string svalue = iter->second;
        unic2utf(svalue, flag);
        string goods = "utf8_";
        goods += name;
        name = goods;
        p_parse_value->value_map.insert(pair<string, string>(name, svalue));
    }
    return true;
}

//请求体提取,client_data_continue状态传过来时是请求体开始
bool identity_parse::identity_request_parse2(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> state == client_data)
    {
        if (strstr((char*)p_webmail_session->p_data, "act=login"))
        {
            p_parse_value->parse_type == LOGIN;
        }
        else if (strstr((char*)p_webmail_session->p_data, "act=checkName"))
        {
            p_parse_value->parse_type == REGIST;
        }
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);//取请求体的长度
        if(p_webmail_session ->requset_length == 0)//没有请求体 
        {
            p_webmail_session -> state = server_data;
            return true;
        }
        p_webmail_session -> state = client_data_continue;
        if(p_parse_value->buf == NULL || p_parse_value->len == 0)
        {
            return true;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            return false;
        }
        /* char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
           pfind +=4;
           if(pfind != NULL)
           {
           p_parse_value->buf = pfind;
           }*/
    }
    if( p_parse_value -> len <  p_webmail_session ->requset_length)//在组包函数中，如果达到字数，请求要求长度就会被置为0
    {
        p_webmail_session -> state = client_data_continue;
        return true;
    }

    /*if (p_parse_value -> len > p_webmail_session ->response_length)
    {
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        pfind +=4;
        if(pfind != NULL)
        {
            p_parse_value->buf = pfind;
        }
    }*/

    p_parse_value -> len = p_webmail_session ->requset_length;
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += "=";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, '&');//&处结束
            p_end2 =p_parse_value -> buf + p_parse_value ->len;
            if(p_end != NULL && p_end <= p_end2)
            {
                name = "requset_post_";
                name += *iter;
                if(p_end <=  p_pos)
                    return true;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) || (p_end > p_end2) )
            {
                if(p_end2 != NULL)
                {
                    name = "requset_post_";
                    name += *iter;
                    if(p_end2 <=  p_pos)
                        return true;
                    string svalue(p_pos, 0, p_end2-p_pos);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                }
            }
        }
    }
    p_webmail_session -> state = server_data;
    return true;
}
//请求体提取,目前没什么用，留着待用时再改
bool identity_parse::identity_request_parse_qq(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> state == client_data)
    {
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);//取请求体的长度
        if(p_webmail_session ->requset_length == 0)//没有请求体 
        {
            p_webmail_session -> state = server_data;
            return true;
        }
        p_webmail_session -> state = client_data_continue;
        if(p_parse_value->buf == NULL || p_parse_value->len == 0)
        {
            return true;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            return false;
        }
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        pfind +=4;
        if(pfind != NULL)
        {
            p_parse_value->buf = pfind;
        }
    }
    if( p_parse_value -> len <  p_webmail_session ->requset_length)//在组包函数中，如果达到字数，请求要求长度就会被置为0
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
        p_webmail_session -> state = client_data_continue;
        return true;
    }
    p_parse_value -> len = p_webmail_session ->requset_length;
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    node_value_list::iterator iter = v_list.begin();
    for (; iter!=v_list.end(); ++iter)
    {
        string tmp = *iter;
        tmp += "=";
        p_pos = strstr(p_begin,tmp.c_str());
        if(p_pos != NULL)
        {
            p_pos  += tmp.length();//pstr移动到pattern内容之后
            p_end = strchr(p_pos, '&');//&处结束
            p_end2 =p_parse_value -> buf + p_parse_value ->len;
            if(p_end != NULL && p_end <= p_end2)
            {
                name = "requset_post_";
                name += *iter;
                if(p_end <=  p_pos)
                    return true;
                string svalue(p_pos, 0, p_end-p_pos);
                string goods = urldecode(svalue);//url 解码  
                svalue = goods;
                p_parse_value->value_map.insert(pair<string,string>(name, svalue));
            }
            else if( (p_end == NULL) || (p_end > p_end2) )
            {
                if(p_end2 != NULL)
                {
                    name = "requset_post_";
                    name += *iter;
                    if(p_end2 <=  p_pos)
                        return true;
                    string svalue(p_pos, 0, p_end2-p_pos);
                    string goods = urldecode(svalue);//url 解码  
                    svalue = goods;
                    p_parse_value->value_map.insert(pair<string,string>(name, svalue));
                }
            }
        }
    }
    p_webmail_session -> state = server_data;
    return true;
}
//珍爱专用请求体，直接把提取关键字写到函数中的
bool identity_parse::identity_request_parse_zhenai(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> state == client_data)
    {
        http_r_context_length_parse(p_session,p_webmail_session ,p_requst,p_response,v_list);//取请求体的长度
        if(p_webmail_session ->requset_length == 0)//没有请求体 
        {
            p_webmail_session -> state = server_data;
            return true;
        }
        p_webmail_session -> state = client_data_continue;
        if(p_parse_value->buf == NULL || p_parse_value->len == 0)
        {
            return true;
        }
    }
    else if(p_webmail_session -> state == client_data_continue)
    {
        if(p_parse_value->buf == NULL)
        {
            return false;
        }
    }
    if( p_parse_value -> len <  p_webmail_session ->requset_length)//在组包函数中，如果达到字数，请求要求长度就会被置为0
    {
        p_webmail_session -> state = client_data_continue;
        return true;
    }
    if (p_parse_value->len > p_webmail_session->requset_length + 16)
    {
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        pfind +=4;
        if(pfind != NULL)
        {
            p_parse_value->buf = pfind;
        }
    p_parse_value -> len = p_webmail_session ->requset_length;
    }
    string name = "";
    char* p_begin = p_parse_value -> buf;
    char* p_pos = NULL;
    char* p_end = NULL;
    char* p_end2 = NULL;
    string tmp = "loginInfo=";
    p_pos = strstr(p_begin,tmp.c_str());
    if(p_pos != NULL)
    {
        p_pos  += tmp.length();//pstr移动到pattern内容之后
        p_end = strchr(p_pos, '&');//&处结束
        if(p_end != NULL)
        {
            name = "requset_post_loginInfo";
            if(p_end <=  p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            string goods = urldecode(svalue);//url 解码  
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name, svalue));
        }
        string tmp2="password=";
        p_pos = strstr(p_pos,tmp2.c_str());
        p_end2 =p_parse_value -> buf + p_parse_value ->len;
        if( (p_pos != NULL) && (p_end2 != NULL) )
        {
            p_pos  += tmp2.length();
            name = "requset_post_password";
            if(p_end2 <=  p_pos)
                return true;
            string svalue(p_pos, 0, p_end2-p_pos);
            string goods = urldecode(svalue);//url 解码  
            svalue = goods;
            p_parse_value->value_map.insert(pair<string,string>(name, svalue));
        }
    }
    p_webmail_session -> state = server_data;
    return true;
}
//应答体解压缩
bool identity_parse::identity_response_gzip_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (p_webmail_session -> state == server_data)
    {
        p_webmail_session -> state = server_data_continue;
        string key = "response_head_key_Content-Encoding";//判断是否压缩包
        parse_value_map::iterator iter = p_parse_value->value_map.find(key);
        if (iter != p_parse_value->value_map.end())
        {
            string tmp = iter->second;
            size_t size = tmp.find("gzip");
            if (size != string::npos)
            {
                p_parse_value -> bgzip = true;
            }
        }
    }
    if (p_parse_value->buf == NULL || p_parse_value->len == 0)
    {
        //p_session->send_len = 0;
        //p_session->p_send_buf = NULL;
        return false;
    }

    if(p_webmail_session ->response_length == 0)
    {
        char *mid = strstr((char *)p_parse_value->buf,"\r\n");
        if(mid == NULL)
            return true;
        int other_len = strtol((char *)p_parse_value->buf,&mid,16);
        p_parse_value->buf = mid+2;
        p_webmail_session ->response_length = other_len;//- rem_packet;
        p_parse_value->len -= mid+2-p_parse_value->buf;
        if(p_webmail_session ->response_length == 0)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            return true;
        }
    }
    /*if( p_parse_value -> len <  p_webmail_session ->response_length )
    {
        return true;
    }//下面程序执行默认前提是应答体已经全部发送过来了
    p_parse_value->len = p_webmail_session ->response_length;*/
    if(p_parse_value->len > p_webmail_session ->response_length +16)
    {
        char * pfind = strstr(p_parse_value->buf,"\r\n\r\n");
        if(pfind != NULL)
        {
            pfind +=4;
            p_parse_value->buf = pfind;
        }
        p_parse_value->len = p_webmail_session ->response_length;
    }
    if (p_parse_value -> bgzip  )//如果是压缩包
    {
        if (p_parse_value->gzip_buffer == NULL)
        {
            p_parse_value->gzip_buffer = new  char[p_parse_value->len *10 + 1];
            p_parse_value->gzip_len = p_parse_value->len*10;
            if(p_parse_value->gzip_buffer == NULL)
            {
                return false;
            }
        }
        //int len = 0;
        //解压文件
        //printf("%u\n", p_parse_value->buf[1]);
        int ret  = httpgzdecompress((Bytef *) p_parse_value->buf, (uLong)p_parse_value->len, (Bytef *)p_parse_value->gzip_buffer, (uLong*)& p_parse_value->gzip_len);
        /*if(len < p_parse_value->gzip_len )
        {
            p_parse_value->gzip_buffer[len ] = 0x0;
        }*/
        p_parse_value->gzip_buffer[p_parse_value->gzip_len ] = 0x0;
        p_webmail_session -> state = client_data;
        if(ret != 0 )
        {
            p_parse_value->len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
    }
    else if (p_parse_value -> bgzip == false)
    {
        if (p_parse_value->gzip_buffer != NULL)
        {
            delete [] p_parse_value->gzip_buffer ;
        }
            p_parse_value->gzip_buffer = new  char[p_parse_value->len +100];
            p_parse_value->gzip_len = p_parse_value->len +100 ;
            if(p_parse_value->gzip_buffer == NULL)
            {
                return false;
            }
        memcpy(p_parse_value->gzip_buffer, p_parse_value->buf,p_parse_value->len);
        p_parse_value->gzip_len = p_parse_value->len;
        p_parse_value->gzip_buffer[p_parse_value->gzip_len] = 0x0;
        return true;
        p_webmail_session -> state = client_data;
    }
    return true;
}
//应答体解压缩--珍爱专用，因为它判断有效性方式很别致
bool identity_parse::identity_response_gzip_parse_zhenai(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (p_webmail_session -> state == server_data)
    {
        p_webmail_session -> state = server_data_continue;
        string key = "response_head_key_Content-Encoding";//判断是否压缩包
        parse_value_map::iterator iter = p_parse_value->value_map.find(key);
        if (iter != p_parse_value->value_map.end())
        {
            string tmp = iter->second;
            size_t size = tmp.find("gzip");
            if (size != string::npos)
            {
                p_parse_value -> bgzip = true;
            }
        }
    }
    p_webmail_session->is_valid = false;
    if(p_webmail_session ->response_length > 0)
    {
        p_webmail_session->is_valid = true;
    }
    if (p_parse_value->buf == NULL || p_parse_value->len == 0)
    {
        return true;
    }
    if(p_webmail_session ->response_length == 0)
    {
        char *mid = strstr((char *)p_parse_value->buf,"\r\n");
        if(mid == NULL)
            return true;
        int other_len = strtol((char *)p_parse_value->buf,&mid,16);
        p_parse_value->buf = mid+2;
        p_webmail_session ->response_length = other_len;//- rem_packet;
        p_parse_value->len -= mid+2-p_parse_value->buf;
        if(p_webmail_session ->response_length == 0)
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            return true;
        }
    }
    /* if( p_parse_value -> len <  p_webmail_session ->response_length )
       {
       return true;
       }//下面程序执行默认前提是应答体已经全部发送过来了
       p_parse_value->len = p_webmail_session ->response_length;*/
    if (p_parse_value -> bgzip)//如果是压缩包
    {
        if (p_parse_value->gzip_buffer == NULL)
        {
            p_parse_value->gzip_buffer = new  char[p_parse_value->len *10];
            if(p_parse_value->gzip_buffer == NULL)
            {
                return false;
            }
        }
        p_parse_value->gzip_len = p_parse_value->len*10;
        //解压文件
        int ret  = httpgzdecompress((Bytef *) p_parse_value->buf, (uLong)p_parse_value->len, (Bytef *)p_parse_value->gzip_buffer, (uLong*)& p_parse_value->gzip_len);
        p_parse_value->gzip_buffer[p_parse_value->gzip_len ] = 0x0;
        p_webmail_session -> state = client_data;
        if(ret != 0 )
        {
            p_parse_value->len = 0;
            p_session->p_send_buf = NO_NULL;
            return false;
        }
    }
    else if (p_parse_value -> bgzip == false)
    {
        if (p_parse_value->gzip_buffer == NULL)
        {
            p_parse_value->gzip_buffer = new  char[p_parse_value->len];
            if(p_parse_value->gzip_buffer == NULL)
            {
                return false;
            }
        }
        memcpy(p_parse_value->gzip_buffer, p_parse_value->buf,p_parse_value->len);
        p_parse_value->gzip_len = p_parse_value->len;
        p_parse_value->gzip_buffer[p_parse_value->gzip_len] = 0x0;
        return true;
        p_webmail_session -> state = client_data;
    }
    return true;
}

//应答体提取-知乎登录专用
bool identity_parse::identity_response_parse(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "r\"";
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            int id= svalue.find("0");
            if (id != string::npos)
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//应答体提取-yingshidaquan专用
bool identity_parse::identity_response_parse_yingshi(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "status";
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            int id = 0;
            if (p_parse_value->parse_type == LOGIN)
            {
                id= svalue.find("1");
            }
            else if (p_parse_value->parse_type == REGIST)
            {
                id= svalue.find("0");
            }
            if (id != string::npos)
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//应答体提取-易车网手机号注册专用
bool identity_parse::identity_response_parse_yicheregiste(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "registeResult";
    if(p_begin == NULL)
    {
        return true;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            int id= svalue.find("1");
            if (id != string::npos)
            {
                p_webmail_session->is_valid = true;
            }
        }
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//应答体提取-易车网专用
bool identity_parse::identity_response_parse_yiche(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "state";
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            int id= svalue.find("0");
            if (id != string::npos)
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//应答体提取-东方财富专用
bool identity_parse::identity_response_parse_dongfang(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    string key = "result";
    /*if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            int id= svalue.find("true");
            if (id != string::npos)
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }*/
    p_webmail_session->is_valid = true;
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//应答体提取-anjuke专用
bool identity_parse::identity_response_parse_anjuke(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "status\":";
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            if (svalue == "1")
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
bool identity_parse::identity_anjuke_reg(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    string key = "result\":";
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();//
        p_end = strchr(p_pos, ',');//,处结束
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
                return true;
            string svalue(p_pos, 0, p_end-p_pos);
            if (svalue == "1")
            {
                p_webmail_session->is_valid = true;
            }
            else
            {
                p_webmail_session->is_valid = false;
            }
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}
//根据两次密码是否一样判断是否有效,顺便判断是否提取成功
bool identity_parse::validity_distinguish(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst, s_http_response * p_response,node_value_list& v_list)
{
    string pass1 = "";
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    node_value_list::iterator iter = v_list.begin();
    for(;iter!=v_list.end();iter ++)
    {
        string name = *iter;
        parse_value_map ::iterator iterator = p_parse_value->value_map.find(name);
        if (iterator != p_parse_value->value_map.end())
        {
            if(pass1 == "")
            {
                pass1 = iterator->second;
            }
            else if(pass1 == iterator->second)
            {
                p_webmail_session->is_valid = true;
            }
            else{
                p_webmail_session->is_valid = false;
            }
            p_session->send_len = 1;
            p_session->p_send_buf = NO_NULL;
        }
    }
    SET_SESSION_OVER(p_session );
    return true;
}

//百姓网
bool identity_parse::identity_bxw_user_parse(session *p_session, webmail_session *p_webmail_session, s_http_request *p_requst, s_http_response *p_response, node_value_list &v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    char * p_begin = p_parse_value->gzip_buffer;
    if(p_begin == NULL)
    {
        return false;
    }
    if (strstr(p_begin, "meta http-equiv=\"refresh\" content=\"0"))
    {
        p_webmail_session->is_valid = true;
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}

//拉手网
bool identity_parse::identity_lashou_reg_parse(session *p_session, webmail_session *p_webmail_session, s_http_request *p_requst, s_http_response *p_response, node_value_list &v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (strstr((char*)p_webmail_session->p_data, "status\":1"))
    {
        p_webmail_session->is_valid = true;
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
    string s_tmp = "requset_cookie_weatherinfo";
    string s_value = "";
    int num_pos = 0;
    parse_value_map::iterator it ;
    it = p_parse_value->value_map.find(s_tmp);
    if (it!= p_parse_value->value_map.end())
    {
        s_value = it->second;
        while ((num_pos = s_value.find_first_of('%',num_pos)) != string::npos)
        {
            s_value.erase(num_pos, 1);
            s_value.insert(num_pos, "\\" );
        }

        unic_to_utf8_str_cls unic_to_utf8(s_value.c_str(), s_value.size());
        s_value = unic_to_utf8();
        num_pos = s_value.find_first_of("\\", 0);
        s_value = s_value.substr(0, num_pos);
        p_parse_value->value_map[s_tmp] = s_value;
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}


//大众点评
bool identity_parse::identity_dzdp_parse(session *p_session, webmail_session *p_webmail_session, s_http_request *p_requst, s_http_response *p_response, node_value_list &v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (strstr((char*)p_webmail_session->p_data, "code\":200"))
    {
        p_webmail_session->is_valid = true;
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}

//珍爱网
bool identity_parse::identity_zhenai_parse(session *p_session, webmail_session *p_webmail_session, s_http_request *p_requst, s_http_response *p_response, node_value_list &v_list)
{
  //  return true;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    //if (strstr((char*)p_webmail_session->p_data, "The URL has moved"))
    if (strstr((char*)p_parse_value->gzip_buffer, "The URL has moved") != NULL)
    {
        p_webmail_session->is_valid = true;
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
  /*  if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }*/
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}

bool identity_parse::identity_qq_reg(session *p_session, webmail_session* p_webmail_session, s_http_request * p_requst, s_http_response * p_response, node_value_list& v_list)
{
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if (strstr((char*)p_webmail_session->p_data, "phone_result\":\"1"))
    {
        p_webmail_session->is_valid = true;
    }
    else
    {
        p_webmail_session->is_valid = false;
    }
    string s_tmp = "response_qq";
    string s_value = "";
    string key = "uin\":\"";

    char * p_pos = NULL;
    char * p_end = NULL;
    char * p_begin = p_parse_value->gzip_buffer;
    if(p_begin == NULL)
    {
        return false;
    }
    p_pos = strstr(p_begin,key.c_str());
    if(p_pos != NULL)
    {
        p_pos  += key.length();
        p_end = strchr(p_pos, '\"');
        if(p_end != NULL)
        {
            if(p_end <= p_pos)
            {
                return true;
            }
            string svalue(p_pos, 0, p_end-p_pos);
            p_parse_value->value_map.insert(pair<string,string>(s_tmp, svalue));
        }
    }
    if (p_parse_value->gzip_buffer != NULL)
    {
        delete [] p_parse_value->gzip_buffer;
        p_parse_value->gzip_buffer = NULL;
        p_parse_value->gzip_len = 0;
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    return true;
}












