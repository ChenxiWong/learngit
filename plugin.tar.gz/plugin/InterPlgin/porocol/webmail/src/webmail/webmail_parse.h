// Last Update:2016-04-22 13:16:20
/**
 * @file webmail_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-27
 */

#ifndef WEBMAIL_PARSE_H
#define WEBMAIL_PARSE_H
//#include "webmail_str.h"
#include <string>
#include <stdint.h>
#include "http_urimethod_analyzer.h"
#include "http_header_parse.h"
#include "webmail_str.h"
using namespace std;
class webmail_parse
{
    public:
        webmail_parse();
        ~webmail_parse();
        bool url_get(char * httpbuf ,uint32_t len ,string &url,string & urlparam);
        bool host_get(char * httpbuf , uint32_t len ,string & host);
        bool http_request_head_parse(webmail_session * p_webmail_session ,char * pbuffer,int len );
        bool http_response_head_parse(webmail_session * p_webmail_session ,char * pbuffer,int len );
        method_type http_method_type(char * buffer ,int len );
        response_type http_response_type(char * buffer ,int len);
        s_http_request m_request;
        s_http_response m_response;
    private:
        http_urimethod_analyzer uriparse;
        http_respcode_analyer http_resp_parse;
        http_head_parse http_head;

};


#endif  /*WEBMAIL_PARSE_H*/
