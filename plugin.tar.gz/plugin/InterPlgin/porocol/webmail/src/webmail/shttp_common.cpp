// Last Update:2015-12-09 13:16:53
/**
 * @file shttp_common.cpp
 * @brief-
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-22
 */

#include "shttp_common.h"
#define  baseChar  (bUpperCase ?'A' : 'a')
#define MAXKEYVALUE 2048
int iUserArray  = 0;
bool bAuditRspFalse = false;
c_http_str mc_http_str;
int reStrCmp(char * str1 ,char * str2)
{
    int i = 0;
    int len1 = strlen(str1);
    int len2 = strlen(str2);
    if(len1 == len2 )	
    {
        for(i = 0 ; i < len1; i++ )
        {
            if(str1[i]!=str2[i])	return str1[i] - str2[i];
        }
    }
    return len1 -len2;
}
void c_http_strInit(c_http_str * p )
{
    p->buf_begin = NULL;
    p->space_use_len = 0;
    p->Nextbuf =NULL;

};
void s_key_value_free(s_key_value * p_key_value)
{
    if(p_key_value == NULL) return ;
    s_key_value * p = p_key_value;
    s_key_value * q = p->link;
    while(p != NULL)
    {
        q = p ->link;
        delete p ;
        p = q;
    }

}
void init_s_http_requset(s_http_request * r) 
{
    c_http_strInit(&r->CentextLangth);
    c_http_strInit(&r->Uri);
    c_http_strInit(&r->UriFile);
    c_http_strInit(&r->UriFileType);
    c_http_strInit(&r->UriProlate);
    c_http_strInit(&r->UriWithParam);
    c_http_strInit(&r->UriParam);
    //SHttpKeyValueoffise = 0;
    s_key_value_free(r->HttpHeaderKeyNameValue);
    r->HttpHeaderKeyNameValue = NULL;
    r->parsestate = 0;
    r->parsepos =NULL;

}
void init_s_http_response(s_http_response *s)
{
    s_key_value_free(s->HttpHeaderKeyNameValue);
    s->HttpHeaderKeyNameValue = NULL;

}

int c_http_strnCmpstr(c_http_str * str1 ,char * name,int len)
{
    int i = 0 ; 
    //int m = 0;
    char * p = str1->buf_begin;
    int wlen = 0;
    c_http_str * pCStr = str1;
    while (pCStr != NULL)
    {
        wlen +=pCStr->space_use_len;
        pCStr = pCStr->Nextbuf;
    }

    if(len < strlen(name)) return -1;
    if(wlen  < len ) return 1;
    for(;len > 0 ;i++&len --) 
    {
        if(i == str1-> space_use_len )
        {
            if(str1->Nextbuf == NULL)
            {
                return 0;
            }
            else
            {
                str1 = str1->Nextbuf;
                if(str1-> space_use_len > strlen(name)) return 1;
                p = str1->buf_begin;
                i=0;
            }
        }
        if(*p == *name ) 
        {
            p++;name++;
            continue;
        }
        return *p - *name;
    }	
    return 0;
}
int c_http_strCmpstr(c_http_str * str1 ,char * name)
{
    int i = 0 ; 
    //int m = 0;
    char * p = str1->buf_begin;
    int len = 0;
    c_http_str * pCStr = str1;
    len +=pCStr->space_use_len;
    if(len < strlen(name)) return -1;
    if(len > strlen(name)) return 1;
    for(;i<len;i++)
    {
        if(*p == *name ) 
        {
            p++;name++;
            continue;
        }
        return *p - *name;
    }
    return 0;
}
c_http_str *find_key_value(s_key_value * phead ,const char * name)
{
    s_key_value * p = phead;
    for(;p!=NULL;p = p->link)
    {
        if(c_http_strCmpstr(&(p->name),(char *)name )== 0)
        {
            return &(p->value);
        }
    }
    return NULL;
}
int c_http_strCmp(c_http_str * str1 , c_http_str * str2)
{       
    int i = 0 ;     
    int m = 0 ;
    char * p = str1->buf_begin;
    char * q = str2->buf_begin;
    for(;;i++)  
    {

        if( i == str1-> space_use_len ) 
        {
            if(str1->Nextbuf == NULL)       
            {
                if( m == str2-> space_use_len  && str2->Nextbuf == NULL) return 0;
                else return 1;
            }
            else    
            {
                str1 = str1->Nextbuf;
                p = str1->buf_begin;
                i=0;
            }
        }
        else if(m == str2-> space_use_len)
        {
            if(str2->Nextbuf == NULL)
            {
                return 1;
            }
            else
            {
                str2 = str2->Nextbuf;
                q = str2->buf_begin;
                m=0;
            }       
        }
        if(*p  == *q) 
        {
            p++;q++;
            continue;
        }
        return *p-*q;
    }
}
char * visitc_http_str(c_http_str ** ppStr,  char ** p )
{
    c_http_str * pStr = *ppStr;
    if(*p!=pStr ->buf_begin) return *p++;
    else 
    {
        ppStr = &(pStr -> Nextbuf);
        pStr = *ppStr;
        if(pStr == NULL) return NULL;
        else 
        {
            *p = pStr -> Nextbuf->buf_begin;
            return *p;       
        }
    }
}

int UrlDeCodeFormat(const char* szSrc,int szlen, char* pBuf, int cbBufLen)
{
    if(szSrc == NULL || pBuf == NULL || cbBufLen <= 0)
        return -1;
    int cbDest = 0; //累加
    unsigned char *pSrc = (unsigned char*)szSrc;
    unsigned char *pDest = (unsigned char*)pBuf;
    while(*pSrc )
    {
        if(*pSrc == '"'|| *pSrc == 0x27)
        {	
            *pDest = ' ';
            ++pSrc;
            szlen --;
            ++pDest;
            ++cbDest;
        }
        /*     else if(*pSrc == '%' &&  pSrc[1] ==2  &&  '0'==pSrc[2] )
               {
         *pDest =  0x20;
         pSrc += 3;
         szlen -=3;
         ++pDest;
         ++cbDest;
         }
         else if(*pSrc == '%' &&  pSrc[1] ==2  &&  'C'==pSrc[2] )
         {
         *pDest =  0x2C;
         pSrc += 3;
         szlen -=3;
         ++pDest;
         ++cbDest;
         }
         else if(*pSrc == '%' &&  pSrc[1] ==2  &&  'E'==pSrc[2] )
         {
         *pDest =  0x2E;
         pSrc += 3;
         szlen -=3;
         ++pDest;
         ++cbDest;
         }
         else if(*pSrc == '%' &&  pSrc[1] ==3  &&  'A'==pSrc[2] )
         {
         *pDest =  0x3A;
         pSrc += 3;
         szlen -=3;
         ++pDest;
         ++cbDest;
         }*/
        else {
            *pDest = *pSrc;
            if(*pDest < 0x20 || *pDest > 127) *pDest =0x20;
            ++pSrc;
            szlen --;
            ++pDest;
            ++cbDest;
        }
    }
    //null-terminator
    *pDest = '\0';
    ++cbDest;
    return cbDest;
}

int UrlDecode(char* szSrc,int szlen,  char* pBuf, int cbBufLen)
{
    if(szSrc == NULL || pBuf == NULL || cbBufLen <= 0 || szlen <=0)
        return -1;

    size_t len_ascii = szlen;
    szSrc[szlen] =0x0;
    unsigned char * end =(unsigned char *) szSrc + szlen;
    if(len_ascii == 0)
    {
        pBuf[0] = 0;
        return true;
    }


    int cbDest = 0; //累加
    unsigned char *pSrc = (unsigned char*)szSrc;
    unsigned char *pDest = (unsigned char*)pBuf;
    while(*pSrc)
    {
        if(pSrc >= end) 
        {
            return cbDest;
        }
        if(*pSrc == '%')
        {
            *pDest = 0;
            //高位
            if(pSrc[1] >= 'A' && pSrc[1] <= 'F')
                *pDest += (pSrc[1] - 'A' + 10) * 0x10;
            else if(pSrc[1] >= 'a' && pSrc[1] <= 'f')
                *pDest += (pSrc[1] - 'a' + 10) * 0x10;
            else
                *pDest += (pSrc[1] - '0') * 0x10;

            //低位
            if(pSrc[2] >= 'A' && pSrc[2] <= 'F')
                *pDest += (pSrc[2] - 'A' + 10);
            else if(pSrc[2] >= 'a' && pSrc[2] <= 'f')
                *pDest += (pSrc[2] - 'a' + 10);
            else
                *pDest += (pSrc[2] - '0');

            pSrc += 3;
        }
        //else if(*pSrc == '+' || *pSrc == '"'|| *pSrc == '\'')
        else if(*pSrc == '"'|| *pSrc == '\'')
        {
            *pDest = ' ';
            ++pSrc;
        }
        else
        {
            *pDest = *pSrc;
            ++pSrc;
        }
        ++pDest;
        ++cbDest;
    }
    //null-terminator
    *pDest = 0x0;
    ++cbDest;
    return cbDest;
}


int UrlEncode(const char* szSrc, char* pBuf, int cbBufLen, bool bUpperCase)
{
    if(szSrc == NULL || pBuf == NULL || cbBufLen <= 0)
        return -1;

    size_t len_ascii = strlen(szSrc);
    if(len_ascii == 0)
    {
        pBuf[0] = 0;
        return 0;
    }


    unsigned char c;
    int cbDest = 0; //累加
    unsigned char * pSrc = (unsigned char * ) szSrc;
    unsigned char *pDest = (unsigned char*)pBuf;
    while(*pSrc && cbDest < cbBufLen - 1)
    {
        c = *pSrc;
        if(isalpha(c) || isdigit(c) || c == '-' || c == '.' || c == '~')
        {
            *pDest = c;
            ++pDest;
            ++cbDest;
        }
        else if(c == ' ')
        {
            *pDest = '+';
            ++pDest;
            ++cbDest;
        }
        else
        {
            //搜检缓冲区大小是否够用?
            if(cbDest + 3 > cbBufLen - 1)
                break;
            pDest[0] = '%';
            pDest[1] = (c >= 0xA0) ? ((c >> 4) - 10 + baseChar) : ((c >> 4) + '0');
            pDest[2] = ((c & 0xF) >= 0xA)? ((c & 0xF) - 10 + baseChar) : ((c & 0xF) + '0');
            pDest += 3;
            cbDest += 3;
        }
        ++pSrc;
    }
    //null-terminator
    *pDest = '\0';
    return cbDest+1;
}


bool isUTF8Code(unsigned char *str, int len)
{
    if (len < 2)
        return false;
    int i = 0;
    while (i < len)
    {
        if (str[i] < 128)
        {
            i++;
            continue;
        }
        if (str[i] >= 128 && str[i] < 194)
        {
            return false;
        }
        if (str[i] >= 194 && str[i] < 224)
        {
            i++;
            if (str[i] >= 128 && str[i] <= 191)
                continue;
            else
                return false;
        }
        if (str[i] >= 224 && str[i] < 240)
        {
            if (str[i] == 224)
            {
                if (str[i + 1] < 160)
                {
                    return false;
                }
            }
            i++;
            if (str[i] >= 128 && str[i] <= 191 && str[i + 1] >= 128 && str[i + 1] <= 191)
                return true;
            else
                return false;
        }
        if (str[i] >= 240 && str[i] < 248)
        {
            if (str[i] == 240)
            {
                if (str[i + 1] < 144)
                {
                    return false;
                }
            }
            i++;
            if (str[i] >= 128 && str[i] <= 191 && str[i + 1] >= 128 && str[i + 1] <= 191 && str[i + 2] >= 128 && str[i
                    + 2] <= 191)
                return true;
            else
                return false;
        }
        if (str[i] >= 248 && str[i] < 252)
        {
            if (str[i] == 248)
            {
                if (str[i + 1] < 136)
                {
                    return false;
                }
            }
            i++;
            if (str[i] >= 128 && str[i] <= 191 && str[i + 1] >= 128 && str[i + 1] <= 191 && str[i + 2] >= 128 && str[i
                    + 2] <= 191 && str[i + 3] >= 128 && str[i + 3] <= 191)
                return true;
            else
                return false;
        }
        if (str[i] >= 252 && str[i] <= 253)
        {
            if (str[i] == 252)
            {
                if (str[i + 1] < 132)
                {
                    return false;
                }
            }
            i++;
            if (str[i] >= 128 && str[i] <= 191 && str[i + 1] >= 128 && str[i + 1] <= 191 && str[i + 2] >= 128 && str[i
                    + 2] <= 191 && str[i + 3] >= 128 && str[i + 3] <= 191 && str[i + 4] >= 128 && str[i + 4] <= 191)
                return true;
            else
                return false;
        }
        if (str[i] > 253)
        {
            return false;
        }
    }
    return true;
}

