// Last Update:2015-12-25 14:04:46
/**
 * @file webmailsina_parse.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-05-11
 */

#ifndef WEBMAILSINA_PARSE_H
#define WEBMAILSINA_PARSE_H


#include "webmail_str.h"
#include "http_urlparam_analyzer.h"
#include <tinyxml_parse.h>
#include "http_post_analyzer.h" 
#include "ungzip.h"
#include "session_save_redis.h"
#include  <jsoncpp/json.h>
#include <string>
using namespace std;
class webmailsina_parse {
    public:
        static bool response_handle_sina_body(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;//  下载 163 附件类的组包
        static bool response_handle_sohu_body_length(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list);
        static bool response_handle_sohu_att_id(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list);
        
         static bool response_handle_163_getbody(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list);
         
         static bool get_redis_map(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) ;

    private:
};

#endif  /*WEBMAILSINA_PARSE_H*/
