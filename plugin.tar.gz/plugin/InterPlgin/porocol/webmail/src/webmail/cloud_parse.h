// Last Update:2016-01-25 15:01:55
/**
 * @file cloud_parse.h
 * @brief this is a declearation of the cloud_parse.cpp
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-11-11
 */

#ifndef CLOUD_PARSE_H
#define CLOUD_PARSE_H
#include <tinyxml_parse.h>
#include <stdint.h>
#include "webmail_str.h"
#include "ungzip.h"
#include "http_post_analyzer.h"
#include "function.h"
#include "unic_to_utf8_str.h"
class cloud_parse
{
    public:
        static bool response_handle_cloud_att(session *p_session, webmail_session *p_webmail_session, 
                s_http_request *p_request, s_http_response *p_respnse, 
                node_value_list& v_list);//下载百度云端的附件。
        static bool request_handle_cloud_att(session *p_session, webmail_session *p_webmail_session, 
                s_http_request *p_request, s_http_response *p_respnse, 
                node_value_list& v_list);//上传百度云端的附件。
        static bool response_donothing_cloud_att(session *p_session, webmail_session *p_webmail_session, 
                s_http_request *p_request, s_http_response *p_respnse, 
                node_value_list& v_list);//上传百度云端的附件。
        static bool request_second_cloud_att(session *p_session, webmail_session *p_webmail_session,
                s_http_request *p_request, s_http_response *p_respnse,
                node_value_list& v_list);//上传秒速完成（云端已经存在要上传的文件。）
        static bool request_nosend_cloud_att(session *p_session, webmail_session *p_webmail_session,
                s_http_request *p_request, s_http_response *p_respnse,
                node_value_list& v_list);//限制cookie函数向后发送
        /************************************ the following add by wangchenxi ************************/
        /*data 2015-12-07
         *brief 金山快盘（网页版）上传解析处理函数
         *author wangchenxi
         */
        static bool request_kuaipan_property(session *p_session,
                webmail_session *p_webmail_session,
                s_http_request *p_request,
                s_http_response *p_respnse,
                node_value_list& v_list);//"上传"解析用户ID标识和文件名
        static bool response_kuaipan_property(session *p_session,
                webmail_session *p_webmail_session,
                s_http_request *p_request,
                s_http_response *p_respnse,
                node_value_list& v_list);//"上传"解析文件标志id（fileid）
        /*data 2015-12-08
         *brief 金山快盘（网页版)下载处理函数 
         *author wangchenxi
         */
        static bool response_kuaipan_property_download(session *p_session,
                webmail_session *p_webmail_session,
                s_http_request *p_request,
                s_http_response *p_respnse,
                node_value_list& v_list); // “下载”解析文件fn  对应file_name
        static bool turn_client_state_to_server_state(session *p_session,
                webmail_session *p_webmail_session,
                s_http_request *p_request,
                s_http_response *p_respnse,
                node_value_list& v_list); // 除了状态转换，啥都不做。
        /*********************************** What add by wangchenxi temporarily stop here ******************/
        /************************************ the following add by cuixiaobo begin ************************/
        static bool burs_360_get_acc(session* p_session,c_packet* p_packet);
        static bool clouddisk360_response_parse_handle(session *p_session,
                webmail_session* p_webmail_session,
                s_http_request * p_requst,
                s_http_response * p_response,
                node_value_list& v_list);
        static bool http_requst_urlparam_parse(session *p_session,
                webmail_session* p_webmail_session,
                s_http_request * p_requst,
                s_http_response * p_response,
                node_value_list& v_list);
        static bool requset_info_handle(session *p_session,
                webmail_session* p_webmail_session,
                s_http_request * p_requst,
                s_http_response * p_response,
                node_value_list& v_list);
        static bool client_get_info(session *p_session,
                webmail_session* p_webmail_session,
                s_http_request * p_requst,
                s_http_response * p_response,
                node_value_list& v_list);

        /************************************ the following add by cuixiaobo end **************************/
};

void init_cloud(void);


/********************************** the following add by wangchenxi ***********************/
bool get_string_from_http_context(string& ,const char* ,const char* ,const char* ,int , int );
/*********************************** What add by wangchenxi temporarily stop here ******************/

#endif  /*CLOUD_PARSE_H*/
