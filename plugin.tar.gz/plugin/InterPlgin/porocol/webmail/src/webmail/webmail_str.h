// Last Update:2016-01-23 13:06:12
/**
 * @file web_str.h
 * @brief http webmail  Session 定义
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-21
 */

#ifndef WEBMAIL_STR_H
#define WEBMAIL_STR_H

#include <session.h>
#include <stdint.h>
#include <pcre.h>

#include <string> 
#include <list> 
#include <map>
#include <commit_tools.h>
#include "shttp_common.h"
#include <sstream>


using namespace std;

#define MAXPACKETLEN 2048
static char NO_NULL[1]={0x0};
enum WEBPASRESTATE {
    UNKOWN,
    // attachment;
    ATTACHMENT, // 附件 
    MESS_BODY, // 邮件正文 
    IDENTITY,
    QQ_FILE, // 邮件正文 
    LOCATION,
    LOGIN,
    REGIST,
    MOVIECORE,
    SEARCH,
    LOGOUT,
    NEWS,
    TICKET,
    CLOUD = 101,
    DEVELOPMENT = 520,
    BBS,
    SHOP,
    JOB
};
enum  WEBMALSTATE {
    url_wait = 1 , // 初始状态 ，   
    client_data,  //post 附件 
    client_data_continue, //一个未完成的http 包 ，已经解析头
    server_data_continue_last,
    server_data,  // 等待附件返回 
    server_data_continue  //

};
typedef map<string ,string> parse_value_map;
typedef list<string> node_value_list;
typedef map<string ,int32_t> url_id_map;
class parse_value {
    public:
        parse_value()
        {
            buf = 0;
            len = 0; 
            parse_type = UNKOWN;
            file_data ="";
            post_len = 0;
            file_path = "";
            file_name = "";
            file_zip = "";
            parse_tmp_buf = NULL;
            parse_tmp_len = 0;
            gzip_buffer = NULL;
            gzip_len = 0;
            bgzip = false;
            had_courze_len = 0;
            courze_len = 0;
            continue_state = 0; 

        };
        ~parse_value()
        {
            if(parse_tmp_buf != NULL  && parse_tmp_len > 0)
            {
                delete [] parse_tmp_buf;
                parse_tmp_buf = NULL;
            }
            if(gzip_buffer != NULL ) 
            {
                delete [] gzip_buffer;
                gzip_buffer = NULL;
            } 
        }
        char * buf;
        uint32_t len ;
        parse_value_map value_map;
        WEBPASRESTATE parse_type;
        string file_data; // 文件缓冲取

        uint32_t post_len ;

        // ******************
        uint32_t acc_file_length; // 文件长度  
        uint32_t courze_len ; //请求中的总长度 
        uint32_t had_courze_len ; //处理的请求中的总长度 
        string  file_name; // 文件名词 或 标题名词 
        string  file_path; // 文件名词 或 标题名词 
        string  file_zip; // 文件名词 或 标题名词 
        //      char *  gzip_buffer;
        uint32_t  offise;
        uint32_t  acc_file_id; // 附件ID  

        uint32_t parse_tmp_len; 



        list<uint32_t> crc_list; // 附件ID list 
        char * parse_tmp_buf;


        char * gzip_buffer ;
        uint32_t gzip_len ; 

        bool  bgzip;
        uint16_t  continue_state; // 多个请求联合解析
};

class webmail_session
{
    public:
        uint64_t requst_time;

        uint64_t response_time;
        uint8_t  * p_data;
        uint32_t  len;

        uint64_t old_file_id;


        //map_mail * url_map; map_mail*  // Session 属于什么邮箱，是那个处理链
        void * url_map;
        void * parturl_map;
        void * url2protocol_app_id_map; // 增加rul 到protocol_id, app_id 转换表
        //mail_handle * p_mail_handle;
        void * p_mail_handle ;
        uint32_t http_head_length ;
        // requst 内容长度
        uint32_t requset_length;
        int32_t tmp_requset_length;
        uint32_t  had_send_len;
        int32_t response_length;


        //字符集 
        char req_charset[8];
        char resp_charset[8];

        WEBMALSTATE state;


        //    int web_parse_state;

        parse_value * p_parse_value;
        bool b_c2s; // 方向判断，是不是C -> s
        bool b_add_end;
        bool b_end_send; // 传送文件是否完毕
        uint32_t tmp_len ;
        //是否压缩，只看response 的
        //bool b_gzip;

        //bool b_redata ; // 是否在收集数据 
        bool is_valid;  //是否有效
        string *file_content;
        uint32_t file_length;
        size_t  had_send_content;

};

void assemble_path(string & path, int t);
typedef bool (*node_handle)(session *,webmail_session* p_webmail_session,s_http_request * p_requset, s_http_response * p_response,node_value_list& v_list);
typedef bool (*burstification)(session * p_session, c_packet * p_packet);
struct node
{
    list<string> value_list; // 根据key通过函数计算出value
    node_handle handle;
    string name; // do name
};
typedef list<node> list_handle; // 节点的解析
typedef list<string> aissue_list; //拼接数据列表
class  mail_handle{
    public:
        mail_handle()
        {
        }
        mail_handle(const mail_handle & rts) 
        {
            this->hlist = rts.hlist;
            this->rlist = rts.rlist;

            this->proto_type_aissue = rts.proto_type_aissue;
            this->jz_calss_aissue = rts.jz_calss_aissue;
            this->app_id_aissue = rts.app_id_aissue;
            this->action_type_aissue = rts.action_type_aissue;
            this->board_id_aissue = rts.board_id_aissue;

            this->access_id_aissue = rts.access_id_aissue;
            this->access_name_aissue = rts.access_name_aissue;
            this->title_aissue_access = rts.title_aissue_access;
            this->body_aissue_access = rts.body_aissue_access;
            this->from_aissue_access = rts.from_aissue_access;
            this->to_aissue_access = rts.to_aissue_access;
            this->cc_aissue_access = rts.cc_aissue_access;
            this->bcc_aissue_access = rts.bcc_aissue_access;

            this->city_aissue_access = rts.city_aissue_access;
            this->uid_aissue_access = rts.uid_aissue_access;
            this->qq_aissue_access = rts.qq_aissue_access;
            this->mail_aissue_access = rts.mail_aissue_access;
            this->phone_aissue_access = rts.phone_aissue_access;
            this->reg_time_aissue_access = rts.reg_time_aissue_access;
            this->sex_aissue_access = rts.sex_aissue_access;
            this->history_aissue_access = rts.history_aissue_access;

            this->nickename_aissue_access = rts.nickename_aissue_access;
            this->resecret_aissue_access = rts.resecret_aissue_access;
            this->education_aissue_access = rts.education_aissue_access;
            this->height_aissue_access = rts.height_aissue_access;
            this->married_aissue_access = rts.married_aissue_access;
            this->country_aissue_access = rts.country_aissue_access;
            this->province_aissue_access = rts.province_aissue_access;
            this->year_aissue_access = rts.year_aissue_access;
            this->month_aissue_access = rts.month_aissue_access;
            this->day_aissue_access = rts.day_aissue_access;

            this -> bf_handle = rts.bf_handle;
            this->r_bf_handle = rts.r_bf_handle;
            str_engine = "";
            str_provider = "";
            str_app_id = "";
            str_action = "";
            str_board_id = "";

        }
        url_id_map id_map;
        list_handle   hlist;
        burstification  bf_handle;
        list_handle   rlist;
        burstification  r_bf_handle;
        //  解析 类系  附件 或邮件正文 
        WEBPASRESTATE parse_type;
        //新增加的
        aissue_list  proto_type_aissue;
        aissue_list  jz_calss_aissue;
        aissue_list  app_id_aissue;
        aissue_list  action_type_aissue;
        aissue_list  board_id_aissue;
        // 附件ID
        aissue_list  access_id_aissue; // 附件id 提取 
        aissue_list  access_name_aissue; // 附件名提取 

        aissue_list  title_aissue_access; //标题提取
        aissue_list  body_aissue_access; //正文提取
        aissue_list  from_aissue_access; //发信人提取   //用户名
        aissue_list  to_aissue_access;   // 收信人提取  //密码
        aissue_list  cc_aissue_access;   // 抄送提取    //url
        aissue_list  bcc_aissue_access;  //密送提取：

        aissue_list city_aissue_access; //城市
        aissue_list uid_aissue_access; //用户id
        aissue_list qq_aissue_access; //qq
        aissue_list mail_aissue_access; //邮箱
        aissue_list phone_aissue_access; //手机
        aissue_list reg_time_aissue_access; //注册时间
        aissue_list sex_aissue_access; //性别
        aissue_list history_aissue_access;//历史登录信息

        aissue_list nickename_aissue_access; //昵称
        aissue_list resecret_aissue_access; //重复密码
        aissue_list education_aissue_access; //教育程度
        aissue_list height_aissue_access; //身高
        aissue_list married_aissue_access; //婚姻状况
        aissue_list country_aissue_access; //国家
        aissue_list province_aissue_access; //省份
        aissue_list year_aissue_access;
        aissue_list month_aissue_access;
        aissue_list day_aissue_access;

        aissue_list aissue_access[100];  //由于新添加字段很多，直接添加了一个数组，对应关系规则已经根据protobuffer模板确定。
        string str_engine;
        string str_provider;
        string str_app_id;
        string str_action;
        string str_board_id;

        int   id ;
};
#define PARTURL 1 
#define PCREURL 2
typedef map <string, pair<uint32_t, uint32_t> > url2id_map; //// 新增加map表，url 对应的 protocol_id，app_id
typedef map<uint32_t, mail_handle*> map_mail; // url 到handle 
class part_url_mail{
    public:
        int type;
        pcre  *re;
        string part_url;
        mail_handle * p_handle ;
};
typedef list<part_url_mail> part_url_list;
// --------------- 
typedef map <string ,node_handle> node_handle_map;//node 解析列表 
typedef map <string,burstification> burstification_map; //组包函数列表
// ----------------  

class map_marge{
    public:
        ~map_marge()
        {

            node_map.clear();
            burs_map.clear();
        }
        static map_marge * get_instance()
        {
            static map_marge instance;
            return & instance;
        }
        void add_node_map(string name , node_handle  handle) 
        {
            if(handle == NULL || name.length()== 0 ) return ;
            node_map.insert(pair<string,node_handle>(name,handle));
        }
        node_handle  find_node_map(string name)
        {
            node_handle_map::iterator it = node_map.find(name);
            if(it != node_map.end())
            {
                node_handle  handle = it->second;
                return handle;
            }
            return NULL;
        }
        void add_burs_map(string name , burstification  handle) 
        {
            if(handle == NULL || name.length()== 0 ) return ;
            burs_map.insert(pair<string,burstification>(name,handle));
        }
        burstification  find_burs_map(string name)
        {
            burstification_map::iterator it = burs_map.find(name);
            if(it != burs_map.end())
            {
                return it->second;
            }
            return NULL;
        }


    private:
        map_marge()
        {
            node_map.clear();
            burs_map.clear();
        }
        node_handle_map node_map;
        burstification_map burs_map;
};

#endif  /*WEBMAIL_STR_H*/
