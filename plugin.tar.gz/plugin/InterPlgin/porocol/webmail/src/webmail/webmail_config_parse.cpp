// Last Update:2016-05-28 16:18:34
/**
 * @file webmail_config_parse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-04-22
 */

#include "webmail_config_parse.h"
using namespace std;

void itoa(int n, string& str)
{
    std::stringstream ss;
    ss << n;
    str = std::string(ss.str());
    ss.clear();
}

void assemble_path(string & path, int t)
{
    path += "[";
    string seq;
    itoa(t, seq);
    path += seq;
    path += "]";
}

webmail_config_parse::webmail_config_parse()
{
    //p_map_mail_uncertain = NULL;
    //p_partlist_uncertain = NULL;
    //flag = 0;
    p_map_mail_uncertain = NULL;
    p_partlist_uncertain = NULL;
    // 循环读取配置文件
    if(p_map_mail_uncertain == NULL)
        p_map_mail_uncertain = new map_mail;
    if(p_partlist_uncertain == NULL)
        p_partlist_uncertain  = new part_url_list;
    //flag = 0;
    b_had_dan_response = false;
}

webmail_config_parse::~webmail_config_parse()
{
    list<map_mail*>::iterator iter = del_mail_list.begin();
    for(;iter != del_mail_list.end() ;iter ++)
    {
        map_mail* p = *iter ;
        map<uint32_t,mail_handle*>::iterator it = p->begin();
        delete p;
    }
    list<mail_handle *> ::iterator it =  del_mailhandle_list.begin();
    for(;it != del_mailhandle_list.end();it ++)
    {
        mail_handle * p = *it;
        delete p ;
    }

    list<part_url_list *> ::iterator it2 =  del_urlparthandle_list.begin();
    for(;it2 != del_urlparthandle_list.end();it2 ++)
    {
        part_url_list * p = *it2;
        part_url_list::iterator p_it = p->begin();
        for(;p_it != p ->end(); p_it ++) 
        {
            if(p_it->type == PCREURL)
            {
                pcre_free(p_it->re);
            }
        }
        delete p ;
    }
    if(p_partlist_uncertain != NULL)//根据valgrind工具检测该空间未释放
    {
       delete p_partlist_uncertain;
    }
    if(p_map_mail_uncertain != NULL)
    {
        delete p_map_mail_uncertain;
    }
}

void webmail_config_parse::parse(string xmlstr,xml_parse  & xml)
{
    string tmp = "" ;
    xml.set_file_path(xmlstr.c_str());

    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        send_data_type = p_value;
    }

    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        time_out = (int)atoi(p_value);
    }

    // 循环读取配置文件
    /* if(flag == 0)
       {
       p_map_mail_uncertain = new map_mail;
       p_partlist_uncertain  = new part_url_list;
       }*/
    //if(p_map_mail_uncertain == NULL)
    //    p_map_mail_uncertain = new map_mail;
    //if(p_partlist_uncertain == NULL)
    //    p_partlist_uncertain  = new part_url_list;
    // 读取一共有多少个mail
    string xpath_mail = "/config/webmail_parse/mail";
    uint32_t mail_count = xml.get_value_count(xpath_mail.c_str());
    for(uint32_t i=0; i<mail_count; ++i)
    {
        // 获取第0个节点mail_name
        //  if (flag == 0)
        {
            p_map_mail = new map_mail;
            del_mail_list.push_back(p_map_mail);
            p_partlist  = new part_url_list;
            del_urlparthandle_list.push_back(p_partlist);
            flag = 1;
        }
        string xpath_mail_tmp = xpath_mail;
        assemble_path(xpath_mail_tmp, i+1);

        string xpath_mail_name = xpath_mail_tmp;
        xpath_mail_name += "/mail_name";

        string mail_name;
        p_value = (char *)xml.get_value(xpath_mail_name.c_str());
        if(p_value != NULL)
        {
            mail_name = p_value;
        }

        //新增tissed
        //mail_handle * p_handles = new mail_handle(); //使用valgrind工具测试该处有内存泄露 查看该变量p_handles发现没有地方对其进行使用
        // del_mailhandle_list.push_back(p_handles);

        /* string xpath_mail_item = xpath_mail_tmp;
           mail_other_keyvalue(xpath_mail_item+ "/proto_type",&(p_handles->proto_type_aissue),xml);
           mail_other_keyvalue(xpath_mail_item+ "/jz_class",&(p_handles->jz_calss_aissue),xml);
           mail_other_keyvalue(xpath_mail_item+ "/app_id",&(p_handles->app_id_aissue),xml);*/

        // 附件列表，可能多个
        string xpath_mail_attach = xpath_mail_tmp;
        xpath_mail_attach += "/urlhandle";

        uint32_t attachment_count = xml.get_value_count(xpath_mail_attach.c_str());
        for(uint32_t j=0; j<attachment_count; ++j)
        {
            mail_handle  * handles = new mail_handle;

            /*handles->proto_type_aissue = p_handles->proto_type_aissue;
              handles->jz_calss_aissue = p_handles->jz_calss_aissue;
              handles->app_id_aissue = p_handles->app_id_aissue;*/
            del_mailhandle_list.push_back(handles);
            string xpath_mail_url_tmp = xpath_mail_attach;
            assemble_path(xpath_mail_url_tmp, j+1);

            string xpaht_urlhandle_item = xpath_mail_url_tmp;
            mail_other_keyvalue(xpaht_urlhandle_item+ "/proto_type",&(handles->proto_type_aissue),xml);
            mail_other_keyvalue(xpaht_urlhandle_item+ "/jz_class",&(handles->jz_calss_aissue),xml);
            mail_other_keyvalue(xpaht_urlhandle_item+ "/app_id",&(handles->app_id_aissue),xml);
            mail_other_keyvalue(xpaht_urlhandle_item+ "/action_type",&(handles->action_type_aissue),xml);
            mail_other_keyvalue(xpaht_urlhandle_item+ "/board_id",&(handles->board_id_aissue),xml);

            if(handles->proto_type_aissue.size() > 0)
            {
                map<string,string>::iterator it_prototype = num_word_code.find(handles->proto_type_aissue.front());
                if(it_prototype != num_word_code.end())
                {
                    handles->str_engine = it_prototype->second;
                }

            }

            if(handles->jz_calss_aissue.size() > 0)
            {
                map<string,string>::iterator it_prototype = num_word_code.find(handles->jz_calss_aissue.front());
                if(it_prototype != num_word_code.end())
                {
                    handles->str_provider = it_prototype->second;
                }

            }
            if(handles->app_id_aissue.size() > 0)
            {
                map<string,string>::iterator it_prototype = num_word_code.find(handles->app_id_aissue.front());
                if(it_prototype != num_word_code.end())
                {
                    handles->str_app_id = it_prototype->second;
                }

            }
            if(handles->action_type_aissue.size() > 0)
            {
                map<string,string>::iterator it_prototype = num_word_code.find(handles->action_type_aissue.front());
                if(it_prototype != num_word_code.end())
                {
                    handles->str_action = it_prototype->second;
                }

            }
            if(handles->board_id_aissue.size() > 0)
            {
                map<string,string>::iterator it_prototype = num_word_code.find(handles->board_id_aissue.front());
                if(it_prototype != num_word_code.end())
                {
                    handles->str_board_id = it_prototype->second;
                }

            }

            string xpath_mail_url = xpath_mail_url_tmp;
            xpath_mail_url += "/url";
            uint32_t url_count = xml.get_value_count(xpath_mail_url.c_str());
            list<string> list_url;

            // 把url放到list里面，取到基本节点后再轮询list把url作为主键插入map表
            for(uint32_t n=0; n<url_count; ++n)
            {
                string path = xpath_mail_url;

                assemble_path(path, n+1);
                p_value = (char *)xml.get_value(path.c_str());
                if(p_value != NULL)
                {
                    string url = p_value;
                    list_url.push_back(url);
                }
            }

            // url_type 
            string xpath_mail_url_type = xpath_mail_url_tmp;
            xpath_mail_url_type += "/url_type";
            p_value = (char *)xml.get_value(xpath_mail_url_type.c_str());
            if(p_value != NULL)
            {
                if(strcmp(p_value,"ATTACHMENT") == 0)
                {
                    handles -> parse_type = ATTACHMENT;
                }
                else if (strcmp(p_value,"MESS_BODY") == 0)
                {
                    handles ->parse_type = MESS_BODY;
                }
                else if (strcmp(p_value,"QQ_FILE") == 0)
                {
                    handles ->parse_type = QQ_FILE;
                }
                else if (strcmp(p_value,"IDENTITY") == 0)
                {
                    handles ->parse_type = IDENTITY;
                }
                else if (strcmp(p_value,"LOGIN") == 0)
                {
                    handles ->parse_type = LOGIN;
                }
                else if (strcmp(p_value,"REGIST") == 0)
                {
                    handles ->parse_type = REGIST;
                }
                else if (strcmp(p_value,"MOVIECORE") == 0)
                {
                    handles ->parse_type = MOVIECORE;
                }
                else if (strcmp(p_value,"LOCATION") == 0)
                {
                    handles ->parse_type = LOCATION;
                }
                else if (strcmp(p_value,"CLOUD") == 0)
                {
                    handles ->parse_type = CLOUD;
                }
                else if (strcmp(p_value, "SEARCH") == 0)
                {
                    handles->parse_type = SEARCH;
                }
                else if (strcmp(p_value, "LOGOUT") == 0)
                {
                    handles->parse_type = LOGOUT;
                }
                else if (strcmp(p_value,"TICKET") == 0)
                {
                    handles ->parse_type = TICKET;
                }
                else if (strcmp(p_value,"NEWS") == 0)
                {
                    handles ->parse_type = NEWS;
                }
                else if (strcmp(p_value,"JOB") == 0)
                {
                    handles ->parse_type = JOB;
                }
                else if (strcmp(p_value, "BBS") == 0)
                {
                    handles->parse_type = BBS;
                }
                else if (strcmp(p_value, "DEVELOPMENT") == 0)
                {
                    handles->parse_type = DEVELOPMENT;
                }
                else if (strcmp(p_value, "SHOP") == 0)
                {
                    handles->parse_type = SHOP;
                }
                else {
                    abort();
                }
            }
            else {
                abort();
            }

            // 处理do的循环
            string xpath_mail_parse = xpath_mail_url_tmp;
            xpath_mail_parse += "/requset_parse";

            // burstification  解析出 
            string bf_xpath = xpath_mail_parse;
            bf_xpath += "/burstification";
            p_value = (char *)xml.get_value(bf_xpath.c_str());
            if(p_value != NULL)
            {
                string tmp = p_value;
                handles->bf_handle = map_marge::get_instance()->find_burs_map(tmp);
                if(handles->bf_handle  == NULL)
                {
                    // 选择默认的 bf_handle
                    //                    abort();
                }

                // 根据 tmp 的值 ，去取组包函数
            }

            uint32_t parse_count = 1 ;//xml.get_value_count(xpath_mail_parse.c_str());

            for(uint32_t n=0; n<parse_count; ++n)
            {
                string xpath_do = xpath_mail_parse;
                //assemble_path(xpath_do, n+1);
                xpath_do += "/do";

                uint32_t do_count = xml.get_value_count(xpath_do.c_str());
                //list_handle handles;
                for(uint32_t m=0; m<do_count; ++m)
                {
                    string xpath_do_tmp = xpath_do;
                    assemble_path(xpath_do_tmp, m+1);
                    string xpath_do_name = xpath_do_tmp;
                    xpath_do_name += "/doname";
                    string doname;
                    p_value = (char *)xml.get_value(xpath_do_name.c_str());
                    if(p_value != NULL)
                    {
                        doname = p_value;
                    }

                    node info;
                    info.handle = map_marge::get_instance()->find_node_map(doname);
                    if(info.handle == NULL)
                    {
                        abort();
                    }

                    string xpath_keyvalue = xpath_do_tmp;
                    //  xpath_keyvalue += "/keyvalue";
                    // uint32_t keyvalue_count =1 ; // xml.get_value_count(xpath_keyvalue.c_str());

                    string xpath_key = xpath_keyvalue;
                    //assemble_path(xpath_key, t+1);
                    xpath_key += "/key";
                    uint32_t key_count = xml.get_value_count(xpath_key.c_str());
                    info.name.swap(doname);
                    for(uint32_t k=0; k<key_count; ++k)
                    {
                        string key_path  = xpath_key;
                        assemble_path(key_path, k+1);
                        p_value = (char *)xml.get_value(key_path.c_str());
                        if(p_value != NULL)
                        {
                            string key = p_value;
                            info.value_list.push_back(key);
                            // name   取到解析的函数 
                            // info.handle 
                        }
                    }
                    handles->hlist.push_back(info);
                }
            }

            // 解析回复 response==+
            string xpath_mail_response = xpath_mail_url_tmp;
            xpath_mail_response += "/response_parse";
            // response_burstification 
            string xpath_mail_response_bf = xpath_mail_response;
            xpath_mail_response_bf += "/burstification";
            p_value  = (char *)xml.get_value(xpath_mail_response_bf.c_str());
            if(p_value != NULL)
            {
                string tmp= p_value;
                // 查找reponse 组包函数 
                handles->r_bf_handle = map_marge::get_instance()->find_burs_map(tmp);
                if(handles->r_bf_handle  == NULL)
                {
                    // 选择默认的 bf_handle
                    abort();
                }
            }

            string xpath_do = xpath_mail_response;
            // assemble_path(xpath_do, n+1);
            xpath_do += "/do";

            uint32_t do_count = xml.get_value_count(xpath_do.c_str());
            for(uint32_t m = 0;m < do_count ; m++ )
            {
                // 
                string xpath_do_tmp = xpath_do;
                assemble_path(xpath_do_tmp, m+1);
                string xpath_do_name = xpath_do_tmp;
                xpath_do_name += "/doname";
                string doname;
                p_value = (char *)xml.get_value(xpath_do_name.c_str());
                if(p_value != NULL)
                {
                    doname = p_value;
                }
                node info;
                info.handle = map_marge::get_instance()->find_node_map(doname);
                info.name.swap(doname);
                //info.handle = map_marge::get_instance()->find_node_map(doname);
                if(info.handle == NULL)
                {
                    abort();//
                }

                string xpath_keyvalue = xpath_do_tmp;

                string xpath_key = xpath_keyvalue;
                //assemble_path(xpath_key, t+1);
                xpath_key += "/key";
                uint32_t key_count = xml.get_value_count(xpath_key.c_str());

                for(uint32_t k=0; k<key_count; ++k)
                {
                    string key_path  = xpath_key;
                    assemble_path(key_path, k+1);
                    p_value = (char *)xml.get_value(key_path.c_str());
                    if(p_value != NULL)
                    {
                        string key = p_value;
                        info.value_list.push_back(key);
                        // info.handle 
                    }

                }
                handles->rlist.push_back(info);
            }

            // tissed 
            string xpath_mail_tissue = xpath_mail_url_tmp;
            xpath_mail_tissue += "/tissue";
            // response_burstification 
            tissue_keyvalue(xpath_mail_tissue+ "/access_id",&(handles->access_id_aissue),xml);
            tissue_keyvalue(xpath_mail_tissue + "/access_name",&(handles->access_name_aissue),xml);
            tissue_keyvalue(xpath_mail_tissue + "/title",&(handles->title_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/body",&(handles->body_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/from",&(handles->from_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/cc",&(handles->cc_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/to",&(handles->to_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/bcc",&(handles->bcc_aissue_access),xml);

            tissue_keyvalue(xpath_mail_tissue + "/city",&(handles->city_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/uid",&(handles->uid_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/qq",&(handles->qq_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/mail",&(handles->mail_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/phone",&(handles->phone_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/reg_time",&(handles->reg_time_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/history",&(handles->history_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/sex",&(handles->sex_aissue_access),xml);

            tissue_keyvalue(xpath_mail_tissue + "/nickename",&(handles->nickename_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/resecret",&(handles->resecret_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/education",&(handles->education_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/height",&(handles->height_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/married",&(handles->married_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/country",&(handles->country_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/province",&(handles->province_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/year",&(handles->year_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/month",&(handles->month_aissue_access),xml);
            tissue_keyvalue(xpath_mail_tissue + "/day",&(handles->day_aissue_access),xml);
            int int_tmp = 0;
            char c_buff[100];
            for(;int_tmp<100; ++int_tmp)
            {
                //由于新添加字段很多，直接添加了一个数组，对应关系规则已经根据table表格确定。
                memset(c_buff, 0, 100);
                sprintf(c_buff, "/No%dkey_list", int_tmp);
                tissue_keyvalue(xpath_mail_tissue + c_buff ,&(handles->aissue_access[int_tmp]),xml);
            }

            // p_value = (char *)xml.get_value(xpath_mail_tissue_access_id.c_str());
            //list_handle handles;
            // 
            // 循环list 插入到map 里面
            list<string>::iterator it;
            for(it=list_url.begin(); it!=list_url.end(); ++it)
            {
                string url = *it;
                uint32_t crc = crc32((unsigned char *)url.c_str(),url.length());

                // 插入map表，对url进行crc32转码
                p_map_mail->insert(pair<uint32_t,mail_handle*>(crc, handles));
            }

            // 拼接 part_url 
            string xpath_mail_part_url = xpath_mail_url_tmp;
            xpath_mail_part_url += "/part_url";
            uint32_t part_url_count = xml.get_value_count(xpath_mail_part_url.c_str());
            for(uint32_t n=0; n<part_url_count; ++n)
            {
                string path = xpath_mail_part_url;

                assemble_path(path, n+1);
                p_value = (char *)xml.get_value(path.c_str());
                if(p_value != NULL)
                {
                    // string url = p_value;
                    // list_part_url.push_back(url);
                    part_url_mail pu_info;
                    pu_info. part_url = p_value;
                    pu_info.type = PARTURL;
                    pu_info.re = NULL;
                    pu_info.p_handle = handles;

                    p_partlist->push_back(pu_info);
                }
            }

            xpath_mail_part_url = xpath_mail_url_tmp;
            xpath_mail_part_url += "/pcre_url";
            part_url_count = xml.get_value_count(xpath_mail_part_url.c_str());
            for(uint32_t n=0; n<part_url_count; ++n)
            {
                string path = xpath_mail_part_url;

                assemble_path(path, n+1);
                p_value = (char *)xml.get_value(path.c_str());
                if(p_value != NULL)
                {
                    // string url = p_value;
                    // list_part_url.push_back(url);
                    part_url_mail pu_info;

                    pu_info. part_url = p_value;
                    pu_info.type = PCREURL;
                    if(!s_prce_init(pu_info.re,p_value))
                    {
                        abort();
                    }

                    pu_info.p_handle = handles;
                    p_partlist->push_back(pu_info);
                }
            }
        }
        // ip 到 邮件的map 
        string xpath_mail_ip = xpath_mail_tmp;
        xpath_mail_ip += "/ip";
        uint32_t ip_count = xml.get_value_count(xpath_mail_ip.c_str());
        //  
        for(uint32_t i=0; i<ip_count; ++i)
        {
            // 
            string xpath_ip_tmp = xpath_mail_ip;
            assemble_path(xpath_ip_tmp, i+1);
            p_value = (char *)xml.get_value(xpath_ip_tmp.c_str());
            // printf("p_value=%s\n",p_value);
            if(p_value != NULL)
            {
                string tmp = p_value ;
                if(tmp == "*")
                {
                    // p_map_mail 循环插入到p_map_mail_uncertain里面
                    if(p_map_mail->size() > 0)
                    {
                        map_mail::iterator iter = p_map_mail->begin();
                        for(; iter!=p_map_mail->end(); ++iter)
                        {
                            p_map_mail_uncertain->insert(pair<uint32_t, mail_handle*>(iter->first, iter->second));
                        }
                    }
                    if(p_partlist->size() > 0)
                    {
                        part_url_list::iterator iter = p_partlist->begin();
                        for(; iter!=p_partlist->end(); ++iter)
                        {
                            p_partlist_uncertain->push_back(*iter);
                        }
                    }
                }
                else
                {
                    c_ip i_ip(tmp);
                    if(p_map_mail -> size() > 0)
                    {
                        map<c_ip,map_mail*>::iterator iter = ip_mail_map.find(i_ip);
                        // 防止陪重复的IP
                        if(iter != ip_mail_map.end())
                        {
                            map_mail * p_mail_tmp = iter->second;
                            map_mail::iterator it = p_map_mail->begin();
                            for(;it != p_map_mail->end(); it ++)
                            {
                                p_mail_tmp ->insert(pair<uint32_t,mail_handle*>(it->first, it->second));
                            }
                            //     p_map_mail->clear();
                        }
                        else
                        {
                            //   printf("add ip %s ---\n" , tmp.c_str());
                            ip_mail_map.insert(pair<c_ip,map_mail*>(i_ip , p_map_mail));
                            //p_map_mail = NULL;
                            //flag = 0 ;
                        }
                    }
                    if(p_partlist->size() > 0)
                    {
                        map<c_ip,part_url_list*>::iterator iter = ip_parturl_mail_map.find(i_ip);
                        if(iter != ip_parturl_mail_map.end())
                        {
                            part_url_list * p_parturl_tmp = iter->second;
                            part_url_list::iterator it = p_partlist->begin();
                            for(; it!=p_partlist->end(); ++it)
                            {
                                p_parturl_tmp->push_back(*it);
                            }
                            //   p_partlist->clear();

                        }
                        else
                        {
                            //   printf("add part ip %s ---\n" , tmp.c_str());
                            ip_parturl_mail_map.insert(pair<c_ip,part_url_list *>(i_ip,p_partlist));
                            flag = 0 ;
                        }
                    }
                }
            }
        }
        // 添加host 配置  ， host 配置取crc32
        // host 到 邮件的map
        string xpath_mail_host = xpath_mail_tmp;
        xpath_mail_host += "/host";
        uint32_t host_count = xml.get_value_count(xpath_mail_host.c_str());
        for(uint32_t i = 0 ; i < host_count ; i ++)
        {
            string xpath_host_tmp = xpath_mail_host;
            assemble_path(xpath_host_tmp, i+1);
            p_value = (char *)xml.get_value(xpath_host_tmp.c_str());
            if(p_value != NULL)
            {
                printf("config host is [%s]\n",p_value);
                int crc_key = crc32((unsigned char*)p_value,strlen(p_value)) ;
                if(p_map_mail -> size() > 0)
                {
                    map<uint32_t,map_mail*>::iterator iter = host_mail_map.find(crc_key);
                    // 防止陪重复的IP
                    if(iter != host_mail_map.end())
                    {
                        map_mail * p_mail_tmp = iter->second;
                        map_mail::iterator it = p_map_mail->begin();
                        for(;it != p_map_mail->end(); it ++)
                        {
                            p_mail_tmp ->insert(pair<uint32_t,mail_handle*>(it->first, it->second));
                        }
                        //p_map_mail ->clear();
                    }
                    else
                    {
                        host_mail_map.insert(pair<uint32_t,map_mail*>(crc_key , p_map_mail));
                        flag = 0 ;
                    }
                }
                if(p_partlist->size() > 0)
                {
                    map<uint32_t,part_url_list*>::iterator iter = host_parturl_mail_map.find(crc_key);
                    if(iter != host_parturl_mail_map.end())
                    {
                        part_url_list * p_parturl_tmp = iter->second;
                        part_url_list::iterator it = p_partlist->begin();
                        for(; it!=p_partlist->end(); ++it)
                        {
                            p_parturl_tmp->push_back(*it);
                        }
                        //  p_partlist->clear();

                    }
                    else
                    {
                        host_parturl_mail_map.insert(pair<uint32_t,part_url_list *>(crc_key,p_partlist));
                        flag = 0 ;
                    }
                }
                //------------------------------------
            }
        }
    }
    return;
    // ip = *  url = * 的换到最后取 
}

//添加url和id号的map表函数
void webmail_config_parse::urlparse(string xmlstr)
{
    xml_parse xml;
    string tmp = "" ;
    xml.set_file_path(xmlstr.c_str());

    // 读取一共有多少个mail
    string xpath_webname = "/config/post/webname";
    uint32_t webname_count = 0;
    webname_count = xml.get_value_count(xpath_webname.c_str());//得到有多少个webname
    for(uint32_t n=0; n< webname_count; ++n)
    {
        string xpath_webname_tmp = xpath_webname;
        assemble_path(xpath_webname_tmp, n+1);//给webname路径编号
        string xpath_url = xpath_webname_tmp;
        xpath_url += "/url";
        string url= "";
        char *p_value = (char *)xml.get_value(xpath_url.c_str());
        if(p_value != NULL)
        {
            url = p_value;
        }
        string xpath_app = xpath_webname_tmp;
        xpath_app += "/appid";
        uint32_t  app = 0;
        p_value = (char *)xml.get_value(xpath_app.c_str());
        if(p_value != NULL)
        {
            app =atoi(p_value);
        }
        string xpath_protocol = xpath_webname_tmp;
        xpath_protocol += "/potoid";
        uint32_t   protocol = 0;
        p_value = (char *)xml.get_value(xpath_protocol.c_str());
        if(p_value != NULL)
        {
            protocol =atoi(p_value);
        }

        pair<uint32_t, uint32_t> value;
        value.first = protocol;
        value.second = app;
        p_url2id_map[url] = value;
    } 

    xpath_webname = "/config/location/webname";
    webname_count = 0;
    webname_count = xml.get_value_count(xpath_webname.c_str());//得到有多少个webname
    for( uint32_t n=0; n< webname_count; ++n)
    {
        string xpath_webname_tmp = xpath_webname;
        assemble_path(xpath_webname_tmp, n+1);//给webname路径编号
        string xpath_url = xpath_webname_tmp;
        xpath_url += "/url";
        string url= "";
        char *p_value = (char *)xml.get_value(xpath_url.c_str());
        if(p_value != NULL)
        {
            url = p_value;
        }
        string xpath_app = xpath_webname_tmp;
        xpath_app += "/appid";
        uint32_t  app = 0;
        p_value = (char *)xml.get_value(xpath_app.c_str());
        if(p_value != NULL)
        {
            app =atoi(p_value);
        }
        if(app != 0)
        {
            url_app_loc_map[url] = app;
        }
        string xpath_flag = xpath_webname_tmp;
        xpath_flag += "/divflag";
        string flag = "";
        p_value = (char *)xml.get_value(xpath_flag.c_str());
        if(p_value != NULL)
        {
            flag = p_value;
        }

        if ( flag != "")
        {
            url_flag_map[url] = flag;
        } 
    }
}

//专用于将代码集转换成数字码
void webmail_config_parse::code_set_value_parse(string xmlstr)
{
    xml_parse xml;
    string tmp = "" ;
    xml.set_file_path(xmlstr.c_str());

    // 读取一共有多少个mail
    string xpath_pair = "/config/protocol/pair";
    uint32_t pair_count = 0;
    pair_count = xml.get_value_count(xpath_pair.c_str());//得到有多少个pair
    for(uint32_t n=0; n< pair_count; ++n)
    {
        string xpath_pair_tmp = xpath_pair;
        assemble_path(xpath_pair_tmp, n+1);//给webname路径编号
        string xpath_numid = xpath_pair_tmp;
        xpath_numid += "/num_id";
        string num_id= "";
        char *p_value = (char *)xml.get_value(xpath_numid.c_str());
        if(p_value != NULL)
        {
            num_id = p_value;
        }
        string xpath_word_code = xpath_pair_tmp;
        xpath_word_code += "/word_code";
        string word_code = "";
        p_value = (char *)xml.get_value(xpath_word_code.c_str());
        if(p_value != NULL)
        {
            word_code = (p_value);

        }
        num_word_code[word_code]=num_id;
    } 
}

void webmail_config_parse::tissue_keyvalue(string  xpath, aissue_list* p_list, xml_parse  & xml )
{
    if(!xml.is_node_exsit(xpath.c_str()))
    {
        return ;
    }
    else
    {
        string tmpkey = xpath;
        tmpkey += "/key";
        uint32_t key_count = xml.get_value_count(tmpkey.c_str());
        for(uint32_t i = 0 ; i < key_count ; i++)
        {
            string key_path  = tmpkey;
            assemble_path(key_path, i+1);
            char * p_value =(char *) xml.get_value(key_path.c_str());
            if(p_value!=NULL)
            {
                string tmp = p_value;
                p_list->push_back(p_value);
            }
        }
    }
}

void webmail_config_parse::mail_other_keyvalue(string  xpath, aissue_list* p_list, xml_parse  & xml )
{
    if(!xml.is_node_exsit(xpath.c_str()))
    {
        return ;
    }
    else
    {
        string tmpkey = xpath;
        //  tmpkey += "/key";
        uint32_t key_count = xml.get_value_count(tmpkey.c_str());
        for(uint32_t i = 0 ; i < key_count ; i++)
        {
            string key_path  = tmpkey;
            assemble_path(key_path, i+1);
            char * p_value =(char *) xml.get_value(key_path.c_str());
            if(p_value!=NULL)
            {
                string tmp = p_value;
                p_list->push_back(p_value);
            }
        }
    }
}

bool s_prce_init(pcre* & re,char * pattern)
{
    const char *error; 
    int  erroffset; 
    re = pcre_compile(pattern,     // pattern, 输入参数，将要被编译的字符串形式的正则表达式 
            0,             // options, 输入参数，用来指定编译时的一些选项 
            &error,         // errptr, 输出参数，用来输出错误信息 
            &erroffset,     // erroffset, 输出参数，pattern中出错位置的偏移量 
            NULL);         // tableptr, 输入参数，用来指定字符表，一般情况用NULL 
    // 返回值：被编译好的正则表达式的pcre内部表示结构 
    if (re == NULL)
    {//如果编译失败，返回错误信息 
        //printf("PCRE compilation failed at offset %d: %s\n", erroffset, error); 
        return false; 
    } 
    return true;
}

bool parturl_compare(part_url_mail * p_parturl,string & url,string & urlwithpath )
{
    int  ovector[1024]; 
    if(p_parturl->type == PARTURL) 
    {
        return (url.compare(0,p_parturl->part_url.length(),p_parturl->part_url)==0);
    }
    else if (p_parturl->type == PCREURL ){
        int rc= pcre_exec(p_parturl->re ,
                NULL,
                urlwithpath.c_str(),
                urlwithpath.length(),
                0,
                0,
                ovector ,
                1024); 
        if (rc < 0)
        {
            return false;
        }
        return true;
    }
    return false;
}

