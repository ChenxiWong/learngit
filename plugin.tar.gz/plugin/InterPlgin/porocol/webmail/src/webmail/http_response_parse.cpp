// Last Update:2016-01-11 15:28:32
/**
 * @file http_response_parse.cpp
 * @brief 
 * @author zhangqi
 * @version 0.1.00
 * @date 2015-11-02
 */

#include "http_response_parse.h"
#define DEFMAXBUF 6553500
#include  "thread_static.h"
bool http_response_parse::response_body_html2txt(session *p_session,webmail_session* p_webmail_session,s_http_request * p_requst,s_http_response * p_response,node_value_list& v_list) 
{
//    return true;

    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_webmail_session -> b_end_send  == false ) 
    {
        if(p_webmail_session -> b_c2s  ) 
        {
            return true;
        }
    }
    if(p_parse_value->len > MAXTCPBUF + ADDITIONALBUF)
    {
        return false;
    }
    if(p_response != NULL) 
    {
        c_http_str *p_value = find_key_value(p_response -> HttpHeaderKeyNameValue,"Content-Type");
        if(p_value  != NULL)
        {
            string ContextType = string(p_value -> buf_begin,0,p_value -> space_use_len);

            p_parse_value->value_map.insert(pair<string,string>(string("ResponseCentextType"), ContextType));
        }
        p_value = find_key_value(p_response -> HttpHeaderKeyNameValue,"Content-Encoding");
        // 是否需要解压文件 
        //if( ContextType.find("gzip")!= string::nps) 
        if(p_value  != NULL )
        {
            string sContentEncode  =  string(p_value -> buf_begin,0, p_value -> space_use_len);
            p_parse_value->value_map.insert(pair<string,string>(string("ResponseCentextEnconding"), sContentEncode));

        }
    }
    if(p_webmail_session ->state == server_data) 
    {
        //  p_parse_value -> parse_type = MESS_BODY;
        // 获取
          
        if(p_webmail_session ->response_length  == 0) 
        {

            // 解析时间 
            if(p_parse_value->len < DEFMAXBUF)
            {
                p_parse_value->parse_tmp_buf   = new char[DEFMAXBUF];
                p_webmail_session ->response_length = DEFMAXBUF ;
            }
            else 
                return  true;

        }
        else 
        {
            if(p_parse_value->len > p_webmail_session ->response_length +16)
            {
                p_webmail_session ->b_add_end = true;
                p_parse_value->parse_tmp_buf   = new char[p_parse_value->len];
            }
            else 
            {
                p_parse_value->parse_tmp_buf   = new char[p_webmail_session ->response_length +16];
                p_session -> send_len = 0;
                p_session->p_send_buf= NO_NULL; 
                // 
            }

        }
        //if(p_parse_value->len > 0)
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len += p_parse_value->len;
        //p_parse_value->file_data = string(p_parse_value->buf, 0,p_parse_value->len);
        if(p_webmail_session ->response_length == 0||p_webmail_session ->response_length >  p_parse_value ->len) 
        {
            // 
                p_webmail_session->state = server_data_continue;
                p_session -> send_len = 0;
                p_session->p_send_buf= NO_NULL; 

            return true;
        }
    }
    else if(p_webmail_session ->state == server_data_continue) 
    {
        if(p_webmail_session ->response_length >  0)
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > p_webmail_session ->response_length) 
            {
                if(p_webmail_session ->response_length > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = p_webmail_session ->response_length - p_parse_value->parse_tmp_len;
                }
            }
        }
        else
        {
            if(p_parse_value->parse_tmp_len  + p_parse_value->len > DEFMAXBUF) 
            {
                if(DEFMAXBUF > p_parse_value->parse_tmp_len)
                {
                    p_parse_value->len = DEFMAXBUF - p_parse_value->parse_tmp_len;
                }
            }
        }
        
        //if(p_parse_value->len > 0)
        if((p_parse_value->parse_tmp_buf!=NULL) && (p_parse_value->len>0))
            memcpy(p_parse_value->parse_tmp_buf + p_parse_value->parse_tmp_len ,p_parse_value->buf,p_parse_value->len);
        p_parse_value->parse_tmp_len += p_parse_value->len;
        p_session -> send_len = 0;
        p_session->p_send_buf= NO_NULL; 

    }
    //printf("p_parse_value->parse_tmp_len = %d  \n " , p_parse_value->parse_tmp_len);
    //printf("p_webmail_session ->response_length = %d \n  " , p_webmail_session ->response_length);
    // 文件是否结束 
    if((p_webmail_session ->response_length  != 0 &&p_parse_value->parse_tmp_len >= p_webmail_session ->response_length) || IS_SESSION_OVER(p_session))
    {
         p_webmail_session -> b_end_send  = true;
         p_session->send_len = 1 ;
         p_session->p_send_buf  = NO_NULL;
        if(p_webmail_session ->response_length < p_parse_value->parse_tmp_len )
            p_webmail_session ->response_length = p_parse_value->parse_tmp_len;

        char * p_data = NULL;
        int  data_len = 0;
        if(p_parse_value->parse_tmp_buf == NULL)
            return true;
        string  sContentEncode = "";
        sContentEncode =  p_parse_value->value_map["ResponseCentextEnconding"];
        string ContextType = "";
        ContextType =  p_parse_value->value_map["ResponseCentextType"];
        string sHtml = "";
        sHtml =  p_parse_value->value_map["htmlurl"];
        char * gzip_buffer = NULL;
        int gzip_len  = 0 ;
        
        if(sContentEncode.find("zip") != string::npos )
        {
            gzip_buffer = new char[ p_webmail_session ->response_length * 10];
            if(gzip_buffer == NULL)
                return true;

             gzip_len  = p_webmail_session ->response_length * 10;
            int len = gzip_len  ;
            //printf("*****************len =   %d\n", len);
            // 
            int ret  = httpgzdecompress((Bytef *)p_parse_value->parse_tmp_buf ,(uLong)p_parse_value->parse_tmp_len,
                    (Bytef *) gzip_buffer, (uLong*)&len);
            if(ret != 0 && p_parse_value->parse_tmp_len>7) 
            {
                //  尝试第二次 解析   sohu 正文 ，  
                ret  = httpgzdecompress((Bytef *)p_parse_value->parse_tmp_buf ,(uLong)p_parse_value->parse_tmp_len -7,
                        (Bytef *) gzip_buffer , (uLong*)&len);

            }
            if(ret != 0 )
            {
                if(gzip_buffer != NULL) 
                {
                    delete [] gzip_buffer;
                    gzip_buffer = NULL;
                }
                return true;

                //return false;
            }
            else {
                gzip_buffer[len] = 0x0;  
                p_data = gzip_buffer ;
                data_len =  len;

            }
        }
        else 
        {
            // 

            p_data  = p_parse_value->parse_tmp_buf ;
            data_len   = p_parse_value->parse_tmp_len ;
            if(data_len > p_webmail_session ->response_length &&  p_webmail_session ->response_length != 0 ) 
            {
                data_len = p_webmail_session ->response_length ;
            }
            //
        }
        // html 接写 
        if(p_data == NULL) 
        {
            if(gzip_buffer != NULL) 
            {
                delete [] gzip_buffer;
                gzip_buffer = NULL;
            }
            return true;
        }
        string sCharset = "";
        if( !ContextType.empty())
        {
            int nps = ContextType.find("charset=");
            if(nps != -1) 
                sCharset= string(ContextType,nps+strlen("charset="),ContextType.length());
        }
        if ( ContextType.find("text/html")!= string::npos && sHtml.find("htm")!= string::npos )
        {

            char * html_buf =  new char[data_len+10];
            int  html_len  = data_len * 10; 

            // html 解析 
            // static __thread CTransEntity  * pEntit = NULL;


            if ( !sCharset .empty()) 
            {
                get_transentity()->Convert(html_buf,html_len,(char *)p_data , data_len  , (char *)sCharset.c_str());
            }
            else 
            {
                get_transentity()->Convert(html_buf,html_len,(char *)p_data , data_len  , NULL);
            }
            html_buf[html_len ] = 0x0;
            string lsvalue = "";
            // 内容转码
            if(html_len != 0 && strncmp(get_transentity()->m_charset,"UTF-8",5)&&strncmp(get_transentity()->m_charset,"UTF8",4)&&strncmp(get_transentity()->m_charset,"utf-8",5)&&strncmp(get_transentity()->m_charset,"utf8",4)) 
            {
                if(html_buf[0] != 0) 
                {
                    //char * p_convert_buf =  new char [ html_len * 10];// get_buffer();
                    //int  num_convert_leng =  html_len * 10 ;//c_thread_static::num_buffer_len ;
                    char * p_convert_buf =  get_buffer();
                    int  num_convert_leng =  c_thread_static::num_buffer_len ;

                    if(get_transentity()->m_charset[0] != 0) 
                    {
                        get_transentity()->cvcharset.Convert(html_buf,html_len,p_convert_buf,num_convert_leng,get_transentity()->m_charset,"UTF-8");
                    } 
                    else {
                        get_transentity()->cvcharset.Convert(html_buf,html_len,p_convert_buf,num_convert_leng,"GBK","UTF-8");
                    }
                    //printf ("num_convert_leng = %d \n",num_convert_leng);
                    //p_convert_buf[num_convert_leng] = 0x0;
                    lsvalue  = p_convert_buf ;
                    if(p_convert_buf != NULL)
                    {
                        //printf ("%s\n", p_convert_buf);
                    }
                 //   delete [] p_convert_buf ;
                }
            }
            else {
                lsvalue = html_buf ;
            }
            // 标题  
            string name = "HtmlTitle";
            string svalue(get_transentity()->m_Title);
            //printf ("%s\n", get_transentity()->m_Title);
            p_parse_value->value_map[name] = svalue;
            // 内容 
            name = "HtmlText";
            p_parse_value->value_map[name] = lsvalue;
            if(html_buf != NULL) 
            {
                delete  [] html_buf ;
                html_buf = NULL;
            }

        }

        if ((ContextType.find("zip")!= string::npos))//文件 
        {
            string name = "FileText"; 
            string svalue ((char *)p_data ,0, data_len );
            p_parse_value->value_map[name] = svalue;
            // 内容 
        }
        //  ungzip  
        if(gzip_buffer != NULL) 
        {
            delete [] gzip_buffer;
            gzip_buffer = NULL;
        }
    }
    return true;
}

