// Last Update:2016-05-13 16:56:23
/**
 * @file webmail_plugin.h
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-21
 */

#ifndef WEBMAIL_PLUGIN_H
#define WEBMAIL_PLUGIN_H

#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include <iconv.h>
#include "commit_tools.h"
#include "webmail_str.h"
#include "webmail_config_parse.h"
#include <tcp_recombine.h>
#include <map>
#include "webmail163_parse.h"
#include "webmailsohu_parse.h"
#include "identity.h"
#include <file_md5.h>
#include "html2txt.h"
#include "thread_static.h"
#include "cloud_parse.h"
#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;


extern "C" {
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info *);
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class webmail_plugin :public protocol_parse_base_handle{
    public:
        webmail_plugin();
        ~webmail_plugin();
        virtual void reload() ;
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);
    private:
        void host_potocol_identify( c_packet * p_packet,webmail_session * p_webmail_session );
        void ip_potocol_identify(c_ip i_ip,webmail_session *p_webmail_session );
        void init_webmail_session(webmail_session * p_webmail_session);
        uint32_t  webmail_time_out; // 单位s
        int       data_interface_type ; //
        uint8_t * webmail_quest_parse(session * p_session,webmail_session *p_webmail_session ,uint8_t * buf,uint32_t & len);
        uint8_t * webmail_answers_parse(session * p_session,webmail_session *p_webmail_session ,uint8_t * buf,uint32_t & len);
        uint8_t * webmail_url_parse_string(uint8_t * buf, uint32_t & len ,string & url,uint32_t  strat_len);
        void aissue_data(webmail_session * p_webmail_session , aissue_list * p_list,string * p_value);
        void aissue_data_identity(webmail_session * p_webmail_session , aissue_list * p_list,string * p_value);
        bool get_required_str_from_value_map(string& str_arg, session* p_session,webmail_session* p_webmail_session,aissue_list& list_arg);
        void get_optional_str_from_value_map(string& str_arg, session* p_session,webmail_session* p_webmail_session,aissue_list& list_arg);

        //遍历读取配置文件
        void list_read_xml(string logPath , int func_type);

        // 处理location的data_handle
        void handle_location_data(session* p_sess, list<data_interface> * p_list);

        void search_handle_data(session* p_sess, list<data_interface> * p_list);
        void news_data_handle(session* p_sess, list<data_interface> * p_list);
        void shop_handle_data(session* p_session, list<data_interface> * p_list);
        void job_data_handle(session* p_sess, list<data_interface> * p_list);
        void logout_handle_data(session* p_sess, list<data_interface> * p_list);
        void ticket_handle_data(session* p_sess, list<data_interface> * p_list);
        void develop_handle_data(session* p_sess, list<data_interface> * p_list);
        void bbs_handle_data(session* p_sess, list<data_interface> * p_list);
        map<uint32_t,string>off_string_map;
        string convertname(string assess_name);
        void  webmail_identity(session* p_session,list<data_interface> * p_list) ;
        void clear_webmail_session(webmail_session * p_webmail_session);
        uint32_t begin_len ;

        uint8_t  * begin_data;
        //        xml_parse  xml;

        void aissue_morekey_data(webmail_session * p_webmail_session , aissue_list * p_list , list<string>& value_list) ;

        void format_account(string & account);

        uint64_t begin_time;

        webmail_config_parse*  config_parse;
        webmail_parse parse;

        map <rule_node_offist * , int  >*  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;
        void multimode_webmail_identity(session* p_session, c_packet* p_packet);

        list<uint32_t> access_id_list;
        list<string> access_list;
        uint32_t access_id;
        string   access_name;
        string   title;
        string   body;
        string   mail_from;
        string   mail_to;
        string   mail_cc;
        string   mail_bcc;

        string mail_city;
        string mail_uid;
        string mail_qq;
        string mail_mail;
        string mail_phone;
        string mail_reg_time;
        string mail_sex;
        string mail_history;

        string mail_nickename;
        string mail_resecret;
        //string mail_birthday;
        string mail_education;
        string mail_height;
        string mail_married;
        string mail_country;
        string mail_province;
        string mail_year;
        string mail_month;
        string mail_day;

        map<string,iconv_t> iconv_map;
        CTransEntity c_html2txt;
        uint32_t max_file_length; // 文件最大大小，默认为50M
        string large_file_path; // 大文件写入的web映射的路径
};


void assemble_data(int num, vector<string> * p_value,string  &tmp , list<string> & value_list);
// 解析函数  添加到
void format_data(string &tmp);


std::string chineseCharDecode(const std::string& from);
std::string convChar(uint32_t val,const char* encTo,const char* encFrom);

void redis_inint();
int verifyMsisdn(char* inMsisdn);
static attach_info *  p_attach_info ;
map <rule_node_offist * , int  >  public_webmail_feature_rule_map ;
#endif  /*WEBMAIL_PLUGIN_H*/
