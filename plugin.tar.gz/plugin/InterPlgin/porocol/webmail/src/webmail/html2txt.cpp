#include "html2txt.h"
#include  <CConvCharSet.h>
//extern CCharDetect				g_chardet;

char *  StrnLowStr (char * src , int len , char * dst) 
{
    int i = 0; 
    int dstlen = strlen(dst);
    for(i = 0 ; i < len ; i++)
    {
        if(src[i] == dst[0]) 
        {
            if(strncasecmp(src + i , dst , dstlen ) == 0 )
            {
                return src + i ;
            }
        }
    }
    return NULL;
}



CTransEntity::CTransEntity()
{
    m_charset[0]=0;
    m_Title[0]=0;
}

CTransEntity::~CTransEntity()
{

}

int CTransEntity::HandleEscapeChar(unsigned char *pbuf, unsigned char *res)
{
    char token[9];
    memset (token, '\0', 9);
    int i;
    char *buf=(char *)pbuf;
    /* copying token into local buffer */
    i = 0;
    while (i <= 8 && buf[i]!=';')
    {
        token[i]=buf[i];
        i++;
    }
    if( buf[i]==';')
    {
        //token[i++]=';';
        //token[i]=0;
        token[i]=';';
    }
    else
    {
        /* if it does not seem to be a token, result is '&' */
        *res = 0x26;
        return 1;
    }
    /* identifying token */
    if (!strcmp(token,"&nbsp;"))
    {
        *res=0x20;
        return 6;
    }
    if (!strncmp (token, "&amp;", 5))
    {
        strcpy((char *)res,"&amp;"); //*res=0x26;
        return 5;
    }
    else if (!strncmp (token, "&lt;", 4))
    {
        strcpy((char *)res,"&lt;");//*res = 0x3C;
        return 4;
    }
    else if (!strncmp (token, "&gt;", 4))
    {
        //strcpy((char *)res,"&gt;");//*res = 0x3E;
        *res = 0x3E;
        return 4;
    }
    else if (!strncmp (token, "&quot;", 6))
    {
        strcpy((char *)res,"&quot;");//      *res = 0x22;
        return 6;
    }
    else if (!strncmp(token,"&apos;",6))
    {
        strcpy((char *)res,"&apos;");//
        return 6;
    }
    else if (!strncmp (token, "&eacute;", 8))
    {
        *res = 0x20;//0xE9;
        return 8;
    }
    else if (!strncmp (token, "&Eacute;", 8))
    {
        *res = 0x20;//0xC9;
        return 8;
    }
    else if (!strncmp (token, "&egrave;", 8))
    {
        *res = 0x20;//0xE8;
        return 8;
    }
    else if (!strncmp (token, "&Egrave;", 8))
    {
        *res = 0x20;//0xC8;
        return 8;
    }
    else if (!strncmp (token, "&ecirc;", 7))
    {
        *res = 0x20;//0xEA;
        return 7;
    }
    else if (!strncmp (token, "&agrave;", 8))
    {
        *res = 0x20;//0xE0;
        return 8;
    }
    else if (!strncmp (token, "&iuml;", 6))
    {
        *res = 0x20;//0xEF;
        return 6;
    }
    else if (!strncmp (token, "&ccedil;", 8))
    {
        *res = 0x20;//0xE7;
        return 8;
    }
    else if (!strncmp (token, "&ntilde;", 8))
    {
        *res = 0x20;//0xF1;
        return 8;
    }
    else if (!strncmp (token, "&copy;", 6))
    {
        *res = 0x20;//0xA9;
        return 6;
    }
    else if (!strncmp (token, "&reg;", 5))
    {
        *res = 0x20;//0xAE;
        return 5;
    }
    else if (!strncmp (token, "&deg;", 5))
    {
        *res = 0x20;//0xB0;
        return 5;
    }
    else if (!strncmp (token, "&ordm;", 6))
    {
        *res = 0x20;//0xBA;
        return 6;
    }
    else if (!strncmp (token, "&laquo;", 7))
    {
        *res = 0x20;//0xAB;
        return 7;
    }
    else if (!strncmp (token, "&raquo;", 7))
    {
        *res = 0x20;//0xBB;
        return 7;
    }
    else if (!strncmp (token, "&micro;", 7))
    {
        *res = 0x20;//0xB5;
        return 7;
    }
    else if (!strncmp (token, "&para;", 6))
    {
        *res = 0x20;//0xB6;
        return 6;
    }
    else if (!strncmp (token, "&frac14;", 8))
    {
        *res = 0x20;//0xBC;
        return 8;
    }
    else if (!strncmp (token, "&frac12;", 8))
    {
        *res = 0x20;//0xBD;
        return 8;
    }
    else if (!strncmp (token, "&frac34;", 8))
    {
        *res = 0x20;//0xBE;
        return 8;
    }
    else if (!strncmp (token, "&#", 2))
    {
        //res[0] = atoi (token + 2);
        //return i + 1;
        strcpy((char *)res,token);
        return i + 1;
    }
    else
    {
        *res = 0x20;
        return i + 1;
    }
}





void CTransEntity::GetEncoding(char *charset)
{
    if (m_charset[0]!=0)
    {
        char buf[64];
        int len=strlen(m_charset);
        int j=0;
        for (int i=0;i<len;i++)
        {
            if (m_charset[i]>='a' && m_charset[i]<='z')
            {
                buf[j++]=m_charset[i]-32;
                continue;
            }
            if (m_charset[i]>='A' && m_charset[i]<='Z'||m_charset[i]>='0' && m_charset[i]<='9')
            {
                buf[j++]=m_charset[i];
                continue;
            }
            if (m_charset[i]=='-'||m_charset[i]=='_')
            {
                buf[j++]=m_charset[i];
                continue;
            }
        }
        buf[j]=0;
        strncpy(m_charset,buf,127);
        m_charset[127] = '\0';
    }
    else
    {
        strncpy(m_charset,"GBK",127);
        m_charset[127] = '\0';
    }
    //ToUpperStr(m_charset);
    char *p1=strchr(m_charset,'_');
    if (p1) *p1='-';
    strncpy(charset,m_charset,127);
}





int CTransEntity::Convert(char *poutbuf, int &olen, char *pinbuf, int inlen, char* exCharSet)
{
    //AOC_DEBUG(" *****Convert  begin [%s]",pinbuf);
    unsigned char esc[32];
    register int len, i, isMarkup, isJavascript, isMeta, l, j;
    register int offset ;
    m_bGetTitleOnce = false;
    m_Title[0]=0;
    m_charset[0]=0;
    if (exCharSet)
    {
        memcpy(m_charset, exCharSet, strlen(exCharSet)+1);
    }
    l = 0;
    isJavascript = 0;
    isMarkup = 0;
    isMeta = 0;
    i=0;
    len=inlen;
    olen=0;
    bool bHeadFirst=false;
    while (i<len && (pinbuf[i]==0x20||pinbuf[i]=='\t'||pinbuf[i]==0xd||pinbuf[i]==0xa||pinbuf[i]==0x00))
        i++;
    if (i>=len) return 0;
    while (len>(i+1) && (pinbuf[len-1]==0x20||pinbuf[len-1]=='\t'||pinbuf[len-1]==0xd||pinbuf[len-1]==0xa||pinbuf[i]==0x00))
        len--;
    while(pinbuf[i] != '<' && i < len  && l < olen)
    {
        poutbuf[l++]=pinbuf[i++];
    }
    //if ((len-i)<32)  return l;
    while (i<len)
    {
        
        if (pinbuf[i]=='<')
        {
            if (i<len-8 && !strncasecmp(pinbuf+i,"<script", 7)) //filter javascript
            {
                i+=8;
                char *psend=StrnLowStr(pinbuf+i,len-i,"</script");
                if (psend)
                {
                    j=psend-pinbuf-i;
                    j+=8;
                    i+=j;
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;
                }
                continue;
            }
            if(i<len-8 && !strncasecmp(pinbuf+i,"<html>", 6))
            {
                i += 6;
            }
            if(i<len && !strncasecmp(pinbuf+i,"</html>", 7))
            {
                i += 7;
            }
            if (i<len-8 && !strncasecmp(pinbuf+i,"<head", 5))  //filter header
            {
                i+=6;
                char *psend=StrnLowStr(pinbuf+i,len-i,"</head");
                if (psend)
                {
                    j=psend-pinbuf-i;
                    j+=6;
                    if (!bHeadFirst)
                    {
                        GetTitleAndCharset(pinbuf+i,j);
                        bHeadFirst=true;
                    }
                    i+=j;
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;

                }
                else
                {
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;
                }
                continue;
            }
            if (i<len-8 && !strncasecmp(pinbuf+i,"<style",6))
            {
                i+=7;
                char *psend=StrnLowStr(pinbuf+i,len-i,"</style");
                if (psend)
                {
                    j=psend-pinbuf-i;
                    j+=7;
                    i+=j;
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;

                }
                else
                {
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;
                }
                continue;
            }
            if (i<len-8 && !strncasecmp(pinbuf+i,"<meta",5))
            {
                i+=6;
                char *pMetaBegin = pinbuf+i;
                char *psend=StrnLowStr(pinbuf+i,len-i,"</meta");
                if (psend)
                {
                    j=psend-pinbuf-i;
                    j+=6;
                    i+=j;
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;					
                }
                else
                {
                    for (;i<len&&pinbuf[i]!='>';i++) ;   //<find end '>
                    if (i<len&& pinbuf[i]=='>') i++;					
                }				
                if (m_charset[0] == 0)
                {
                    char *pMetaEnd = pinbuf+i;
                    char *pCharset = StrnLowStr(pMetaBegin, pMetaEnd-pMetaBegin, "charset=");
                    if (pCharset != NULL)
                    {
                        pCharset+=8;
                        for (; (*pCharset == ' ') && (pCharset < pMetaEnd); pCharset++);
                        int nCharset = 0;
                        for (; (*pCharset != '\"') && (pCharset < pMetaEnd); pCharset++, nCharset++)
                        {
                            m_charset[nCharset] = *pCharset;
                        }
                        m_charset[nCharset] = '\0';
                    }					
                }
                continue;
            }

            if (i<len-4)
            { //line handle
                if (!strncasecmp(pinbuf+i,"<p",2)||!strncasecmp(pinbuf+i,"<pre",4)||!strncasecmp(pinbuf+i,"<br",3)||
                        !strncasecmp(pinbuf+i,"<li",3)||!strncasecmp(pinbuf+i,"<ul",3)||
                        !strncasecmp(pinbuf+i,"<ul",3)||!strncasecmp(pinbuf+i,"<ol",3)||!strncasecmp(pinbuf+i,"<tr",3))
                {
                    for (;i<len &&pinbuf[i]!='>';i++) ;
                    if (i<len &&pinbuf[i]=='>')
                        i++;

                    if (l>0 && poutbuf[l-1]==0x0a)
                        continue;
#ifdef WIN32
                    poutbuf[l++]=0x0d;
#endif
                    poutbuf[l++]=0x0a;
                    continue;
                }
                if( !strncasecmp(pinbuf+i,"<body",5) ) 
                {
                    for (;i<len &&pinbuf[i]!='>';i++) ;
                    if(pinbuf[i] == '>') i++;
                    for(;i<len &&pinbuf[i]!='<'; i++)
                    {
                        poutbuf[l++] = pinbuf[i];
                    }
                }
                if (!strncasecmp(pinbuf+i,"<td",3)||!strncasecmp(pinbuf+i,"<th",3) )  //table column handle
                {
                    for (;i<len &&pinbuf[i]!='>';i++) ;
                    if (i<len &&pinbuf[i]=='>')
                        i++;
                    poutbuf[l++]=0x20;
                    poutbuf[l++]=0x20;
                    continue;
                }
            }
            if (!strncmp(pinbuf+i,"</",2))
            {
                for (;i<len &&pinbuf[i]!='>';i++) ;
                if (i<len&&pinbuf[i]=='>')
                    i++;
                continue;
            }
            if (i<len-5 && !strncasecmp(pinbuf+i,"<div",4))
            {
                for (;i<len &&pinbuf[i]!='>';i++) ;
                if (i<len &&pinbuf[i]=='>')
                    i++;
                poutbuf[l++]=0x20;
                poutbuf[l++]=0x20;
                continue;

            }
            for (;i<len && pinbuf[i]!='>';i++)   //find '<' skip <aaa>command
            {
                //				if (pinbuf[i]==')')   //may script command
                //					break;
                ;

            }
            if (i<len&& pinbuf[i]=='>') i++;
            continue;
        }
        if (pinbuf[i]==0x26)  //&
        {
            isMarkup=0;
            if (i<len-1)
            {
                for (j=i;j<len&&(j-i)<9;j++)
                {
                    if (pinbuf[j]==';')
                    {
                        isMarkup=1;
                        break;
                    }
                }
            }
            if (isMarkup)
            {
                memset (esc, '\x00', 32);
                offset = HandleEscapeChar((unsigned char *)(pinbuf + i), esc);
                i+=offset;
                j=strlen((char *)esc);
                memcpy(poutbuf+l,esc,j);
                l+=j;
            }
            else
            {
                poutbuf[l++]=pinbuf[i++];
            }
            continue;
        }
        if (pinbuf[i]=='\r'||pinbuf[i]=='\n')
        {
            i++;
            continue;
        }
        if (pinbuf[i]=='>')    //Not < matches
        {
            i++;
            continue;
        }
        if (pinbuf[i]==0x20||pinbuf[i]=='\t')
        {
            //begin add for ticket 611 by litian 20070828
            if(l>0 && poutbuf[l-1]!=0x20)
                poutbuf[l++]=0x20;
            //end add for ticket 611 by litian 20070828
            i++;
            /*			continue;
                        if (l>0 && poutbuf[l-1]==0x20)
                        {
                        continue;
                        }
                        else
                        poutbuf[l++]=0x20;*/
            continue;
        }
        if ((unsigned char)pinbuf[i]<0x20||(unsigned char)pinbuf[i]==0xff)
        {
            i++;
            continue;
        }

        poutbuf[l++]=pinbuf[i++];
    }
    olen=l;
    poutbuf[olen]=0;
    if (m_charset[0] == 0)
    {
        char *pCharset = StrnLowStr(pinbuf, inlen, "charset=");
        if (pCharset != NULL)
        {
            pCharset+=8;
            int nCharset = 0;
            for (; (*pCharset != '\"') && (pCharset < (pinbuf + inlen)); pCharset++, nCharset++)
            {
                m_charset[nCharset] = *pCharset;
            }
            m_charset[nCharset] = '\0';
        }					
    }
    if (m_charset[0]==0 && olen>0)
    {
        string charset;
       // 字符集识别函数 
        charset=ZHCNcode(poutbuf,olen);
        strncpy(m_charset,charset.c_str(),charset.length());
    }
    ConvertTitle();
    return olen;
}

void CTransEntity::GetTitleAndCharset(char *pbuff, int len)
{
    char *pt=StrnLowStr(pbuff,len,"<title");
    char *ps=NULL;
    int i;
    //AOC_DEBUG("GetTitleAndCharset pbuff [%s]",pbuff);
    if (pt)
    {
        pt+=6;
        int stpos=pt-pbuff;
        int remlen=len-stpos;
        for (i=0;i<remlen&&pt[i]!='>';i++) ;
        if (i<remlen-7)
        {
            i++;
            while (i<remlen && (pt[i]==0x0d||pt[i]==0x0a||pt[i]==0x20||pt[i]=='\t')) i++;
            if (i<remlen-7)
            {
                pt+=i;
                remlen-=i;
                ps=pt;
                char *pe=StrnLowStr(pt,remlen,"</title");
                if (pe)
                {
                    int tlen=pe-pt;
                    if (tlen<200)
                    {
                        memcpy(m_Title,pt,tlen);
                        m_Title[tlen]=0;
                    }
                    else
                    {
                        memcpy(m_Title,pt,200);
                        m_Title[200]=0;
                        tlen=200;
                    }
                    if (tlen>1)
                    {
                        tlen--;
                        while (tlen>0 && (m_Title[tlen]==0x0a||m_Title[tlen]==0x0a))
                        {
                            m_Title[tlen]=0;
                            tlen--;
                        }
                    }
                }
            }
        }
    }
    pt=StrnLowStr(pbuff,len,"<meta ");
    if (pt)
    {
        pt+=6;
        int remlen=len-(pt-pbuff);
        for (i=0;i<remlen&&pt[i]!='>';i++) ;
        if (i<remlen)
        {
            ps=StrnLowStr(pt,i,"charset");
            if (ps)
            {
                ps+=8;
                pt+=i;
                while (ps<pt)
                {
                    if (*ps==' '||*ps=='=')
                        ps++;
                    else
                        break;
                }
                if (*ps=='%') ps+=3;
                if (ps<pt)
                {
                    for (i=0;i<18 && *ps!='\"' && *ps!='>';i++)
                    {
                        m_charset[i]=*ps;
                        ps++;
                    }
                    m_charset[i]=0;
                }
            }

        }
    }
}


void CTransEntity::ConvertTitle()
{
    if (m_Title[0]!=0)
    {
        char charset[128];
        char tmp[2048];
        if (m_charset[0] == 0)
        {
            GetEncoding(charset);
        }
        else
        {
            memcpy(charset, m_charset, strlen(m_charset)+1);
        }
        if (strncmp(charset,"UTF-8",5)&&strncmp(charset,"UTF8",4)&&strncmp(charset,"utf-8",5)&&strncmp(charset,"utf8",4))
        {
            int osize=2048;
            int inlen=strlen(m_Title);
            //CConvertCharSet cvcharset;
            cvcharset.Convert(m_Title,inlen,tmp,osize,charset,"UTF-8");
            if (osize>0)
            {
                if (osize>250)
                    osize=250;
                memcpy(m_Title,tmp,osize);
                //				m_Title[osize]=' ';
                m_Title[osize]=0;

            }
            else
                m_Title[0]=0;
        }
    }
}
