// Last Update:2015-10-15 14:25:50
/**
 * @file unic_to_utf8.h
 * @brief 
 * @author renzezhong
 * @version 0.1.00
 * @date 2015-10-15
 */

#ifndef UNIC_TO_UTF8_H
#define UNIC_TO_UTF8_H
#include <iostream>
#include <stdint.h>
using namespace std;
int unicode_to_utf8(uint32_t, unsigned char*, int);
#endif  /*UNIC_TO_UTF8_H*/
