// Last Update:2016-09-03 09:36:41
/**
 * @file webmail_plugin.cpp
 * @brief 
 * @author wangxiang
 * @version 0.1.00
 * @date 2015-04-24
 */

#include "webmail_plugin.h"
#include "news_parse.h"
//#include "config_text.h"
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/statfs.h>
#include <sys/syscall.h>
#include "file_passwd.h"

#define WEBMAILDEFINEPORT 80
const char * config_path = "";
static string display_print = "";
static bool init_parse_all_xml = false;

static webmail_config_parse static_config_parse;

static bool b_check_config  = true;

extern "C" {
    int get_plugin_id()
    {
        return 3;
    }
    //protocol_parse_base_handle * attach()
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info  = p ; 
        return new  webmail_plugin();
    }
}
static string&   replace_str_all(string&   str,const   string&   old_value,const   string&   new_value)
{
    while(true)   {
        string::size_type   pos(0);
        if(   (pos=str.find(old_value))!=string::npos   )
            str.replace(pos,old_value.length(),new_value);
        else   break;
    }
    return   str;
}
static void replace_rule(string& svalue)
{
    replace_str_all(svalue, "\t", "");
    replace_str_all(svalue, "\r\n", "");
    replace_str_all(svalue, "\n", "");
}

webmail_plugin::webmail_plugin()
{
    if(!init_parse_all_xml)
    {
        passwd_file file;
        string path = getenv("NPR_ROOT");
        path += "/conf/";
        file.get_file_name(path+"/config/");
        file.get_file_name(path+"/xml/");
        if (file.st.size() != 0)
        {
            list<string*>::iterator it = file.st.begin();

            for (; it!= file.st.end(); ++it)
            {
                if (*it != NULL)
                {
                    file.jiemi(**it);
                    delete *it;
                    *it = NULL;
                }
            }
            file.st.clear();
        }
        else
        {
            list<string*>::iterator it = file.st_xml.begin();

            for (; it!= file.st_xml.end(); ++it)
            {
                if (*it != NULL)
                {
                    delete *it;
                    *it = NULL;
                }
            }
            file.st_xml.clear();
        }
    }
    data_interface_type = FILESEND;
    webmail_time_out = 60;
    config_parse = NULL;
    init_webmail163();
    init_webmailsohu();
    init_identity();
    //init_webmailsina();
    init_cloud();
    init_news();
    reload();
}
webmail_plugin::~webmail_plugin()
{
    if(c_thread_static::p_redis_host!=NULL)
    {
        delete c_thread_static::p_redis_host ;
    }
    if(c_thread_static::p_redis != NULL)
    {
        delete c_thread_static::p_redis ;
    }
}
//遍历读取路径下的配置文件
void webmail_plugin::list_read_xml(string logPath , int func_type)
{
    DIR * p_dir;
    xml_parse  xml;
    p_dir = opendir(logPath.c_str());
    struct dirent *ent;
    while ((ent = readdir(p_dir)) != NULL)
    {
        string filename = ent->d_name;
        if((filename == ".") || (filename == ".."))
        {
            continue;
        }
        string str_log_file = logPath;
        str_log_file  += filename;//文件名
        struct stat logBuf;
        struct tm *pt;
        int res = stat(str_log_file.c_str(), &logBuf);//获取文件状态
        if (res != 0)
        {
            printf("error!");
            printf("%d\n",errno);
            break;
        }
        if (S_ISREG(logBuf.st_mode))//是普通文件
        {
            int mid = filename.rfind('.');
            string extrac = "";
            if(mid < filename.length())
            {
                extrac = string(filename,mid);
                if (extrac == ".xml" )//读取配置文件
                {
                    xml.set_file_path(str_log_file.c_str());
                    if(func_type == 1)
                    {
                        static_config_parse.parse(str_log_file, xml);//一般性读取配置文件
                    }
                    else if (func_type == 2)
                    {
                        static_config_parse.code_set_value_parse(str_log_file);//读取 代码集的配置文件
                    }
                }
            }
        }
        else if (S_ISDIR(logBuf.st_mode))//是文件夹
        {
            list_read_xml(str_log_file +"/",func_type);
        }
    }
    closedir(p_dir);
    return;
}


void webmail_plugin::reload()
{
    xml_parse  xml;
    string npr = getenv("NPR_ROOT");
    string path = npr;
    path +="/conf/webmail_plugin.xml";
    xml.set_file_path(path.c_str());
    char* display_value = (char*)xml.get_value("/config/display");
    display_print = display_value;

    if(b_check_config)
    {
        b_check_config = false;
        //协议识别
        path = "/config/DFI";
        int num  = xml.get_value_count(path.c_str());
        for(int i = 0 ; i < num ; i++)
        {
            string xpath = path;
            xml.assemble_path(xpath, i);
            string type_path = xpath;
            type_path +="/type";
            char * value  = (char *)xml.get_value(type_path.c_str());
            int  type = 0 ;
            if(value  != NULL)
            {
                type  = atoi(value);
            }
            type_path = xpath;
            type_path +="/config_path";
            value  = (char *)xml.get_value(type_path.c_str());
            if(value  == NULL)
            {

                continue;
            }

            list<rule_node_offist * > node_list;
            int rule_num = 600 ;

            protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), rule_num);
            list<rule_node_offist * > ::iterator iter = node_list.begin();
            for(;iter != node_list.end(); iter ++)
            {
                rule_node_offist * p = *iter ;
                public_webmail_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
            }
        }
    }
    string tmp = "";
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口 
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net") 
        {
            data_interface_type = NETSEND;
        }
    }
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        webmail_time_out = atoi(p_value);
    }
    if(!init_parse_all_xml)
    {
        //循环读取代码集配置文件，将之对应放入map表中
        p_value = (char *)xml.get_value("/config/word_code_xml_path");
        if(p_value != NULL)
        {
            string  word_code_xml_path = npr;
            word_code_xml_path += "conf/";
            word_code_xml_path += p_value;
            list_read_xml(word_code_xml_path,2);
        }

        //获取循环读取配置文件的路径，并进行循环读取
        p_value = (char *)xml.get_value("/config/config_path");
        if(p_value != NULL)
        {
            string  config_path = npr;
            config_path += "conf/";
            config_path += p_value;
            list_read_xml(config_path,1);
        }
        static_config_parse.parse(path,xml);

        passwd_file file;
        string pwd_path = npr;
        pwd_path += "/conf/";
        file.get_file_name(pwd_path+"/config/");
        file.get_file_name(pwd_path+"/xml/");
        if (file.st.size() == 0)
        {
            list<string*>::iterator it = file.st_xml.begin();
            for (; it!=file.st_xml.end(); ++it)
            {
                if (*it != NULL)
                {
                    delete *it;
                    *it = NULL;
                }
            }
            file.st_xml.clear();
        }
        else
        {
            list<string*>::iterator it = file.st_xml.begin();
            for (; it!=file.st_xml.end(); ++it)
            {
                if (*it != NULL)
                {
                    unlink((**it).c_str());
                    delete *it;
                    *it = NULL;
                }
            }
            file.st_xml.clear();
            it = file.st.begin();
            for (; it!= file.st.end(); ++it)
            {
                if (*it != NULL)
                {
                    delete *it;
                    *it = NULL;
                }
            }
            file.st.clear();
        }

        // url_map 解析
        string url_map_path = npr;
        url_map_path += "/conf/url_map.xml";
        xml.set_file_path(url_map_path.c_str());
        static_config_parse.urlparse(url_map_path);
        init_parse_all_xml = true;
    }
    config_parse = &static_config_parse;//为了解决valgrind测试出的内存泄露
    feature_rule_map = &public_webmail_feature_rule_map;


}

void webmail_plugin::init_webmail_session(webmail_session * p_webmail_session)
{
    p_webmail_session->requst_time = 0;
    p_webmail_session->response_time = 0;
    p_webmail_session->b_c2s = false;
    p_webmail_session->p_data = NULL;
    p_webmail_session->len = 0; 
    p_webmail_session -> url_map = NULL;
    p_webmail_session -> parturl_map = NULL;

    p_webmail_session->is_valid = false;
    p_webmail_session -> url2protocol_app_id_map = NULL;// 增加url到protocol_id, app_id 的对应表

    p_webmail_session -> p_mail_handle = NULL;

    p_webmail_session -> requset_length = 0;

    p_webmail_session -> response_length = 0;


    p_webmail_session ->response_length  = 0 ;

    p_webmail_session -> req_charset[0]=0x0;

    p_webmail_session -> resp_charset[0] =0x0;


    p_webmail_session -> state = url_wait;

    //   p_webmail_session -> web_parse_state = 1; 

    p_webmail_session -> tmp_len = 0;

    p_webmail_session ->b_add_end = false;
    p_webmail_session ->b_end_send = false;
    p_webmail_session -> p_parse_value = new parse_value;
    p_webmail_session -> old_file_id = 0 ;

    if(p_webmail_session ->file_content == NULL)
    {
        p_webmail_session -> file_content = new string();
    }
    *(p_webmail_session ->file_content) = "";
    p_webmail_session -> file_length = 0;
    p_webmail_session -> had_send_content = 0;
}

void  webmail_plugin::multimode_webmail_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }
    p_session->is_http = false;
    p_session->is_c2s = false;
    p_session->is_s2c = false;
    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet -> rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 80)
            {
                p_session->is_http =true;
                p_session->is_c2s = true;
                return;
            }else if(iter->second == 81)
            {
                p_session->is_http =true;
                p_session->is_s2c = true;
                return;
            }

        }
    }

    return ;
}


bool webmail_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(c_thread_static::p_redis == NULL)
    {
        redis_inint();
    }
    if(!p_packet -> b_is_tcp) 
    {
        p_session->proto_type = 2;
        return false;
    }
    p_session->proto_type = 1;
    multimode_webmail_identity(p_session, p_packet);

    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(!p_session->is_http)return false;
    // 只有端口判断是否是webmail 协议--
    //    if(ntohs(p_session ->srcport) == WEBMAILDEFINEPORT)
    if(p_session->is_s2c)
    {
        // 第一个包是 返回包 ，直接放弃 
        p_session -> b_src_is_ser  = true;
        if(config_parse->b_had_dan_response)
        {
            init_webmail_session(p_webmail_session);

            ip_potocol_identify(p_session->srcip , p_webmail_session);
            p_webmail_session->state = server_data;
            // IP 分捡
        }
        else
        {
            return false;
        }
        // 处理担心
    }   
    //else if(ntohs(p_session -> dstport) == WEBMAILDEFINEPORT)
    else if(p_session->is_c2s)
    {   
        // 判断是否是我们需要的IP    
        // init_webmail_session(p_webmail_session);
        //p_webmail_session->url_map = NULL;//为了兼容0包的情况，如果不加这两两句的话如果0包过来以后url_map以及p_webmail_session->part_url_map不为空那么其host将不会进行匹配
        //p_webmail_session->parturl_map = NULL;
        ip_potocol_identify(p_session -> dstip , p_webmail_session);
        if(p_webmail_session ->url_map == NULL  && p_webmail_session ->parturl_map == NULL)
        {
            host_potocol_identify(p_packet , p_webmail_session);
        }
        if(p_webmail_session ->url_map == NULL  && p_webmail_session ->parturl_map == NULL)
        {

            if(p_webmail_session->url_map==NULL && p_webmail_session->parturl_map==NULL)
            {
                init_webmail_session(p_webmail_session);
            }
            if(p_webmail_session ->url_map == NULL)
            {
                p_webmail_session ->url_map = config_parse->p_map_mail_uncertain;
            }

            if(p_webmail_session ->parturl_map == NULL)
            {
                p_webmail_session ->parturl_map = config_parse->p_partlist_uncertain;
            }

        }
        p_session -> b_src_is_ser = false;
    }
    if(p_webmail_session ->url_map == NULL  && p_webmail_session ->parturl_map == NULL)
    {
        return false;
    }
    else
    {
        return true;
    }
}

// host 分捡  ===
void webmail_plugin::host_potocol_identify( c_packet * p_packet,webmail_session * p_webmail_session )
{
    // 查询host 字段
    //return ;
    string shost = "";
    if(parse.host_get((char *)p_packet->p_app_data,p_packet->app_data_len,shost ))
    {
        uint32_t crc_host =crc32((unsigned char*)shost.c_str(),shost.length());
        if(display_print == "true")
        {
            cout<<endl<<"-----------------------------"<<endl
                <<"Host :"<<shost
                <<endl<<"-----------------------------"<<endl;
            cout.flush();
        }
        map<uint32_t,map_mail*>::iterator iter = config_parse->host_mail_map.find(crc_host);
        if(iter == config_parse->host_mail_map.end())
        {
            map<uint32_t,part_url_list*> ::iterator it = config_parse->host_parturl_mail_map.find(crc_host);
            if(it != config_parse->host_parturl_mail_map.end())
            {
                init_webmail_session(p_webmail_session);
                p_webmail_session ->parturl_map = it ->second;
            }
        }
        else
        {
            init_webmail_session(p_webmail_session);
            p_webmail_session ->url_map = iter ->second;

            map<uint32_t,part_url_list*> ::iterator it = config_parse->host_parturl_mail_map.find(crc_host);
            if(it !=  config_parse->host_parturl_mail_map.end())
            {
                p_webmail_session ->parturl_map = it ->second;
            }
        }

    }
}
// ip 分捡
void webmail_plugin::ip_potocol_identify(c_ip i_ip,webmail_session *p_webmail_session )
{

    map<c_ip,map_mail*>::iterator iter = config_parse->ip_mail_map.find(i_ip);
    if(iter == config_parse->ip_mail_map.end())
    {
        map<c_ip,part_url_list*> ::iterator it = config_parse->ip_parturl_mail_map.find(i_ip);
        //if(it ==  config_parse.ip_parturl_mail_map.end())
        if(it != config_parse->ip_parturl_mail_map.end())
        {
            init_webmail_session(p_webmail_session);
            p_webmail_session ->parturl_map = it ->second;
        }
    }
    else
    {
        init_webmail_session(p_webmail_session);
        p_webmail_session ->url_map = iter ->second;

        map<c_ip,part_url_list*> ::iterator it = config_parse->ip_parturl_mail_map.find(i_ip);
        if(it !=  config_parse->ip_parturl_mail_map.end())
        {
            p_webmail_session ->parturl_map = it ->second;
        }
    }
}

void webmail_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    try {
        // 判断是否是我们需要的 URL  ，URL 是我们需要的邮箱  
        webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
        string tmp = ""; 
        // fin = 1 
        //
        if(!p_packet -> b_is_tcp || p_packet -> p_tcphdr  == NULL) 
        {
            return ;
        }

        if(p_packet ->app_data_len  == 0 || p_packet ->p_app_data == NULL)
            return ;
        //  判断方向-
        if((p_session->srcport== p_packet->get_src_port() &&  p_session -> b_src_is_ser )  ||- 
                (p_session -> b_src_is_ser  == false  && p_session->dstport ==  p_packet->get_src_port() )  )
        {   
            p_webmail_session ->b_c2s = false;
        }   
        else {
            p_webmail_session ->b_c2s = true;
        }   

        if(p_packet -> p_tcphdr -> fin == 1)
        {
            if(((!p_webmail_session ->b_c2s )&&((p_session ->server.get_next_seq() == p_packet->p_tcphdr->seq)||(p_session ->server.m_b_one_packet)))
                    || ((p_webmail_session ->b_c2s )&&((p_session ->client.get_next_seq() == p_packet->p_tcphdr->seq)||(p_session ->client.m_b_one_packet))))
            {
                if(p_webmail_session ->b_add_end  )
                {
                    p_webmail_session -> b_end_send = true;
                    SET_EXPORT(p_session);
                }

                SET_SESSION_OVER(p_session);
                //return ;
            }
        }

        if(p_webmail_session -> url_map == NULL &&  p_webmail_session ->parturl_map == NULL)
        {
            SET_SESSION_OVER(p_session);
            return ;
        }

        //提取URL 
        mail_handle * p_mail_handle =(mail_handle*) p_webmail_session ->p_mail_handle;
        map_mail * p_url_map = (map_mail *)p_webmail_session->url_map;
        part_url_list * p_part_url_list =(part_url_list *)p_webmail_session->parturl_map;

        if(p_webmail_session ->b_c2s) 
        {
            switch(p_webmail_session->state) 
            {
                case server_data:
                case server_data_continue:
                    {
                        // 判断是否数据包 
                        //SET_EXPORTDATA(p_session);
                        if( parse.http_method_type((char *)p_packet->p_app_data,p_packet->app_data_len)!= OPTIONS )
                        {
                            if(p_mail_handle->r_bf_handle(p_session , p_packet))
                            {

                                SET_EXPORT(p_session);
                            }
                        }
                        return ;
                        //pococol_parse_handle(p_session);

                    }
                case url_wait: // 判断url  ，是否是我们需要的url 
                    {
                        tmp = ""; 
                        string urlparam ="";
                        if(parse.url_get((char *)p_packet->p_app_data , p_packet -> app_data_len ,tmp,urlparam))
                        {
                            if(display_print == "true")
                            {
                                cout<<endl<<"-----------------------------"<<endl
                                    <<"Url :"<<urlparam
                                    <<endl<<"-----------------------------"<<endl;
                                cout.flush();
                            }
                            // 取url 
                            if(tmp.length() == 0) 
                            {
                                SET_SESSION_OVER(p_session);
                            } 
                            if(p_url_map!= NULL)
                            {
                                map_mail::iterator iter = p_url_map->find(crc32((unsigned char *)tmp.c_str(),tmp.length()));
                                if(iter != p_url_map->end())
                                {
                                    p_webmail_session-> p_mail_handle  = (void *)(iter->second) ;
                                    mail_handle * p_mail_handle =(mail_handle*) p_webmail_session ->p_mail_handle;
                                    p_webmail_session -> state = client_data;
                                    p_webmail_session->p_parse_value -> parse_type = p_mail_handle -> parse_type ;
                                    string str_name = "requset_head_key_Url";
                                    p_webmail_session -> p_parse_value -> value_map.insert(pair<string,string>(str_name,urlparam));
                                    if(p_mail_handle->bf_handle(p_session , p_packet))
                                    {
                                        SET_EXPORT(p_session);
                                    }
                                    return ;
                                }
                            }
                            if(p_part_url_list!= NULL)
                            {
                                // 查找 
                                part_url_list::iterator it = p_part_url_list->begin();
                                for(;it!= p_part_url_list->end();it ++)
                                {
                                    // if(tmp.compare(0,it->part_url.length(),it->part_url)==0)
                                    part_url_mail* p_part_url_mail = (part_url_mail*)&(*it);
                                    if(parturl_compare(p_part_url_mail,tmp,urlparam))
                                    {
                                        p_webmail_session-> p_mail_handle  = (void *)(it->p_handle) ;
                                        mail_handle * p_mail_handle =(mail_handle*) p_webmail_session ->p_mail_handle;
                                        p_webmail_session -> state = client_data;
                                        p_webmail_session->p_parse_value -> parse_type = p_mail_handle -> parse_type ;
                                        string str_name = "requset_head_key_Url";
                                        p_webmail_session -> p_parse_value -> value_map.insert(pair<string,string>(str_name,urlparam));
                                        if(p_mail_handle->bf_handle(p_session , p_packet))
                                        {
                                            SET_EXPORT(p_session);
                                        }
                                        return ;
                                    }
                                }
                            }

                        }
                        SET_SESSION_OVER(p_session);
                    }
                    break;
                case client_data ://send_attachment_post:
                case client_data_continue: // 包未完成，需要继续发包
                    if(p_mail_handle != NULL && p_mail_handle->bf_handle !=NULL)
                    {
                        if(p_mail_handle->bf_handle(p_session , p_packet))
                        {
                            // EXPORT DATA 
                            SET_EXPORT(p_session);
                        }
                    }
                    else {
                        SET_SESSION_OVER(p_session);
                    }
                    break;

                default:
                    {
                        SET_SESSION_OVER(p_session);
                        return;
                    }
            }
        }
        else {
            switch(p_webmail_session -> state ) 
            {
                case url_wait: //直接丢取这个包  
                    break;
                case client_data: // 第一次发包  // 
                case client_data_continue: // 包未完成，需要继续发包
                    {
                        // 判断是否是继续包 ，
                        //if( parse.http_response_type((char *)p_packet->p_app_data,p_packet->app_data_len)!= HTTP_CONTINUE )
                        {
                            if(p_mail_handle != NULL && p_mail_handle->bf_handle !=NULL)
                            {
                                if(p_mail_handle->bf_handle(p_session , p_packet))
                                {
                                    // EXPORT DATA 
                                    SET_EXPORT(p_session);
                                }
                                break;// 无用包丢弃 
                            }
                        }
                        break;
                    }
                case server_data:
                case server_data_continue:
                    // 附件返回数据不会很大 ， 直接处理 
                    {
                        if(p_mail_handle->r_bf_handle != NULL&&p_mail_handle->r_bf_handle(p_session , p_packet))
                        {
                            SET_EXPORT(p_session);
                        }
                    }
                    break;
                default:
                    {
                        SET_SESSION_OVER(p_session);
                        return;
                    }
            }
            return ;
        }
    }
    catch(...)
    {

        exit(1);
    }
}

void webmail_plugin::pococol_parse_handle(session * p_session)
{
    // 按照已知的链表处理 
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    //SET_SESSION_OVER(p_session) ; 
    //return ;
    switch(p_webmail_session -> state )
    {
        case url_wait:
            break;
        case server_data_continue_last:
            p_webmail_session -> state = server_data;
        case client_data:
            {
                if(p_webmail_session->requst_time == 0)
                {
                    p_webmail_session->requst_time = p_session->packet_time;
                }
                p_parse_value->buf = p_session->client.get_tcp_data(p_parse_value->len); 
                if(p_parse_value->len == 0 ) 
                {
                    return ;
                }
                // http 解析  
                if(!parse.http_request_head_parse(p_webmail_session,p_parse_value->buf , p_parse_value->len ))
                {
                    //SET_SESSION_OVER(p_session);
                    if(!(GET == parse.m_request.HttpMothed||POST == parse.m_request.HttpMothed ))
                    {   
                        p_session->client.clear_buf();
                        p_session->server.clear_buf();
                    } 
                    return ;
                }
                p_parse_value->len = p_parse_value->len - (parse.m_request.parsepos -p_parse_value->buf);


                // 长度大于100M 丢弃
                if(p_parse_value->len > 104857600)
                {
                    if(p_webmail_session -> b_end_send)
                    {
                        p_session->p_send_buf = NO_NULL;
                        p_session->send_len = 0;
                    }
                    return;
                }

                list_handle::iterator iter = p_mail_handle->hlist.begin();
                p_webmail_session -> http_head_length = parse.m_request.parsepos -p_parse_value->buf;
                p_webmail_session -> had_send_len = p_parse_value->len;
                p_parse_value->buf = parse.m_request.parsepos;
                // 解析取值  
                for(;iter !=  p_mail_handle->hlist.end();iter ++)
                {
                    if(iter->handle == NULL) continue;
                    if(!iter->handle(p_session,p_webmail_session,&(parse.m_request),&(parse.m_response),iter ->value_list))
                    {
                        if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                        {   
                            if (p_webmail_session -> b_end_send ) 
                            {
                                p_session->client.clear_buf();
                                p_session->server.clear_buf();
                            }
                            else {
                                p_session->client.clear_next_buf();
                                p_session->server.clear_next_buf();
                            }
                        } 
                        p_session->send_len  = 0;
                        if(p_webmail_session -> b_end_send)
                        {
                            p_session->p_send_buf = NO_NULL;
                            p_session->send_len = 1;
                        }
                        return ;// 解析失败 需要继续缓存数据 
                    }
                }
                // 需要发送但是没有数据发送的
                if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                {   
                    if( p_webmail_session -> state ==  client_data_continue )
                    {
                        p_session->client.clear_next_buf();
                        p_session->server.clear_next_buf();
                    }
                    else { 
                        p_session->client.clear_buf();
                        p_session->server.clear_buf();
                    }
                } 
                // 解析完毕 ， 不是client_data_continue 状态 ,改变状态
                if(p_webmail_session-> state  != client_data_continue) 
                {
                    p_webmail_session -> state = server_data; 
                }
                // 开始组织数据，填充数据
            }
            break;
        case client_data_continue: // 包未完成，需要继续发包
            {
                p_parse_value->buf = p_session->client.get_tcp_data(p_parse_value->len); 
                list_handle::iterator iter = p_mail_handle->hlist.begin();
                // p_webmail_session -> had_send_len  +=  p_parse_value->len ;
                for(;iter !=  p_mail_handle->hlist.end();iter ++)
                {
                    if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                    {   
                        p_session->client.clear_buf();
                        p_session->server.clear_buf();
                    } 
                    if(iter->handle == NULL) continue;
                    if(!iter->handle(p_session,p_webmail_session,NULL,NULL,iter ->value_list))
                    {
                        if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                        {   
                            p_session->client.clear_buf();
                            p_session->server.clear_buf();
                        }        
                        return ;// 解析失败 需要继续缓存数据 
                    }
                }
                if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                {   
                    p_session->client.clear_buf();
                    p_session->server.clear_buf();
                } 
            }
            // 直接写导出写文件 
            break;
        case server_data:
            {
                p_parse_value->buf = p_session->server.get_tcp_data(p_parse_value->len); 
                if(p_parse_value->buf == NULL) 
                {
                    return ;
                }
                // http response head 解析  
                if(!parse.http_response_head_parse(p_webmail_session,p_parse_value->buf ,p_parse_value->len ))
                {
                    SET_SESSION_OVER(p_session);
                    return ;
                }
                p_parse_value->len = p_parse_value->len - (parse.m_response.parsepos - p_parse_value->buf);
                p_parse_value->buf = parse.m_response.parsepos;
                list_handle::iterator iter = p_mail_handle->rlist.begin();
                if(p_webmail_session->requst_time  == 0)
                {
                    p_webmail_session->requst_time = p_session->packet_time;
                }
                for(;iter !=  p_mail_handle->rlist.end();iter ++)
                {
                    // 解析取值  解析需要解析的部分 查询需要解析的值 放入 value-map中 
                    if(iter->handle == NULL) continue;
                    if(!iter->handle(p_session,p_webmail_session,&(parse.m_request),&(parse.m_response),iter->value_list))
                    {
                        /* if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                           {   
                           p_session->client.clear_buf();
                           p_session->server.clear_buf();
                           }*/ 
                        return;
                    }
                }

                if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                {
                    p_session->client.clear_buf();
                    p_session->server.clear_buf();
                }
            }
            break;
        case server_data_continue:
            {
                p_parse_value->buf = p_session->server.get_tcp_data(p_parse_value->len); 
                list_handle::iterator iter = p_mail_handle->rlist.begin();
                for(;iter !=  p_mail_handle->rlist.end();iter ++)
                {
                    // 解析取值  解析需要解析的部分 查询需要解析的值 放入 value-map中 
                    if(iter->handle == NULL) continue;
                    if(!iter->handle(p_session,p_webmail_session,NULL,NULL,iter->value_list))
                    {
                        /*    if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                              {   
                              p_session->client.clear_buf();
                              p_session->server.clear_buf();
                              }*/ 
                        return;  
                    }
                }
                if(p_session->send_len == 0 && p_session->p_send_buf  != NULL)
                {
                    p_session->client.clear_buf();
                    p_session->server.clear_buf();
                }
            }
            break;
        default:
            SET_SESSION_OVER(p_session);
            return;
    }
}

static void classify_ip_kind(string  ip_str, int& is_ipv6, int& is_ipv4)
{
    is_ipv6 = 0;
    is_ipv4 = 0;
    size_t pos = ip_str.find(".");
    if(pos == string::npos)
    {
        pos = ip_str.find(":");
        if(pos != string::npos)
        {
            is_ipv6 = 1;
            is_ipv4 = 0;
        }
    }
    else
    {
        is_ipv4 = 1;
        is_ipv6 = 0;
    }

}

//填充公共信息
static void insert_comm_msg(session* p_session, Comm_msg* p_comm)
{
    int is_ipv6 ;
    int is_ipv4 ;
    uint32_t busy_time = 0;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_session -> b_src_is_ser)
    {
        p_comm ->set_src_port(ntohs(p_session->dstport));
        p_comm ->set_dst_port(ntohs(p_session->srcport));
        p_comm ->set_dst_ip(p_session->srcip.ip_str());
        classify_ip_kind(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->dstip.ip_str());
        }
    }
    else
    {
        p_comm ->set_src_port(ntohs(p_session->srcport));
        p_comm ->set_dst_ip(p_session->dstip.ip_str());
        classify_ip_kind(p_session->dstip.ip_str(), is_ipv6, is_ipv4);
        p_comm ->set_dst_port(ntohs(p_session->dstport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->srcip.ip_str());
        }
    }
    p_comm->set_is_ipv4(is_ipv4);
    p_comm->set_is_ipv6(is_ipv6);
    p_comm->set_proto(p_session->proto_type);
    p_comm->set_line_num(p_session->mac_line_num);
    p_comm->set_dev_num(p_session->device_num);

    p_comm->set_link_layer_type(0);
    p_comm ->set_is_mpls(p_session -> m_is_mpls);
    p_comm ->set_n_label(p_session -> m_label);
    p_comm ->set_inner_label(p_session->m_inner_label);
    p_comm ->set_other_label(p_session->m_other_lable);

    //cout << "@@@@@@@@@@@@@@@@@@@@@@@@@@@device_number:"<< p_session->device_num << endl;
    p_comm ->set_time(p_webmail_session->requst_time);//截取时间
    p_comm ->set_total_pay_load_bytes(p_session->packet_len);
    p_comm ->set_tatal_pay_load_packets(p_session->packet_num);
    if(p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    p_comm ->set_duration(busy_time);

}


//提取必须项目函数
bool webmail_plugin::get_required_str_from_value_map(string& str_arg, session* p_session,webmail_session* p_webmail_session,aissue_list& list_arg)
{
    if(list_arg.size() > 0)
    {
        aissue_data(p_webmail_session, &list_arg, &str_arg);
    }
    if(str_arg.size() == 0)
    {
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        SET_SESSION_OVER(p_session);
        return false;
    }
    return true;
}

//提取可选项函数
void webmail_plugin::get_optional_str_from_value_map(string& str_arg, session* p_session,webmail_session* p_webmail_session,aissue_list& list_arg)
{
    if(list_arg.size() > 0)
    {
        aissue_data(p_webmail_session, &list_arg, &str_arg);
        if(str_arg.size() > 0)
        {
            //cout<<str_arg<<endl;
        }
        return;
    }
    return;
}

// 开发暂时使用的data_handle接口
void webmail_plugin::develop_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg = "from 标签";
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->from_aissue_access);
}

//响应体头部信息填写
void fill_s2c_head_info(webmail_session* p_webmail_session, s2c_http_head_msg& s2c, int& datalen)
{
    //debug_printf("暂时未添加响应体头部信息支持", " ");
}


//请求体头部信息填写
void fill_c2s_head_info( webmail_session* p_webmail_session, c2s_http_head_msg& c2s, int& datalen)
{
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("requset_head_key_Method");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_method(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Url");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_url(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Referer");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_referer(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Accept");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_accept(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Accept-Language");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_accept_language(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_User-Agent");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_user_agent(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Accept-Encoding");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_accept_encoding(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Host");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_host(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Cookie");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_cookie(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Accept-Charset");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_accept_charset(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Via");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_via(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Content-Length");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_content_length(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_Content-Type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_content_type(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
    iter = p_parse_value->value_map.find("requset_head_key_X_Forwarded_For");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp = iter->second;
        c2s.set_x_forwarded_for(str_tmp);
        datalen += str_tmp.size();
        str_tmp = "";
    }
}

//将解析所得的http头部信息填充到msg的具体实现
void fill_with_head_info_in_http_msg(webmail_session* p_webmail_session, st_http_msg& http, int& datalen)
{
    switch(http.direction_type())
    {
        case 0:
            {
                break;
            }
        case 1:
            {
                c2s_http_head_msg* p_c2s = http.mutable_c2s();
                fill_c2s_head_info(p_webmail_session, *p_c2s, datalen);
                break;
            }
        case 2:
            {
                s2c_http_head_msg* p_s2c = http.mutable_s2c();
                fill_s2c_head_info(p_webmail_session, *p_s2c, datalen);
                break;
            }
        case 3:
            {
                c2s_http_head_msg* p_c2s = http.mutable_c2s();
                fill_c2s_head_info(p_webmail_session, *p_c2s, datalen);
                s2c_http_head_msg* p_s2c = http.mutable_s2c();
                fill_s2c_head_info(p_webmail_session, *p_s2c, datalen);
                break;
            }
        default:
            {
                break;
            }
    }
}

//打印上行http头部信息
static void cout_c2s_http_head_msg(c2s_http_head_msg& c2s_head)
{
    string str_tmp("");
    str_tmp = c2s_head.method();
    if(str_tmp.size() != 0)
    {
        cout<<"Method"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.url();
    if(str_tmp.size() != 0)
    {
        cout<<"Url"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.host();
    if(str_tmp.size() != 0)
    {
        cout<<"Host"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.referer();
    if(str_tmp.size() != 0)
    {
        cout<<"Referer"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.accept();
    if(str_tmp.size() != 0)
    {
        cout<<"Accept"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.accept_language();
    if(str_tmp.size() != 0)
    {
        cout<<"Accept-Language"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.user_agent();
    if(str_tmp.size() != 0)
    {
        cout<<"User-Agent"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.accept_encoding();
    if(str_tmp.size() != 0)
    {
        cout<<"Accept-Encoding"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.cookie();
    if(str_tmp.size() != 0)
    {
        cout<<"Cookie"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.accept_charset();
    if(str_tmp.size() != 0)
    {
        cout<<"Accept-Charset"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.via();
    if(str_tmp.size() != 0)
    {
        cout<<"Via"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.content_length();
    if(str_tmp.size() != 0)
    {
        cout<<"Content-Type"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.x_forwarded_for();
    if(str_tmp.size() != 0)
    {
        cout<<"X-Forwarded-For"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = c2s_head.content_length();
    if(str_tmp.size() != 0)
    {
        cout<<"Content-Length"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
}

//打印下行http头部信息
static void cout_s2c_http_head_msg(s2c_http_head_msg& s2c_head)
{
}

// 打印公共信息
static void cout_comm_msg(Comm_msg& comm_msg)
{
    string str_tmp ("");
    str_tmp = comm_msg.src_ip();
    if(str_tmp.size() != 0)
    {
        cout<<"数据包源地址"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    str_tmp = comm_msg.dst_ip();
    if(str_tmp.size() != 0)
    {
        cout<<"数据包目的地址"<<": "<<str_tmp<<endl;
        str_tmp = "";
    }
    int int_tmp = comm_msg.src_port();
    cout<<"数据包源端口"<<": "<<int_tmp<<endl;
    int_tmp = comm_msg.dst_port();
    cout<<"数据包目的端口"<<": "<<int_tmp<<endl;
}

static void cout_st_http_msg(st_http_msg& http)
{
    Comm_msg* p_comm = http.mutable_common();
    // 打印公共信息和http头部信息
    cout_comm_msg(*p_comm);
    int direction_type = http.direction_type();
    switch(direction_type)
    {
        case 0:
            {
                break;
            }
        case 1:
            {
                c2s_http_head_msg c2s_head = http.c2s();
                cout_c2s_http_head_msg(c2s_head);
                break;
            }
        case 2:
            {
                s2c_http_head_msg s2c_head = http.s2c();
                cout_s2c_http_head_msg(s2c_head);
                break;
            }
        case 3:
            {
                c2s_http_head_msg c2s_head = http.c2s();
                s2c_http_head_msg s2c_head = http.s2c();
                cout_c2s_http_head_msg(c2s_head);
                cout_s2c_http_head_msg(s2c_head);
                break;
            }
        default:
            {
                break;
            }
    }
}

static void cout_search_msg(search_msg& search)
{
    st_http_msg* st_http = search.mutable_st_http();
    cout_st_http_msg(*st_http);
    cout<<"搜索类消息"<<endl;
    string str_tmp = search.engine_type();
    if(str_tmp.size() != 0)
    {
        cout<<"协议代码:"<<str_tmp<<endl;
    }
    str_tmp = search.keyword();
    if(str_tmp.size() != 0)
    {
        cout<<"搜索关键字:"<<str_tmp<<endl;
    }
    str_tmp = search.board();
    if(str_tmp.size() != 0)
    {
        cout<<"搜索版块: "<<str_tmp<<endl;
    }
    str_tmp = search.uid();
    if(str_tmp.size() != 0)
    {
        cout<<"用于标识、区分的id:"<<str_tmp<<endl;
    }
    str_tmp = search.board_name();
    if(str_tmp.size() != 0)
    {
        cout<<"板块名称:"<<str_tmp<<endl;
    }
    cout<<"---------------------分界线-----------------"<<endl;
}

bool del_double_chr(char *p_str,char *p_dst)
{
    char *p_tmp;
    char *p_begin = strchr(p_str,'\"');
    if(p_begin == NULL)
        return false;
    char *p_end = strchr(p_begin+1,'\"');
    if(p_end == NULL)
        return false;
    memcpy(p_dst,p_begin+1,p_end-p_begin-1);
    return true;
}

void   webmail_plugin::potocol_data_handle(session* p_session,list<data_interface> * p_list)
{
    if(p_session->send_len == 0 && p_session->p_send_buf == NULL)
        return ;
    if(data_interface_type  == FILESEND) 
    {
        webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
        if(p_session->send_len  > 20971520) 
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            clear_webmail_session(p_webmail_session);
            return ;
        }
        // 接口 
        parse_value * p_parse_value = p_webmail_session ->p_parse_value;

        data_interface m_data ;
        m_data.b_out_type = FILESEND;
        if(p_parse_value -> parse_type==ATTACHMENT || p_parse_value -> parse_type==QQ_FILE)
        {
            // 直接写文件  // 零时 方案 
            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
            //p_session->p_send_buf[p_session->send_len] = 0x0;
            // p_parse_value->file_data =  p_session->p_send_buf;
            uint32_t access_id = 0;
            string  assess_name = "";
            string value = "";
            if(true) 
            {
                //附件ID  计算 crc32 
                if(p_mail_handle->access_id_aissue.size() > 0)
                {
                    //aissue_data(p_webmail_session,&(p_mail_handle->access_id_aissue),&value);
                    aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                    //附件ID  计算 crc32 
                    list<string>::iterator iter = access_list.begin();

                    for(;iter != access_list.end();iter ++)
                    {
                        access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                        access_id_list.push_back(access_id);
                    }
                }
                // access name 
                if(p_mail_handle->access_name_aissue.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->access_name_aissue),&assess_name);
                }
                if(assess_name.length() == 0)
                    assess_name = "file.dat";
                //if(assess_name.length() !=0 ) 
                {
                    // 文件名未取到

                    //string requst_time;
                    //DNUMTOSTR(p_dns_session->requst_time, requst_time);
                    w_file_str * file_str = new w_file_str;

                    // access name 
                    if(p_parse_value->file_path.length() == 0) 
                    {
                        string requst_time_str;
                        DNUMTOSTR(p_webmail_session->requst_time, requst_time_str);
                        file_str->file_path = "/";
                        file_str -> file_path += get_year_month();
                        file_str-> file_path += get_day_hour();
                        file_str-> file_path += get_min_sec();

                        DNUMTOSTR(access_id,file_str-> file_name);
                        file_str-> file_name += "_";
                        file_str-> file_name  += requst_time_str;
                        file_str-> file_name += "_";
                        file_str-> file_name += assess_name;
                        file_str-> file_name += ".wmatt";
                        p_parse_value -> file_path = file_str->file_path;
                        p_parse_value ->file_name = file_str->file_name;
                    }
                    else {

                        file_str->file_path = p_parse_value ->file_path ;
                        file_str->file_name = p_parse_value ->file_name ;

                    }
                    //begin_time = u64_time;
                    //开始写文件 
                    if(p_session->send_len ==1 &&p_session->p_send_buf[0] == 0x0)
                    {
                        file_str->file_data =NULL;
                        file_str->datalen = 0;
                    }
                    else {
                        char * access_file_data = new char[p_session->send_len+1];
                        if(access_file_data == NULL)
                            return;

                        memcpy(access_file_data ,p_session->p_send_buf,p_session->send_len );
                        file_str->file_data = access_file_data;
                        file_str->datalen = p_session->send_len;
                    }

                    if(p_webmail_session-> b_end_send == true)
                    {
                        p_parse_value->file_path = "";
                        file_str->finished = true;
                        p_webmail_session ->b_add_end = false;
                    }
                    else  {

                        file_str->finished = false;
                    }

                    m_data.data = file_str;
                    p_list -> push_back(m_data);
                }
                p_session->send_len = 0;
                p_session->p_send_buf = NULL;
                p_session->client.clear_buf();
                p_session->server.clear_buf();
                access_id_list.clear();
                access_list.clear();
                if(p_webmail_session-> b_end_send)
                {
                    p_webmail_session -> state = url_wait;
                    clear_webmail_session(p_webmail_session);
                }
                return ;

                // 清理 
            }
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            access_id_list.clear();
            access_list.clear();

            //m_data.data = p_parse_value->file_str;
            //p_list -> push_back(m_data);
        }
        else if(p_webmail_session->p_parse_value -> parse_type == MESS_BODY)
        {
            string requst_time_str = date_time3(p_webmail_session->requst_time); 
            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
            // 组织需要的数据

            // 会话结束   初始化 webmail_session
            string value = "";
            access_id = 0;
            access_name = "";
            title = "";
            body = "";

            if(p_mail_handle->access_id_aissue.size() > 0)
            {
                //aissue_data(p_webmail_session,&(p_mail_handle->access_id_aissue),&value);
                aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                //附件ID  计算 crc32 
                list<string>::iterator iter = access_list.begin();

                for(;iter != access_list.end();iter ++)
                {
                    access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                    access_id_list.push_back(access_id);
                }
            }

            // title_aissue_access 
            if(p_mail_handle->title_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->title_aissue_access),&title);
            }
            // body_aissue_access
            if(p_mail_handle->body_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->body_aissue_access),&body);
            }

            if(!body.empty())
            {
                char * buffer = new char[body.length()];
                if(buffer != NULL)
                {
                    int len = 0;
                    html_to_txt(buffer, len, body.c_str(), body.length());
                    body.clear();
                    //body.assign(buffer, buffer+len);
                    body = string(buffer, 0, len);
                    if(buffer != NULL)
                    {
                        delete [] buffer;
                    }
                    buffer = NULL;
                }
            }

            // from_aissue_access
            mail_from = "";
            if(p_mail_handle->from_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&mail_from);
            }
            if(!mail_from.empty())
            {
                //format_account(mail_from);
            }
            //to_aissue_access 
            mail_to = "";
            if(p_mail_handle->to_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->to_aissue_access),&mail_to);
            }
            if(!mail_to.empty())
            {
                //format_account(mail_to);
            }
            //cc_aissue_access 
            mail_cc = "";
            if(p_mail_handle->cc_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->cc_aissue_access),&mail_cc);
            }
            if(!mail_cc.empty())
            {
                //format_account(mail_cc);
            }
            //bcc_aissue_access 
            mail_bcc = "";
            if(p_mail_handle->bcc_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
            }
            if(!mail_bcc.empty())
            {
                //format_account(mail_bcc);
            }

            //
            // 开始写文件 或者发送结束  // 
            string requst_time;
            DNUMTOSTR(p_session->last_packet_time, requst_time);
            w_file_str * file_str = new w_file_str;

            // access name 
            file_str->file_path = "/";
            file_str -> file_path += get_year_month();
            file_str-> file_path += get_day_hour();
            file_str-> file_path += get_min_sec();

            //DNUMTOSTR(file_str-> file_name, access_id);
            file_str ->file_name += requst_time_str;
            file_str-> file_name += ".wm";
            //begin_time = u64_time;
            //开始写文件 
            // 文件 内容  
            p_parse_value->file_data = "[webmail]\n";
            p_parse_value->file_data +=requst_time;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="sendtime:";
            p_parse_value->file_data +=requst_time_str;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="from:";
            p_parse_value->file_data +=mail_from;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="to:";
            p_parse_value->file_data +=mail_to;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="cc:";
            p_parse_value->file_data +=mail_cc;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="bcc:";
            p_parse_value->file_data +=mail_bcc;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="subject:";
            p_parse_value->file_data +=title;
            p_parse_value->file_data +="\n";
            p_parse_value->file_data +="content:";
            p_parse_value->file_data +=body;
            p_parse_value->file_data +="\n";

            list<uint32_t>::iterator it = access_id_list.begin();
            if(it != access_id_list.end() )
            {
                p_parse_value->file_data +="attachment:";
                string tmp = "";
                for (;it != access_id_list.end() ; it++) 
                {
                    tmp = "";
                    if(it != access_id_list.begin())
                    {
                        p_parse_value->file_data+="|";
                    }

                    DNUMTOSTR(*it, tmp);
                    p_parse_value->file_data += tmp;
                }

                p_parse_value->file_data +="\n";
            }

            //
            char * access_file_data = new char[p_parse_value->file_data.length()+1];
            if(access_file_data == NULL)
                return;

            memcpy(access_file_data ,p_parse_value->file_data.c_str(),p_parse_value->file_data.length() );

            file_str->file_data = access_file_data;
            file_str->datalen = p_parse_value->file_data.length();
            file_str->finished = true;
            m_data.data = file_str;
            p_list -> push_back(m_data);
            p_parse_value->file_data = "";
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            clear_webmail_session(p_webmail_session);
            access_id_list.clear();
            access_list.clear();
            p_webmail_session -> state = url_wait;
        }
    }
    else if (data_interface_type == NETSEND)
    {
        webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
        if(p_webmail_session == NULL)
            return;

        if(p_session->send_len  > 20971520) 
        {
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            clear_webmail_session(p_webmail_session);
            return ;
        }

        mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;

        // 接口 
        parse_value * p_parse_value = p_webmail_session ->p_parse_value;
        if(p_parse_value == NULL)
            return;

        data_interface m_data;

        if(p_parse_value -> parse_type == CLOUD)   // 带附件
        {
            //if(p_webmail_session->b_end_send)
            {
                net_str * p_net = new net_str;
                p_net -> msg = new CAmsg;
                p_net->msg->Clear();
                // 设置 
                p_net->msg->set_type(6); // 文件类型

                p_net->msg->set_is_file(15);

                file_msg *p_file = p_net->msg->mutable_file();//发送两种类型数据，一种是file类型
                http_cloud_msg* p_cloud = p_net->msg->mutable_http_cloud();//一种是云盘类型
                Comm_msg* p_comm =  p_cloud -> mutable_comm_msg();
                // 公共 消息 
                if(p_session -> b_src_is_ser)
                {
                    p_comm ->set_src_port(ntohs(p_session->dstport));
                    p_comm ->set_dst_ip(p_session->srcip.ip_str());
                    p_comm ->set_dst_port(ntohs(p_session->srcport));
                    if(p_session->b_vpn)        //VPN消息
                    {
                        p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                        p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                        p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                    }
                    else
                    {
                        p_comm ->set_src_ip(p_session->dstip.ip_str());
                    }
                }
                else
                {
                    p_comm ->set_src_port(ntohs(p_session->srcport));
                    p_comm ->set_dst_ip(p_session->dstip.ip_str());
                    p_comm ->set_dst_port(ntohs(p_session->dstport));
                    if(p_session->b_vpn)        //VPN消息
                    {
                        p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                        p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                        p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                    }
                    else
                    {
                        p_comm ->set_src_ip(p_session->srcip.ip_str());
                    }
                }
                p_comm ->set_time(p_webmail_session->requst_time);

                Comm_msg* p_comm1 =  p_file -> mutable_comm_msg();
                // 公共 消息 
                if(p_session -> b_src_is_ser)
                {
                    p_comm1 ->set_src_port(ntohs(p_session->dstport));
                    p_comm1 ->set_dst_ip(p_session->srcip.ip_str());
                    p_comm1 ->set_dst_port(ntohs(p_session->srcport));
                    if(p_session->b_vpn)        //VPN消息
                    {
                        p_comm1 ->set_vpn_src_ip(p_session->dstip.ip_str());
                        p_comm1 ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                        p_comm1 ->set_src_ip(p_session->vpn_dstip.ip_str());
                    }
                    else
                    {
                        p_comm1 ->set_src_ip(p_session->dstip.ip_str());
                    }
                }
                else
                {
                    p_comm1 ->set_src_port(ntohs(p_session->srcport));
                    p_comm1 ->set_dst_ip(p_session->dstip.ip_str());
                    p_comm1 ->set_dst_port(ntohs(p_session->dstport));
                    if(p_session->b_vpn)        //VPN消息
                    {
                        p_comm1 ->set_vpn_src_ip(p_session->srcip.ip_str());
                        p_comm1 ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                        p_comm1 ->set_src_ip(p_session->vpn_srcip.ip_str());
                    }
                    else
                    {
                        p_comm1 ->set_src_ip(p_session->srcip.ip_str());
                    }
                }
                p_comm1 ->set_time(p_webmail_session->requst_time);

                /* p_attach_info -> p_protocal -> PotocolStatistics(6,1,0,1);
                   p_attach_info -> p_protocal -> PotocolStatistics(15,1,0,1);*/

                mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
                uint32_t access_id = 0;
                uint32_t uint_file_crc_ids;
                string str_offise = "";
                string str_file_crc_ids = "";
                string assess_name = "";
                string     str_md5 = "";
                string str_user_id = "";
                string       value = "";
                string  str_app_id = "";
                string str_is_upload= "";
                //附件ID  计算 crc32 
                if(p_mail_handle->access_id_aissue.size() > 0)
                {
                    aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                    //附件ID  计算 crc32 
                    list<string>::iterator iter = access_list.begin();
                    for(;iter != access_list.end();iter ++)
                    {
                        access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                        access_id_list.push_back(access_id);
                    }
                }
                // access name 
                if(p_mail_handle->access_name_aissue.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->access_name_aissue),&assess_name);
                }
                if(assess_name.size() == 0)
                {
                    delete p_net->msg;
                    delete p_net;
                    p_net->msg = NULL;
                    p_net = NULL;
                    SET_SESSION_OVER(p_session);
                    return;
                }
                if(assess_name.length() != 0)
                {
                    if(p_webmail_session-> b_end_send == true)
                    {
                        p_webmail_session ->b_add_end = false;
                    }
                }

                if(! strcmp("name", assess_name.c_str()))
                {
                    string str_requst_time;
                    DNUMTOSTR(p_webmail_session -> requst_time, str_requst_time);
                    string file_name = "cloud_" ;
                    string src_ip = p_session->srcip.ip_str();
                    file_name += src_ip;
                    file_name += '_';
                    string dst_ip = p_session->dstip.ip_str();
                    file_name = file_name + dst_ip;
                    file_name += '_';
                    file_name += str_requst_time;
                    file_name += '_';
                    assess_name.assign(file_name);
                }
                //to_aissue_access str_md5
                if(p_mail_handle->to_aissue_access.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->to_aissue_access),&str_md5);
                }
                // from_aissue_access str_user_id
                if(p_mail_handle->from_aissue_access.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&str_user_id);
                }
                //cc_aissue_access str_app_id
                if(p_mail_handle->cc_aissue_access.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->cc_aissue_access),&str_app_id);
                }
                //bcc_aissue_access str_is_upload
                if(p_mail_handle->bcc_aissue_access.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&str_is_upload);
                }
                //body_aissue_access str_offise
                if(p_mail_handle->body_aissue_access.size() > 0)
                {
                    aissue_data(p_webmail_session,&(p_mail_handle ->body_aissue_access),&str_offise);
                }
                // 文件名
                p_cloud -> set_filename(assess_name);
                //文件md5
                //p_cloud -> set_md5(str_md5);
                p_file->set_file_id(p_webmail_session->requst_time);//文件id是截包时间
                p_file->set_file_name(assess_name);
                //当是多端口传输时，如果该流内的文件内容提取完毕(即b_end_send == true)，先将状态置为false，调用p_file_set_b_end，在将状态设置为true,以执行缓存区的清理以及状态修改。
                if(str_offise != "4294967295" && p_webmail_session -> b_end_send  && str_app_id == "1")
                {
                    p_webmail_session -> b_end_send = false;
                    p_file->set_b_end(p_webmail_session->b_end_send);
                    p_webmail_session -> b_end_send = true;//为了执行b_end_send为true 相应的缓存去清理以及状态改变。
                    string :: size_type str_pos = str_offise.size();
                    //对上传而言,offise的倒数第6位即相应整形数据的十万分位当没传完时是0，传完了将其设置为为1。
                    if(str_is_upload == "1")
                    {
                        str_offise[str_pos - 6] = '1';
                    }
                }
                //当不是多端口传输时，应该是什么状态，就是什么状态。
                if((str_offise == "4294967295" && str_app_id == "1") || str_app_id != "1")
                {
                    p_file->set_b_end(p_webmail_session->b_end_send);
                }
                if(p_webmail_session->b_end_send)
                {
                    p_attach_info -> p_protocal -> PotocolStatistics(6,1,0,1);
                    p_attach_info -> p_protocal -> PotocolStatistics(15,1,0,1);
                }
                if(str_app_id == "1")
                {
                    p_file -> set_offise((uint32_t)(cl_function::to_int(str_offise.c_str()) + p_webmail_session -> had_send_content));
                }
                //针对百度get模式下载的，多端口传输的，记录每次发送内容的长度，作为数据的绝对偏移地址（数据起始位置。）
                if(str_offise  != "4294967295" && str_is_upload == "0" && str_app_id == "1")
                {
                    p_webmail_session -> had_send_content += p_session -> send_len;
                    p_file -> set_offise_type(1);//绝对偏移地址。
                }
                //针对百度post模式上传的，多端口传输的，记录每次发送内容的长度，作为数据的偏移标识（非真实数据起始位置。）
                if(str_offise  != "4294967295" && str_is_upload == "1" && str_app_id == "1")
                {
                    p_webmail_session -> had_send_content += p_session -> send_len;
                    p_file -> set_offise_type(2);//非绝对偏移地址。
                }

                //针对百度多端口传输，发送文件总长，作为文件结束依据
                if(str_offise  != "4294967295" && str_app_id == "1")
                {
                    //title_aissue_access 分多端口传文件总长度。
                    string str_content_length ;
                    if(p_mail_handle->title_aissue_access.size() > 0)
                    {
                        aissue_data(p_webmail_session,&(p_mail_handle ->title_aissue_access),&str_content_length);
                    }
                    p_file->set_file_length(cl_function :: to_int(str_content_length.c_str()));
                }



                if(str_is_upload.size() == 1)
                {
                    uint32_t is_upload_int = cl_function :: to_int(str_is_upload.c_str());
                    p_cloud -> set_is_upload(is_upload_int);
                }
                //str_app_id --> app_id_
                uint32_t app_id_cloud = cl_function :: to_int(str_app_id.c_str());
                p_cloud -> set_app_id(app_id_cloud);
                //用户ID
                if(app_id_cloud == 1 && str_user_id.size() != 0)
                {
                    string :: size_type pos = str_user_id.find(";");
                    if(pos != string :: npos)
                    {
                        str_user_id.replace(pos, 1, "");
                    }
                }
                p_cloud -> set_username(str_user_id);
                //offise
                //   p_cloud -> set_offise((uint32_t)cl_function::to_int(str_offise.c_str()));


                //file_crc_ids
                if("1" == str_is_upload && str_app_id == "1")
                {
                    str_file_crc_ids.assign(assess_name);
                    str_file_crc_ids += p_session->srcip.ip_str();
                    uint_file_crc_ids = crc32((unsigned char *)str_file_crc_ids.c_str(),str_file_crc_ids.size());
                }
                else if("0" == str_is_upload && str_app_id == "1")
                {
                    str_file_crc_ids.assign(assess_name);
                    str_file_crc_ids += p_session->dstip.ip_str();
                    uint_file_crc_ids = crc32((unsigned char *)str_file_crc_ids.c_str(),str_file_crc_ids.size());
                }
                if(str_offise  != "4294967295" && str_app_id == "1")
                {
                    p_file->set_file_id(uint_file_crc_ids);//文件id是截包时间
                }
                //p_cloud -> set_file_crc_ids(uint_file_crc_ids);
                // 文件结束标识
                //p_cloud->set_b_end(p_webmail_session->b_end_send);
                //p_cloud->set_b_end(true);
                //SET_SESSION_OVER(p_session);
                // 文件数据内容
                if(p_session->p_send_buf != NULL ) 
                {
                    if(p_session->p_send_buf != NO_NULL  && p_session->send_len != 1)
                        p_file->set_data(p_session->p_send_buf, p_session->send_len);
                    else
                        p_file->set_data(p_session->p_send_buf, 0);
                }
                /*if(p_session->p_send_buf != NULL ) 
                  {
                  if(p_session->p_send_buf != NO_NULL  && p_session->send_len != 1)
                  {
                  string tmp;
                  tmp.insert(tmp.end(), p_session->p_send_buf, p_session->p_send_buf+p_session->send_len);
                 *(p_webmail_session->file_content) += tmp;
                 p_webmail_session->file_length += p_session->send_len;
                 }
                 }*/
                // 接口 
                p_net ->datalen  = 20 + p_session->send_len;
                m_data.b_out_type = NETSEND;
                m_data.data = p_net;
                p_list -> push_back(m_data);
            }
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            if(p_webmail_session-> b_end_send)
            {
                access_id_list.clear();
                access_list.clear();
                p_webmail_session -> state = url_wait;
                p_session->client.clear_buf();
                p_session->server.clear_buf();
                clear_webmail_session(p_webmail_session);
            }
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
        }
        /*if (p_parse_value -> parse_type == MOVIECORE)
          {
          uint32_t num_len = p_session->client.get_data_len();
          char *p_begin = p_session->client.get_tcp_data(num_len);
          }*/

        if(p_parse_value -> parse_type == IDENTITY) 
        {
            webmail_identity( p_session,p_list);
        }
        if(p_parse_value -> parse_type == ATTACHMENT)
        {
            net_str * p_net = new net_str;
            p_net -> msg = new CAmsg;
            p_net->msg->Clear();
            // 设置 
            p_net->msg->set_type(6); // 文件

            file_msg* p_file = p_net->msg->mutable_file();
            Comm_msg* p_comm =  p_file -> mutable_comm_msg();
            // 公共 消息 
            if(p_session -> b_src_is_ser)
            {
                p_comm ->set_src_port(ntohs(p_session->dstport));
                p_comm ->set_dst_ip(p_session->srcip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
            }
            else
            {
                p_comm ->set_src_port(ntohs(p_session->srcport));
                p_comm ->set_dst_ip(p_session->dstip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
            }
            p_comm ->set_time(p_webmail_session->requst_time);

            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;

            uint32_t access_id = 0;
            string  assess_name = "";
            string value = "";
            //附件ID  计算 crc32 
            if(p_mail_handle->access_id_aissue.size() > 0)
            {
                aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                //附件ID  计算 crc32 
                list<string>::iterator iter = access_list.begin();

                for(;iter != access_list.end();iter ++)
                {
                    access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                    access_id_list.push_back(access_id);
                }
            }

            // access name 
            if(p_mail_handle->access_name_aissue.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->access_name_aissue),&assess_name);
            }

            if(assess_name.length() != 0)
            {
                if(p_webmail_session-> b_end_send == true)
                {
                    p_webmail_session ->b_add_end = false;
                }
            }

            // 文件唯一标识，标识某个文件，用于组文件 
            p_file->set_file_id(p_webmail_session->requst_time);

            p_attach_info -> p_protocal -> PotocolStatistics(6,1,0,1);
            // 首先判断文件名是由几段组成的
            int x;
            string result = "";
            x = assess_name.find("?=",2);
            if(x !=assess_name.length()-2 && x!= string::npos)
            {
                string mid_access_name(assess_name,0,x+2);
                result = convertname(mid_access_name);
                string othername(assess_name,x+3,assess_name.size());
                result += convertname(othername);
                p_file->set_file_name(result);//发送文件名
            }
            else
            {
                p_file->set_file_name(convertname( assess_name));//发送文件名
            }

            // 附件唯一标识 
            p_file->set_file_crc_id(access_id);
            // 文件结束标识
            p_file->set_b_end(p_webmail_session->b_end_send);
            if(p_webmail_session -> b_end_send ) 
            {
                SET_SESSION_OVER(p_session);
            }
            // 文件数据内容
            if(p_session->p_send_buf != NULL ) 
            {
                if(p_session->p_send_buf != NO_NULL  && p_session->send_len != 1)
                    p_file->set_data(p_session->p_send_buf, p_session->send_len);
                else
                    p_file->set_data(p_session->p_send_buf, 0);
            }
            // 接口 
            p_net ->datalen  = 20 + p_session->send_len ;
            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            p_list -> push_back(m_data);

            //p_session->client.clear_buf();
            //p_session->server.clear_buf();
            p_session->client.clear_next_buf();
            p_session->server.clear_next_buf();
            if(p_webmail_session-> b_end_send)
            {
                p_session->client.clear_buf();
                p_session->server.clear_buf();
                access_id_list.clear();
                access_list.clear();
                p_webmail_session -> state = url_wait;
                clear_webmail_session(p_webmail_session);
            }
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            return ;
            //p_session->client.clear_buf();
            //p_session->server.clear_buf();
        }
        else if(p_parse_value -> parse_type == QQ_FILE)
        {
            if(p_session->send_len == 0)
            {
                if(p_webmail_session-> b_end_send)
                {
                    access_id_list.clear();
                    access_list.clear();
                    p_webmail_session -> state = url_wait;
                    clear_webmail_session(p_webmail_session);
                }
                p_session->p_send_buf = NULL;
                p_session->client.clear_buf();
                p_session->server.clear_buf();
                return;
            }

            net_str * p_net = new net_str;
            p_net -> msg = new CAmsg;
            p_net->msg->Clear();
            // 设置 
            p_net->msg->set_type(7); // qq http 发送离线文件

            qq_file_msg* p_qq_file = p_net->msg->mutable_qq_file();
            Comm_msg* p_comm =  p_qq_file -> mutable_comm_msg();
            // 公共 消息 
            string  assess_name = "";
            if(p_session -> b_src_is_ser)
            {
                assess_name = p_session->srcip.ip_str();
                p_comm ->set_src_port(ntohs(p_session->dstport));
                p_comm ->set_dst_ip(p_session->srcip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
            }
            else
            {
                assess_name = p_session->dstip.ip_str();
                p_comm ->set_src_port(ntohs(p_session->srcport));
                p_comm ->set_dst_ip(p_session->dstip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
            }
            //处理文件名将.替换成
            size_t strsize=0;
            for(;strsize < assess_name.size(); strsize++)
            {
                if (assess_name[strsize] =='.')
                {
                    assess_name[strsize] = '_';
                }
            }

            p_comm ->set_time(p_webmail_session->requst_time);

            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;

            uint32_t access_id = 0;
            string value = "";
            //附件ID  计算 crc32 
            if(p_mail_handle->access_id_aissue.size() > 0)
            {
                aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                //附件ID  计算 crc32 
                list<string>::iterator iter = access_list.begin();

                for(;iter != access_list.end();iter ++)
                {
                    access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                    access_id_list.push_back(access_id);
                }
            }

            // access name 
            // 文件唯一标识，标识某个文件，用于组文件 
            if(p_webmail_session->old_file_id == 0)
            {
                p_webmail_session->old_file_id = p_webmail_session->requst_time ;
                string tmp;
                DNUMTOSTR(p_webmail_session->old_file_id, tmp);
                assess_name += "_";
                assess_name += tmp;
            }
            else
            {
                if(p_webmail_session->requst_time != p_webmail_session->old_file_id)
                {
                    net_str * p_net2 = new net_str;
                    p_net2 -> msg = new CAmsg;
                    p_net2->msg->Clear();
                    // 设置 
                    p_net2->msg->set_type(7); // qq http 发送离线文件

                    qq_file_msg* p_qq_file2 = p_net2->msg->mutable_qq_file();
                    Comm_msg* p_comm2 =  p_qq_file2 -> mutable_comm_msg();
                    // 公共 消息 
                    if(p_session -> b_src_is_ser)
                    {
                        p_comm2 ->set_src_port(ntohs(p_session->dstport));
                        p_comm2 ->set_dst_ip(p_session->srcip.ip_str());
                        p_comm2 ->set_dst_port(ntohs(p_session->srcport));
                        if(p_session->b_vpn)        //VPN消息
                        {
                            p_comm2 ->set_vpn_src_ip(p_session->dstip.ip_str());
                            p_comm2 ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                            p_comm2 ->set_src_ip(p_session->vpn_dstip.ip_str());
                        }
                        else
                        {
                            p_comm2 ->set_src_ip(p_session->dstip.ip_str());
                        }
                    }
                    else
                    {
                        p_comm2 ->set_src_ip(p_session->srcip.ip_str());
                        p_comm2 ->set_src_port(ntohs(p_session->srcport));
                        p_comm2 ->set_dst_ip(p_session->dstip.ip_str());
                        p_comm2 ->set_dst_port(ntohs(p_session->dstport));
                        if(p_session->b_vpn)        //VPN消息
                        {
                            p_comm2 ->set_vpn_src_ip(p_session->srcip.ip_str());
                            p_comm2 ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                            p_comm2 ->set_src_ip(p_session->vpn_srcip.ip_str());
                        }
                        else
                        {
                            p_comm2 ->set_src_ip(p_session->srcip.ip_str());
                        }
                    }
                    p_comm2 ->set_time(p_webmail_session->requst_time);

                    p_qq_file2->set_file_id(p_webmail_session->old_file_id);
                    // 发送文件结束标记 
                    string tmp;
                    DNUMTOSTR(p_webmail_session->old_file_id, tmp);
                    assess_name += "_";
                    assess_name += tmp;
                    p_qq_file2->set_file_name(assess_name);

                    // 文件结束标识
                    p_qq_file2->set_b_end(true);

                    // 数据来源类型：1 http，2 tcp，3 udp
                    p_qq_file2->set_send_type(1);

                    // 文件数据内容
                    p_qq_file2->set_data(NO_NULL, 0);

                    p_attach_info -> p_protocal -> PotocolStatistics(7,1,0,1);
                    //p_qq_file->set_data(p_session->p_send_buf, 0);
                    // 接口 
                    p_net2 ->datalen  = 20 + p_session->send_len ;
                    m_data.b_out_type = NETSEND;
                    m_data.data = p_net2;
                    p_list -> push_back(m_data);
                }
                else
                {
                    string tmp;
                    DNUMTOSTR(p_webmail_session->old_file_id, tmp);
                    assess_name += "_";
                    assess_name += tmp;
                }
                p_webmail_session->old_file_id = p_webmail_session->requst_time ;
            }
            p_qq_file->set_file_id(p_webmail_session->requst_time);
            // 文件名
            p_qq_file->set_file_name(assess_name);
            // p_attach_info -> p_protocal -> PotocolStatistics(7,1,0,1);

            // 文件结束标识
            p_qq_file->set_b_end(p_webmail_session->b_end_send);
            if(p_webmail_session->b_end_send)
            {
                p_attach_info -> p_protocal -> PotocolStatistics(7,1,0,1);
                SET_SESSION_OVER(p_session );
            }

            // 数据来源类型：1 http，2 tcp，3 udp
            p_qq_file->set_send_type(1);

            // 文件数据内容
            if(p_session->p_send_buf != NULL )
            {
                // 发送长度不为0的文件内容
                if(p_session->p_send_buf != NO_NULL  && p_session->send_len != 1)
                {
                    p_qq_file->set_data(p_session->p_send_buf, p_session->send_len);
                }
                // 发送文件结束标记
                else if(p_session->p_send_buf == NO_NULL  && p_session->send_len == 1)
                {
                    p_qq_file->set_data(p_session->p_send_buf, 0 );
                }
                // 异常内容返回
                else
                {
                    delete p_net -> msg;
                    delete p_net;
                    if(p_webmail_session-> b_end_send)
                    {
                        access_id_list.clear();
                        access_list.clear();
                        p_webmail_session -> state = url_wait;
                        clear_webmail_session(p_webmail_session);
                    }
                    p_session->send_len = 0;
                    p_session->p_send_buf = NULL;
                    p_session->client.clear_buf();
                    p_session->server.clear_buf();
                    return;
                }
            }

            // 接口 
            p_net ->datalen  = 20 + p_session->send_len ;
            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            p_list -> push_back(m_data);

            if(p_webmail_session-> b_end_send)
            {
                access_id_list.clear();
                access_list.clear();
                p_webmail_session -> state = url_wait;
                clear_webmail_session(p_webmail_session);
            }
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
        }
        else if(p_webmail_session->p_parse_value -> parse_type == MESS_BODY)
        {
            //
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            access_id_list.clear();
            p_net->msg->Clear();
            // 设置
            p_net->msg->set_type(5); // webmai_msg

            webmail_msg* p_webmail = p_net->msg->mutable_webmail();
            Comm_msg* p_comm = p_webmail->mutable_comm_msg();
            st_http_msg* p_http = p_webmail -> mutable_st_http();
            insert_comm_msg(p_session, p_comm);
            Comm_msg* p_comm2 = p_http->mutable_common();
            insert_comm_msg(p_session, p_comm2);

            string requst_time_str = date_time3(p_webmail_session->requst_time);
            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
            // 组织需要的数据

            // 会话结束   初始化 webmail_session
            access_id = 0;
            access_name = "";
            title = "";
            body = "";
            access_list.clear();
            if(p_mail_handle->access_id_aissue.size() > 0)
            {
                aissue_morekey_data(p_webmail_session,&(p_mail_handle->access_id_aissue),access_list);
                //附件ID  计算 crc32
                list<string>::iterator iter = access_list.begin();

                for(;iter != access_list.end();iter ++)
                {
                    access_id = crc32((unsigned char *)iter -> c_str(),iter -> length());
                    access_id_list.push_back(access_id);
                }
            }

            // title_aissue_access
            if(p_mail_handle->title_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->title_aissue_access),&title);
            }
            // body_aissue_access
            if(p_mail_handle->body_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->body_aissue_access),&body);
            }

            if(!body.empty())
            {
                // 163正文需要2次转换才能去除掉格式
                char * buffer = new char[body.length() +1];
                if(buffer != NULL)
                {
                    int len = 0;
                    //html_to_txt(buffer, len, body.c_str(), body.length());
                    c_html2txt.Convert(buffer, len, (char*)body.c_str(), body.length(),NULL);
                    body.clear();
                    //body.assign(buffer, buffer+len);
                    body = string(buffer, 0, len);
                    body = chineseCharDecode(body);
                    if(buffer != NULL)
                    {
                        delete [] buffer;
                    }
                }
                buffer = NULL;
            }
            // from_aissue_access
            mail_from = "";
            if(p_mail_handle->from_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&mail_from);
            }
            //to_aissue_access
            mail_to = "";
            if(p_mail_handle->to_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->to_aissue_access),&mail_to);
            }
            replace_str(mail_to,";","|");
            replace_str(mail_to,",","|");
            //cc_aissue_access
            mail_cc = "";
            if(p_mail_handle->cc_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->cc_aissue_access),&mail_cc);
            }
            replace_str(mail_cc,";","|");
            replace_str(mail_cc,",","|");
            //bcc_aissue_access
            mail_bcc = "";
            if(p_mail_handle->bcc_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
            }

            replace_str(mail_bcc,";","|");
            replace_str(mail_bcc,",","|");
            // 发件人
            p_webmail->set_from(mail_from);
            // 收件人
            p_webmail->set_to(mail_to);
            // 抄送
            p_webmail->set_cc(mail_cc);
            // 密送
            p_webmail->set_bcc(mail_bcc);
            // 主题
            p_webmail->set_title(title);

            p_attach_info -> p_protocal -> PotocolStatistics(5,1,0,1);
            // 正文
            p_webmail->set_body(body);
            // 字符集，暂时不用
            p_webmail->set_charset("");


            if(p_mail_handle-> uid_aissue_access.size() > 0)
            {
                string str_user_name;
                aissue_data(p_webmail_session,&(p_mail_handle-> uid_aissue_access),&str_user_name);
                //cout << "user_name:" << str_user_name << endl;
                p_webmail -> set_username(str_user_name);
                p_net->datalen += str_user_name.size();
            }
            if(p_mail_handle->mail_aissue_access.size() > 0)
            {
                string str_mail_from;
                aissue_data(p_webmail_session,&(p_mail_handle-> mail_aissue_access),&str_mail_from);
                //cout << "mail_from:" << str_mail_from << endl;
                p_webmail -> set_mail_from(str_mail_from);
                p_net->datalen += str_mail_from.size();
            }
            if(p_mail_handle->phone_aissue_access.size() > 0)
            {
                string str_rcpt_to;
                aissue_data(p_webmail_session,&(p_mail_handle-> phone_aissue_access),&str_rcpt_to);
                //cout << "rcpt:" << str_rcpt_to << endl;
                p_webmail -> set_rcpt_to(str_rcpt_to);
                p_net->datalen += str_rcpt_to.size();
            }

            if(p_mail_handle->sex_aissue_access.size() > 0)
            {
                string str_uid;
                aissue_data(p_webmail_session,&(p_mail_handle-> sex_aissue_access),&str_uid);
                //cout << "uid:" << str_uid << endl;
                p_webmail ->set_uid(str_uid);
                p_net->datalen += str_uid.size();
            }

            if(p_mail_handle->history_aissue_access.size() > 0)
            {
                string str_session_id;
                aissue_data(p_webmail_session,&(p_mail_handle-> history_aissue_access),&str_session_id);
                //cout << "session_id:" << str_session_id << endl;
                p_webmail -> set_sessonid(str_session_id);
                p_net->datalen += str_session_id.size();
            }

            if(p_mail_handle->resecret_aissue_access.size() > 0)
            {
                string str_passwd;
                aissue_data(p_webmail_session,&(p_mail_handle-> resecret_aissue_access),&str_passwd);
                //cout << "passwd:" << str_passwd << endl;
                p_webmail -> set_passwd(str_passwd);
                p_net->datalen += str_passwd.size();
            }
            if(p_mail_handle->education_aissue_access.size() > 0)
            {
                string str_domain;
                aissue_data(p_webmail_session,&(p_mail_handle-> education_aissue_access),&str_domain);
                //cout << "domain:" << str_domain<< endl;
                p_webmail -> set_domain(str_domain);
                p_net->datalen += str_domain.size();
            }
            if(p_mail_handle->height_aissue_access.size() > 0)
            {
                string str_mainfile;
                aissue_data(p_webmail_session,&(p_mail_handle-> height_aissue_access),&str_mainfile);
                //cout << "mainfile:" << str_mainfile << endl;
                p_webmail -> set_mainfile(str_mainfile);
                p_net->datalen += str_mainfile.size();
            }
            if(p_mail_handle->nickename_aissue_access.size() > 0)
            {
                string str_mail_send_time;
                aissue_data(p_webmail_session,&(p_mail_handle-> nickename_aissue_access),&str_mail_send_time);
                //cout << "mail_send_time:" << str_mail_send_time << endl;
                p_webmail -> set_mail_send_time(cl_function :: to_int(str_mail_send_time.c_str()));
                p_net->datalen += str_mail_send_time.size();
            }
            if(p_mail_handle->married_aissue_access.size() > 0)
            {
                string str_folder;
                aissue_data(p_webmail_session,&(p_mail_handle-> married_aissue_access),&str_folder);
                //cout << "mail_send_time:" << str_folder << endl;
                p_webmail -> set_folder(str_folder);
                p_net->datalen += str_folder.size();
            }
            if(p_mail_handle->reg_time_aissue_access.size() > 0)
            {
                string str_from_part;
                aissue_data(p_webmail_session,&(p_mail_handle-> reg_time_aissue_access),&str_from_part);
                //cout << "mail_from_part:" << str_from_part << endl;
                p_webmail -> set_from_part(str_from_part);
                p_net->datalen += str_from_part.size();
            }
            if(p_mail_handle->year_aissue_access.size() > 0)
            {
                string str_to_part;
                aissue_data(p_webmail_session,&(p_mail_handle-> year_aissue_access),&str_to_part);
                //cout << "mail_to_part:" << str_to_part << endl;
                p_webmail -> set_to_part(str_to_part);
                p_net->datalen += str_to_part.size();
            }
            if(p_mail_handle->month_aissue_access.size() > 0)
            {
                string str_cc_part;
                aissue_data(p_webmail_session,&(p_mail_handle-> month_aissue_access),&str_cc_part);
                //cout << "mail_cc_part:" << str_cc_part << endl;
                p_webmail -> set_cc_part(str_cc_part);
                p_net->datalen += str_cc_part.size();
            }
            if(p_mail_handle->day_aissue_access.size() > 0)
            {
                string str_bcc_part;
                aissue_data(p_webmail_session,&(p_mail_handle-> bcc_aissue_access),&str_bcc_part);
                //cout << "mail_bcc_part:" << str_bcc_part << endl;
                p_webmail -> set_bcc_part(str_bcc_part);
                p_net->datalen += str_bcc_part.size();
            }
            if(p_mail_handle->city_aissue_access.size() > 0)
            {
                string str_eml_path;
                aissue_data(p_webmail_session,&(p_mail_handle-> city_aissue_access),&str_eml_path);
                //cout << "mail_eml_path:" << str_eml_path << endl;
                p_webmail -> set_eml_path(str_eml_path);
                p_net->datalen += str_eml_path.size();
            }
            if(p_mail_handle->proto_type_aissue.size() > 0)
            {
                string str_other_file;
                aissue_data(p_webmail_session,&(p_mail_handle-> proto_type_aissue),&str_other_file);
                // cout << "mail_otherfile:" << str_other_file << endl;
                p_webmail -> set_other_file(str_other_file);
                p_net->datalen += str_other_file.size();
            }

            // 数组，附件标识
            list<uint32_t>::iterator it = access_id_list.begin();
            if(it != access_id_list.end() )
            {
                for(; it!=access_id_list.end(); ++it)
                {
                    p_webmail->add_file_crc_ids(*it);
                }
            }
            p_webmail -> set_engine_type(p_mail_handle->str_engine);
            p_webmail -> set_service_provider(p_mail_handle->str_provider);
            p_webmail -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
            string str_savefolder = "";
            if(p_mail_handle->married_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle-> married_aissue_access),&str_savefolder);
                //p_webmail -> set_folder(str_folder);
                //p_net->datalen += str_folder.size();
            }
            if(str_savefolder == "002")
            {
                p_webmail -> set_action("51");
            }
            else
            {
                p_webmail -> set_action(p_mail_handle->str_action);
            }


            // st 增加 add by cxb
            // 把提取出的请求头信息，cookie，url，user-agent等放入到消息体中
            parse_value_map::iterator iter_dire = p_parse_value->value_map.find("direction_type");
            if(iter_dire != p_parse_value->value_map.end())
            {
                p_http->set_direction_type(atoi(iter_dire->second.c_str()));
            }
            //p_http->set_direction_type(1);
            fill_with_head_info_in_http_msg(p_webmail_session, *p_http, p_net->datalen);
            p_net ->datalen  = 20 + mail_from.length() + mail_to.length() + mail_cc.length() + mail_bcc.length() + title.length() + body.length();
            // 接口
            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            {
                p_list -> push_back(m_data);
            }
            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            p_session->client.clear_buf();
            p_session->server.clear_buf();
            access_id_list.clear();
            access_list.clear();
            clear_webmail_session(p_webmail_session);
            p_webmail_session -> state = url_wait;
            SET_SESSION_OVER(p_session );
            p_session->client.clear_buf();
            p_session->server.clear_buf();
        }
        else if (p_webmail_session->p_parse_value -> parse_type == REGIST)
        {
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            //access_id_list.clear();
            p_net->msg->Clear();
            // 设置消息类型号 
            p_net->msg->set_type(12); // 注册信息

            regist_msg* p_regist = p_net->msg->mutable_regist();
            Comm_msg* p_comm =  p_regist -> mutable_comm_msg();

            // 增加st公共消息头, add by zq
            st_http_msg* p_http = p_regist -> mutable_st_http();
            insert_comm_msg(p_session, p_comm);

            Comm_msg* p_comm2 = p_http->mutable_common();
            insert_comm_msg(p_session, p_comm2);

            // 公共 消息 
            if(p_session -> b_src_is_ser)
            {
                p_comm ->set_src_port(ntohs(p_session->dstport));
                p_comm ->set_dst_ip(p_session->srcip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
            }
            else
            {
                p_comm ->set_src_port(ntohs(p_session->srcport));
                p_comm ->set_dst_ip(p_session->dstip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
            }
            p_comm ->set_time(p_webmail_session->requst_time);//截取时间？

            string requst_time_str = date_time3(p_webmail_session->requst_time);//将时间转换为常用格式 
            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
            // 组织需要的数据

            // 会话结束   初始化 webmail_session
            access_id = 0;

            mail_from = "";
            if(p_mail_handle->from_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&mail_from);
            }
            mail_to = "";
            if(p_mail_handle->to_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->to_aissue_access),&mail_to);
            }
            mail_cc = "";
            if(p_mail_handle->cc_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->cc_aissue_access),&mail_cc);
            }

            mail_bcc = "";
            if(p_mail_handle->bcc_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
            }

            mail_uid = "";
            if(p_mail_handle->uid_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->uid_aissue_access),&mail_uid);
            }
            mail_city = "";
            if(p_mail_handle->city_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->city_aissue_access),&mail_city);
            }
            mail_qq = "";
            if(p_mail_handle->qq_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->qq_aissue_access),&mail_qq);
            }
            mail_mail = "";
            if(p_mail_handle->mail_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->mail_aissue_access),&mail_mail);
            }
            mail_phone = "";
            if(p_mail_handle->phone_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->phone_aissue_access),&mail_phone);
            }
            mail_reg_time = "";
            if(p_mail_handle->reg_time_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->reg_time_aissue_access),&mail_reg_time);
            }
            mail_sex = "";
            if(p_mail_handle->sex_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->sex_aissue_access),&mail_sex);
            }
            mail_nickename = "";
            if(p_mail_handle->nickename_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->nickename_aissue_access),&mail_nickename);
            }
            mail_resecret = "";
            if(p_mail_handle->resecret_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->resecret_aissue_access),&mail_resecret);
            }
            mail_education = "";
            if(p_mail_handle->education_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->education_aissue_access),&mail_education);
            }
            mail_height = "";
            if(p_mail_handle->height_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->height_aissue_access),&mail_height);
            }
            mail_married = "";
            if(p_mail_handle->married_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->married_aissue_access),&mail_married);
            }
            mail_country = "";
            if(p_mail_handle->country_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->country_aissue_access),&mail_country);
            }
            mail_province = "";
            if(p_mail_handle->province_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->province_aissue_access),&mail_province);
            }
            mail_year = "";
            if(p_mail_handle->year_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->year_aissue_access),&mail_year);
            }
            mail_month = "";
            if(p_mail_handle->month_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->month_aissue_access),&mail_month);
            }
            mail_day = "";
            if(p_mail_handle->day_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->day_aissue_access),&mail_day);
            }
            title = ""; //提取旧密码字段
            if(p_mail_handle->title_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->title_aissue_access),&title);
            }

            p_regist->set_old_password(title);
            p_regist->set_cell_phone(mail_phone);
            p_regist->set_email(mail_mail);
            p_regist->set_qq(mail_qq);
            p_regist->set_username(mail_from);
            p_regist->set_nickename(mail_nickename);
            p_regist->set_uuid(mail_uid);
            p_regist->set_secret(mail_to);
            p_regist->set_resecret(mail_resecret);
            // 增加注册时候验证码
            p_regist->set_confirm_code(mail_cc);
            // 增加session_id的提取
            p_regist->set_session_id(mail_bcc);
            p_regist->set_education(mail_education);
            p_regist->set_country(mail_country);
            p_regist->set_province(mail_province);
            p_regist->set_city(mail_city);
            /*cout << "regist_phone:"<< mail_phone << endl;
              cout << "regist_mail:"<< mail_mail << endl;
              cout << "regist_qq:"<< mail_qq<< endl;
              cout << "regist_uaername:"<< mail_from<< endl;
              cout << "regist_nickename:"<< mail_nickename<< endl;
              cout << "regist_uid:"<<mail_uid << endl;
              cout << "regist_password:"<<mail_to << endl;
              cout << "regist_repassword:"<< mail_resecret<< endl;
              cout << "regist_confirm:"<<mail_cc << endl;
              cout << "regist_education:"<< mail_education<< endl;
              cout << "regist_country:"<< mail_country<< endl;
              cout << "regist_privince:"<< mail_province<< endl;
              cout << "regist_city:"<< mail_city<< endl;*/

            // st 增加 add by zq
            // 把提取出的请求头信息，cookie，url，user-agent等放入到消息体中
            parse_value_map::iterator iter_dire = p_parse_value->value_map.find("direction_type");
            if(iter_dire != p_parse_value->value_map.end())
            {
                p_http->set_direction_type(atoi(iter_dire->second.c_str()));
            }

            fill_with_head_info_in_http_msg(p_webmail_session, *p_http, p_net->datalen);

            string str_arg ("");
            int int_tmp = 0;

            p_regist -> set_engine_type(p_mail_handle->str_engine);
            p_regist -> set_service_provider(p_mail_handle->str_provider);
            p_regist -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
            p_regist -> set_action(p_mail_handle->str_action);
            // 把字符串转换成编码集
            //  add by zq end

            p_attach_info -> p_protocal -> PotocolStatistics(12,1,0,1);
            if ((mail_mail == "") && (mail_from.find('@',0) != string::npos))
            {
                p_regist->set_email(mail_from);
                //cout << "regist_email:"<< mail_from<< endl;
            }
            else
            {
                p_regist->set_email(mail_mail);
                //cout << "regist_email:"<< mail_from<< endl;
            }

            if ((mail_phone == "") && (verifyMsisdn((char *)mail_from.c_str()) == 0))
            {
                p_regist->set_cell_phone(mail_from);
                //cout << "regist_phone:"<<mail_from << endl;
            }
            else
            {
                p_regist->set_cell_phone(mail_phone);
                //    cout << "regist_phone:"<<mail_phone<< endl;
            }
            //注册日期
            uint64_t  reg_time;
            reg_time = atol(mail_reg_time.c_str());
            p_regist->set_required_time(reg_time);
            //cout << "regist_regtime:"<< reg_time<< endl;

            uint32_t reg_tmp;
            reg_tmp = atoi(mail_height.c_str());
            p_regist->set_height(reg_tmp);

            if (strstr(mail_sex.c_str(), "男") || strstr(mail_sex.c_str(), "1"))
            {
                p_regist->set_sex(1);
            }
            else if (strstr(mail_sex.c_str(), "女") || strstr(mail_sex.c_str(), "2"))
            {
                p_regist->set_sex(2);
            }
            else
            {
                p_regist->set_sex(3);
            }

            if (p_webmail_session->is_valid)
            {
                p_regist->set_successed(2);
            }
            else
            {
                p_regist->set_successed(1);
            }

            /*if (strstr(mail_married.c_str(),"1"))
              {
              p_regist->set_married(2);
              }
              else
              {
              p_regist->set_married(1);
              }*/
            p_regist->set_married(2);

            if (mail_year != "")
            {
                string birthday = "";
                birthday = mail_year + "." + mail_month + "." + mail_day;
                p_regist->set_birthday(birthday);
                //cout << "regist_birthday:"<<birthday << endl;
            }

            url2id_map::iterator iter;
            iter =config_parse->p_url2id_map.find(mail_cc);
            pair<uint32_t,uint32_t> value;
            uint32_t protocol_id;
            if(iter != config_parse->p_url2id_map.end() )
            {
                value = iter ->second;
                protocol_id = value.first;
                //protocol_id
                p_regist->set_protocol_code(protocol_id);
            }
            p_net ->datalen  = 20 + mail_from.length() + mail_to.length() + mail_uid.length() + 
                mail_city.length() + mail_mail.length()  + mail_resecret.length() + 
                mail_year.length() + mail_month.length() + mail_day.length() + mail_reg_time.length() + 
                mail_sex.length() + mail_history.length() + mail_qq.length() + mail_phone.length() +
                mail_reg_time.length() + mail_education.length() + mail_height.length() + 
                mail_married.length() + mail_country.length() + mail_province.length() +
                p_mail_handle->str_engine.length() + p_mail_handle->str_provider.length() + p_mail_handle->str_app_id.length() +
                p_mail_handle->str_action.length() + title.length() + sizeof(int);

            //cout_st_http_msg(*p_http);
            // 接口 
            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            p_list -> push_back(m_data);

            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            access_id_list.clear();
            access_list.clear();
            clear_webmail_session(p_webmail_session);
            p_webmail_session -> state = url_wait;
            SET_SESSION_OVER(p_session );
            clear_webmail_session(p_webmail_session);
            p_session->client.clear_buf();
            p_session->server.clear_buf();

        }

        else if (p_webmail_session->p_parse_value -> parse_type == LOGIN)
        {
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            access_id_list.clear();
            p_net->msg->Clear();
            // 设置消息类型号 
            p_net->msg->set_type(13); // 登录信息

            login_msg* p_login = p_net->msg->mutable_login();
            Comm_msg* p_comm = p_login->mutable_comm_msg();
            st_http_msg* p_http = p_login -> mutable_st_http();
            insert_comm_msg(p_session, p_comm);

            Comm_msg* p_comm2 = p_http->mutable_common();
            insert_comm_msg(p_session, p_comm2);

            string requst_time_str = date_time3(p_webmail_session->requst_time);//将时间转换为常用格式 
            mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
            // 组织需要的数据

            // 会话结束   初始化 webmail_session
            access_id = 0;

            p_net->datalen = 20;
            mail_from = "";
            if(p_mail_handle->from_aissue_access.size() > 0)
            {
                aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&mail_from);
                p_net->datalen += mail_from.size();
            }
            mail_to = "";
            if(p_mail_handle->to_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->to_aissue_access),&mail_to);
                p_net->datalen += mail_to.size();
            }
            mail_cc = "";
            if(p_mail_handle->cc_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->cc_aissue_access),&mail_cc);
                p_net->datalen += mail_cc.size();
            }
            mail_uid = "";
            if(p_mail_handle->uid_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->uid_aissue_access),&mail_uid);
                p_net->datalen += mail_uid.size();
            }
            mail_city = "";
            if(p_mail_handle->city_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->city_aissue_access),&mail_city);
                p_net->datalen += mail_city.size();
            }
            mail_qq = "";
            if(p_mail_handle->qq_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->qq_aissue_access),&mail_qq);
                p_net->datalen += mail_qq.size();
            }
            mail_mail = "";
            if(p_mail_handle->mail_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->mail_aissue_access),&mail_mail);
                p_net->datalen += mail_mail.size();
            }
            mail_phone = "";
            if(p_mail_handle->phone_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->phone_aissue_access),&mail_phone);
                p_net->datalen += mail_phone.size();
            }
            mail_reg_time = "";
            if(p_mail_handle->reg_time_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->reg_time_aissue_access),&mail_reg_time);
                p_net->datalen += mail_reg_time.size();
            }
            mail_sex = "";
            if(p_mail_handle->sex_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->sex_aissue_access),&mail_sex);
                p_net->datalen += mail_sex.size();
            }
            mail_history = "";
            if(p_mail_handle->history_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->history_aissue_access),&mail_history);
                p_net->datalen += mail_history.size();
            }
            mail_bcc = "";
            if(p_mail_handle->bcc_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
            }
            mail_nickename = "";
            if(p_mail_handle->nickename_aissue_access.size() > 0)
            {
                aissue_data_identity(p_webmail_session,&(p_mail_handle->nickename_aissue_access),&mail_nickename);
                p_net->datalen += mail_nickename.size();
            }
            p_attach_info -> p_protocal -> PotocolStatistics(13,1,0,1);

            // 把提取出的请求头信息，cookie，url，user-agent等放入到消息体中
            parse_value_map::iterator iter_dire = p_parse_value->value_map.find("direction_type");
            if(iter_dire != p_parse_value->value_map.end())
            {
                p_http->set_direction_type(atoi(iter_dire->second.c_str()));
            }

            fill_with_head_info_in_http_msg(p_webmail_session, *p_http, p_net->datalen);

            string str_arg ("");
            int int_tmp = 0;

            p_login -> set_engine_type(p_mail_handle->str_engine);
            p_login -> set_service_provider(p_mail_handle->str_provider);
            p_login -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
            p_login -> set_action(p_mail_handle->str_action);
            p_login -> set_session_id(mail_bcc);//会话ID
            // 把字符串转换成编码集

            p_login->set_user_name(mail_from);
            p_login->set_passwd(mail_to);
            p_login->set_uuid(mail_uid);
            p_login->set_uid(mail_uid);
            p_login->set_city(mail_city);
            p_login->set_qq(mail_qq);
            p_login->set_nice_name(mail_nickename);
            // 增加注册时候验证码
            p_login->set_confirm_code(mail_cc);
            /*cout << "login_username:"<<mail_from << endl;
              cout << "login_passwd:"<< mail_to<< endl;
              cout << "login_uid:"<<mail_uid << endl;
              cout << "login_city:"<<mail_city<< endl;
              cout << "login_qq:"<< mail_qq<< endl;
              cout << "login_nickname:"<< mail_nickename<< endl;
              */
            if ((mail_mail == "") && (mail_from.find('@',0) != string::npos))
            {
                p_login->set_mail(mail_from);
                //cout << "login_mail:"<<mail_from << endl;
            }
            else
            {
                p_login->set_mail(mail_mail);
                //cout << "login_mail:"<<mail_from << endl;
            }

            if ((mail_phone == "") && (verifyMsisdn((char *)mail_from.c_str()) == 0))
            {
                p_login->set_cell_phone(mail_from);
                //cout << "login_phone:"<< mail_from<< endl;
            }
            else
            {
                p_login->set_cell_phone(mail_phone);
                //cout << "login_phone:"<< mail_from<< endl;
            }

            //注册日期
            uint64_t  reg_time;
            reg_time = atol(mail_reg_time.c_str());
            p_login->set_regist_time(reg_time);

            if (strstr(mail_sex.c_str(), "男") || strstr(mail_sex.c_str(), "1"))
            {
                p_login->set_sex(1);
            }
            else if (strstr(mail_sex.c_str(), "女") || strstr(mail_sex.c_str(), "2"))
            {
                p_login->set_sex(2);
            }
            else
            {
                p_login->set_sex(3);
            }

            if (p_webmail_session->is_valid)
            {
                p_login->set_successed(2);
            }
            else
            {
                p_login->set_successed(1);
            }

            url2id_map::iterator iter;
            iter =config_parse->p_url2id_map.find(mail_cc);
            pair<uint32_t,uint32_t> value;
            uint32_t protocol_id;
            if(iter != config_parse->p_url2id_map.end() )
            {
                value = iter ->second;
                protocol_id = value.first;
                //protocol_id
                p_login->set_protocol_code(protocol_id);
            }

            //历史信息
            if (mail_history != "")
            {
                string user = "";
                string pawd = "";
                mail_history = urldecode(mail_history);
                mail_history = urldecode(mail_history);
                if (protocol_id == 7)
                {
                    int pos1 = mail_history.find_first_of("=");
                    int pos2 = mail_history.find_first_of("&");
                    user = mail_history.substr(pos1 + 1, pos2 - pos1 -1);
                    pos1 = mail_history.find_first_of("=", pos2);
                    pos2 = mail_history.find_first_of("&", pos1);
                    pawd = mail_history.substr(pos1 + 1, pos2 - pos1 -1);
                    if ((user.find('@',0) != string::npos) || (verifyMsisdn((char *)user.c_str()) == 0))
                    {
                        p_login->set_cookie_username(user);
                    }
                    p_login->set_cookie_password(pawd);
                }
            }

            p_net ->datalen  = 20 + mail_from.length() + mail_to.length() + mail_uid.length() + 
                mail_city.length() + mail_mail.length() + mail_qq.length() + mail_reg_time.length() + 
                mail_year.length() + mail_month.length() + mail_day.length() + mail_reg_time.length() + 
                mail_sex.length() + mail_history.length() + mail_nickename.length() + mail_bcc.length() + mail_cc.length();
            // 接口 

            //cout_st_http_msg(*p_http);

            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            p_list -> push_back(m_data);

            p_session->send_len = 0;
            p_session->p_send_buf = NULL;
            access_id_list.clear();
            access_list.clear();
            clear_webmail_session(p_webmail_session);
            p_webmail_session -> state = url_wait;
            SET_SESSION_OVER(p_session );
        }
        else if(p_webmail_session->p_parse_value -> parse_type == LOCATION)
        {
            handle_location_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == SEARCH)
        {
            search_handle_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == TICKET)
        {
            ticket_handle_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == LOGOUT)
        {
            logout_handle_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == DEVELOPMENT)
        {
            develop_handle_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == NEWS)
        {
            news_data_handle(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == JOB)
        {
            job_data_handle(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == BBS)
        {
            bbs_handle_data(p_session, p_list);
        }
        else if(p_webmail_session->p_parse_value->parse_type == SHOP)
        {
            shop_handle_data(p_session,p_list);
        }
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        SET_SESSION_OVER(p_session );
        return;
    }
}

void webmail_plugin::handle_location_data(session* p_session, list<data_interface> * p_list)
{
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
        return;

    if(p_session->send_len  > 20971520) 
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        clear_webmail_session(p_webmail_session);
        SET_SESSION_OVER(p_session);
        return;
    }

    // 接口 
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value == NULL)
    {
        SET_SESSION_OVER(p_session);
        return;
    }

    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    data_interface m_data;
    mail_from = "";
    if(p_mail_handle->from_aissue_access.size() > 0)
    {
        aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&mail_from);
    }
    if(mail_from.size() == 0)
    {
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        SET_SESSION_OVER(p_session );
        return;
    }

    mail_to = "";
    if(p_mail_handle->to_aissue_access.size() > 0)
    {
        aissue_data_identity(p_webmail_session,&(p_mail_handle->to_aissue_access),&mail_to);
    }
    if(mail_to.size() == 0)
    {
        p_session->client.clear_buf();
        p_session->server.clear_buf();
        SET_SESSION_OVER(p_session );
        return;
    }

    net_str * p_net =  new net_str;
    p_net -> msg = new CAmsg;
    access_id_list.clear();
    p_net->msg->Clear();
    // 设置消息类型号 
    p_net->msg->set_type(14); // location_msg

    http_lbs_msg* p_location = p_net->msg->mutable_http_lbs();
    Comm_msg* p_comm =  p_location -> mutable_comm_msg();
    // 公共 消息 
    if(p_session -> b_src_is_ser)
    {
        p_comm ->set_src_port(ntohs(p_session->dstport));
        p_comm ->set_dst_ip(p_session->srcip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->srcport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->dstip.ip_str());
        }
    }
    else
    {
        p_comm ->set_src_port(ntohs(p_session->srcport));
        p_comm ->set_dst_ip(p_session->dstip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->dstport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->srcip.ip_str());
        }
    }
    p_comm ->set_time(p_webmail_session->requst_time);//截取时间？
    string requst_time_str = date_time3(p_webmail_session->requst_time);//将时间转换为常用格式 

    // 会话结束   初始化 webmail_session
    access_id = 0;
    access_name = "";
    access_list.clear();

    mail_cc = "";
    if(p_mail_handle->cc_aissue_access.size() > 0)
    {
        aissue_data_identity(p_webmail_session,&(p_mail_handle->cc_aissue_access),&mail_cc);
    }
    mail_bcc = "";
    if(p_mail_handle->cc_aissue_access.size() > 0)
    {
        aissue_data_identity(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
    }
    body = "";//imei
    if(p_mail_handle->cc_aissue_access.size() > 0)
    {
        aissue_data(p_webmail_session,&(p_mail_handle->body_aissue_access),&body);
    }
    access_name = "";//imsi
    if(p_mail_handle->cc_aissue_access.size() > 0)
    {
        aissue_data(p_webmail_session,&(p_mail_handle->access_name_aissue),&access_name);
    }

    map<string ,uint32_t>::iterator it = config_parse->url_app_loc_map.find(mail_cc);
    if(it != config_parse->url_app_loc_map.end() )
    {
        uint32_t app = it->second;
        p_location->set_app_id(app);
    }

    p_attach_info -> p_protocal -> PotocolStatistics(14,1,0,1);

    double longtitude = s2f(mail_from);
    double latitude = s2f(mail_to);
    // 需要增加经纬度的判定

    //取出除数标志分别进行处理
    map<string ,string>::iterator iter = config_parse->url_flag_map.find(mail_cc);
    if(iter != config_parse->url_flag_map.end() )
    {
        string flag = iter ->second;
        if(flag == "1")
        {
        }
        else if(flag == "2")
        {
            double i = 111326;
            double j = 120930;
            longtitude = longtitude/i;
            latitude = latitude/j;
        }
        else if(flag == "3")
        {
            double i = 1000000;
            longtitude = longtitude/i;
            latitude = latitude/i;
        }
        else if(flag == "4")
        {
            double j = 100;
            longtitude = longtitude/j;
            latitude = latitude/j;
        }
    }

    //经度
    p_location->set_longitude(longtitude);
    //维度
    p_location->set_latitude(latitude);
    p_location->set_username(mail_bcc);
    p_location->set_imei(access_name);
    p_location->set_imsi(body);
    //url
    //p_location->set_url(mail_cc);

    p_net ->datalen  = 20 + mail_from.length() + mail_to.length() + mail_cc.length() + mail_bcc.length() + title.length() + body.length();
    // 接口 
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);

    /*webmail_counter wbml(&plugin_shmid_wml, &plugin_shmid_wml1);
      wbml.cnt_atomic_operate_add(1);
      wbml.cnt_atomic_operate_add1((p_net->datalen-20));*/

    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    access_id_list.clear();
    access_list.clear();
    clear_webmail_session(p_webmail_session);
    p_webmail_session->state = url_wait;
    SET_SESSION_OVER(p_session);
}

void webmail_plugin::clear_webmail_session(webmail_session * p_webmail_session)
{
    if(p_webmail_session == NULL)
        return;

    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value != NULL)
    {
        delete  p_parse_value;
    }

    p_parse_value = NULL;
    p_webmail_session ->p_parse_value = NULL;
    p_webmail_session -> requst_time = 0;
    p_webmail_session -> response_time = 0;

    p_webmail_session -> p_data = NULL;
    p_webmail_session -> len =  0 ;

    p_webmail_session -> http_head_length = 0;
    p_webmail_session -> requset_length = 0;
    p_webmail_session -> requset_length = 0;

    p_webmail_session -> tmp_requset_length = 0;
    p_webmail_session -> had_send_len = 0;

    p_webmail_session -> response_length = 0;

    p_webmail_session ->req_charset[0] =0x0;
    p_webmail_session ->resp_charset[0] =0x0;

    p_webmail_session ->state  =  url_wait;

    p_webmail_session -> p_parse_value = new parse_value;

    //(*p_webmail_session->file_content).clear();
    p_webmail_session->file_length = 0;
}

void webmail_plugin::aissue_morekey_data(webmail_session * p_webmail_session , aissue_list * p_list , list<string>& value_list) 
{
    vector<string> *p_value = new vector<string>[p_list->size()];
    int num = p_list ->size();
    int i = 0;
    string tmp  = "";
    string separate_character ="|";
    aissue_list::iterator iter = p_list->begin();
    parse_value_map::iterator it;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    for(;iter!=p_list->end();iter ++)
    {
        tmp = "";
        it = p_parse_value->value_map.find(*iter);
        // 分割符号解析 
        if(it!= p_parse_value->value_map.end())
        {
            tmp= it->second;
        }
        if(tmp =="")
        {
            //delete [] p_value;
            //p_value = NULL;
            //return ;
            continue ;
        }
        splitEx(tmp,separate_character,p_value[i]) ; 
        i++;
    }
    // 循环片接数据 
    tmp = "";
    assemble_data(num,p_value,tmp,value_list);
    delete [] p_value;
    p_value = NULL;
}

void assemble_data(int num, vector<string> * p_value,string & tmp , list<string> & value_list)
{
    string value = tmp;
    if(num > 0)
    {
        vector<string>::iterator b = p_value[num-1].begin();
        vector<string>::iterator e = p_value[num-1].end();
        if(b == e)  //空的时候不记录
        {

            assemble_data(--num,p_value,value ,value_list);
            return ;
        } 
        --num;
        for(; b!=e;b++)
        {
            value = tmp;
            value += *b;
            assemble_data(num,p_value,value,value_list);
        }
    }
    else {
        value_list.push_back(value);
    }
}

void webmail_plugin::webmail_identity(session* p_session,list<data_interface> * p_list)
{
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value -> parse_type == IDENTITY)
    {
        // 
        //string requst_time_str = date_time3(p_webmail_session->requst_time); 
        mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
        //
        string url = "";
        string title = "";
        string body = "";
        string username = "";
        string password = "";
        string webname = "";
        string file = "";
        if(p_mail_handle->access_id_aissue.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->access_id_aissue),&url);
        }


        if(p_mail_handle->title_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->title_aissue_access),&title);
        }
        // body
        if(p_mail_handle->body_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->body_aissue_access),&body);
        }
        if(p_mail_handle->from_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->from_aissue_access),&username);
        }

        //to_aissue_access 
        if(p_mail_handle->to_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->to_aissue_access),&password);
        }
        //cc_aissue_access 
        if(p_mail_handle->cc_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->cc_aissue_access),&webname);
        }

        //bcc_aissue_access 
        if(p_mail_handle->cc_aissue_access.size() > 0)
        {
            aissue_data(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&file);
        }

        string tmp = "";
        DNUMTOSTR(p_webmail_session->requst_time, tmp);
        if(!url.empty()) 
        {
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            access_id_list.clear();
            p_net->msg->Clear();
            // 设置 
            p_net->msg->set_type(10); // 

            http_msg* p_http = p_net->msg->mutable_http();
            Comm_msg* p_comm =  p_http -> mutable_comm_msg();
            // 公共 消息 
            if(p_session -> b_src_is_ser)
            {
                p_comm ->set_src_port(ntohs(p_session->dstport));
                p_comm ->set_dst_ip(p_session->srcip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
            }
            else
            {
                p_comm ->set_src_port(ntohs(p_session->srcport));
                p_comm ->set_dst_ip(p_session->dstip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
            }
            p_comm ->set_time(p_webmail_session->requst_time);

            p_http ->set_url(url);
            p_http ->set_name(username);
            p_http ->set_passwd(password);
            //p_http ->set_title(title);
            //p_http ->set_body(body);
            p_http ->set_webname(webname );
            p_attach_info -> p_protocal -> PotocolStatistics(10,1,0,1);
            if(!file.empty())
            {
                char md5_value[MD5_SIZE];
                ComputeMd5((char *)file.c_str(),file.length(),md5_value);
                p_http ->set_mid(string(md5_value));
            }
            //bcc_aissue_access 
            p_net ->datalen  = url.length() + username.length() + password.length() + title.length()+ body.length() + webname.length();
            // --------------
            data_interface m_data;
            // 接口 
            m_data.b_out_type = NETSEND;
            m_data.data = p_net;
            //if(p_net->msg->type()>0 && p_net->msg->type()<8)
            p_list -> push_back(m_data);
        }
        // file
        if(!file.empty() )
        {
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            access_id_list.clear();
            p_net->msg->Clear();
            // 设置 
            p_net->msg->set_type(6); // 

            file_msg* p_file = p_net->msg->mutable_file();
            Comm_msg*  p_comm =  p_file -> mutable_comm_msg();
            // 公共 消息 
            if(p_session -> b_src_is_ser)
            {
                p_comm ->set_src_port(ntohs(p_session->dstport));
                p_comm ->set_dst_ip(p_session->srcip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->srcport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->dstip.ip_str());
                }
            }
            else
            {
                p_comm ->set_src_port(ntohs(p_session->srcport));
                p_comm ->set_dst_ip(p_session->dstip.ip_str());
                p_comm ->set_dst_port(ntohs(p_session->dstport));
                if(p_session->b_vpn)        //VPN消息
                {
                    p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
                    p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
                    p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
                }
                else
                {
                    p_comm ->set_src_ip(p_session->srcip.ip_str());
                }
            }
            p_comm ->set_time(p_webmail_session->requst_time);

            if(title.empty())
            {
                p_file ->set_file_name(title);
            }
            //p_file ->set_mid(tmp);
            p_attach_info -> p_protocal -> PotocolStatistics(6,1,0,1);
            p_file ->set_file_id(p_webmail_session->requst_time);

            p_file->set_data(file);
            data_interface m_data1;
            // 接口 
            m_data1.b_out_type = NETSEND;
            m_data1.data = p_net;
            //if(p_net->msg->type()>0 && p_net->msg->type()<8)
            p_list -> push_back(m_data1);
        }
        // file

        if(!body.empty() )
        {
            net_str * p_net =  new  net_str;
            p_net -> msg = new CAmsg;
            access_id_list.clear();
            p_net->msg->Clear();
            // 设置 
            p_net->msg->set_type(11); // 

            urltext_msg* p_html = p_net->msg->mutable_urltext();

            p_attach_info -> p_protocal -> PotocolStatistics(11,1,0,1);
            p_html ->set_url(url);
            p_html ->set_title(title);
            p_html ->set_text_id(p_webmail_session->requst_time);
            // DNUMTOSTR(p_webmail_session->requst_time, tmp);
            p_html->set_body(body);
            data_interface m_data1;
            // 接口 
            m_data1.b_out_type = NETSEND;
            m_data1.data = p_net;
            //if(p_net->msg->type()>0 && p_net->msg->type()<8)
            p_list -> push_back(m_data1);
        }

        //************************************************


        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
        //p_session->client.clear_buf();
        //p_session->server.clear_buf();
        access_id_list.clear();
        access_list.clear();
        clear_webmail_session(p_webmail_session);
        p_webmail_session -> state = url_wait;

        // **********************************************
    }
    p_session->client.clear_buf();
    p_session->server.clear_buf();
    SET_SESSION_OVER(p_session);
    return;
}

void format_data(string& tmp)
{
    char * buffer = new char[tmp.length()];
    if(buffer != NULL)
    {
        int len = 0;
        html_to_txt(buffer, len, tmp.c_str(), tmp.length());
        tmp.clear();
        //tmp.assign(buffer, buffer+len);
        tmp = string(buffer, 0, len);
        if(buffer != NULL)
        {
            delete [] buffer;
        }
    }
    buffer = NULL;
}

void webmail_plugin::format_account(string & account)
{
}

void webmail_plugin::aissue_data(webmail_session * p_webmail_session , aissue_list * p_list , string * p_value)
{
    string tmp ="";
    *p_value = "";
    aissue_list::iterator iter = p_list->begin();
    parse_value_map::iterator it ;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value == NULL)
    {
        return;
    }
    int i = 0;
    for(;iter!=p_list->end();iter ++)
    {
        //----
        tmp = *iter;
        it = p_parse_value->value_map.find(tmp);
        // 如果没有该值 
        if(it!= p_parse_value->value_map.end())
        {
            // 

            if(i > 0)
                *p_value +="-";
            *p_value += it->second;
            i++;
        }
    }
    if (p_value->length() == 0) //根据valgrind工具分析，主要解决第3980进行无效读取
    {
        return ;
    }
    string s_value = "";
    s_value = *p_value;
    char c_end = s_value[s_value.length()-1];
    if (c_end == '-'&& p_value -> length() > 1)
    {
        p_value->erase(p_value->end()-1);
    }
    else if (c_end == ',')
    {
        if(p_value -> size () <  3)
        {
            return ;
        }
        *p_value = p_value->substr(1,p_value->size()-3);
    }
    get_rid_of_garbled(*p_value, *p_value);
    replace_rule(*p_value);
}

void webmail_plugin::news_data_handle(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();
    p_net->msg->set_type(18);
    scan_msg* p_scan = p_net->msg-> mutable_scan();
    st_http_msg* p_http = p_scan -> mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }
    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;
    p_scan -> set_engine_type(p_mail_handle->str_engine);
    p_scan -> set_service_provider(p_mail_handle->str_provider);
    p_scan -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_scan -> set_action(p_mail_handle->str_action);
    p_scan -> set_board(p_mail_handle->str_board_id);
    if(p_mail_handle->title_aissue_access.size() > 0)
    {
        string str_search_key;
        aissue_data(p_webmail_session,&(p_mail_handle-> title_aissue_access),&str_search_key);
        p_scan -> set_search_key(str_search_key);
        p_net->datalen += str_search_key.size();
    }
    if(p_mail_handle->uid_aissue_access.size() > 0)
    {
        string str_user_name;
        aissue_data(p_webmail_session,&(p_mail_handle-> uid_aissue_access),&str_user_name);
        //cout << "user_name:" << str_user_name << endl;
        p_scan -> set_user_name(str_user_name);
        p_net->datalen += str_user_name.size();
    }

    if(p_mail_handle->qq_aissue_access.size() > 0)
    {
        string str_action;
        aissue_data(p_webmail_session,&(p_mail_handle-> qq_aissue_access),&str_action);
        //cout << "action:" << str_action << endl;
        p_scan -> set_action(str_action);
        p_net->datalen += str_action.size();
    }
    if(p_mail_handle->mail_aissue_access.size() > 0)
    {
        string str_email;
        aissue_data(p_webmail_session,&(p_mail_handle-> mail_aissue_access),&str_email);
        //cout << "email:" << str_email << endl;
        p_scan -> set_email(str_email);
        p_net->datalen += str_email.size();
    }
    if(p_mail_handle->phone_aissue_access.size() > 0)
    {
        string str_mobil;
        aissue_data(p_webmail_session,&(p_mail_handle-> phone_aissue_access),&str_mobil);
        //cout << "mobil:" << str_mobil << endl;
        p_scan -> set_mobil(str_mobil);
        p_net->datalen += str_mobil.size();
    }

    if(p_mail_handle->sex_aissue_access.size() > 0)
    {
        string str_uid;
        aissue_data(p_webmail_session,&(p_mail_handle-> sex_aissue_access),&str_uid);
        //cout << "uid:" << str_uid << endl;
        p_scan ->set_uid(str_uid);
        p_net->datalen += str_uid.size();
    }
    if(p_mail_handle->bcc_aissue_access.size() > 0)
    {
        string str_title;
        aissue_data(p_webmail_session,&(p_mail_handle-> bcc_aissue_access),&str_title);
        //cout << "uid:" << str_uid << endl;
        p_scan ->set_title(str_title);
        p_net->datalen += str_title.size();
    }

    if(p_mail_handle->history_aissue_access.size() > 0)
    {
        string str_session_id;
        aissue_data(p_webmail_session,&(p_mail_handle-> history_aissue_access),&str_session_id);
        //cout << "session_id:" << str_session_id << endl;
        p_scan -> set_session_id(str_session_id);
        p_net->datalen += str_session_id.size();
    }
    if(p_mail_handle->resecret_aissue_access.size() > 0)
    {
        string str_user_passwd;
        aissue_data(p_webmail_session,&(p_mail_handle-> resecret_aissue_access),&str_user_passwd);
        //cout << "user_passwd:" << str_user_passwd << endl;
        p_scan -> set_user_passwd(str_user_passwd);
        p_net->datalen += str_user_passwd.size();
    }
    if(p_mail_handle->education_aissue_access.size() > 0)
    {
        string str_content;
        aissue_data(p_webmail_session,&(p_mail_handle-> education_aissue_access),&str_content);
        //cout << "content:" << str_content << endl;
        p_scan -> set_content(str_content);
        p_net->datalen += str_content.size();
    }
    if(p_mail_handle->height_aissue_access.size() > 0)
    {
        string str_verify_code;
        aissue_data(p_webmail_session,&(p_mail_handle-> height_aissue_access),&str_verify_code);
        //cout << "verify:" << str_verify_code << endl;
        p_scan -> set_verify_code(str_verify_code);
        p_net->datalen += str_verify_code.size();
    }
    //cout_st_http_msg(*p_http);

    string str_arg_1 = "";
    get_optional_str_from_value_map(str_arg_1, p_session, p_webmail_session, p_mail_handle->aissue_access[20]);
    p_scan->set_board_name(str_arg_1);
    p_net->datalen += str_arg_1.size();
    str_arg_1 = "";

    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;

    p_list -> push_back(m_data);
}

void webmail_plugin::bbs_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();
    bbs_msg* p_bbs = p_net->msg->mutable_bbs();
    st_http_msg* p_http = p_bbs->mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();

    p_net->datalen = 20;
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;
    p_net->msg->set_type(20);

    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }

    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);

    p_bbs -> set_engine_type(p_mail_handle->str_engine);
    p_bbs -> set_service_provider(p_mail_handle->str_provider);
    p_bbs -> set_app_id(p_mail_handle->str_app_id);
    p_bbs -> set_action(p_mail_handle->str_action);
    p_bbs -> set_board_id(p_mail_handle->str_board_id);


    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[3]);
    p_bbs->set_username(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[4]);
    p_bbs->set_password(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[5]);
    p_bbs->set_nickname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[6]);
    p_bbs->set_bbs_topic(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[8]);
    p_bbs->set_copy_from(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[9]);
    p_bbs->set_link_url(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[10]);
    p_bbs->set_author(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[12]);
    p_bbs->set_issue_status(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[14]);
    p_bbs->set_sessonid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[15]);
    p_bbs->set_uid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[16]);
    p_bbs->set_software(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[17]);
    p_bbs->set_content_meta(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[19]);
    p_bbs->set_touid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[20]);
    p_bbs->set_to_nickname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[21]);
    p_bbs->set_message_text(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[22]);
    p_bbs->set_tid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[23]);
    p_bbs->set_aid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[24]);
    p_bbs->set_newpassword(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[25]);
    p_bbs->set_newpassword2(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[26]);
    p_bbs->set_newemail(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[27]);
    p_bbs->set_newusername(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[28]);
    p_bbs->set_bbs_board_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[29]);
    p_bbs->set_mood_text(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[30]);
    p_bbs->set_qq_num(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[31]);
    p_bbs->set_birthday(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[32]);
    p_bbs->set_filename(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();


    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}

//搜索类信息函数提取，压入发送队列
void webmail_plugin::search_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();

    p_net->msg->set_type(17);
    search_msg* p_search = p_net->msg->mutable_search();

    st_http_msg* p_http = p_search->mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();

    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }

    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);

    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->access_name_aissue);
    p_search->set_keyword(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    p_search -> set_engine_type(p_mail_handle->str_engine);
    p_search -> set_service_provider(p_mail_handle->str_provider);
    p_search -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_search -> set_action(p_mail_handle->str_action);
    p_search -> set_board(p_mail_handle->str_board_id);

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->from_aissue_access);
    p_search->set_uid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->to_aissue_access);
    p_search->set_session_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[10]);
    p_search->set_board_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    //cout_search_msg(*p_search);

    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}


//票务类信息提取，压入到发送队列
void webmail_plugin::ticket_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();

    p_net->msg->set_type(22);
    ticket_msg* p_ticket = p_net->msg->mutable_ticket();
    st_http_msg* p_http = p_ticket->mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();

    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }

    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);

    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;

    p_ticket -> set_flight_type(p_mail_handle->str_engine);
    p_ticket -> set_service_provider(p_mail_handle->str_provider);
    p_ticket -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_ticket -> set_action(p_mail_handle->str_action);
    p_ticket -> set_board(p_mail_handle->str_board_id);

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[4]);
    p_ticket->set_origin_city(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[5]);
    p_ticket->set_dest_city(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[6]);
    p_ticket->set_origin_station(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[7]);
    p_ticket->set_dest_station(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[8]);
    p_ticket->set_begin_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[9]);
    p_ticket->set_end_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[10]);
    p_ticket->set_air_com(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[11]);
    p_ticket->set_flight_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[12]);
    p_ticket->set_businesstime(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[13]);
    p_ticket->set_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[14]);
    p_ticket->set_pickup_certificate_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[15]);
    p_ticket->set_pickup_certificatecode(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[16]);
    p_ticket->set_relationship_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[17]);
    p_ticket->set_relationship_mobilephone(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[18]);
    p_ticket->set_relationship_email(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[19]);
    p_ticket->set_telintersectional(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[20]);
    p_ticket->set_relationship_telnum(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[21]);
    p_ticket->set_relationship_ext(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[22]);
    p_ticket->set_relationship_address(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[23]);
    p_ticket->set_website(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[24]);
    p_ticket->set_english_lastname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[25]);
    p_ticket->set_english_firstname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[26]);
    p_ticket->set_nationlity(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[27]);
    p_ticket->set_password(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[28]);
    p_ticket->set_company(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[29]);
    p_ticket->set_username(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[30]);
    p_ticket->set_person_qlty(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[31]);
    p_ticket->set_mobilephone(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[32]);
    p_ticket->set_nickname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[33]);
    p_ticket->set_using_language(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[34]);
    p_ticket->set_study_experience(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[35]);
    p_ticket->set_position(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[36]);
    p_ticket->set_recentwork(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[37]);
    p_ticket->set_connect_account_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[38]);
    p_ticket->set_connect_account(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[39]);
    p_ticket->set_connect_passwd(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[40]);
    p_ticket->set_transfer_city(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[41]);
    p_ticket->set_transfer_station(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[42]);
    p_ticket->set_adults_qlty(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[43]);
    p_ticket->set_child_qlty(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[44]);
    p_ticket->set_seat_class(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[45]);
    p_ticket->set_ticket_price(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[46]);
    p_ticket->set_language(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[47]);
    p_ticket->set_pnr(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[48]);
    p_ticket->set_search_key_words(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[49]);
    if(str_arg.size() < 5 )
    {
        p_ticket->set_flight_class(str_arg);
        p_net->datalen += str_arg.size();
    }
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[50]);
    p_ticket->set_flightid_bno(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[51]);
    p_ticket->set_session_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[52]);
    p_ticket->set_order_qty_str(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[53]);
    p_ticket->set_return_tickets(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[54]);
    p_ticket->set_throught_lines(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[55]);
    p_ticket->set_wait_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[56]);
    p_ticket->set_to_car_no(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[57]);
    p_ticket->set_back_car_no(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[58]);
    p_ticket->set_to_car_date(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[59]);
    p_ticket->set_bak_car_date(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[60]);
    p_ticket->set_verify_code(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[61]);
    p_ticket->set_expiration_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[62]);
    p_ticket->set_inquiry_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[63]);
    p_ticket->set_operation_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[64]);
    p_ticket->set_uid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[65]);
    p_ticket->set_search_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[66]);
    p_ticket->set_back_time(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[67]);
    p_ticket->set_from_station_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[68]);
    p_ticket->set_to_station_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[69]);
    p_ticket->set_transfer_station_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[71]);
    p_ticket->set_line_no(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[72]);
    p_ticket->set_inorout(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}


//登出类信息提取，并且压入发送队列
void webmail_plugin::logout_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();
    logout_msg* p_logout = p_net->msg->mutable_logout();
    st_http_msg* p_http = p_logout->mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();

    p_net->datalen = 20;
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;
    p_net->msg->set_type(24);

    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }

    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);

    // 碰到有的网站提取不到登出时的用户名，所以注释该判定
    /*if(!get_required_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->from_aissue_access))
      {
      delete p_net->msg;
      delete p_net;
      p_net->msg = NULL;
      p_net = NULL;
      SET_SESSION_OVER(p_session);
      return;
      }*/

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->from_aissue_access);
    p_logout->set_user_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->uid_aissue_access);
    p_logout->set_uid(str_arg);
    cout << "uid:"<< str_arg<< endl;
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->mail_aissue_access);
    p_logout->set_mail(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->nickename_aissue_access);
    if(str_arg.size() > 0)
    {
        int i = 0;
        char p_dest[200] = { 0 };
        if(str_arg[0] == '\"')
        {
            bool ret = del_double_chr((char *)str_arg.c_str(),p_dest);
            if(ret == true)
            {
                str_arg=p_dest;
                str_arg = base64_decode(str_arg.c_str(),str_arg.length(),i);
            }
        }
        p_logout->set_nicke_name(str_arg);
        p_net->datalen += str_arg.size();
    }
    str_arg.clear();
    mail_bcc = "";
    if(p_mail_handle->bcc_aissue_access.size() > 0)
    {
        aissue_data_identity(p_webmail_session,&(p_mail_handle->bcc_aissue_access),&mail_bcc);
        p_net->datalen += mail_bcc.size();
    }

    p_logout -> set_session_id(mail_bcc);
    p_logout -> set_engine_type(p_mail_handle->str_engine);
    p_logout -> set_service_provider(p_mail_handle->str_provider);
    p_logout -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_logout -> set_action(p_mail_handle->str_action);
    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}


//购物类信息提取，并压入发送队列
void webmail_plugin::shop_handle_data(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();
    p_net->msg->set_type(19);
    shop_msg* p_shop = p_net->msg-> mutable_shop();
    st_http_msg* p_http = p_shop -> mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }
    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);
    //debug
    //c2s_http_head_msg c2s_head = p_http -> c2s();
    // cout_c2s_http_head_msg(c2s_head);
    //debug_end
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    string str_arg ("");
    int int_tmp = 0;
    //code_to_charset(p_session);
    p_shop -> set_engine_type(p_mail_handle->str_engine);
    p_shop -> set_service_provider(p_mail_handle->str_provider);
    p_shop -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_shop -> set_action(p_mail_handle->str_action);
    p_shop -> set_board(p_mail_handle->str_board_id);

    if(p_mail_handle->from_aissue_access.size() > 0)
    {
        string str_buy_account;
        aissue_data(p_webmail_session,&(p_mail_handle-> from_aissue_access),&str_buy_account);
        //cout << "search_key:" << str_search_key << endl;
        p_shop->set_buy_account(str_buy_account);
        p_net->datalen += str_buy_account.size();
    }

    if(p_mail_handle->to_aissue_access.size() > 0)
    {
        string str_buy_nickname;
        aissue_data(p_webmail_session,&(p_mail_handle-> to_aissue_access),&str_buy_nickname);
        //cout << "user_name:" << str_user_name << endl;
        p_shop->set_buy_nickname(str_buy_nickname);
        p_net->datalen += str_buy_nickname.size();
    }

    if(p_mail_handle->title_aissue_access.size() > 0)
    {
        string str_sell_account;
        aissue_data(p_webmail_session,&(p_mail_handle-> title_aissue_access),&str_sell_account);
        //cout << "action:" << str_action << endl;
        p_shop->set_sell_account(str_sell_account);
        p_net->datalen += str_sell_account.size();
    }
    if(p_mail_handle->bcc_aissue_access.size() > 0)
    {
        string str_sell_nichname;
        aissue_data(p_webmail_session,&(p_mail_handle-> bcc_aissue_access),&str_sell_nichname);
        //cout << "email:" << str_email << endl;
        p_shop->set_sell_nichname(str_sell_nichname);
        p_net->datalen += str_sell_nichname.size();
    }
    if(p_mail_handle->city_aissue_access.size() > 0)
    {
        string str_mobil;
        aissue_data(p_webmail_session,&(p_mail_handle-> city_aissue_access),&str_mobil);
        //cout << "mobil:" << str_mobil << endl;
        p_shop->set_order_num(str_mobil);
        p_net->datalen += str_mobil.size();
    }

    if(p_mail_handle->uid_aissue_access.size() > 0)
    {
        string str_uid;
        aissue_data(p_webmail_session,&(p_mail_handle-> uid_aissue_access),&str_uid);
        //cout << "mobil:" << str_mobil << endl;
        p_shop->set_uid(str_uid);
        p_net->datalen += str_uid.size();
    }

    if(p_mail_handle->body_aissue_access.size() > 0)
    {
        string str_materials_code;
        aissue_data(p_webmail_session,&(p_mail_handle-> body_aissue_access),&str_materials_code);
        //cout << "uid:" << str_uid << endl;
        p_shop->set_materials_code(str_materials_code);
        p_net->datalen += str_materials_code.size();
    }

    if(p_mail_handle->mail_aissue_access.size() > 0)
    {
        string str_goods_name;
        aissue_data(p_webmail_session,&(p_mail_handle-> mail_aissue_access),&str_goods_name);
        //cout << "session_id:" << str_session_id << endl;
        p_shop->set_goods_name(str_goods_name);
        p_net->datalen += str_goods_name.size();
    }
    if(p_mail_handle->province_aissue_access.size() > 0)
    {
        string str_user_passwd;
        aissue_data(p_webmail_session,&(p_mail_handle->province_aissue_access),&str_user_passwd);
        //cout << "user_passwd:" << str_user_passwd << endl;
        p_shop->set_buyphone(str_user_passwd);
        p_net->datalen += str_user_passwd.size();
    }
    if(p_mail_handle->reg_time_aissue_access.size() > 0)
    {
        string str_content;
        aissue_data(p_webmail_session,&(p_mail_handle-> reg_time_aissue_access),&str_content);
        //cout << "content:" << str_content << endl;
        p_shop->set_buycount(str_content);
        p_net->datalen += str_content.size();
    }
    if(p_mail_handle->sex_aissue_access.size() > 0)
    {
        string str_verify_code;
        aissue_data(p_webmail_session,&(p_mail_handle-> sex_aissue_access),&str_verify_code);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_money(atoi(str_verify_code.c_str()));
        p_net->datalen += str_verify_code.size();
    }
    if(p_mail_handle->history_aissue_access.size() > 0)
    {
        string str_buytime;
        aissue_data(p_webmail_session,&(p_mail_handle-> history_aissue_access),&str_buytime);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_buytime(str_buytime);
        p_net->datalen += str_buytime.size();
    }
    if(p_mail_handle->nickename_aissue_access.size() > 0)
    {
        string str_addresstime;
        aissue_data(p_webmail_session,&(p_mail_handle-> nickename_aissue_access),&str_addresstime);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_addresstime(str_addresstime);
        p_net->datalen += str_addresstime.size();
    }
    if(p_mail_handle->resecret_aissue_access.size() > 0)
    {
        string str_address;
        aissue_data(p_webmail_session,&(p_mail_handle-> resecret_aissue_access),&str_address);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_address(str_address);
        p_net->datalen += str_address.size();
    }
    if(p_mail_handle->education_aissue_access.size() > 0)
    {
        string str_contact_account_type;
        aissue_data(p_webmail_session,&(p_mail_handle-> education_aissue_access),&str_contact_account_type);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_contact_account_type(str_contact_account_type);
        p_net->datalen += str_contact_account_type.size();
    }
    if(p_mail_handle->height_aissue_access.size() > 0)
    {
        string str_contact_account;
        aissue_data(p_webmail_session,&(p_mail_handle-> height_aissue_access),&str_contact_account);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_contact_account(str_contact_account);
        p_net->datalen += str_contact_account.size();
    }
    if(p_mail_handle->married_aissue_access.size() > 0)
    {
        string str_leaveword;
        aissue_data(p_webmail_session,&(p_mail_handle-> married_aissue_access),&str_leaveword);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_leaveword(str_leaveword);
        p_net->datalen += str_leaveword.size();
    }
    if(p_mail_handle->country_aissue_access.size() > 0)
    {
        string str_username;
        aissue_data(p_webmail_session,&(p_mail_handle-> country_aissue_access),&str_username);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_username(str_username);
        p_net->datalen += str_username.size();
    }
    if(p_mail_handle->phone_aissue_access.size() > 0)
    {
        string str_phone;
        aissue_data(p_webmail_session,&(p_mail_handle-> phone_aissue_access),&str_phone);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_phone(str_phone);
        p_net->datalen += str_phone.size();
    }
    if(p_mail_handle->year_aissue_access.size() > 0)
    {
        string str_pickup_certificate_type;
        aissue_data(p_webmail_session,&(p_mail_handle-> year_aissue_access),&str_pickup_certificate_type);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_pickup_certificate_type(str_pickup_certificate_type);
        p_net->datalen += str_pickup_certificate_type.size();
    }
    if(p_mail_handle->month_aissue_access.size() > 0)
    {
        string str_pickup_certificate;
        aissue_data(p_webmail_session,&(p_mail_handle-> month_aissue_access),&str_pickup_certificate);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_pickup_certificate(str_pickup_certificate);
        p_net->datalen += str_pickup_certificate.size();
    }
    if(p_mail_handle->day_aissue_access.size() > 0)
    {
        string str_reg_account_type;
        aissue_data(p_webmail_session,&(p_mail_handle-> day_aissue_access),&str_reg_account_type);
        //cout << "verify:" << str_verify_code << endl;
        p_shop->set_reg_account_type(str_reg_account_type);
        p_net->datalen += str_reg_account_type.size();
    }

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[4]);
    p_shop->set_reg_account(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[5]);
    p_shop->set_pay_account_type(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[6]);
    p_shop->set_pay_account(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[7]);
    p_shop->set_reciever_name(str_arg);
    p_net->datalen += str_arg.size();

    /* str_arg.clear();
       get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[8]);
       p_shop->set_uid(str_arg);
       p_net->datalen += str_arg.size();*/

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[8]);
    p_shop->set_session_id(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[9]);
    p_shop->set_associate(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[10]);
    p_shop->set_email(str_arg);
    p_net->datalen += str_arg.size();

    str_arg.clear();
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[11]);
    p_shop->set_color(str_arg);
    p_net->datalen += str_arg.size();

    //	cout_st_http_msg(*p_http);

    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;

    p_list -> push_back(m_data);
}

// 丹丹修改提取函数
void webmail_plugin::aissue_data_identity(webmail_session * p_webmail_session , aissue_list * p_list , string * p_value)
{
    string tmp ="";
    *p_value = "";
    aissue_list::iterator iter = p_list->begin();
    parse_value_map::iterator it ;
    parse_value * p_parse_value = p_webmail_session ->p_parse_value;
    if(p_parse_value == NULL)
    {
        return;
    }
    for(;iter!=p_list->end();iter ++)
    {
        tmp = *iter;
        it = p_parse_value->value_map.find(tmp);
        // 如果没有该值 
        if(it!= p_parse_value->value_map.end())
        {
            *p_value = it->second;
            get_rid_of_garbled(*p_value, *p_value);
            replace_rule(*p_value);
            return;
        }
    }
}

//超时处理函数
void webmail_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time - p_session->last_packet_time > webmail_time_out *1000000)
    {
        webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
        if(p_webmail_session == NULL)
            return;
        p_webmail_session -> b_end_send = true;
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
    //p_session->last_packet_time = check_time;
}

//求职类信息提取，压入到发送队列
void webmail_plugin::job_data_handle(session* p_session, list<data_interface> * p_list)
{
    data_interface m_data;
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session == NULL)
    {
        return;
    }
    net_str* p_net = new net_str;
    p_net->datalen = 20;
    p_net->msg = new CANmsg;
    p_net->msg->Clear();

    p_net->msg->set_type(21);
    job_msg* p_job = p_net->msg->mutable_job();
    st_http_msg* p_http = p_job->mutable_st_http();
    Comm_msg* p_comm = p_http->mutable_common();
    parse_value* p_parse_value = p_webmail_session->p_parse_value;
    if (p_parse_value == NULL)
    {
        return;
    }
    mail_handle * p_mail_handle = (mail_handle *)p_webmail_session ->p_mail_handle;
    if (p_mail_handle == NULL)
    {
        return;
    }

    p_job -> set_engine_type(p_mail_handle->str_engine);
    p_job -> set_service_provider(p_mail_handle->str_provider);
    p_job -> set_app_id(atoi(p_mail_handle->str_app_id.c_str()));
    p_job -> set_action(p_mail_handle->str_action);
    string str_tmp_tmp ("");
    parse_value_map::iterator iter = p_parse_value->value_map.find("direction_type");
    if(iter != p_parse_value->value_map.end())
    {
        str_tmp_tmp = iter->second;
        p_http->set_direction_type(atoi(str_tmp_tmp.c_str()));
    }

    fill_with_head_info_in_http_msg( p_webmail_session, *p_http, p_net->datalen);

    string str_arg ("");
    int int_tmp = 0;
    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[5]);
    p_job->set_reg_account(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[6]);
    p_job->set_password(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[7]);
    p_job->set_resume_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[8]);
    p_job->set_resume_sex(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[9]);
    p_job->set_resume_certificate_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[10]);
    p_job->set_resume_certificate_code(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[11]);
    p_job->set_resume_mobile(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[12]);
    p_job->set_resume_address(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[13]);
    p_job->set_resume_city(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[14]);
    p_job->set_file_path(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[15]);
    p_job->set_email_account(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[16]);
    p_job->set_resume_date(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[17]);
    p_job->set_session_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[18]);
    p_job->set_usename(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[19]);
    p_job->set_nickname(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[20]);
    p_job->set_birthday(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[21]);
    p_job->set_wrokyear(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[22]);
    p_job->set_location(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[23]);
    p_job->set_resume_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[24]);
    p_job->set_resume_school(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[25]);
    p_job->set_is_full_time(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[26]);
    p_job->set_edu_from_time(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[27]);
    p_job->set_edu_to_time(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[28]);
    p_job->set_edu_degree_input(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[29]);
    p_job->set_edu_major(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[30]);
    p_job->set_edu_detail(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[31]);
    p_job->set_edu_isoverseas(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[32]);
    p_job->set_industry_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[33]);
    p_job->set_issue_date(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[34]);
    p_job->set_provide_salary(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();



    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[35]);
    p_job->set_search_key(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[36]);
    p_job->set_key_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[37]);
    p_job->set_job_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[38]);
    p_job->set_company_size(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[39]);
    p_job->set_company_type(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[40]);
    p_job->set_email(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[41]);
    p_job->set_job_id(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[42]);
    p_job->set_title(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[43]);
    p_job->set_emply(atoi(str_arg.c_str()));
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[44]);
    p_job->set_address(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[45]);
    p_job->set_uid(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    get_optional_str_from_value_map(str_arg, p_session, p_webmail_session, p_mail_handle->aissue_access[46]);
    p_job->set_company_name(str_arg);
    p_net->datalen += str_arg.size();
    str_arg.clear();

    insert_comm_msg(p_session, p_comm);
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);

}
//资源回收
void webmail_plugin::resources_recovery(session * p_session)
{
    webmail_session * p_webmail_session = (webmail_session *)p_session->expansion_data;
    if(p_webmail_session!=NULL)
    {   
        if(p_webmail_session -> p_parse_value != NULL)
            delete p_webmail_session -> p_parse_value;
        p_webmail_session -> p_parse_value = NULL;
        if(p_webmail_session->file_content != NULL) 
            delete  p_webmail_session->file_content  ;
        p_webmail_session->file_content  = NULL;

    }
}

//字符集转换
string webmail_plugin::convertname(string assess_name)
{
    char buf[1024];
    int len = 1024;
    size_t pos = assess_name.find("*=UTF-8''");//sohu邮箱下载附件取文件名的特殊情况
    if(pos != string::npos)
    {
        assess_name.assign(assess_name,pos+9,assess_name.length()-(pos + 9));
    }
    UrlDecode((char *)assess_name.c_str(), assess_name.length(),(char * ) buf , len);
    buf[len] = 0x0;
    assess_name = buf;
    if(assess_name.length() < 6)
    {
        return assess_name;
    }
    if((!assess_name.compare(0,2,"=?",2)) && (!assess_name.compare(assess_name.length()-2,2,"?=",2)) )
    {
        int n;
        n = assess_name.find("?",2);
        if(n ==assess_name.length()-2)
        {
            return assess_name;
        }
        string charset(assess_name,2,n-2);
        int m = assess_name.find("?",n+1);
        if(m ==assess_name.length()-2)
        {
            return assess_name;
        }
        string code(assess_name,n+1,m-n-1);
        string name (assess_name,m+1,assess_name.length()-2-m-1);
        if(code!="B")
        {
            return assess_name;
        }
        int decode_len = 0;
        string decode = base64_decode(name.c_str(), name.length(), decode_len);
        if(charset == "UTF8")
        {
            return decode;
        }
        else
        {
            iconv_t cd;
            char* p_buf = (char*)calloc(1,2*decode.length());
            map<string,iconv_t>::iterator it = iconv_map.find(charset);
            if(it==iconv_map.end())
            {
                cd = iconv_open("utf-8",charset.c_str());
                if ((iconv_t)-1 == cd)
                {
                    return decode;
                }
                iconv_map.insert(pair<string,iconv_t>(charset,cd));
            }
            else
            {
                cd = it->second;
            }
            char* p_dst = p_buf;
            char* p_src = (char*)decode.c_str();
            size_t dst = 2*decode.length();
            size_t src = decode.length();
            iconv(cd, &p_src, &src, &p_dst, &dst);
            string file_name = p_buf;
            free(p_buf);
            return file_name;
        }
    }
    else
    {
        return assess_name;
    }
}



//解码？？？
std::string chineseCharDecode(const std::string& str){
    std::istringstream iss(str);
    std::ostringstream oss;
    char c;
    int v;

    while(1){
        iss>>c;
        if(!iss) break;
        if(c=='&'){
            iss>>c;
            if(!iss) break;
            if(c=='#'){
                iss>>v;
                if(!iss){

                    oss<<"&#";
                    iss.clear();
                    continue;
                }
                iss>>c;
                if(!iss){

                    oss<<"&#"<<v;
                    break;
                }
                if(c==';'){

                    try{
                        oss<<convChar(v,"UTF-8","UTF-16");
                    }
                    catch(...){
                        oss<<"&#"<<v<<c<<";";
                    }
                }
                else{
                    oss<<"&#"<<v<<c;
                }
            }
            else {
                oss<<'&'<<c;
            }
        }
        else oss<<c;
    }
    return oss.str();
}



std::string convChar(uint32_t val,const char* encTo,const char* encFrom){
    iconv_t pt=iconv_open(encTo,encFrom);
    if(pt== (iconv_t)-1){
        return "";
    }
    iconv(pt,NULL,NULL,NULL,NULL);
    uint8_t x[8];
    uint8_t* p=x;
    *(reinterpret_cast<uint16_t*>(p))=0xfeff;
    p+=2;
    *(reinterpret_cast<uint32_t*>(p))=val;
    p+=4;
    *(reinterpret_cast<uint16_t*>(p))=0;
    const char * str=(const char*)x;
    char* out=new char[100];
    size_t b=100;
    const char** in=&str;
    size_t lenin=sizeof(x);
    char* buf=out;
    int ret=iconv(pt,(char**)in,&lenin,&out,&b);
    if(ret){
        //  switch(errno){
        /*case E2BIG:
          delete[] buf;
          break;
          case EILSEQ:
          delete[] buf;
          "been  encountered  in the input.\n");
          break;
          case EINVAL:
          delete[] buf;
          break;*/
        //      default:
        delete[] buf;
        // }
    }
    iconv_close(pt);
    std::string retval(buf);
    delete[] buf;
    return retval;
}

void redis_inint()
{
    if (c_thread_static::p_redis_host == NULL)
    {
        c_thread_static::p_redis_host = new string("");
    }
    xml_parse  xml;
    string npr = getenv("NPR_ROOT");
    string path = npr;
    path +="/conf/webmail_plugin.xml";
    xml.set_file_path(path.c_str());
    char *p_value = (char *)xml.get_value("/config/redis/host");
    if (p_value != NULL)
    {
        *c_thread_static::p_redis_host = p_value;
    }
    p_value = (char *)xml.get_value("/config/redis/port");
    if (p_value != NULL)
    {
        c_thread_static::num_redis_port = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/redis/databaseid");
    if (p_value != NULL)
    {
        c_thread_static::num_redis_id = atoi(p_value);
    }
    p_value = (char *)xml.get_value("/config/redis/timeout");
    if (p_value != NULL)
    {
        c_thread_static::num_webmail_redis_time_out = atoi(p_value);
    }
    if(c_thread_static::p_redis != NULL)
    {
        delete [] c_thread_static::p_redis ;
    }
    c_thread_static::p_redis = new Redis(*c_thread_static::p_redis_host , c_thread_static::num_redis_port);
}

int verifyMsisdn(char* inMsisdn)
{
    int len = strlen(inMsisdn);
    if (11 != len)
    {
        return 1;
    }
    for(int i = 0; i < len; i++)
    {
        if(0 == isdigit(inMsisdn[i]))
        {
            return 2;
        }
    }
    return 0;
}


