// html2txt.h: interface for the CHTML2Txt class.
//
//////////////////////////////////////////////////////////////////////

#ifndef  HTML2TXT_H
#define  HTML2TXT_H

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <ctype.h>
#include <CConvCharSet.h>
#include <strings.h>


class CTransEntity
{
public:
	void ConvertTitle();
	void GetTitleAndCharset(char *pbuff,int len);
	int Convert(char *poutbuf, int &olen, char *pinbuf, int inlen, char* exCharSet);
	void GetEncoding(char *charset);
	void ClearMeta();
	CTransEntity();
	virtual ~CTransEntity();
	int HandleEscapeChar(unsigned char *pbuf,unsigned char *res);
	char m_Title[1024];
	char m_charset[128];
    CConvCharSet cvcharset;
private:
    bool m_bGetTitleOnce;
};

#endif
