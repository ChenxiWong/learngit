// Last Update:2016-11-17 10:39:50
/**
 * @file isakmp_plugin.cpp
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-04-14
 */

#include "isakmp_plugin.h"
#include <commit_tools.h>
#include <sys/stat.h>
//#include "shm_statistics.h"

#define ISAKMP_PORT 500
#define NAT_T_PORT 4500


static bool b_check_config  = true;


extern "C"
{
    int get_plugin_id()
    {
        return 10001;
    }
    protocol_parse_base_handle * attach( attach_info * p)
    {
        p_attach_info = p;
        return new  isakmp_plugin();
    }
}


isakmp_plugin::isakmp_plugin()
{
    data_interface_type = FILESEND;
    isakmp_time_out = 1;
    //msg = NULL;
    reload();
}

isakmp_plugin::~isakmp_plugin()
{
}

void isakmp_plugin::reload()
{
    string tmp = "" ;
    string config_path = getenv("NPR_ROOT");
    config_path += "/conf/isakmp_plugin.xml";
    xml.set_file_path(config_path.c_str());
    char * p_value = (char *)xml.get_value("/config/send_data_type");
    if(p_value != NULL)
    {
        tmp = p_value;
        if(tmp == "file") // 文件接口
        {
            data_interface_type = FILESEND;
        }
        else if(tmp == "net" ) //网络接口
        {
            data_interface_type = NETSEND;
        }
    }
    if(b_check_config)
    {
        b_check_config = false;
        //协议识别
        string path = "/config/DFI";
        int num  = xml.get_value_count(path.c_str());
        for(int i = 0 ; i < num ; i++)
        {
            string xpath = path;
            xml.assemble_path(xpath, i);
            string type_path = xpath;
            type_path +="/type";
            char * value  = (char *)xml.get_value(type_path.c_str());
            int  type = 0 ;
            if(value  != NULL)
            {
                type  = atoi(value);
            }
            type_path = xpath;
            type_path +="/config_path";
            value  = (char *)xml.get_value(type_path.c_str());
            if(value  == NULL)
            {

                continue;
            }

            list<rule_node_offist * > node_list;

            int rule_num = 100 ;
            protocol_identify_string_conf_parse.config_parse (value,&node_list ,&(p_attach_info -> g_p_ac_tree), rule_num);
            list<rule_node_offist * > ::iterator iter = node_list.begin();
            for(;iter != node_list.end(); iter ++)
            {
                rule_node_offist * p = *iter ;
                public_isakmp_feature_rule_map.insert(pair<rule_node_offist *, int>( p , type));
            }
        }
    }

    feature_rule_map = &public_isakmp_feature_rule_map;
    p_value = (char *)xml.get_value("/config/time_out");
    if(p_value != NULL)
    {
        isakmp_time_out = atoi(p_value);
    }
}

void isakmp_plugin::init_isakmp_session(isakmp_session * p_isakmp_session)
{
    //printf("Init isakmp session:%ld\n",sizeof(isakmp_session));
    p_isakmp_session->requst_time = 0;
    p_isakmp_session->response_time = 0;
    p_isakmp_session->pl_info = new list<isakmp_message*>();
    p_isakmp_session->pl_info->clear();
    p_isakmp_session->p_data = NULL;
    p_isakmp_session->data_len = 0;
    p_isakmp_session->status = AGGRE_ISAKMP_BEGIN;
}

void isakmp_plugin::multimode_isakmp_identity(session* p_session, c_packet* p_packet)
{
    if(p_packet -> rule_reulst->get_result_map()->size() == 0)
    {
        return ;
    }
    p_session->is_isakmp = false;
    p_session->is_c2s = false;
    p_session->is_s2c = false;
    uint32_t num_long = ntohl(*((uint32_t*) (p_packet->p_app_data + 24)));
    if( num_long == p_packet->app_data_len)
    {
        p_session->is_isakmp = true;
        return;
    }
    map <rule_node_offist * ,int > ::iterator iter = feature_rule_map->begin();
    for(;iter != feature_rule_map->end();  iter ++)
    {
        if(iter ->first ->rule_cmp(p_packet->rule_reulst->get_result_map(),p_packet -> app_data_len ) )
        {
            if(iter->second == 500)
            {
                p_session->is_isakmp = true;
                break;//暂时不需要判定方向问题
                //continue;
            }
            else if(iter->second == 501)
            {
                p_session->is_c2s = true;
                p_session->is_isakmp = true;
                break;
            }
        }
    }
    return ;
}

bool isakmp_plugin::potocol_identify(session * p_session, c_packet * p_packet)
{
    if(p_packet->b_is_tcp)
    {
        return false;
    }

    multimode_isakmp_identity(p_session, p_packet);
    if(p_session->is_isakmp)
    {
        isakmp_session * p_isakmp_session = (isakmp_session *)p_session->expansion_data;
        init_isakmp_session(p_isakmp_session);
        return true;
    }
    return false;
}

void isakmp_plugin::potocol_sign_judge(session * p_session, c_packet * p_packet)
{
    if(p_session == NULL || p_packet == NULL )
    {
        return;
    }
    /* p_session->packet_len += p_packet->buff_len;
       p_session->packet_num++;

       if(p_session->packet_begin_time == 0)
       {
       p_session->packet_begin_time = p_packet->m_timeval;
       p_session->packet_end_time = p_packet->m_timeval;
       }
       if(p_packet->m_timeval > p_session->packet_end_time )
       {
       p_session->packet_end_time = p_packet->m_timeval;
       }*/
    if(p_packet->b_is_tcp || p_packet->p_app_data == NULL || p_packet->app_data_len == 0)
    {
        return;
    }
    isakmp_session *p_isakmp_session = (isakmp_session *)p_session->expansion_data;
    p_isakmp_session->p_data = (char *)p_packet->p_app_data;
    p_isakmp_session->data_len = p_packet->app_data_len;
    p_isakmp_session->packet_time = p_packet->m_timeval;
    //公共字段提取
    p_session -> m_is_mpls = p_packet -> m_is_mpls;
    p_session -> m_label = p_packet -> m_label;
    p_session -> m_inner_label = p_packet -> m_inner_label;
    p_session -> m_other_lable = p_packet -> m_other_lable;
    //协议确定，过滤ESP数据包
    if(ntohs(p_packet->get_src_port()) == NAT_T_PORT || ntohs(p_packet->get_dst_port()) == NAT_T_PORT)
    {
        if(p_packet->app_data_len < 4)
        {
            return;
        }
        if(*(uint32_t*)(p_packet->p_app_data) != 0x00000000)
        {
            return;
        }
        else
        {
            p_isakmp_session->b_nat = true;
        }
    }
    else
    {
        //p_isakmp_session->b_nat = false;
    }
    //包方向判断
    if((p_packet->get_src_port() == p_session->srcport) && (p_packet->get_src_ip() == p_session->srcip))
    {
        p_isakmp_session->b_pkt_direction = true;
    }
    else
    {
        p_isakmp_session->b_pkt_direction = false;
    }
    SET_EXPORT(p_session);
    return;
}

void isakmp_plugin::pococol_parse_handle(session * p_session)
{
    isakmp_session * p_isakmp_session = (isakmp_session *)p_session->expansion_data;
    if(p_isakmp_session->p_data == NULL || p_isakmp_session->data_len == 0)
    {
        return;
    }
    //解析数据包的内容
    isakmp_message *p_isakmp_message = new isakmp_message(p_isakmp_session->packet_time, p_isakmp_session->b_pkt_direction);
    if(p_isakmp_message->data_parse(p_isakmp_session->p_data, p_isakmp_session->data_len,p_isakmp_session->status))
    {
        //当message链表空时，只对含有SA载荷的消息进行缓存
        if(p_isakmp_session->pl_info->empty() && p_isakmp_message->header.next_payload != SECURITY_ASSOCIATION_PAYLOAD &&p_isakmp_message->header.next_payload != KEY_EXCHANGE_PAYLOAD &&p_isakmp_message->header.next_payload !=NONCE_PAYLOAD && p_isakmp_message->header.next_payload != IDENTIFICATION_PAYLOAD )
        {
            //SET_SESSION_OVER(p_session);
            delete p_isakmp_message;
        }
        else
        {
            p_isakmp_session->pl_info->push_back(p_isakmp_message);
        }
        //由于只需要取SA载荷的相关消息，所以在收到含有KEY_EXCHANGE_PAYLOAD和IDENTIFICATION_PAYLOAD的消息时session即可结束
        //if(p_isakmp_message->header.next_payload == KEY_EXCHANGE_PAYLOAD || p_isakmp_message->header.next_payload == IDENTIFICATION_PAYLOAD)
       /* if(ntohl(p_isakmp_message->header.message_id)==1)
        {
            SET_SESSION_OVER(p_session);
        }*/
        if(p_isakmp_session->status == AGGRE_ISAKMP_END ||(p_isakmp_message->header.next_payload == IDENTIFICATION_PAYLOAD && p_isakmp_message->header.exchange_type == 2))
        {
            p_isakmp_session->status = AGGRE_ISAKMP_BEGIN ;
            SET_SESSION_OVER(p_session);
        }
    }
    else
    {
       if(p_isakmp_message->header.next_payload == IDENTIFICATION_PAYLOAD && p_isakmp_message->header.exchange_type == 2)
        {
            p_isakmp_session->status = AGGRE_ISAKMP_BEGIN ;
            SET_SESSION_OVER(p_session);
        }
        delete p_isakmp_message;
    }
    if(IS_SESSION_OVER(p_session))              //session结束时统一输出
    {
        p_session->send_len = 1;
        p_session->p_send_buf = NO_NULL;
    }
    else
    {
        p_session->send_len = 0;
        p_session->p_send_buf = NULL;
    }

    p_isakmp_session->p_data = NULL;
    p_isakmp_session->data_len = 0;
    p_isakmp_session->b_pkt_direction = false;
    p_isakmp_session->packet_time = 0;
}

void isakmp_plugin::potocol_data_handle(session* p_session, list<data_interface> * p_list)
{
    int is_ipv6 ;
    int is_ipv4 ;
    uint32_t busy_time = 0;

    isakmp_session * p_isakmp_session = (isakmp_session *)p_session->expansion_data;
    if(p_isakmp_session->pl_info->empty())
    {
        return;
    }
    //isakmp_output_interface output_interface;
    output_interface.init();
    //数据流方向初步判断（单向or双向）
    list<isakmp_message*>::iterator iter = p_isakmp_session->pl_info->begin();
    if(p_isakmp_session->pl_info->size() > 1)
    {
        bool msg_direction = (*iter)->b_direction;
        //output_interface.direction = 0;
        for(;iter != p_isakmp_session->pl_info->end(); ++iter)
        {
            if((*iter)->b_direction != msg_direction)
            {
                output_interface.direction = 3;    //双向
                break;
            }
        }
    }
    //双向流，找到服务端发送的含有SA载荷的消息进行处理，如果没有，则处理最后一个含有SA载荷的消息
    if(output_interface.direction == 3)
    {
        for(iter = p_isakmp_session->pl_info->begin(); iter != p_isakmp_session->pl_info->end(); ++iter)
        {
            if((*iter)->header.next_payload == SECURITY_ASSOCIATION_PAYLOAD && (*iter)->header.initiator_cookie != 0 && (*iter)->header.responder_cookie != 0)
                //if((*iter)->header.message_id != 1 && (*iter)->header.initiator_cookie != 0 && (*iter)->header.responder_cookie != 0)
            {
                output_interface.message_handling(*iter, p_session);
                break;
            }
        }
        if(iter == p_isakmp_session->pl_info->end())
        {
            for(; iter != p_isakmp_session->pl_info->begin();)
            {
                --iter;
                if((*iter)->header.next_payload == SECURITY_ASSOCIATION_PAYLOAD)
                    //if((*iter)->header.message_id != 0)
                {
                    output_interface.message_handling(*iter, p_session);
                    break;
                }
            }
        }
    }
    //单向流，处理最后message链表里最后一条含有SA载荷的消息
    else
    {
        for(iter = p_isakmp_session->pl_info->end(); iter != p_isakmp_session->pl_info->begin();)
        {
            --iter;
            if((*iter)->header.next_payload == SECURITY_ASSOCIATION_PAYLOAD)
            {
                output_interface.message_handling(*iter, p_session);
                break;
            }
        }
    }
    for(iter = p_isakmp_session->pl_info->end(); iter != p_isakmp_session->pl_info->begin();)
    {
        --iter;
        if((*iter)->header.next_payload == KEY_EXCHANGE_PAYLOAD)
        {
            output_interface.message_handling(*iter, p_session);
            break;
        }
    }
    for(iter = p_isakmp_session->pl_info->end(); iter != p_isakmp_session->pl_info->begin();)
    {
        --iter;
        if((*iter)->header.next_payload == IDENTIFICATION_PAYLOAD)
        {
            output_interface.message_handling(*iter, p_session);
            break;
        }
    }
    //取session开始的时间
    iter = p_isakmp_session->pl_info->begin();
    output_interface.time = (*iter)->packet_time;
    //计算通信速率
    /* if(p_isakmp_session->pl_info->size() > 1)
       {
       uint64_t total_throughput = 0;
       for(iter = p_isakmp_session->pl_info->begin(); iter != p_isakmp_session->pl_info->end(); ++iter)
       {
       total_throughput += ntohl((*iter)->header.length);
       }
       uint64_t session_duration = ((*(p_isakmp_session->pl_info->rbegin()))->packet_time - (*(p_isakmp_session->pl_info->begin()))->packet_time);
       if(session_duration != 0)
       {
       output_interface.communication_rate = (double)total_throughput / session_duration;
       }
       else
       {
       output_interface.communication_rate = 0.000001;
       }

       }
       else
       {
       output_interface.communication_rate = 0.000001;
       }*/
    double session_duration = (double)(p_session->packet_end_time - p_session->packet_begin_time);
    if (session_duration != 0)
    {
        //output_interface.communication_rate = ((double)total_throughput / session_duration)*1000000;
        output_interface.communication_rate = ((double)p_session->packet_len / session_duration)*1000000;
    }
    else
    {
        output_interface.communication_rate = 1; 
    }

    //add new common header
    classify_ip_kind_info(p_session->srcip.ip_str(), is_ipv6, is_ipv4);
    output_interface.is_ipv4 = is_ipv4;
    output_interface.is_ipv6 = is_ipv6;
    output_interface.is_mpls = p_session->m_is_mpls;
    output_interface.n_label = p_session->m_label;
    output_interface.in_nerlabel = p_session->m_inner_label;
    output_interface.other_label = p_session->m_other_lable;
    output_interface.proto = p_session->proto_type;
    output_interface.total_payloadbytes = p_session->packet_len;
    output_interface.total_payloadpackets = p_session->packet_num;
    if(p_session->packet_end_time > p_session->packet_begin_time)
    {
        busy_time = p_session->packet_end_time - p_session->packet_begin_time;
    }
    else
    {
        busy_time = 0;
    }
    output_interface.duration = busy_time;
    //将数据加入接口
    isakmp_interface_handling(p_list);
    p_session->send_len = 0;
    p_session->p_send_buf = NULL;
    return;
    /*
       isakmp_session * p_isakmp_session = (isakmp_session *)p_session->expansion_data;
       data_interface m_data ;
    // 根据解析的数据来判定文件后缀
    if(data_interface_type  == FILESEND )
    {
    if(p_session->send_len != 0 && p_session->p_send_buf != NULL)
    {
    m_data.b_out_type = FILESEND;

    string requst_time;
    DNUMTOSTR(p_isakmp_session->requst_time, requst_time);
    struct timeval tv ;
    gettimeofday(&tv, NULL);
    uint64_t u64_time = tv.tv_sec * 100000 + tv.tv_sec;

    if(file_path.empty())
    {
    // 文件相对路径
    file_path = "/";
    file_path += get_year_month();
    file_path += get_day_hour();
    file_path += get_min_sec();

    file_name = date_time();
    file_name += "-";
    file_name += requst_time;
    begin_time = u64_time;
    file_data= "";
    row = 0;
    file_str = new w_file_str;
    }

    file_str->finished = false;
    if(row==max_row || u64_time-begin_time > max_time_scr * 100000) 
    {
    file_str->finished = true;
    }

    string isakmp_file_name = file_name;
    isakmp_file_name += ".isakmp";
    file_str->file_path = file_path;
    file_str->file_name.swap(isakmp_file_name);

    // 申请内存存储数据，写文件后自动析构
    {
    if(row > 0)
    file_data +="\n[isakmp]\n";
    else
    file_data +="[isakmp]\n";

    row ++;
    // 拷贝数据 
    requst_time = date_time3(p_isakmp_session->requst_time);
    file_data += requst_time;
    file_data += "\n";
    // 用户名和密码 
    file_data += *(p_isakmp_session->username);
    file_data += "\n";
    file_data += *(p_isakmp_session->passwd);
    file_data += "\n";

    if(p_session -> b_src_is_ser) 
    {
    // 客户端 IP 
    file_data += p_session->dstip.ip_str();
    file_data += ":";
    string dst_port;
    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
    file_data += dst_port;
    file_data += "\n";
    // isakmp IP
    file_data += p_session->srcip.ip_str();
    file_data += ":";
    string src_port;
    DNUMTOSTR(ntohs(p_session->srcport), src_port);
    file_data += src_port;
    file_data += "\n";
}
else
{
    // 客户端 IP 
    file_data += p_session->srcip.ip_str();
    file_data += ":";
    string src_port;
    DNUMTOSTR(ntohs(p_session->srcport), src_port);
    file_data += src_port;
    file_data += "\n";
    // isakmp IP
    file_data += p_session->dstip.ip_str();
    file_data += ":";
    string dst_port;
    DNUMTOSTR(ntohs(p_session->dstport), dst_port);
    file_data += dst_port;
    file_data += "\n";
}

if(!file_str->finished)
{
    if(file_data.length() < 1024*1024 )
    {
        return;
    }
    else
    {
        file_str->finished = true;
    }
}

if(file_str->finished)
{
    char * isakmp_file_data = new char[file_data.length()+1];
    strcpy(isakmp_file_data,file_data.c_str());
    file_str->file_data = isakmp_file_data;
    file_str->datalen = file_data.length();
}
}

m_data.data = file_str;
p_list -> push_back(m_data);
if(file_str->finished)
{
    file_path = "";
    file_name = "";
    begin_time = u64_time;
}
}
}
else if (data_interface_type == NETSEND)
{
    if((*p_isakmp_session->username).empty() || (*p_isakmp_session->passwd).empty())
        return;

    net_str * p_net =  new  net_str;
    p_net -> msg = new CAmsg;
    p_net->msg->Clear();
    // 设置 
    p_net->msg->set_type(3); // isakmp

    isakmp_message* p_isakmp = p_net->msg->mutable_isakmp();
    Comm_msg* p_comm =  p_isakmp -> mutable_comm_msg();
    // 公共 消息 

    if(p_session -> b_src_is_ser) 
    {
        p_comm ->set_src_port(ntohs(p_session->dstport));
        p_comm ->set_dst_ip(p_session->srcip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->srcport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->dstip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_srcip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_dstip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->dstip.ip_str());
        }
    }
    else
    {
        p_comm ->set_src_port(ntohs(p_session->srcport));
        p_comm ->set_dst_ip(p_session->dstip.ip_str());
        p_comm ->set_dst_port(ntohs(p_session->dstport));
        if(p_session->b_vpn)        //VPN消息
        {
            p_comm ->set_vpn_src_ip(p_session->srcip.ip_str());
            p_comm ->set_vpn_dst_ip(p_session->vpn_dstip.ip_str());
            p_comm ->set_src_ip(p_session->vpn_srcip.ip_str());
        }
        else
        {
            p_comm ->set_src_ip(p_session->srcip.ip_str());
        }
    }
    p_comm ->set_time(p_isakmp_session->requst_time);
    //  域名 
    string user_name = *p_isakmp_session->username;
    string user_pass = *p_isakmp_session->passwd;

    p_attach_info -> p_protocal -> PotocolStatistics(3,1,0,1);
    // 去除乱码
    //erase_not_ascii(user_name);
    //erase_not_ascii(user_pass);

    p_isakmp->set_username(user_name);
    p_isakmp->set_password(user_pass);
    //p_isakmp->set_is_valid(p_isakmp_session->b_available);
    if (p_isakmp_session->b_available)
    {
        p_isakmp->set_is_valid(2);
    }
    else
    {
        p_isakmp->set_is_valid(1);
    }
    p_net->datalen = 20 + user_name.length() + user_pass.length();
    // 接口 
    m_data.b_out_type = NETSEND;
    m_data.data = p_net;
    p_list -> push_back(m_data);
}

p_session->send_len = 0;
p_session->p_send_buf = NULL;
p_session->client.clear_buf();
SET_SESSION_OVER(p_session);
*/
}

void isakmp_plugin::time_out(session * p_session, uint64_t check_time)
{
    if(check_time-p_session->last_packet_time > isakmp_time_out *1000000)
    {
        // 开始超时处理
        //  printf("ISAKMP session time out!\n");
        SET_EXPORT(p_session);
        SET_SESSION_OVER(p_session);
    }
    return;
}

void isakmp_plugin::resources_recovery(session * p_session)
{
    isakmp_session * p_isakmp_session = (isakmp_session *)p_session->expansion_data;
    //  p_isakmp_session->display_isakmp_message_list();
    list<isakmp_message*>::iterator iter = p_isakmp_session->pl_info->begin();
    for(;iter != p_isakmp_session->pl_info->end(); ++iter)
    {
        delete *iter;
    }
    p_isakmp_session->pl_info->clear();
    delete p_isakmp_session->pl_info;
    return;
}

//Summary:  ISAKMP插件接口数据处理函数
//Parameters:
//       p_list: 数据接口链表指针
//Return : 无
void isakmp_plugin::isakmp_interface_handling(list<data_interface> *p_list)
{
    data_interface m_data;
    if(data_interface_type == NETSEND)
    {
        net_str * p_net = new net_str;
        p_net->msg = new CAmsg;
        p_net->msg->Clear();
        p_net->msg->set_type(27); // isakmp

        isakmp_msg* p_isakmp = p_net->msg->mutable_isakmp();
        Comm_msg* p_comm = p_isakmp->mutable_comm_msg();
        //公共消息
        p_comm ->set_src_ip(output_interface.client_ip.ip_str());
        p_comm ->set_src_port(ntohs(output_interface.client_port));
        p_comm ->set_dst_ip(output_interface.server_ip.ip_str());
        p_comm ->set_dst_port(ntohs(output_interface.server_port));
        p_comm ->set_time(output_interface.time);

        p_comm ->set_line_num(output_interface.mac_line_num);
        p_comm ->set_dev_num(output_interface.device_num);

        //cout << "@@@@@@@@@@@@@@@@@@@@@@@@@@@line_number:"<< output_interface.time << endl;
        p_comm->set_is_ipv4(output_interface.is_ipv4);
        p_comm->set_is_ipv6(output_interface.is_ipv6);
        p_comm->set_proto(output_interface.proto);
        p_comm->set_link_layer_type(0);
        p_comm ->set_is_mpls(output_interface.is_mpls);
        p_comm ->set_n_label(output_interface.n_label);
        p_comm ->set_inner_label(output_interface.in_nerlabel);
        p_comm ->set_other_label(output_interface.other_label);
        p_comm ->set_total_pay_load_bytes(output_interface.total_payloadbytes);
        p_comm ->set_tatal_pay_load_packets(output_interface.total_payloadpackets);
        p_comm ->set_duration(output_interface.duration);

        //ISAKMP消息
        p_isakmp->set_protocol_family(1210003);
        p_isakmp->set_communication_rate(output_interface.communication_rate);
        p_isakmp->set_direction(output_interface.direction);
        //p_isakmp->set_init_respond_cookie(output_interface.init_respond_cookie);
        p_isakmp->set_initiator_cookie(output_interface.initiator_cookie);
        p_isakmp->set_responder_cookie(output_interface.responder_cookie);
        p_isakmp->set_protocol_version(output_interface.protocol_version);
        p_isakmp->set_exchange_type(output_interface.exchange_type);
        p_isakmp->set_b_sa_payload(output_interface.b_sa_payload);
        p_isakmp->set_b_cookie_zero(output_interface.b_cookie);
        p_isakmp->set_b_nat(output_interface.b_nat);
        if(output_interface.key_exchange_data!="")
        {
            p_isakmp->set_key_exchange_data(output_interface.key_exchange_data);
        }
        if(output_interface.nonce_data!="")
        {
            p_isakmp->set_nonce_data(output_interface.nonce_data);
        }
        p_isakmp->set_identification_id_type(output_interface.identification_id_type);
        if(output_interface.identification_data!="")
        {
            p_isakmp->set_identification_data(output_interface.identification_data);
        }
        set<uint32_t>::iterator iter;
        for(iter = output_interface.s_encryption_algorithm.begin(); iter != output_interface.s_encryption_algorithm.end(); ++iter)
        {
            p_isakmp->add_encryption_algorithm(*iter);
        }
        for(iter = output_interface.s_hash_algorithm.begin(); iter != output_interface.s_hash_algorithm.end(); ++iter)
        {
            p_isakmp->add_hash_algorithm(*iter);
        }

        for(iter = output_interface.s_group_destription.begin(); iter != output_interface.s_group_destription.end(); ++iter)
        {
            p_isakmp->add_group_destription(*iter);
        }

        for(iter = output_interface.s_authentication_method.begin(); iter != output_interface.s_authentication_method.end(); ++iter)
        {
            p_isakmp->add_authentication_method(*iter);
        }
        for(iter = output_interface.s_life_type.begin(); iter != output_interface.s_life_type.end(); ++iter)
        {
            p_isakmp->add_life_type(*iter);
        }
        for(iter = output_interface.s_life_duration.begin(); iter != output_interface.s_life_duration.end(); ++iter)
        {
            p_isakmp->add_life_duration(*iter);
        }

        list<isakmp_payload*>::iterator iter_l;
        for(iter_l = output_interface.l_vendor_id_payload.begin(); iter_l != output_interface.l_vendor_id_payload.end(); ++iter_l)
        {
            p_isakmp->add_vendor_id((*iter_l)->p_data, (*iter_l)->data_len);
        }
        if(output_interface.transform_data!="")
        {
            p_isakmp->set_transform_data(output_interface.transform_data);
        }
        //p_net->datalen = 20 + user_name.length() + user_pass.length();
        // 接口
        m_data.b_out_type = NETSEND;
        m_data.data = p_net;
        p_list -> push_back(m_data);
    }
    return;
}




//Summary:  ISAKMP消息解析函数
//Parameters:
//       p_data: ISAKMP数据包数据内容头指针.
//       data_len: 数据长度
//Return : true:解析成功，false：解析失败
bool isakmp_message::data_parse(const char* p_data, int16_t data_len, int& status)
{
    //printf("isakmp header length:%ld\n",sizeof(isakmp_message_header));
    //解析消息头
    int64_t len = 0;
    if(ntohl(*(uint32_t *)p_data)== 0)
    {
        p_data += 4;
    }


    if(b_nat)
    {
        if(data_len < (int16_t)(sizeof(isakmp_message_header) + 4) )
        {
            return false;
        }
        else
        {
            header = *(isakmp_message_header*)(p_data+4);
            p_data += sizeof(isakmp_message_header) + 4;
            data_len -= sizeof(isakmp_message_header) + 4;
        }
    }
    else
    {
        if(data_len < (int16_t)(sizeof(isakmp_message_header)))
        {
            return false;
        }
        else
        {
            header = *(isakmp_message_header*)p_data;
            p_data += sizeof(isakmp_message_header);
            data_len -= sizeof(isakmp_message_header);
        }
    }
    len = (int64_t)ntohl(header.length);
    //解析载荷
    //if((!payload_encrypted()) && (!is_ikev2()) && ((int64_t)data_len < (int64_t)ntohl(header.length)))                    //根据消息头判断后续载荷是否加密且不为IKEV2协议（目前暂不支持IKEV2协议）
    if((!is_ikev2()) && (((int64_t)data_len + sizeof(isakmp_message_header)) >=len))               //根据消息头判断后续载荷是否加密且不为IKEV2协议（目前暂不支持IKEV2协议）
    {
        uint8_t payload_type = header.next_payload;
        uint8_t exchange_type = header.exchange_type;
        while(payload_type != 0)
        {
            //解析通用载荷头 RFC2408 P25
            if(data_len < 4)
            {
                return false;
            }
            if(!payload_encrypted())
            {
                uint8_t next_payload = *p_data;
                int16_t payload_length = ntohs(*(int16_t*)(p_data+2));
                if(payload_length < 0 ||data_len < payload_length)
                {
                    return false;
                }
                //解析载荷内容
                if(!payload_parse(p_data+4, payload_length-4, payload_type,exchange_type))
                {
                    return false;
                }
                if(payload_type == 13 && next_payload == 0 && exchange_type == 4)
                {
                status = AGGRE_ISAKMP_END;
                }
                payload_type = next_payload;
                p_data += payload_length;
                data_len -= payload_length;
            }
            else
            {
                if(!payload_parse(p_data,len-sizeof(isakmp_message_header), payload_type,exchange_type))
                {
                    return false;
                }
                break;
            }
        }
    }
    else
    {
        return false;
    }
    return true;
}


//Summary:  ISAKMP载荷解析函数
//Parameters:
//       p_data: ISAKMP载荷数据头指针.
//       data_len: 载荷数据长度
//       payload_type: 载荷类型，见宏定义
//Return : true:解析成功，false：解析失败
bool isakmp_message::payload_parse(const char* p_data, int16_t data_len, uint8_t payload_type,uint8_t exchange_type)
{
    isakmp_payload* p_payload = NULL;
    switch(payload_type)
    {
        case SECURITY_ASSOCIATION_PAYLOAD:
            p_payload = security_association_payload_parse(p_data, data_len);
            if(p_payload == NULL)
            {
                return false;
            }
            break;
            //case PROPOSAL_PAYLOAD:
            //    break;
            //case TRANSFORM_PAYLOAD:
            //    break;
        case KEY_EXCHANGE_PAYLOAD:
            p_payload = key_exchange_payload_parse(p_data,data_len);
            if(p_payload == NULL)
            {
                return false;
            }
            break;

        case NONCE_PAYLOAD:
            p_payload = nonce_payload_parse(p_data,data_len);
            if(p_payload == NULL)
            {
                return false;
            }
            break;
        case VENDOR_ID_PAYLOAD:
        case NAT_DISCOVERY_PAYLOAD:
            p_payload = general_payload_parse(p_data, data_len, payload_type);
            if(p_payload == NULL)
            {
                return false;
            }
            break;
        case IDENTIFICATION_PAYLOAD:
            p_payload = identification_payload_parse(p_data,data_len,exchange_type);
           /* if(p_payload == NULL)
            {
                return false;
            }*/
            break;
        case CERTIFICATE_PAYLOAD:
        case CERTIFICATE_REQUEST_PAYLOAD:
        case HASH_PAYLOAD:
        case SIGNATURE_PAYLOAD:
        case NOTIFICATION_PAYLOAD:
        case DELETE_PAYLOAD:
        case NATD_PAYLOAD:
            break;
        default:
            //printf("Unidentified payload type:%d!\n",payload_type);
            return false;
    }
    if(p_payload == NULL&&payload_type!=HASH_PAYLOAD&&payload_type!=CERTIFICATE_REQUEST_PAYLOAD&&payload_type!=NATD_PAYLOAD)
    {

        return false;
    }
    l_payload.push_back(p_payload);
    return true;
}

//Summary:  security_association_payload解析函数，格式详见RFC2408 P27
//Parameters:
//       p_data: 数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，返回一个指向security_association_payload的指针；若解析失败失败，则返回NULL
security_association_payload* isakmp_message::security_association_payload_parse(const char* p_data, int16_t data_len)
{
    if(data_len < 8)
    {
        return NULL;
    }
    security_association_payload *p_security_association_payload = new security_association_payload();
    p_security_association_payload->domain_of_interpretation = ntohl(*(uint32_t*)p_data);
    p_security_association_payload->situation = ntohl(*(uint32_t*)(p_data+4));
    //uint32_t domain_of_interpretation = ntohl(*(uint32_t*)p_data);
    //printf("DOI:%d\n",domain_of_interpretation);
    //uint32_t situation = ntohl(*(uint32_t*)(p_data+4));
    //printf("Situation:%d\n",situation);
    if((p_security_association_payload->situation & 0x06) != 0)    //目前版本不支持situation标志中secrecy与integrity标志位为1时的解析
    {
        delete p_security_association_payload;
        return NULL;
    }
    p_data += 8;
    data_len -= 8;

    //解析proposal载荷
    uint8_t payload_type = PROPOSAL_PAYLOAD;
    proposal_payload *p_proposal_payload = NULL;
    while(payload_type == PROPOSAL_PAYLOAD)
    {
        if(data_len < 4)
        {
            delete p_security_association_payload;
            return NULL;
        }
        uint8_t next_payload = *p_data;
        int16_t payload_length = ntohs(*(int16_t*)(p_data+2));
        if(payload_length < 0 ||data_len < payload_length)
        {
            delete p_security_association_payload;
            return NULL;
        }
        p_proposal_payload = proposal_payload_parse(p_data, payload_length);
        if(p_proposal_payload == NULL)
        {
            delete p_security_association_payload;
            return NULL;
        }
        p_security_association_payload->l_p_payload.push_back(p_proposal_payload);
        payload_type = next_payload;
        p_data += payload_length;
        data_len -= payload_length;
    }
    return p_security_association_payload;
}

key_exchange_payload* isakmp_message::key_exchange_payload_parse(const char* p_data, int16_t data_len)
{
    if(data_len < 0||p_data+data_len==NULL)
    {
        return NULL;
    }
    key_exchange_payload *p_key_exchange_payload = new key_exchange_payload();
    p_key_exchange_payload->key_exchange_data_length = data_len;
    p_key_exchange_payload->key_exchange_data = new char[data_len];
    memset(p_key_exchange_payload->key_exchange_data,0x00,data_len);
    memcpy(p_key_exchange_payload->key_exchange_data,p_data,data_len);
    return p_key_exchange_payload;
}
nonce_payload* isakmp_message::nonce_payload_parse(const char* p_data, int16_t data_len)
{
    if(data_len < 0||p_data+data_len==NULL)
    {
        return NULL;
    }
    nonce_payload *p_nonce_payload = new nonce_payload();
    p_nonce_payload->nonce_data_length = data_len;
    p_nonce_payload->nonce_data = new char[data_len];
    memset(p_nonce_payload->nonce_data,0x00,data_len);
    memcpy(p_nonce_payload->nonce_data,p_data,data_len);
    return p_nonce_payload;
}
identification_payload* isakmp_message::identification_payload_parse(const char* p_data, int16_t data_len,uint8_t exchange_type)
{
    if(data_len < 0||p_data + data_len==NULL||exchange_type == 2)
    {
        return NULL;
    }
    identification_payload *p_identification_payload = new identification_payload();
    if((*(p_data+1)==17)&&(ntohs(*(uint16_t *)(p_data+2)))==500)
    {
        p_identification_payload->identification_id_type = *p_data;
        p_identification_payload->identification_data_length = data_len-4;
        p_identification_payload->identification_data = new char[data_len-4];
        memset(p_identification_payload->identification_data,0x00,data_len-4);
        memcpy(p_identification_payload->identification_data,p_data+4,data_len-4);
    }
    else
    {
        p_identification_payload->identification_data_length = data_len;
        p_identification_payload->identification_data = new char[data_len];
        memset(p_identification_payload->identification_data,0x00,data_len);
        memcpy(p_identification_payload->identification_data,p_data,data_len);
    }
    return p_identification_payload;
}
//Summary: proposal_payload解析函数,，格式详见RFC2408 P28
//Parameters:
//       p_data: 数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，返回一个指向proposal_payload的指针；若解析失败失败，则返回NULL
proposal_payload* isakmp_message::proposal_payload_parse(const char* p_data, int16_t data_len)
{
    if(data_len <4)
    {
        return NULL;
    }
    proposal_payload *p_proposal_payload = new proposal_payload();
    p_proposal_payload->proposal_number = *(p_data+4);
    p_proposal_payload->protocol_id = *(p_data+5);
    p_proposal_payload->spi_size = *(p_data+6);
    p_proposal_payload->total_transforms = *(p_data+7);
    if(p_proposal_payload->total_transforms !=1)
    {
        p_proposal_payload ->transform_data_len = ntohs(*(uint16_t *)(p_data+2));
        p_proposal_payload ->transform_data = new char[p_proposal_payload ->transform_data_len];
        memset(p_proposal_payload->transform_data,0x00,p_proposal_payload ->transform_data_len);
        memcpy(p_proposal_payload->transform_data,p_data,p_proposal_payload->transform_data_len);
    }
    //uint8_t proposal_number = *p_data;
    //uint8_t protocol_id = *(p_data+1);
    //uint8_t spi_size = *(p_data+2);
    //uint8_t total_transforms = *(p_data+3);
    //printf("Proposal number:%d, protocol ID:%d, Total tranforms:%d\n",proposal_number, protocol_id, total_transforms);
    data_len -= 8;
    p_data += 8;
    if(p_proposal_payload->spi_size!=0)
    {
        if(data_len < p_proposal_payload->spi_size)
        {
            delete p_proposal_payload;
            return NULL;
        }
        data_len -= p_proposal_payload->spi_size;
        p_data += p_proposal_payload->spi_size;
    }
    uint8_t payload_type = TRANSFORM_PAYLOAD;
    transform_payload* p_transform_payload = NULL;
    //while(payload_type == TRANSFORM_PAYLOAD)
    if(payload_type == TRANSFORM_PAYLOAD)
    {
        if(data_len < 4)
        {
            delete p_proposal_payload;
            return NULL;
        }
        uint8_t next_payload = *p_data;
        int16_t payload_length = ntohs(*(int16_t*)(p_data+2));
        if(payload_length < 0 ||data_len < payload_length)
        {
            delete p_proposal_payload;
            return NULL;
        }
        p_transform_payload = transform_payload_parse(p_data+4, payload_length-4);
        if(p_transform_payload == NULL)
        {
            delete p_proposal_payload;
            return NULL;
        }
        p_proposal_payload->l_t_payload.push_back(p_transform_payload);
        payload_type = next_payload;
        p_data += payload_length;
        data_len -= payload_length;
    }
    return p_proposal_payload;
}

//Summary:  transform_payload解析函数，格式详见RFC2408 P30
//Parameters:
//       p_data: 数据内容头指针.
//       data_len: 数据长度
//Return : 若解析成功，返回一个指向transform_payload的指针；若解析失败失败，则返回NULL
transform_payload* isakmp_message::transform_payload_parse(const char* p_data, int16_t data_len)
{
    if(data_len <4)
    {
        return NULL;
    }
    transform_payload *p_transform_payload = new transform_payload();
    p_transform_payload->transform_num = *p_data;
    p_transform_payload->transform_id = *(p_data+1);
    //uint8_t transform_num = *p_data;
    //uint8_t transform_id = *(p_data+1);
    //printf("Transform num:%d, transform id:%d\n",transform_num, transform_id);
    p_data += 4;
    data_len -= 4;
    uint16_t attribute_type;
    //uint16_t value;
    uint16_t attribute_length;
    while(data_len > 0)
    {
        if(data_len <4)
        {
            delete p_transform_payload;
            return NULL;
        }
        attribute_type = ntohs(*(uint16_t*)p_data);
        if((attribute_type & 0x8000) == 0)
        {
            //TLV
            attribute_length =  ntohs(*(uint16_t*)(p_data+2));
            if(data_len < attribute_length+4)
            {
                delete p_transform_payload;
                return NULL;
            }
            char *p_value = new char[attribute_length];
            memcpy(p_value, p_data+4, attribute_length);
            data_len -= 4 + attribute_length;
            p_data += 4 + attribute_length;
            data_attributes *p_data_attributes = new data_attributes((attribute_type & (0x7FFF)), attribute_length, p_value);
            p_transform_payload->l_attributes.push_back(p_data_attributes);
            //p_transform_payload->l_attributes.push_back(data_attributes((attribute_type & (0x7FFF)), attribute_length, p_value));
            //printf("Type:%d, Length:%d, Value:\n",(attribute_type & (0x7FFF)), attribute_length);
        }
        else
        {
            //TV
            //uint16_t *p_value =  (uint16_t*)malloc(sizeof(uint16_t));
            char* p_value = new char[2];
            memcpy(p_value, p_data+2,2);
            //*(uint16_t*)p_value = (uint16_t)ntohs(*(uint16_t*)(p_data+2));
            data_len -= 4;
            p_data += 4;
            data_attributes *p_data_attributes = new data_attributes((attribute_type & (0x7FFF)), 2, p_value);
            p_transform_payload->l_attributes.push_back(p_data_attributes);
            //p_transform_payload->l_attributes.push_back(data_attributes((attribute_type & (0x7FFF)), 2, p_value));
            //printf("Type:%d, Value:%d\n",(attribute_type & (0x7FFF)), *p_value);
        }
    }
    return p_transform_payload;
}

//Summary:  一般载荷解析函数(取出长度，拷贝出数据内容)
//Parameters:
//       p_data: 数据内容头指针.
//       data_len: 数据长度
//       payload_type: 载荷类型
//Return : 返回一个指向isakmp_payload的指针
isakmp_payload* isakmp_message::general_payload_parse(const char* p_data, int16_t data_len,uint8_t payload_type)
{
    //printf("Payload:%d\n", payload_type);
    if (data_len < 0)
    {
        return NULL;
    }

    char* p_value = new char[data_len];
    memcpy(p_value,p_data,data_len);
    isakmp_payload* p_payload = new isakmp_payload(payload_type, p_value, data_len);
    return p_payload;
}




//打印函数，仅供测试使用
void isakmp_message::display()
{
    printf("  b_nat:%d,  b_direction:%d\n", b_nat, b_direction);
    printf("  ***Header***\n");
    printf("\tinitiator_cookie: ");
    char *p = (char*)&header.initiator_cookie;
    for(int i = 0; i<8; ++i)
    {
        printf("%02X", (unsigned char)p[i]);
    }
    printf("\n\tinitiator_cookie: ");
    p = (char*)&header.responder_cookie;
    for(int i = 0; i<8; ++i)
    {
        printf("%02X", (unsigned char)p[i]);
    }
    printf("\n");
    printf("\tnext_payload: %d\n\tversion: %d.%d\n\texchange_type: %d\n\tflags: 0X%02X\n\tmessage_id: %d\n\tlength: %d\n",
            header.next_payload, header.version >> 4, header.version & 0X0F, header.exchange_type, header.flags, ntohl(header.message_id), ntohl(header.length));
    /*
       char *p = (char*)&header;
       for(int i = 0; (uint64_t)i<sizeof(isakmp_message_header); ++i)
       {
       printf("%02X ", (unsigned char)p[i]);
       if((i+1)%8 == 0)
       {
       printf("\n");
       }
       }
       printf("\n");
       */
    list<isakmp_payload*>::iterator iter = l_payload.begin();
    printf("  ***Payload***\n");
    for(int j=1;iter != l_payload.end(); ++iter , ++j)
    {
        printf("\tPayload #%d#, type: %-4d\n",j, (*iter)->type);
        if((*iter)->type == SECURITY_ASSOCIATION_PAYLOAD)
        {
            security_association_payload* p_s_payload = (security_association_payload*)(*iter);
            printf("\t\tDomain_of_interpretation: %-4d, situation: %-4d\n ",p_s_payload->domain_of_interpretation,p_s_payload->situation);
            list<proposal_payload*>::iterator iter1 = p_s_payload->l_p_payload.begin();
            for(; iter1 != p_s_payload->l_p_payload.end(); ++iter1)
            {
                printf("\t\tProposal_number: %-4d, protocol_id: %-4d, spi_size: %-4d, total_transforms: %-4d\n",(*iter1)->proposal_number, (*iter1)->protocol_id, (*iter1)->spi_size, (*iter1)->total_transforms);
                list<transform_payload*>::iterator iter2 = (*iter1)->l_t_payload.begin();
                for(; iter2 != (*iter1)->l_t_payload.end(); ++iter2)
                {
                    printf("\t\t\tTransform_num: %-4d, transform_id: %-4d\n",(*iter2)->transform_num, (*iter2)->transform_id);
                    list<data_attributes*>::iterator iter3 = (*iter2)->l_attributes.begin();
                    for(; iter3 != (*iter2)->l_attributes.end(); ++iter3)
                    {
                        printf("\t\t\t\tAttribute: Type: %-4d, Length: %-4d, Value: ", (*iter3)->type, (*iter3)->length);
                        for(int k = 0; k<(*iter3)->length; k++)
                        {
                            printf("%02X ",(unsigned char)((*iter3)->p_value)[k]);
                        }
                        printf("\n");
                    }
                }

            }

        }
        else
        {
            printf("\t\tData_length: %d\n\t\tData: ",(*iter)->data_len);
            for(int m = 0; m < (*iter)->data_len; ++m)
            {
                printf("%02X ",(unsigned char)((*iter)->p_data)[m]);
                if((m+1)%16==0 && m+1 < (*iter)->data_len)
                {
                    printf("\n\t\t      ");
                }
            }
            printf("\n");
        }
        //printf("\n");
    }
    printf("\n");
    return;
}


//Summary:  接口消息处理函数，负责组织数据
//Parameters:
//       p_msg: isakmp消息指针
//       p_session: session指针
//Return : 无返回值

void isakmp_output_interface::message_handling(isakmp_message *p_msg, session* p_session)
{
    if(p_msg == NULL || p_session == NULL)
    {
        return;
    }
    //if(p_msg->header.next_payload != SECURITY_ASSOCIATION_PAYLOAD && p_msg->header.next_payload != KEY_EXCHANGE_PAYLOAD && p_msg->header.next_payload != NONCE_PAYLOAD &&p_msg->header.next_payload != IDENTIFICATION_PAYLOAD)
    if(ntohl(p_msg->header.message_id)==1)
    {
        return;
    }
    string str_init((char *)&p_msg->header.initiator_cookie,(char *)&p_msg->header.initiator_cookie+8);
    initiator_cookie = str_init ;
    string str_resp((char *)&p_msg->header.responder_cookie,(char *)&p_msg->header.responder_cookie+8);
    responder_cookie = str_resp ;
    protocol_version = p_msg->header.version;
    exchange_type = p_msg->header.exchange_type;
    b_sa_payload = true;
    b_cookie = true;


    //IP、端口
    if((p_msg->header.responder_cookie != 0 && p_msg->b_direction) || (p_msg->header.responder_cookie == 0 && !p_msg->b_direction))
    {
        server_ip = p_session->srcip;
        client_ip = p_session->dstip;
        server_port = p_session->srcport;
        client_port = p_session->dstport;
    }
    else
    {
        server_ip = p_session->dstip;
        client_ip = p_session->srcip;
        server_port = p_session->dstport;
        client_port = p_session->srcport;
    }

    mac_line_num = p_session-> mac_line_num;
    device_num = p_session-> device_num;

    //方向
    if(direction != 3)
    {
        direction = (p_msg->header.responder_cookie == 0? 1:2);
    }
    //解析载荷
    if(p_msg->l_payload.empty())
    {
        return;
    }
    list<isakmp_payload*>::iterator iter1 = p_msg->l_payload.begin();
    for(;iter1 != p_msg->l_payload.end(); ++iter1)
    {
        if (*iter1 == NULL)
        {
            continue;
        }

        switch((*iter1)->type)
        {
            case SECURITY_ASSOCIATION_PAYLOAD:
                {
                    security_association_payload* p_s_payload = (security_association_payload*)(*iter1);
                    //printf("\t\tDomain_of_interpretation: %-4d, situation: %-4d\n ",p_s_payload->domain_of_interpretation,p_s_payload->situation);
                    if(p_s_payload->l_p_payload.empty())
                    {
                        continue;
                    }
                    /*
                       string str_init((char *)&p_msg->header.initiator_cookie,(char *)&p_msg->header.initiator_cookie+8);
                       initiator_cookie = str_init ;
                       string str_resp((char *)&p_msg->header.responder_cookie,(char *)&p_msg->header.responder_cookie+8);
                       responder_cookie = str_resp ;
                       */
                    list<proposal_payload*>::iterator iter2 = p_s_payload->l_p_payload.begin();
                    for(; iter2 != p_s_payload->l_p_payload.end(); ++iter2)
                    {
                        //printf("\t\tProposal_number: %-4d, protocol_id: %-4d, spi_size: %-4d, total_transforms: %-4d\n",(*iter1)->proposal_number, (*iter1)->protocol_id, (*iter1)->spi_size, (*iter1)->total_transforms);
                        if (*iter2 == NULL)
                        {
                            continue;
                        }
                        if((*iter2)->l_t_payload.empty())
                        {
                            continue;
                        }
                        transform_data_len = (*iter2)->transform_data_len;
                        if((*iter2)->transform_data!=NULL)
                        {
                            string trans_str((*iter2)->transform_data,(*iter2)->transform_data+(*iter2)->transform_data_len);
                            transform_data = trans_str;
                        }
                        list<transform_payload*>::iterator iter3 = (*iter2)->l_t_payload.begin();
                        for(; iter3 != (*iter2)->l_t_payload.end(); ++iter3)
                        {
                            //printf("\t\t\tTransform_num: %-4d, transform_id: %-4d\n",(*iter2)->transform_num, (*iter2)->transform_id);
                            if (*iter3 == NULL)
                            {
                                continue;
                            }
                            if((*iter3)->l_attributes.empty())
                            {
                                continue;
                            }
                            list<data_attributes*>::iterator iter4 = (*iter3)->l_attributes.begin();
                            for(; iter4 != (*iter3)->l_attributes.end(); ++iter4)
                            {
                                if (*iter4 == NULL)
                                {
                                    continue;
                                }
                                switch((*iter4)->type)
                                {
                                    case 1:                 //encryption_algorithm
                                        s_encryption_algorithm.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        break;
                                    case 2:                 //hash_algorithm
                                        s_hash_algorithm.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        break;
                                    case 3:                 //authentication_method
                                        s_authentication_method.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        break;
                                    case 4:                 //group_destription
                                        s_group_destription.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        break;
                                    case 11:                 //group_destription
                                        s_life_type.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        break;
                                    case 12:                 //group_destription
                                        if(exchange_type == 4)
                                        {
                                            s_life_duration.insert(ntohs(*(uint16_t*)((*iter4)->p_value)));
                                        }else if(exchange_type == 2)
                                        {
                                            if(*(uint8_t *)((*iter4)->p_value)==0)
                                            {
                                            s_life_duration.insert(ntohl(*(uint32_t*)((*iter4)->p_value)));
                                            }else
                                            {
                                            s_life_duration.insert(ntohs(*(uint16_t *)((*iter4)->p_value)));
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                /*
                                   printf("\t\t\t\tAttribute: Type: %-4d, Length: %-4d, Value: ", (*iter3)->type, (*iter3)->length);
                                   for(int k = 0; k<(*iter3)->length; k++)
                                   {
                                   printf("%02X ",(unsigned char)((*iter3)->p_value)[k]);
                                   }
                                   printf("\n");
                                   */
                            }
                        }

                    }
                    break;
                }
            case VENDOR_ID_PAYLOAD:
                {
                    if(!b_nat)
                    {
                        if((*iter1)->data_len == 16 && memcmp((*iter1)->p_data, nat_hash,16) == 0)
                        {
                            b_nat = true;
                        }
                    }
                    l_vendor_id_payload.push_back(*iter1);
                    break;
                }
            case KEY_EXCHANGE_PAYLOAD:
                {
                    key_exchange_payload* p_k_payload = (key_exchange_payload*)(*iter1);
                    if(p_k_payload->key_exchange_data!=NULL)
                    {
                        string key_str(p_k_payload->key_exchange_data,p_k_payload->key_exchange_data+p_k_payload->key_exchange_data_length);
                        key_exchange_data = key_str;
                    }
                    break;
                }
            case NONCE_PAYLOAD:
                {
                    nonce_payload* p_n_payload = (nonce_payload*)(*iter1);
                    if(p_n_payload->nonce_data!=NULL)
                    {
                        string nonce_str(p_n_payload->nonce_data,p_n_payload->nonce_data+p_n_payload->nonce_data_length);
                        nonce_data = nonce_str;
                    }
                    break;
                }
            case IDENTIFICATION_PAYLOAD:
                {
                    identification_payload* p_i_payload = (identification_payload*)(*iter1);
                    identification_id_type = p_i_payload->identification_id_type; 
                    if(p_i_payload->identification_data!=NULL&&p_i_payload->identification_id_type==1)
                    {
                        char *ipaddr=NULL;
                        char addr[20];
                        in_addr inaddr;
                        inaddr.s_addr=(unsigned int)(*(uint32_t *)p_i_payload->identification_data);
                        ipaddr=inet_ntoa(inaddr);
                        strcpy(addr,ipaddr);
                        identification_data = addr;
                    }
                    if(p_i_payload->identification_data!=NULL&&p_i_payload->identification_id_type!=1)
                    {
                        string identification_str(p_i_payload->identification_data,p_i_payload->identification_data+p_i_payload->identification_data_length);
                        identification_data = identification_str;
                    }
                    break;
                }
            default:
                break;
        }
    }
    return;
}


