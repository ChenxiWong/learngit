// Last Update:2016-11-16 20:52:06
/**
 * @file isakmp_str.h
 * @brief isakmp Session 定义
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2016-04-15
 */

#ifndef ISAKMP_STR_H
#define ISAKMP_STR_H

#define AGGRE_ISAKMP_BEGIN 0
#define AGGRE_ISAKMP_END 1

#include <session.h>
#include <stdint.h>
#include <string>
#include <list>
#include <set>
using namespace std;


//载荷类型宏定义 RFC2408 P22
#define NONE_PAYLOAD 0
#define SECURITY_ASSOCIATION_PAYLOAD 1
#define PROPOSAL_PAYLOAD 2
#define TRANSFORM_PAYLOAD 3
#define KEY_EXCHANGE_PAYLOAD 4
#define IDENTIFICATION_PAYLOAD 5
#define CERTIFICATE_PAYLOAD 6
#define CERTIFICATE_REQUEST_PAYLOAD 7
#define HASH_PAYLOAD 8
#define SIGNATURE_PAYLOAD 9
#define NONCE_PAYLOAD 10
#define NOTIFICATION_PAYLOAD 11
#define DELETE_PAYLOAD 12
#define VENDOR_ID_PAYLOAD 13
#define NAT_DISCOVERY_PAYLOAD 20
#define NATD_PAYLOAD 130



const char nat_hash[16] = {0x4a,0x13,0x1c,0x81,0x07,0x03,0x58,0x45,0x5c,0x57,0x28,0xf2,0x0e,0x95,0x45,0x2f};
static char NO_NULL[1]={0};

#pragma pack(push, 1)
//ISAKMP消息头  RFC2408 P22
struct isakmp_message_header
{
    uint64_t initiator_cookie;
    uint64_t responder_cookie;
    uint8_t next_payload;
    uint8_t version;
    uint8_t exchange_type;
    uint8_t flags;
    uint32_t message_id;
    uint32_t length;
};
#pragma pack(pop)



//ISAKMP载荷类
class isakmp_payload
{
    public:
        isakmp_payload(){};
        isakmp_payload(uint8_t payload_type, char* p_payload_data, int16_t payload_data_len):type(payload_type),data_len(payload_data_len),p_data(p_payload_data){};
        virtual ~isakmp_payload()
        {
            //printf("Isakmp payload: delelte data!\n");
            if(p_data!=NULL)
            {
                delete [] p_data;
            }
        };
    public:
        uint8_t type;
        int16_t data_len;
        char *p_data;
};


//数据属性类   RFC2408 P26
class data_attributes
{
    public:
        data_attributes(uint16_t data_type, uint16_t data_length,char* p_data_value):type(data_type),length(data_length),p_value(p_data_value){};
        ~data_attributes()
        {
            if(p_value!=NULL)
            {
                delete []p_value;
            }
        };

    public:
        uint16_t type;
        uint16_t length;
        char *p_value;
};



//transform payload类  RFC2408 P30
class transform_payload :public isakmp_payload
{
    public:
        transform_payload():isakmp_payload(TRANSFORM_PAYLOAD, NULL, 0), transform_num(0),transform_id(0){};
        virtual ~transform_payload()
        {
            //printf("Transform payload: delelte data!\n");
            list<data_attributes*>::iterator iter = l_attributes.begin();
            for(; iter != l_attributes.end(); ++iter)
            {
                delete *iter;
            }
            l_attributes.clear();
        };
    public:
        uint8_t transform_num;
        uint8_t transform_id;
        list<data_attributes*> l_attributes;                   //属性链表，存储transform_payload中的各条属性
};


//proposal_payload类  RFC2408 P28
class proposal_payload :public isakmp_payload
{
    public:
        proposal_payload():isakmp_payload(PROPOSAL_PAYLOAD, NULL, 0), proposal_number(0), protocol_id(0), spi_size(0), total_transforms(0), p_spi(NULL),transform_data(NULL){};
        virtual ~proposal_payload()
        {
            //printf("Proposal payload: delelte data!\n");
            if(p_spi!=NULL)
            {
                delete[] p_spi;
            }
            if(transform_data!=NULL)
            {
               delete[] transform_data;
            }
            transform_data = NULL;
            list<transform_payload*>::iterator iter = l_t_payload.begin();
            for(; iter != l_t_payload.end(); ++iter)
            {
                delete *iter;
            }
            l_t_payload.clear();
        };
    public:
        uint8_t proposal_number;
        uint8_t protocol_id;
        uint8_t spi_size;
        uint8_t total_transforms;
        char *p_spi;
        char *transform_data;
        uint16_t transform_data_len;
        list<transform_payload*> l_t_payload;            //transform_payload链表，存储proposal_payload中所有的transform_payload
};

//security_association_payload类  RFC2408 P27
class security_association_payload :public isakmp_payload
{
    public:
        security_association_payload():isakmp_payload(SECURITY_ASSOCIATION_PAYLOAD, NULL, 0), domain_of_interpretation(0), situation(0),p_situation(NULL){};
        virtual ~security_association_payload()
        {
            //printf("Security association payload: delelte data!\n");
            if(p_situation!=NULL)
            {
                delete[] p_situation;
            }
            list<proposal_payload*>::iterator iter = l_p_payload.begin();
            for(; iter != l_p_payload.end(); ++iter)
            {
                delete *iter;
            }
            l_p_payload.clear();
        };
    public:
        uint32_t domain_of_interpretation;
        uint32_t situation;
        char *p_situation;
        list<proposal_payload*> l_p_payload;           //proposal_payload链表，存储security_association_payload中所有的proposal_payload
};
//key_exchange_payload类  RFC2408 P27
class key_exchange_payload :public isakmp_payload
{
    public:
        key_exchange_payload():isakmp_payload(KEY_EXCHANGE_PAYLOAD, NULL, 0), key_exchange_data_length(0), key_exchange_data(NULL){};
        virtual ~key_exchange_payload()
        {
            //printf("key exchange payload: delelte data!\n");
            if(key_exchange_data!=NULL)
            {
                delete[] key_exchange_data;
            }
        };
    public:
        uint16_t key_exchange_data_length;
        char *key_exchange_data;
};
//none_payload类  RFC2408 P27
class nonce_payload :public isakmp_payload
{
    public:
        nonce_payload():isakmp_payload(NONCE_PAYLOAD, NULL, 0), nonce_data_length(0),nonce_data(NULL){};
        virtual ~nonce_payload()
        {
            //printf("Nonce payload: delelte data!\n");
            if(nonce_data!=NULL)
            {
                delete[] nonce_data;
            }
        };
    public:
        uint16_t nonce_data_length;
        char *nonce_data;
};
//Identification_payload类  
class identification_payload :public isakmp_payload
{
    public:
        identification_payload():isakmp_payload(IDENTIFICATION_PAYLOAD, NULL, 0), identification_data_length(0),identification_id_type(0),identification_data(NULL){};
        virtual ~identification_payload()
        {
            //printf("Identification payload: delelte data!\n");
            if(identification_data!=NULL)
            {
                delete[] identification_data;
            }
        };
    public:
        uint32_t identification_data_length;
        uint8_t identification_id_type;
        char *identification_data;
};

//ISAKMP消息类，存储一个ISAKMP数据包中的所有内容
class isakmp_message
{
    public:
        isakmp_message(uint64_t time, bool b_packet_direction):packet_time(time),b_nat(0),b_direction(b_packet_direction)
    {
        l_payload.clear();
    };
        ~isakmp_message()
        {
            list<isakmp_payload*>::iterator iter = l_payload.begin();
            for(;iter != l_payload.end(); ++iter)
            {
                delete *iter;
            }
            l_payload.clear();
        };
        bool data_parse(const char* p_data, int16_t data_len,int& status);          //ISAKMP消息解析函数
    public:
        uint64_t packet_time;       //数据包到达时间
        bool b_nat;                 //是否支持nat-t
        bool b_direction;           //数据包方向：1与session一致，0与session相反
        struct isakmp_message_header header;        //ISAKMP消息头
        list<isakmp_payload*> l_payload;        //ISAKMP载荷链表，存储包中所有的载荷
    public:
        bool payload_encrypted()    //判断载荷是否加密
        {
            return ((header.flags)&(0x01))>0? true:false;
        };
        bool is_ikev2()             //判断协议版本是否是ikev2
        {
            return ((header.version)&(0x20))>0? true:false;
        };
        void display();             //打印数据至屏幕，仅供调试使用
    private:
        bool payload_parse(const char* p_data, int16_t data_len, uint8_t payload_type,uint8_t exchange_type);                                 //载荷解析函数
        security_association_payload* security_association_payload_parse(const char* p_data, int16_t data_len);         //security_association_payload解析函数
        key_exchange_payload* key_exchange_payload_parse(const char* p_data, int16_t data_len);                         //key_exchage_payload解析函数
        nonce_payload* nonce_payload_parse(const char* p_data, int16_t data_len);                                       //none_payload解析函数
        identification_payload* identification_payload_parse(const char* p_data, int16_t data_len,uint8_t exchange_type);         //identification_payload解析函数
        proposal_payload* proposal_payload_parse(const char* p_data, int16_t data_len);                                 //proposal_payload解析函数
        transform_payload* transform_payload_parse(const char* p_data, int16_t data_len);                               //transform_payload解析函数
        isakmp_payload* general_payload_parse(const char* p_data, int16_t data_len,uint8_t payload_type);               //一般载荷解析函数
        //bool key_exchange_payload_parse(const char* p_data, int16_t data_len);
        //bool nonce_payload_parse(const char* p_data, int16_t data_len);
        //bool vendor_id_payload_parse(const char* p_data, int16_t data_len);
        //bool nat_discovery_payload_parse(const char* p_data, int16_t data_len);
};

class isakmp_output_interface
{
    public:
        isakmp_output_interface(){};
        ~isakmp_output_interface()
        {
            s_encryption_algorithm.clear();
            s_hash_algorithm.clear();
            s_group_destription.clear();
            s_authentication_method.clear();
            s_life_type.clear();
            s_life_duration.clear();
            l_vendor_id_payload.clear();
        };
        void init()
        {
            direction = 0;
            initiator_cookie= "";
            responder_cookie= "";
            key_exchange_data="";
            nonce_data="";
            identification_data="";
            protocol_version =0;
            exchange_type = 0;
            identification_id_type=0;
            b_sa_payload = false;
            b_cookie = false;
            b_nat = false;
            transform_data_len = 0;
            transform_data = "";
            s_encryption_algorithm.clear();
            s_hash_algorithm.clear();
            s_group_destription.clear();
            s_authentication_method.clear();
            s_life_type.clear();
            s_life_duration.clear();
            l_vendor_id_payload.clear();
            mac_line_num = "";
            device_num = "";
            dev_no = "";
            layer_type = 0;
            is_ipv4 = 0;
            is_ipv6 = 0;
            is_mpls = 0;
            n_label = 0;
            in_nerlabel = 0;
            other_label = 0;
            proto = 0;
            duration = 0;
            total_payloadbytes = 0;
            total_payloadpackets = 0;
        };
        void message_handling(isakmp_message *p_msg, session* p_session);
    public:
        uint64_t time;
        c_ip server_ip;
        c_ip client_ip;
        string mac_line_num;
        string device_num;
        //add new common header
        string dev_no;
        uint32_t layer_type;
        uint32_t is_ipv4;
        uint32_t is_ipv6;
        uint32_t is_mpls;
        uint32_t n_label;
        uint32_t in_nerlabel;
        uint32_t other_label;
        uint32_t proto;
        double  duration;
        //double ip_ju;
        //double ip_wd;
        uint32_t total_payloadbytes;
        uint32_t total_payloadpackets;

        uint16_t server_port;
        uint16_t client_port;
        uint8_t  direction;
        double communication_rate;
        string initiator_cookie;
        string responder_cookie;
        string key_exchange_data;
        string nonce_data;
        string identification_data;
        uint16_t protocol_version;
        uint8_t  exchange_type;
        uint8_t identification_id_type;
        bool   b_sa_payload;
        bool   b_cookie;
        bool   b_nat;
        uint16_t transform_data_len;
        string transform_data;
        set<uint32_t> s_encryption_algorithm;
        set<uint32_t> s_hash_algorithm;
        set<uint32_t> s_group_destription;
        set<uint32_t> s_authentication_method;
        set<uint32_t> s_life_type;
        set<uint32_t> s_life_duration;
        list<isakmp_payload*> l_vendor_id_payload;
};

class isakmp_session
{
    public:
        uint64_t requst_time;
        uint64_t response_time;
        bool b_nat;
        list<isakmp_message*> *pl_info;         //ISAKMP消息链表，存储所有已解析的ISAKMP消息

        const char *p_data;
        int16_t data_len;
        bool b_pkt_direction;
        uint64_t packet_time;
        int status;
        //isakmp_message *p_msg;

        //bool b_c2s;              //数据包方向判断，是不是C->S
    public:
        void display_isakmp_message_list()      //打印函数，仅供调试使用
        {
            list<isakmp_message*>::iterator iter = pl_info->begin();
            for(int i = 1;iter != pl_info->end(); ++iter, ++i)
            {
                printf("########## Message: %d ##########\n",i);
                (*iter)->display();
            }
        };
};



#endif  /*ISAKMP_STR_H*/
