// Last Update:2016-04-21 10:50:45
/**
 * @file isakmp_plugin.h
 * @brief 
 * @author Zhao Yanbing
 * @version 0.1.00
 * @date 2015-04-15
 */

#ifndef isakmp_PLUGIN_H
#define isakmp_PLUGIN_H
#include <protocol_parse_base_handle.h>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <xml_parse.h>
#include <c_ip.h>
#include "isakmp_str.h"
#include <tcp_recombine.h>
#include <map>

#include <ac_rule.h>
#include <DFI_config_parse.h>

using namespace std;

extern "C"
{
    int get_plugin_id();
    protocol_parse_base_handle * attach(attach_info * p );
};

#define DNUMTOSTR(n,s) \
{ std::stringstream ss; \
    ss<<n; \
    s+=std::string(ss.str()) ;\
    ss.clear(); }

class isakmp_plugin :public protocol_parse_base_handle{
    public:
        isakmp_plugin();
        ~isakmp_plugin();
        virtual void reload();
        virtual bool potocol_identify(session* p_sess, c_packet* p_pack);
        virtual void potocol_sign_judge(session* p_sess, c_packet* p_pack);
        virtual void pococol_parse_handle(session* p_sess);
        virtual void potocol_data_handle(session* p_sess, list<data_interface> * p_list);
        virtual void time_out(session* p_sess,uint64_t check_time);
        virtual void resources_recovery(session* p_sess);


        map <rule_node_offist * , int  >*  feature_rule_map ;
        DFI_conf_parse protocol_identify_string_conf_parse;
        bool b_check_conf ;
        void multimode_isakmp_identity(session* p_session, c_packet* p_packet);

    private:

        void init_isakmp_session(isakmp_session * p_isakmp_session);
        void isakmp_interface_handling(list<data_interface> * p_list);
        uint32_t  isakmp_time_out;          //超时时间，单位s
        int       data_interface_type ;
        xml_parse  xml;
        isakmp_output_interface output_interface;
        //uint64_t begin_time;
        //CAmsg * msg ;
};
static attach_info *  p_attach_info ;
static map <rule_node_offist * , int  >  public_isakmp_feature_rule_map ;
#endif  /*ISAKMP_PLUGIN_H*/
