#!/bin/bash
make clean
make
cp -rf  $NPR_SDK/../plugin/InterPlgin/porocol/isakmp/lib/libisakmp.so  $NPR_ROOT/plugin/InterPlugin/

